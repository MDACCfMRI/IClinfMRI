function Fn_batch_SPM12_InvNor(Input_T1)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright � 2017 The University of Texas MD Anderson Cancer Center
% ||   
% Input_T1='1218807_3DVOLUME.nii';

Dir_spm=which('spm.m');
Dir_spm=fileparts(Dir_spm);

Dir_tmp=which('IClinfMRI.m');
Dir_tmp=fileparts(Dir_tmp);
Dir_tmp=[Dir_tmp filesep 'Template'];

Dir_T1=(pwd); 
%% For Normalization
% ============================================== [READ JOB TEMPLATE] ======
clear C
p_DoS=which('Fn_batchJob_Nor.m');
%// Read lines from input file
fid = fopen(p_DoS, 'r');
C = textscan(fid, '%s', 'Delimiter', '\n');
fclose(fid); C=C{1};

% ============================================ [REPLACE JOB CONTENT] ======
% <source>
clear Ls_RP; Ls_RP={'matlabbatch{1}.spm.tools.oldnorm.estwrite.subj.source'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));
C{Idx}=[ Ls_RP{1} '= {''' Dir_T1 filesep Input_T1 ',1''};' ];

% <resample>
clear Ls_RP; Ls_RP={'matlabbatch{1}.spm.tools.oldnorm.estwrite.subj.resample'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));
C{Idx}=[ Ls_RP{1} '= {''' Dir_T1 filesep Input_T1 ',1''};' ];

% <T1 template>
clear Ls_RP; Ls_RP={'matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.template'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));
C{Idx}=[ Ls_RP{1} '= {''' Dir_spm filesep 'toolbox' filesep 'OldNorm' filesep  'T1.nii,1''};' ];

% ================================================= [WRITE JOB TEMP] ======
p_JOB_Nor=[Dir_T1 filesep 'TEMP_JOB_Nor.m']; 

if (exist(p_JOB_Nor,'file')==2)
    delete (p_JOB_Nor)
end
fid=fopen(p_JOB_Nor,'wt');
[nrows,ncols] = size(C);
for row = 1:nrows
    fprintf(fid, '%s \n',C{row,:});
end
fclose(fid);


%% For Inverse Normalization
% ============================================== [READ JOB TEMPLATE] ======
clear C
p_DoS=which('Fn_batchJob_InvNor.m');
%// Read lines from input file
fid = fopen(p_DoS, 'r');
C = textscan(fid, '%s', 'Delimiter', '\n');
fclose(fid); C=C{1};

% ============================================ [REPLACE JOB CONTENT] ======
% <Transformation Martrix>
clear Ls_RP; Ls_RP={'matlabbatch{1}.spm.util.defs.comp{1}.inv.comp{1}.sn2def.matname'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));
C{Idx}=[ Ls_RP{1} '= {''' Dir_T1 filesep strrep(Input_T1,'.nii','_sn.mat') '''};' ];

% <Inversed space>
clear Ls_RP; Ls_RP={'matlabbatch{1}.spm.util.defs.comp{1}.inv.space'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));
C{Idx}=[ Ls_RP{1} '= {''' Dir_T1 filesep Input_T1 '''};' ];

% <MNI Data for inverse normalization>
clear Ls_RP; Ls_RP={'matlabbatch{1}.spm.util.defs.out{1}.pull.fnames'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));
% C{Idx}=[ Ls_RP{1} '= {''' Dir_tmp filesep 'MNI152_SAreaW_R30.nii''' ...
%                   ';''' Dir_tmp filesep 'MNI152_SAreaB_R24.nii''' ...
%                   ';''' Dir_tmp filesep 'MNI152_T1_2mm_brain.nii''' ...
%     '};' ];

C{Idx}=[ Ls_RP{1} '= {''' Dir_tmp filesep 'MNI152_Meta_LangW.nii''' ...
                  ';''' Dir_tmp filesep 'MNI152_Meta_LangB.nii''' ...
                  ';''' Dir_tmp filesep 'MNI152_T1_2mm_brain.nii''' ...
                  ';''' Dir_tmp filesep 'MNI152_MetaExt_LangW.nii''' ...
                  ';''' Dir_tmp filesep 'MNI152_MetaExt_LangB.nii''' ...
                  ';''' Dir_tmp filesep 'MNI152_LangParcels_n220_LH_Binary.nii''' ...
    '};' ];


% C{Idx}=[ Ls_RP{1} '= {''' Dir_tmp filesep 'MNI152_SAreaW_R30.nii''' ...
%     '};' ];
% ================================================= [WRITE JOB TEMP] ======
p_JOB_InvNor=[Dir_T1 filesep 'TEMP_JOB_InvNor.m']; 
% spm_jobman('run', p_JOB);
if (exist(p_JOB_InvNor,'file')==2)
    delete (p_JOB_InvNor)
end
fid=fopen(p_JOB_InvNor,'wt');
[nrows,ncols] = size(C);
for row = 1:nrows
    fprintf(fid, '%s \n',C{row,:});
end
fclose(fid);

%%
spm_jobman('run', p_JOB_Nor);
spm_jobman('run', p_JOB_InvNor);










