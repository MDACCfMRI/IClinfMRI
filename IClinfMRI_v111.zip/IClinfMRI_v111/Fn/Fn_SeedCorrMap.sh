#!/bin/sh

# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

==========================================================================================
||  Script
||    Fn_SeedCorrMap.sh 
||
||  Aim
||    Conduct Seed-based Peasron Correlation Map
||  Input
||     -i : Time-series 4D Dataset
||     -s : Seed Mask
||     -S : Seed Label
||     -m : Global Mask (Ex. Brain Mask)
||  Input(Option) 
||     -a : "p_T1"
||     -o : Output filename 
||     -M : glm/Pearson (default='glm')  
||     -Z : Convert r to z (default='n') 
||
||  Example
||    Fn_SeedCorrMap.sh -a "T1.nii" -i "input.nii" -s "seed.nii" -m "mask.nii" -o "output.nii"
||    Fn_SeedCorrMap.sh -a "T1.nii" -i "input.nii" -s "seed.nii" -m "mask.nii" -o "output.nii" -Z 'y'
||  
==========================================================================================
Created by Irene Hsu on 2017.03.09 (Bash shell) 
		@ MD Anderson
EOF

exit
}


# ============================================================================[TEST]====="
# Fn_MDAP5_FC.sh -i "${DirOT}/BM004_BN.nii.gz"


# ============================================================================[Help]====="
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="

#echo "Total $argn input arguments"

Opt_numb=0;
while getopts "i:a:s:S:m:o:M:Z:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
    i)
        pIn=$OPTARG
    ;;
    a)
        pT1=$OPTARG
    ;;
    s)
        pSeed=$OPTARG
    ;;
    S)
        Tp_Seed=$OPTARG
    ;;
    m)
        pMsk=$OPTARG
    ;;
    o)
		    pOut=$OPTARG
    ;;
    M)
        Method=$OPTARG
    ;;
    Z)
        r2z=$OPTARG
    ;;
    x)
		    empty=$OPTARG
    ;;
    esac
done

ImExt='nii.gz'
# ImExt='nii'
ImExtOT='nii'
# ===========================================================[Check Input arguments]====="
# if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; echo "|| fslver = [${fslver}]"

DirO="$(dirname "$pOut")"

if [ ${#DirO} -le 3 ]; then
DirO="$(dirname "$pIn")"
fi

if [ -z "${Method}" ]; then
    Method='glm'
fi 

if [ -z "${r2z}" ]; then
    r2z='n'
fi 

if [ -z "${pT1}" ];then 
  pT1="${DirO}/----------"
fi

# if [ -z "${FN_MCRT}" ] || [ -n "${FN_MCRT}" ]; then
# if [ -z "${fOut}" ] ; then
# 	fOut="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_CC.nii.gz";
# else
# 	fOut="$(echo `basename $fOut`)";
# fi

# ============================================================================[Main]====="

#---------------------------------------------------------------------{ START }----------#
# echo "|| "

echo "==================================================================================="
echo "|| Calculating Seed-based Corr. Map >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
echo "||    [ Data   ] =[ $(echo `basename $(ls $pIn)`) ] "
echo "||    [ T1w    ] =[ $(echo `basename $(ls $pT1)`) ] "
echo "||    [ Seed   ] =[ $(echo `basename $(ls $pSeed)`) ] "
echo "||    [ Mask   ] =[ $(echo `basename $(ls $pMsk)`) ] "
echo "||    [ Method ] =[ ${Method} ] "
echo "||    [ r to z ] =[ ${r2z} ] "
# echo "||	(2) ::  [ Output FN  ] =[ ${fOut} ] "
# echo "||	(2) ::  [ Output Dir  ] =[ ${DirO} ] "
# echo "|| "
echo "-----------------------------------------------------------------------------------"
# echo "|| "

if [ -z "${pIn}" ] || [ -z "${pSeed}" ] || [ -z "${pMsk}" ];then 
# if [ -z "${pIn}" ] || [ -z "${pSeed}" ] || [ -z "${Mask}" ] || [ -z "${pOut}" ];then 
echo "|| Not enough Input ! Please Check"
exit 1
fi


# =======================================================================================#
#     { 01. Parameter Setting }
# =======================================================================================#


pSeed_tmp="${DirO}/$(echo `basename $pSeed` | sed 's/.nii.gz//g'| sed 's/.nii//g')_tmp.${ImExt}"
mv ${pSeed} ${pSeed_tmp}
3dcalc -a ${pSeed_tmp} -datum short -expr 'ispositive(a)' -prefix "${pSeed}"

DimIn="$(3dinfo -nijk ${pIn})" # 
DimSeed="$(3dinfo -nijk ${pSeed})" # 

# DimIn="$(echo "$(${fslver}fslinfo ${pIn} | awk 'NR==2{print $2}')*$(${fslver}fslinfo ${pIn} | awk 'NR==3{print $2}')*$(${fslver}fslinfo ${pIn} | awk 'NR==4{print $2}')" | bc)"
# DimSeed="$(echo "$(${fslver}fslinfo ${pSeed} | awk 'NR==2{print $2}')*$(${fslver}fslinfo ${pSeed} | awk 'NR==3{print $2}')*$(${fslver}fslinfo ${pSeed} | awk 'NR==4{print $2}')" | bc)"


if [ "${DimIn}" -ne "${DimSeed}" ]; then
  pTEMP="${DirO}/$(echo `basename $pSeed` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MATACH_RESOLUTION.${ImExt}"
  rm -f ${pTEMP}; 3dresample -master ${pIn} -prefix "${pTEMP}" -inset ${pSeed}
  pSeed=${pTEMP}
fi

#=========================================================================================
#----- oO(^^)Oo ------------------------------------------------------------[ FC Mapping ]

fIn=$(echo `basename $pIn` | sed 's/.nii.gz//g'| sed 's/.nii//g')
fSeed=$(echo `basename $pSeed` | sed 's/.nii.gz//g'| sed 's/.nii//g')
fOut=$(echo `basename $pOut` | sed 's/.nii.gz//g'| sed 's/.nii//g')

pSeedTS="${DirO}/TS_${fIn}__SEED_${fSeed}.txt"
rm -f ${pSeedTS}; 3dmaskave -mask "${pSeed}" -mrange 1 1 -quiet "${pIn}" > "${pSeedTS}"

#--------------------------------------[ Calculate Correlation Coef  ]-(Method A)-------||
if [ "$Method" == "glm" ];then 

    echo "||     Calculate Corr via GLM";echo "|| "

    # pSeedTS="${DirO}/TS_${fIn}__SEED_${fSeed}.txt"
    # rm -f ${pSeedTS};3dmaskave -mask "${pSeed}" -mrange 1 1 -quiet "${p_Nor}" > "${pSeedTS}"
    rm -f ${DirO}/3dDeconvolve.err ${DirO}/3dREMLfit.err ${DirO}/Decon.REML_cmd
    rm ${DirO}/${fOut}_* ${DirO}/${fOut}*
    # <<Produce Design matrix via  3dDeconvolve>>
    3dDeconvolve -jobs 4 -float -polort 1 \
                 -input "${pIn}" -mask "${pMsk}" \
                 -num_stimts 1 \
                 -stim_file 1 "${pSeedTS}" -stim_label 1 'Seed' \
                 -tout -rout -x1D_stop \
                 -fitts "${DirO}/${fOut}_fitt" \
                 -errts "${DirO}/${fOut}_rsdu" \
                 -x1D "${DirO}/${fOut}_design" \
                 -xjpeg "${DirO}/${fOut}_design.jpg"


    # <<Produce GLM result which corrected autocorrelation by Design matrix>>       
    3dREMLfit -matrix "${DirO}/${fOut}_design.xmat.1D" \
              -input "${pIn}" -mask "${pMsk}" \
              -tout -rout -verb -GOFORIT \
              -Rbuck "${DirO}/${fOut}.${ImExt}"

    3dcalc -a ${DirO}/${fOut}.${ImExt}'[4]' -b ${DirO}/${fOut}.${ImExt}'[2]' \
    -expr "ispositive(b)*sqrt(a)-isnegative(b)*sqrt(a)" -prefix ${DirO}/${fOut}_CR

    # <<Change Lable >>
    rm -f "${DirO}/tmp.txt"
    cp "${DirO}/${fOut}_CR+orig.HEAD" "${DirO}/tmp.txt"; rm -f "${DirO}/${fOut}_CR+orig.HEAD"
    sed 's/Seed_R^2/QURT_R^2/' "${DirO}/tmp.txt" > "${DirO}/${fOut}_CR+orig.HEAD"
    3dcalc -a "${DirO}/${fOut}_CR+orig" -b "${pMsk}" -expr 'a*ispositive(b)' -prefix "${DirO}/${fOut}_CR.${ImExt}"
    rm -f ${DirO}/${fOut}_CR+orig*
    rm -f "${DirO}/tmp.txt"


    if [ "${r2z}" = "y" ];then
        pOutZ="${DirO}/${fOut}_CRZ.${ImExt}"
        rm -f ${pOutZ}; 3dcalc -a "${DirO}/${fOut}_CR.${ImExt}" -expr "0.5*log((1+a)/(1-a))" -datum float -prefix "${pOutZ}"
    fi

    if [ -f "${pOutZ}" ];then
      # pOutZT1="${DirO}/${fOut}_CRZ%T1.${ImExt}"
      pOutZT1="${DirO}/${fOut}_CRZ%T1.${ImExtOT}"
      if [ ! -f "${pOutZT1}" ];then
        # echo ">>>>>>>>HERE"
        3dresample -master ${pT1} -rmode Linear -prefix "${pOutZT1}" -inset ${pOutZ}
        rm -f "${DirO}/${fOut}_CR.${ImExt}" "${pOutZ}"
      fi
    fi

    rm -f ${DirO}/${fOut}_design.jpg ${DirO}/${fOut}_design.xmat.1D
    # if [ -f "${DirO}/${fOut}_CR.${ImExt}" ];then
    # echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    # echo "||   Output at `dirname  ${DirO}/${fOut}_CR.nii.gz`"
    # echo "||   ............(R) `basename  ${DirO}/${fOut}_CR.nii.gz`"
    # if [ "${r2z}" = "y" ] && [ -f "${pOutZ}" ];then echo "||   ............(Z) `basename  ${pOutZ}`"; fi


fi
# # --------------------------------------[ Calculate Correlation Coef  ]-(Method B)-------||
# # --------------------------------------[ Calculate Correlation Coef  ]-(Method B)-------||
# # --------------------------------------[ Calculate Correlation Coef  ]-(Method B)-------||
if [ "$Method" == "Pearson" ];then 

    # pSeedTS="${DirO}/TS_${fIn}__SEED_${fSeed}.txt"
    # rm -f ${pSeedTS}; 3dmaskave -mask "${pSeed}" -mrange 1 1 -quiet "${pIn}" > "${pSeedTS}"

    rm -f ${pOut}; 3dfim+ -input "${pIn}" -ideal_file "${pSeedTS}" -out 'Correlation' -fim_thr 0 -mask "${pMsk}" -bucket "${pOut}"

    pOutZ="${DirO}/${fOut}Z.${ImExt}"
    rm -f ${pOutZ};
    if [ "${r2z}" = "y" ];then
        if [ ! -f "${pOutZ}" ];then
          rm -f ${pOutZ}; 3dcalc -a ${pOut} -expr "0.5*log((1+a)/(1-a))" -datum float -prefix "${pOutZ}"
        fi
    fi

    if [ -f "${pOutZ}" ];then
      pOutZT1="${DirO}/${fOut}_CRZ%T1.${ImExtOT}"
      rm -f ${pOutZT1};
      if [ ! -f "${pOutZT1}" ];then
        # echo ">>>>>>>>HERE"
        3dresample -master ${pT1} -rmode Linear -prefix "${pOutZT1}" -inset ${pOutZ}

        if [ -f "${pOutZT1}" ];then
          rm -f "${DirO}/${fOut}_CR.nii.gz" 
          # rm -f "${pOutZ}" 
          rm -f "${pOut}" 
          rm -f ${DirO}/Seed_XYZ*
        fi
      fi
    fi
    # if [ -f "${pOut}" ];then
    # echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    # echo "||   Output at `dirname  ${pOut}`"
    # echo "||   ............(R) `basename  ${pOut}`"
    # if [ "${r2z}" = "y" ] && [ -f "${pOutZ}" ];then echo "||   ............(Z) `basename  ${pOutZ}`"; fi
fi


rm -f ${pSeedTS}; 
rm -f ${pSeed}
rm -f ${DirO}/3dDeconvolve.err ${DirO}/3dREMLfit.err ${DirO}/Decon.REML_cmd



echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

