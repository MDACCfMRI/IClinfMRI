%-----------------------------------------------------------------------
% Job saved on 04-Feb-2018 22:38:44 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6685)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.spatial.normalise.write.subj.def = {'/Volumes/LING128G/Proposal_TestDataP3/P1_DICRCP06/2_T1Segment/y_P1_3DVolumePre.nii'};
matlabbatch{1}.spm.spatial.normalise.write.subj.resample = {
                                                            '/Volumes/LING128G/Proposal_TestDataP3/P1_DICRCP06/P1_Resting.nii,1'
                                                            '/Volumes/LING128G/Proposal_TestDataP3/P1_DICRCP06/P1_2mmFlair.nii,1'
                                                            '/Volumes/LING128G/Proposal_TestDataP3/P1_DICRCP06/P1_3DVolumePre.nii,1'
                                                            };
matlabbatch{1}.spm.spatial.normalise.write.woptions.bb = [-90 -126 -72
                                                          91 91 109];
matlabbatch{1}.spm.spatial.normalise.write.woptions.vox = [2 2 2];
matlabbatch{1}.spm.spatial.normalise.write.woptions.interp = 1;
matlabbatch{1}.spm.spatial.normalise.write.woptions.prefix = 'w';
