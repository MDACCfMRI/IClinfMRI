#!/bin/sh


# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

||  =================={ Usage :: Fn_MDAS3_cvrPrep.sh }====================================
||   
||  [Purpose]:  
||
||  [Usage]: Fn_MDAS3_cvrPrep.sh [OPTIONS]
||       ex: Fn_MDAS3_cvrPrep.sh -t "p_Task" -a "p_T1" -j "p_Jump" -T "TR" -P "PREPIDX"-O "Dir_OT" -F "SDIR"
|| 			  
||
||  [OPTIONS]:
||            -t <p_Task> : The fullpath of the fMRI data for CVR mapping
||            -a <p_T1> : The fullpath of the "T1w" stucture image
||            -j <p_Jump> : The fullpath of the high-resolution EPI
||            -d <p_Diagram> : The fullpath of the task diagram which save with txt file
||            -S <SDIR>   : The Directory of the Function Folder
||
||	[Optional aguments]
||            -T <TR> : The Repetition Time(TR) [Unit: seconds] (default for MDA FAS : -T '2')
||            -P <PREPIDX> : Preprocessing Index [Unit: seconds] (default MDA FAS : -P 'T1;M1;F0;D1;S1')
||            -z <tPattern> : the tpattern of slice timing correction (default : -z 'alt+z')
||            -c <y/n> : when the high resolution EPI is non-avaliable, 
||                       the data will be registered based on its coordinated (default='y')
||            -s <FWHM> : smooth with ?? mm FWHM (default='4')
||            -v <vsize> : Register to T1 with ?? voxel size  (default='2')
||            -O <Dir_OT> : The Directory of output files (default : parent dir of the Task folder)
|| 
||  ======================================================================================
Created by Irene Hsu on 2017.05.01 (Bash shell) @ MD Anderson

EOF
exit
}

# ============================================================================[DEMO]====="
DEMO="X"
if [ "$DEMO" == "O" ]; then

IIDD="P04_P3" # 

DirM="/mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/${IIDD}"
SDIR='/mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn'
p_T1="$(ls ${DirM}/${IIDD}*_3DVOLUME.nii)"

# p_Lesion="$(ls ${DirM}/${IIDD}*_3DVOLUME_Lesion.nii.gz)"
# p_Jump="$(ls ${DirM}/${IIDD}*BOTHHANDS.nii.gz)"

p_Task="$(ls ${DirM}/${IIDD}*_CVR.nii.gz)"
p_Diagram="$(ls ${DirM}/CVR/${IIDD}_RRF_D12_P20.txt)"

# bash ${SDIR}/Fn_MDAS3_cvrPrep.sh -t "$p_Task" -a "$p_T1" -T '2' -S '20 60 100 140 180 220' -D '20' -c 'y' -P 'T0;M1;F0;D1;S1' -F ${SDIR} 

# bash ${SDIR}/Fn_MDAS3_cvrPrep.sh -a "$p_T1" -T '2' -c 'y' -P 'T0;M1;F0;D1;S1' -F ${SDIR} 


TimeStamp="$(date +"D%m%d_T%H%M%S")";p_Status="${DirM}/===(LOG)_${IIDD}_CVR===${TimeStamp}.txt"; rm -f $p_Status

bash ${SDIR}/Fn_MDAS3_cvrPrep.sh -t "$p_Task" -a "$p_T1" -T '3' -d "$p_Diagram" -c 'y' -P 'T0;M1;F0;D1;N1;S1' -S ${SDIR}	 

#bash ${SDIR}/Fn_MDAS3_cvrPrep.sh -t "$p_Task" -a "$p_T1" -T '3' -d "$p_Diagram" -c 'y' -P 'T0;M1;F0;D1;N1;S1' -S ${SDIR} 2>&1 | tee ${p_Status}			 


# Reg_Coord="n"
# TR="2"
# bash ${SDIR}/Fn_MDAS3_cvrPrep.sh -t "$p_Task" -a "$p_T1" -j "${p_Jump}" -T "${TR}" -z "alt+z" -P "T0;M1;F0;D1;S1" -O "/mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/P1218807" -F "/mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn" -c "n" -S "${ONSET}" -D "${DUR}" 


fi

# ============================================================================[Help]====="
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="
argn="${#}" # number of all input arguments
#argcon=${@} # all contents of the input arguments

# echo "Total $argn input arguments"

Opt_numb=0;
while getopts "t:a:j:c:T:d:P:z:s:v:Z:O:S:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
    t)
        p_Task=$OPTARG
    ;;
    a)
        p_T1=$OPTARG
    ;;
    j)
        p_Jump=$OPTARG
    ;;    
    c)
        Reg_Coord=$OPTARG
    ;;
    T)
        TR=$OPTARG
    ;;
    d)
        p_Diagram=$OPTARG
    ;;  
    P)
		PrepIdx=$OPTARG
    ;;
    z)
		tpattern=$OPTARG
    ;; 
    s)
		krnl_Blur=$OPTARG
    ;;  
    v)
		vsize=$OPTARG
    ;;
    Z)
		TH=$OPTARG
    ;;  
    O)
		Dir_OT=$OPTARG
    ;;
    S)
		SDIR=$OPTARG
	;;
    x)
		empty=$OPTARG
    ;;
    esac
done

# =======================================================================================#
# 	  { 00. Check Inputs }
# =======================================================================================#
#if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; # echo "||"; echo "|| fsl verson = [${fslver}]";echo "||"
ImExt='nii.gz'
ImExtOT='nii'
# ----------------------------------------------------------------------------------- [TR]
if [ -z "${TR}" ];then 
	TR=2
fi
# -------------------------------------------------------------------------------- [ONSET]
# if [ -z "${ONSET}" ];then 
# 	ONSET="20 60 100 140 180 220"
# fi
# ----------------------------------------------------------------------------- [DURATION]
# if [ -z "${DUR}" ];then 
# 	DUR="20"
# fi
# -------------------------------------------------------------------- [Preprocessing IDX]
if [ -z "${PrepIdx}" ];then 
	PrepIdx='T1;M1;F0;D0;N0;S1';
fi
# ---------------------------------------------------------- [tpattern for slicing Timing]
if [ -z "${tpattern}" ];then 
	tpattern='alt+z';
fi
# -------------------------------------------------------------------- [Preprocessing IDX]
if [ -z "${Reg_Coord}" ];then 
	Reg_Coord='y';
fi

if [ -z "${krnl_Blur}" ];then 
	krnl_Blur='4';
fi

if [ -z "${vsize}" ];then 
	vsize='2';
fi
# ---------------------------------------------------------------------- [FDR z threshold]
if [ -z "${TH}" ];then 
	TH="1.96";
fi
# --------------------------------------------------------------------- [Check Output Dir]
if [ -z "${Dir_OT}" ];then 
	#Dir_OT=$(pwd)
	if [ -f "${p_Task}" ];then
		Dir_OT=$(dirname "$p_Task")
	elif [ -f "${p_T1}" ];then
		Dir_OT=$(dirname "$p_T1")
	elif [ -f "${p_Jump}" ];then
		Dir_OT=$(dirname "$p_Jump")
	else
		Dir_OT='---'
	fi
fi

if [ -z "${SDIR}" ];then 
	SDIR='---';
# SDIR=$(find $PWD -name 'Fn_MDAS2_rsPrep.sh' | sed 's/\/Fn_MDAS2_rsPrep.sh//g' ); #echo "$SDIR"
# SDIR=$(find $HOME -name 'Fn_MDAP0_Download.sh' | sed 's/\/Fn_MDAP0_Download.sh//g' ); #echo "$SDIR"
fi
# =======================================================================================#
# 	  { 00. Assignment }
# =======================================================================================#
if [ -f "${p_T1}" ];then
	Tp_T1=$(echo `basename $(ls $p_T1)` | cut -d "_" -f2 | sed 's/.nii.gz//g' | sed 's/.nii//g')
else
	Tp_T1="-----"
fi
if [ -f "${p_Task}" ];then

	n_subS=$(grep -o "_" <<< "$(echo `basename ${p_Task}` | sed 's/.nii.gz//g' | sed 's/.nii//g')" | wc -l);
	n_subS=$(echo "$n_subS + 1" | bc)
	ID=$(echo `basename $p_Task` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	TaskN=$(echo $ID | sed 's/.nii.gz//g'| sed 's/.nii//g' | cut -d '_' -f $n_subS)
	PID=$(echo $ID | cut -d '_' -f 1)
	DesignMtx="${PID}_DesignMtx_${TaskN}_SPM" 

	# -------------------------------------------------------------------------- [Creat Dirs]
	Dir_Task="${Dir_OT}/${TaskN}" # Update an new Folder
	Dir_Tasktmp="${Dir_OT}/${TaskN}/Fd_Temp" # Update an new Folder
	Dir_Reg="${Dir_OT}/1_RegMtx" # Update an new Folder
	Dir_Seg="${Dir_OT}/2_T1Segment" # Update an new Folder

	if [ ! -d "${Dir_Task}" ];then mkdir -p "${Dir_Task}"; fi
	if [ ! -d "${Dir_Reg}" ];then mkdir -p "${Dir_Reg}";fi
	if [ ! -d "${Dir_Seg}" ];then mkdir -p "${Dir_Seg}"; fi
	if [ ! -d "${Dir_Tasktmp}" ];then mkdir -p "${Dir_Tasktmp}"; fi
	# --------------------------------------------------------- [Check Output p_Jump & p_Seed]
	if [ -z "${p_T1}" ];then p_T1="${Dir_Reg}/----------";fi
	if [ -z "${p_Jump}" ];then p_Jump="${Dir_Reg}/----------";fi
	if [ -z "${p_T1Msk}" ];then p_T1Msk="${Dir_Reg}/----------";fi

	# ------------------------------------------------------------------- [Namimg RegMtx Name]
	Tp_Task=$(echo `basename $(ls $p_Task)` | cut -d "_" -f2 | sed 's/.nii.gz//g' | sed 's/.nii//g')

	if [ -f "${p_Jump}" ];then 
		Tp_Jump=$(echo `basename $(ls $p_Jump)` | cut -d "_" -f2 | sed 's/.nii.gz//g' | sed 's/.nii//g')
		RegMed="BBR"
		Reg_Coord='n';
		if [ "$(3dinfo -nt ${p_Jump})" -gt "1" ]; then
			p_JumpV01="${Dir_Tasktmp}/$(echo `basename $p_Jump` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V01.${ImExt}"
			if [ ! -f "${p_JumpV01}" ];then
				#fslroi "${p_Jump}" "${p_JumpV01}" 0 1
				3dcalc -a ${p_Jump}'[0]' -expr 'a' -prefix "${p_JumpV01}"
			fi
		elif [ "$(3dinfo -nt ${p_Jump})" -eq "1" ]; then
			p_JumpV01=${p_Jump}
		fi
	else
		if [ "$Reg_Coord" == "y" ]; then
			RegMed="CBR"
			Tp_Jump="Coordinate-Based Resampling"
		else
			RegMed="IBR"
			Tp_Jump="Intensity-Based Registration"
		fi
	fi

# ---------------------------------------------------------------------------------------#
# --------------------------{ Calculate number of substring ';' of the given filename}---#
# ---------------------------------------------------------------------------------------#
	n_ele=$(grep -o ";" <<< "$(echo $PrepIdx)" | wc -l);n_ele=$(echo "$n_ele + 1" | bc) ; 

	for i in `seq 1 $n_ele`
	do
		PREPNm=$(echo $PrepIdx | cut -d ';' -f $i | cut -c 1)
		PREPYN=$(echo $PrepIdx | cut -d ';' -f $i | cut -c 2)
		#echo "Now to  ${PREPNm} = [${PREPYN}]"
		if [ "$PREPNm" = "T" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxT="O" ;  else  IdxT="-";  fi ; fi
		if [ "$PREPNm" = "M" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxM="O" ;  else  IdxM="-";  fi ; fi
		if [ "$PREPNm" = "F" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxF="O" ;  else  IdxF="-";  fi ; fi
		if [ "$PREPNm" = "D" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxD="O" ;  else  IdxD="-";  fi ; fi
		if [ "$PREPNm" = "N" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxN="O" ;  else  IdxN="-";  fi ; fi
		if [ "$PREPNm" = "S" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxS="O" ;  else  IdxS="-";  fi ; fi
	done
	IdxF="-" ; # Unsupport this function yet
fi

# ========================================================================[CheckBox]====="
#=========================================================================================
# ------------------------------------------------------------------------ [(F) Field Map]
# IdxF="-"
# ----------------- [(T) SliceT, (M) MCRT, (F)Field Map, (D) Despike & Detrend,(S) Smooth]
# if [ -f "${p_Task}" ]; then
# IdxT="O"; IdxM="O"; IdxD="O"; IdxS="O"; IdxP="O";IdxV="O"
# else
# IdxT="-"; IdxM="-"; IdxD="-"; IdxS="-"; IdxP="-";IdxV="-"
# fi

# ============================================================================[Main]====="

NOWTIME="$(date +"%m-%d-%Y  %r")"; 
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "  Date : ${NOWTIME}"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| "

BYellow='\033[1;33m';BRed='\033[1;31m';NC='\033[0m'

echo "|| "
echo "==========================={ Information Fn_MDAS3_cvrPrep.sh}====================== "
echo "|| "

if [ ! -d "${SDIR}" ];then 
 echo -e "||	(0) ::  [ Script Dir] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo "||	(0) ::  [ Script Dir] =[ ${SDIR} ] "
fi

if [ ! -f "${p_Task}" ];then 
  echo -e "||	(1) ::  [ Task Data | TR (s)] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo  "||	(1) ::  [ Task Data | TR (s)] =[ `basename $p_Task` (${Tp_Task})| TR= ${TR} (s) ] "
fi


if [ ! -f "${p_Diagram}" ];then 
  echo -e "||	(1) ::  [ Diagram           ] =[ ${BRed}NOT EXIST${NC} ] "
else
	IRF="$(echo `basename $p_Diagram` | sed 's/.txt//g' | sed 's/.xmat.1D//g' | cut -d '_' -f 1)"
	DelayTime="$(echo `basename $p_Diagram` | sed 's/.txt//g' | sed 's/.xmat.1D//g' | cut -d '_' -f 7)"
	echo  "||	(2) ::  [ Diagram           ] =[ `basename $p_Diagram` | Delay=${DelayTime} (s)] "
fi

if [ ! -f "${p_T1}" ];then 
  echo -e "||	(4) ::  [ T1 Anatomy        ] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo  "||	(4) ::  [ T1 Anatomy        ] =[ $(echo `basename $(ls $p_T1)`)  (${Tp_T1})] "
fi

if [ -f "${p_Task}" ];then 
	echo "||	(5) ::  [ Jumping  (${RegMed})    ] =[ $(echo `basename  $p_Jump`)  (${Tp_Jump})] "
fi

echo "||	(*) ::  [ Output Dir        ] =[ ${Dir_OT} ] "
echo "||	-------------------------------------------------------------------------- "

if [ ! -f "${p_Task}" ] || [ ! -f "${p_T1}" ] || [ ! -d "${SDIR}" ];then
    echo "|| ";echo -e ">>>>>>>>>>>>>>>>>>>> ${BRed}Lask of Files, Please Check !! ${NC} >>>>>>>>>>>>>>>>>>>>>>>>>>>>>";echo "|| "
    exit 1
else
	echo "|| ";echo "||	>> EXECUTING >>> ";echo "|| "
fi

echo "|| >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
echo "||	>>> [${IdxT}] (T) Slice Timing  (tpattern = $tpattern)    "
echo "||	>>> [${IdxM}] (M) MotionCRT & Register to T1 with voxel size of ${vsize} mm  "
echo "||	>>> [${IdxF}] (F) FiledMapCRT       "
echo "||	>>> [${IdxD}] (D) Despike & Detrend   " 
echo "||	>>> [${IdxN}] (N) Regressout Motion Effect   " 
echo "||	>>> [${IdxS}] (S) Smooth with ${krnl_Blur} mm FWHM "								
echo "================================================================================== "
echo "|| "


if [ ! -f "${p_Task}" ] || [ ! -f "${p_T1}" ] || [ ! -f "${p_Diagram}" ]; then
    echo "|| Lask Files, Please Check !!!"
    exit 1
fi

#-----------------------------------------------------------------{ START: T1 }----------#
if [ -f "${p_T1}" ];then
	cp $p_T1 ${Dir_Reg}
#if [ ! -f "${p_NReg}" ] && [ -f "${p_T1}" ];then
	fT1="$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g' )";

	if [ ! -f "${Dir_Seg}/${fT1}.nii" ];then 
		3dcalc -a "${p_T1}" -expr 'a' -prefix "${Dir_Seg}/${fT1}.nii"
		# cp $p_T1 "${Dir_Seg}/${fT1}.${ImExt}"
		# gzip -d "${Dir_Seg}/${fT1}.${ImExt}"
	fi

	if [ ! -f "${Dir_Seg}/c1${fT1}.nii" ];then 
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) SPM Segmentation >>>>>>>>>>>>>> " 
		echo "||	"
		matlab -nodisplay -r "addpath('$SDIR');cd('${Dir_Seg}');Fn_batch_SPM12_Segment('${fT1}.nii');quit;"; stty echo
	else
		echo "||	(*) T1 Segmentation   | Data Existence (O) SPM Segmentation >>>>>>>>>>>>>> " 

	fi

	#-----------------------------------------------------[ Assign Filenames ]----------||
	p_T1_MskHead="${Dir_Seg}/${fT1}_Msk_Head.${ImExt}"
	p_T1_MskBrn="${Dir_Seg}/${fT1}_Msk_Brain.${ImExt}"
	p_T1_Brn="${Dir_Seg}/${fT1}_Brain.${ImExt}"
	p_T1_MskWM="${Dir_Seg}/${fT1}_Msk_WM.${ImExt}"
	p_T1_MskCSF="${Dir_Seg}/${fT1}_Msk_CSF.${ImExt}"
	p_T1_MskAFNI="${Dir_Seg}/${fT1}_aMsk.${ImExt}"

	# Create a rough T1 Mask by afni
	if [ ! -f "${p_T1_MskAFNI}" ];then 
		rm -f "${p_T1_MskAFNI}"
		3dAutomask -dilate 1 -prefix "${p_T1_MskAFNI}" "${p_T1}"
	fi
	#-----------------------------------------------------[ Create Head Mask ]----------||
	if [ ! -f "${p_T1_MskHead}" ];then 
		echo "||	" 
		echo "||	(*) T1 Segmentation   | Data Existence (X) Create Head Mask >>>>>>>>>>>>>> " 		
		echo "||	"

		Type="Head"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}"; rm -f "${p_Tmp}" "${p_T1_MskHead}"
		3dcalc -a "${Dir_Seg}/c1${fT1}.nii" -b "${Dir_Seg}/c2${fT1}.nii" -c "${Dir_Seg}/c3${fT1}.nii" -d "${Dir_Seg}/c4${fT1}.nii" -e "${Dir_Seg}/c5${fT1}.nii" \
			   -expr 'ispositive(a+b+c+d+e-0.8)' -prefix "${p_Tmp}" -datum float
		3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskHead}" -fill_holes -fill_dirs xy -dilate_input 1 -3;rm -f "${p_Tmp}"
		3dmerge -dxyz=1 -1clust 1 20 -prefix "${p_Tmp}" "${p_T1_MskHead}"; rm -f "${p_T1_MskHead}"
		#mv "${p_Tmp}" "${p_T1_MskHead}"
		#${fslver}fslmaths "${p_T1_MskAFNI}" -mul "${p_Tmp}" "${p_T1_MskHead}"; rm -f "${p_Tmp}"
		3dcalc -a "${p_T1_MskAFNI}" -b "${p_Tmp}" -expr 'ispositive(a)*ispositive(b)' -prefix "${p_T1_MskHead}";rm -f "${p_Tmp}"


	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Create Head Mask >>>>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_MskHead}`"
		
	fi

	#-----------------------------------------------------[ Create Brain Mask ]----------||
	if [ ! -f "${p_T1_MskBrn}" ];then  
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) Create Brain Mask >>>>>>>>>>>>> " 
		echo "||	"
		Type="Brain"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}";
		3dcalc -a "${Dir_Seg}/c1${fT1}.nii" -b "${Dir_Seg}/c2${fT1}.nii" -c "${Dir_Seg}/c3${fT1}.nii" -expr 'ispositive(a+b+c-0.3)' -prefix "${p_Tmp}" 
		3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskBrn}" -fill_holes -fill_dirs xy -dilate_input 2 -3; rm -f ${p_Tmp}
		3dmerge -dxyz=1 -1clust 1 20 -prefix "${p_Tmp}" "${p_T1_MskBrn}"; rm -f "${p_T1_MskBrn}"
		# mv "${p_Tmp}" "${p_T1_MskBrn}"; rm -f "${p_Tmp}"
		#${fslver}fslmaths "${p_T1_MskAFNI}" -mul "${p_Tmp}" "${p_T1_MskBrn}"; rm -f "${p_Tmp}"
		3dcalc -a "${p_T1_MskAFNI}" -b "${p_Tmp}" -expr 'ispositive(a)*ispositive(b)' -prefix "${p_T1_MskBrn}";rm -f "${p_Tmp}"
	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Create Brain Mask >>>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_MskBrn}`"
		
	fi
	#-----------------------------------------------------[ Create T1 Brain  ]-----------||

	if [ ! -f "${p_T1_Brn}" ];then 
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) Mask out Non-Brain >>>>>>>>>>>> "
		echo "||	"
		#rm -f ${p_T1_Brn}
		3dcalc -a "${p_T1}" -b "${p_T1_MskBrn}" -expr 'a*b' -prefix "${p_T1_Brn}"
	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Mask out Non-Brain >>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_Brn}`"
		
	fi
fi
# echo "================================================================================== "
echo "||"
echo "---------------------------------------------------------------------------------- "
echo "||"
#---------------------------------[ Downsample T1 Resolution ]----------------------------------||
#-----------------------------------------------------------------------------------------------||

VPVAssign="$(echo ${vsize}*${vsize}*${vsize} | bc)"
IDX_Resample='n'
if [ -f "${p_T1}" ];then
	p_T1_ds="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ds.${ImExt}"; 
	p_T1Msk_ds="${Dir_Reg}/$(echo `basename $p_T1_MskBrn` | sed 's/.nii.gz//g'| sed 's/.nii//g')_ds.${ImExt}"; 
	#DimIn="$(echo "$(${fslver}fslinfo ${p_T1_ds} | awk 'NR==2{print $2}')*$(${fslver}fslinfo ${p_T1_ds} | awk 'NR==3{print $2}')*$(${fslver}fslinfo ${p_T1_ds} | awk 'NR==4{print $2}')" | bc)"
	# DimIn="$(3dinfo -nijk ${p_T1_ds})"
	
	if [ -f "${p_T1_ds}" ];then 
		VPVIn="$(3dinfo -voxvol ${p_T1_ds})" # 
		if [ "$(echo "$VPVIn != $VPVAssign" | bc -l)" -eq 1 ]; then IDX_Resample='y';rm -f ${p_T1_ds};fi
	fi
	if [ ! -f "${p_T1_ds}" ]; then
		3dresample -dxyz ${vsize} ${vsize} ${vsize} -rmode Linear -prefix ${p_T1_ds} -inset ${p_T1}
	fi

	if [ -f "${p_T1Msk_ds}" ];then 
		VPVIn="$(3dinfo -voxvol ${p_T1Msk_ds})" # 
		if [ "$(echo "$VPVIn != $VPVAssign" | bc -l)" -eq 1 ]; then IDX_Resample='y';rm -f ${p_T1Msk_ds};fi
	fi
	if [ ! -f "${p_T1Msk_ds}" ]; then
		3dresample -dxyz ${vsize} ${vsize} ${vsize} -rmode Linear -prefix ${p_T1Msk_ds} -inset ${p_T1_MskBrn}
	fi
fi


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
p_In="${p_Task}" #(Renew Dataset)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
# =========================================================================================
# ----- oO(^^)Oo ----------------------------------------------------------[ Slice Timing ]
# echo "||	>>> [${IdxT}] (T) Slice Timing      | "
# echo "||	>>> [${IdxM}] (M) MotionCRT         | "
# echo "||	>>> [${IdxF}] (F) FiledMapCRT       | " 
# echo "||	>>> [${IdxD}] (D) Despike & Detrend | " 
# echo "||	>>> [${IdxS}] (S) Smooth            | "	

# echo ">>>>> 477"
if [ "$IdxT" == "O" ]; then
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	if [ "${#ID}" -eq "${#FN_In}" ];then
		p_Tshift="${Dir_Tasktmp}/${FN_In}_T.${ImExt}";
	else
		p_Tshift="${Dir_Tasktmp}/${FN_In}T.${ImExt}";
	fi
	
	if [ ! -f "${p_Tshift}" ];then
		echo "||	" 	
		echo "||	(T) Slice Timing      | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> " 	
		echo "||	"
		rm -f ${p_Tshift}
		# 3dTshift -TR ${TR} -slice 0 -tpattern 'alt+z' -prefix ${p_Tshift} ${p_In}
		3dTshift -TR ${TR} -slice 0 -tpattern ${tpattern} -prefix ${p_Tshift} ${p_In}
	else
		echo "||	(T) Slice Timing      | Data Existence (O) Named by `basename  ${p_Tshift}`   " 
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_Tshift}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	p_Tshift="${Dir_Tasktmp}/----------"
fi
# echo ">>>>> 502"
# #=========================================================================================
# #----- oO(^^)Oo --------------------------[ Motion Correction :: PART I. Extract Base Img]

if [ "$IdxM" == "O" ]; then
	# <<Make Dir>>
	Dir_MCRT="${Dir_Task}/Fd_MCRT_${PID}"
	if [ ! -d "${Dir_MCRT}" ];then mkdir -p "${Dir_MCRT}";fi
	# <<Assign FN>>
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	if [ "${#ID}" -eq "${#FN_In}" ];then
		p_MCRT="${Dir_Tasktmp}/${FN_In}_M.${ImExt}";
	else
		p_MCRT="${Dir_Tasktmp}/${FN_In}M.${ImExt}";
	fi

	if [ ! -f "${p_MCRT}" ];then
		echo "||	" 	
		echo "||	(M) Motion Correction | Data Existence (X) Conducting !!! >>>>>>>>>>PART I" 
		echo "||	........................................................(Extract Base Img)" 
		echo "||	"
	fi

	#<<Examine each imaging run for outliers>>
	p_MCRT_outlier="${Dir_MCRT}/$(echo `basename $p_MCRT` | sed 's/.nii.gz//g' | sed 's/.nii//g')_outlier.txt";
	if [ ! -f "${p_MCRT_outlier}" ];then
		rm -f ${p_MCRT_outlier}; 3dToutcount -automask -range "${p_In}" > ${p_MCRT_outlier}
	fi
	base=`cat ${p_MCRT_outlier} | perl -0777an -F"\n" -e '$i=0; $small=999999; map {/\s*(\d+)/; if ($small > $1) {$small = $1; $ind=$i}; $i++;} @F; print $ind'`
else
	base='0'
fi

if [ "$(3dinfo -nt ${p_In})" -gt "1" ]; then
	# p_TaskV01="${Dir_Tasktmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V`printf "%03d" ${base}`.nii.gz"
	# if [ ! -f "${p_TaskV01}" ];then 3dcalc -a ${p_In}"[${base}]" -expr 'a' -prefix "${p_TaskV01}"; fi
	if [ "$IdxM" == "O" ]; then
		p_TaskV01="${Dir_MCRT}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V`printf "%03d" ${base}`.${ImExt}"
	else
		p_TaskV01="${Dir_Tasktmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V`printf "%03d" ${base}`.${ImExt}"
	fi
	if [ ! -f "${p_TaskV01}" ];then 3dcalc -a ${p_In}"[${base}]" -expr 'a' -prefix "${p_TaskV01}"; fi

fi

#-------------------------------------------------------------------------------------
# CoRegister Segments to TASK Space
#-------------------------------------------------------------------------------------
# RegMtx_task2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_task2anat_${Tp_Task}_2_${Tp_T1}.mat"; 
# RegMtx_anat2task="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2task_${Tp_T1}_2_${Tp_Task}.mat";  
RegMtx_task2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_task2anat_${Tp_Task}_2_${Tp_T1}"; 
RegMtx_anat2task="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2task_${Tp_T1}_2_${Tp_Task}";  

#-------------------------------------------------------------------------------------------||
#--------------------------------------------[ IBR Registration : TASK to ANAT  ]-----------||
# if [ ! -f "${p_Jump}" ];then 
# 	if [ ! -f "${RegMtx_task2anat}" ];then 
# 		echo "||	"	
# 		echo "||	(R) Registration      | REGISTRATION(${RegMed}) Task >> Anatomy Data >>>>>>>>>>> "	
# 		echo "||	"
# 		flirt -ref ${p_T1} -in ${p_TaskV01} -cost normmi -searchcost normmi -dof 6 -omat "${RegMtx_task2anat}"
# 	else
# 		echo "||	(R) Registration      | REGISTRATION(${RegMed}) Task >> Anatomy Data  (Exist) .. "
# 	fi

# fi

#-------------------------------------------------------------------------------------------||
#--------------------------------------------[ BBR Registration : TASK to ANAT  ]-----------||
#-------------------------------------------------------------------------------------------||
if [ -f "${p_Jump}" ];then 
	cp $p_Jump ${Dir_Reg}
	cp $p_JumpV01 ${Dir_Reg}
#--------------------------------------------[ BBR Registration : TASK to JUMP  ]-----------||
	RegMtx_task2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_task2jump_${Tp_Task}_2_${Tp_Jump}"; 
	RegMtx_jump2task="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2task_${Tp_Jump}_2_${Tp_Task}"; 
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(01)  | REGISTRATION(BBR) [Task >> Jump -- ----] 
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_task2jump}.1D" ];then 
		echo "||"	
		echo "||	(R) Registration(01)  | REGISTRATION(${RegMed}) [Task >> Jump -- ----]>>>>>>>>>> "	
		echo "||	"
		Des="Jump";pOut="${Dir_Reg}/$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${Des}.${ImExt}";

		cd $Dir_Reg
		rm -f "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*
		rm -f "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D"
		rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D"
		Des="Jump";pOut="${Dir_Reg}/$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${Des}.${ImExt}"; 
		align_epi_anat.py -dset2to1 -dset2 ${p_TaskV01} -dset1 ${p_JumpV01} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
		rm -f ${pOut}; 3dAFNItoNIFTI -prefix "${pOut}" "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig"

		rm -f "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*
		mv "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_task2jump}.1D"
	else
		echo "||"
		echo "||	(R) Registration(01)  | REGISTRATION(${RegMed}) [Task >> Jump -- ----] ..(Exist) "
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(02)  | REGISTRATION(BBR) [Task << Jump -- ----] 
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_jump2task}.1D" ];then 
		echo "||	" 		
		echo "||	(R) Registration(02)  | REGISTRATION(${RegMed}) [Task << Jump -- ----] >>>>>>>>> "
		echo "||	"		
		# convert_xfm -inverse "${RegMtx_task2jump}" -omat "${RegMtx_jump2task}"
		mv "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_jump2task}.1D"
	else
		echo "||	" 
		echo "||	(R) Registration(02)  | REGISTRATION(${RegMed}) [Task << Jump -- ----] ..(Exist) "
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(03)  | REGISTRATION(BBR) [---- -- Jump >> Anat] 
#-------------------------------------------------------------------------------------------||
	# RegMtx_jump2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2anat_${Tp_Jump}_2_${Tp_T1}"; # Updata ".mat" later
	# RegMtx_anat2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2jump_${Tp_T1}_2_${Tp_Jump}.mat"; 

	RegMtx_jump2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2anat_${Tp_Jump}_2_${Tp_T1}"; 
	RegMtx_anat2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2jump_${Tp_T1}_2_${Tp_Jump}"; 
	
	if [ ! -f "${RegMtx_jump2anat}.1D" ];then 
		echo "||	"	
		echo "||	(R) Registration(03)  | REGISTRATION(${RegMed}) [---- -- Jump >> Anat] ......... "
		echo "||	"
		# epi_reg --epi="${p_JumpV01}" --t1="${p_T1}" --t1brain="${p_T1_Brn}" --out="${RegMtx_jump2anat}"
		rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
		rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D"
		rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
		rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig".*
		rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D"

		rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
		rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig".*
		rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D"



		CMDis="$(@Center_Distance -dset ${p_T1_Brn} ${p_JumpV01})"
		#CMDis="0" # no_move
		#CMDis="20" # big_move
		CMDis="40" # giant_move
		#CMDis="60" # ginormous_move
		echo "||"; 
		echo "|| Anat = [${p_T1_Brn}]"; 
		echo "|| EPI  = [${p_JumpV01}]"; 
		echo "|| CMDis= [${CMDis}]";

		if [ `echo "${CMDis} > 5" | bc` -eq 1 ] && [ `echo "${CMDis} <= 20" | bc` -eq 1 ]; then
			echo "|| CMDis level = [big_move]";echo "||"
			align_epi_anat.py -anat2epi -epi2anat -big_move -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		elif [ `echo "${CMDis} > 20" | bc` -eq 1 ] && [ `echo "${CMDis} <= 45" | bc` -eq 1 ]; then
			echo "|| CMDis level = [giant_move]";echo "||"
			align_epi_anat.py -anat2epi -epi2anat -giant_move -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		elif [ `echo "${CMDis} > 46" | bc` -eq 1 ]; then
			echo "|| CMDis level = [ginormous_move]";echo "||"
			align_epi_anat.py -anat2epi -epi2anat -ginormous_move -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		else
			echo "|| CMDis level = [normal]";echo "||"
			align_epi_anat.py -anat2epi -epi2anat -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -anat_has_skull yes -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		fi
		#align_epi_anat.py -anat2epi -epi2anat -anat ${p_T1} -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		#align_epi_anat.py -anat2epi -epi2anat -anat ${p_T1} -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip -giant_move 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
			# shift_only         *OR* sho =  3 parameters
			# shift_rotate       *OR* shr =  6 parameters
			# shift_rotate_scale *OR* srs =  9 parameters
			# affine_general     *OR* aff = 12 parameters

		mv "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_jump2anat}.1D"
		
		Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}";
		# mv ${RegMtx_jump2anat}.nii.gz ${pOut}
		# flirt -ref "${p_T1}" -in "${p_Jump}" -applyxfm -init "${Tr_jump2t1}" -interp "sinc" -out "${pOut}"
		# RegMtx_jump2anat="$(ls ${RegMtx_jump2anat}.mat)" # Update 
		rm -f ${pOut}; 3dAllineate -base ${p_T1} -input ${p_JumpV01} -final wsinc5 -1Dmatrix_apply "${RegMtx_jump2anat}.1D" -prefix ${pOut}
		
		if [ -f "${pOut}" ];then 
			rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
			rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
			rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
	    fi

	else
		# RegMtx_jump2anat="$(ls ${RegMtx_jump2anat}.mat)" 
		# RegMtx_jump2anat="$(ls ${RegMtx_jump2anat}.1D)" 
		echo "||	" 
		echo "||	(R) Registration(03)  | REGISTRATION(${RegMed}) [---- -- Jump >> Anat] ..(Exist) "
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(04)  | REGISTRATION(BBR) [---- -- Jump << Anat] 
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_anat2jump}.1D" ];then 
		echo "||	"	
		echo "||	(R) Registration(04)  | REGISTRATION(${RegMed}) ---- -- [Jump << Anat] ......... "	
		echo "||	"
		# convert_xfm -inverse "${RegMtx_jump2anat}" -omat "${RegMtx_anat2jump}"
		if [ -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" ];then 
			mv "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_anat2jump}.1D"
		fi

		if [ -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" ];then 
			mv "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_anat2jump}.1D"
		fi
	else
		echo "||	" 
		echo "||	(R) Registration(04)  | REGISTRATION(${RegMed}) [---- -- Jump << Anat] ..(Exist) "	
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(05)  | REGISTRATION(BBR) [Task -- Jump -> Anat] 
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_task2anat}.1D" ];then 
		echo "||	"	
		echo "||	(R) Registration(05)  | REGISTRATION(${RegMed}) [Task -- Jump -> Anat] ......... "
		echo "||	"
		# convert_xfm -omat "${RegMtx_task2anat}" -concat "${RegMtx_jump2anat}" "${RegMtx_task2jump}"
		#cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" -I "${RegMtx_task2jump}.1D" > "${RegMtx_task2anat}.1D"


		if [ -f "${RegMtx_jump2anat}.1D" ] && [ -f "${RegMtx_task2jump}.1D" ];then 
			cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" "${RegMtx_task2jump}.1D" > "${RegMtx_task2anat}.1D"
		else
			if [ ! -f "${RegMtx_jump2anat}.1D" ];then 
				echo "||	"	
				echo "||	(R) Registration(05)  | lack  ${RegMtx_jump2anat}.1D"
				echo "||	"
			fi
			if [ ! -f "${RegMtx_task2jump}.1D"  ];then 
				echo "||	"	
				echo "||	(R) Registration(05)  | lack  ${RegMtx_jump2anat}.1D"
				echo "||	"
			fi
		fi

		
	else
		echo "||	"
		echo "||	(R) Registration(05)  | REGISTRATION(${RegMed}) [Task -- Jump -> Anat] ..(Exist) "
		echo "||	"
	fi
	Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}";
	if [ ! -f "${pOut}" ] && [ -f "${RegMtx_task2anat}.1D" ];then 
		3dAllineate -base ${p_T1} -input ${p_TaskV01} -final wsinc5 -1Dmatrix_apply "${RegMtx_task2anat}.1D" -prefix ${pOut}
		echo "|| "
		echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		echo "|| ...........`dirname  ${pOut}`"
		echo "|| .................`basename  $(ls ${pOut})`"
		echo "|| ---------------------------------------------------------------------------------"
	fi
fi

#-------------------------------------------------------------------------------------------||
#----------------------------------------[ IBR/CBR Registration : TASK to ANAT  ]-----------||
#-------------------------------------------------------------------------------------------||
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(01)  | REGISTRATION(CRT) 
#-------------------------------------------------------------------------------------------||
if [ ! -f "${p_Jump}" ];then 
	echo "||"	
	echo "||	(R) Registration(01)  | REGISTRATION(${RegMed}) [Task >> Anat -- ----]>>>>>>>>>> "	
	echo "||	"
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(01)  | REGISTRATION(CBR) Coordinate-Based Registration
#-------------------------------------------------------------------------------------------||	

	if [ "$Reg_Coord" == "y" ]; then
		Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"; 
		if [ ! -f "${pOut}" ];then 
			3dresample -master ${p_T1} -rmode Linear -prefix ${pOut} -inset ${p_TaskV01}
		fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(01)  | REGISTRATION(IBR) Intensity-Based Registration
#-------------------------------------------------------------------------------------------||	
	else	
		if [ ! -f "${RegMtx_task2anat}.1D" ];then 
			cp ${p_TaskV01} ${Dir_Reg}
			cd $Dir_Reg
			rm -f "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*
			rm -f "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D"
			
			CMDis="$(@Center_Distance -dset ${p_T1_Brn} ${p_TaskV01})"
			#CMDis="0" # big_move
			#CMDis="20" # big_move
			CMDis="40" # giant_move
			#CMDis="60" # ginormous_move
			echo "||"; 
			echo "|| Anat = [${p_T1_Brn}]"; 
			echo "|| EPI  = [${p_TaskV01}]"; 
			echo "|| CMDis= [${CMDis}]";

			if [ `echo "${CMDis} > 5" | bc` -eq 1 ] && [ `echo "${CMDis} <= 20" | bc` -eq 1 ]; then
				echo "|| CMDis level = [big_move]";echo "||"
				align_epi_anat.py -dset2to1 -dset1to2 -big_move -dset2 ${p_TaskV01} -dset1 ${p_T1_Brn} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
			elif [ `echo "${CMDis} > 20" | bc` -eq 1 ] && [ `echo "${CMDis} <= 45" | bc` -eq 1 ]; then
				echo "|| CMDis level = [giant_move]";echo "||"
				align_epi_anat.py -dset2to1 -dset1to2 -giant_move -dset2 ${p_TaskV01} -dset1 ${p_T1_Brn} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
			elif [ `echo "${CMDis} > 46" | bc` -eq 1 ]; then
				echo "|| CMDis level = [ginormous_move]";echo "||"
				align_epi_anat.py -dset2to1 -dset1to2 -ginormous_move -dset2 ${p_TaskV01} -dset1 ${p_T1_Brn} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
			else
				echo "|| CMDis level = [normal]";echo "||"
				align_epi_anat.py -dset2to1 -dset1to2 -dset2 ${p_TaskV01} -dset1 ${p_T1_Brn} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
			fi

			mv "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_task2anat}.1D"
			mv "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_anat2task}.1D"

			Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"; 
			rm -f ${pOut}; 3dAllineate -base ${p_T1} -input ${p_TaskV01} -final wsinc5 -1Dmatrix_apply "${RegMtx_task2anat}.1D" -prefix ${pOut}
			#3dAFNItoNIFTI -prefix "${pOut}" "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig"
			Des="${Tp_Task}";pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')%{$RegMed}_${Des}.${ImExt}"; 
			rm -f ${pOut}; 3dAllineate -base ${p_TaskV01} -input ${p_T1} -final wsinc5 -1Dmatrix_apply "${RegMtx_anat2task}.1D" -prefix ${pOut}

			rm -f "$(echo `basename $p_TaskV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*		
		fi
	fi
fi

if [ -f "${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig.HEAD" ];then 
	pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns.${ImExt}"; 
	3dAFNItoNIFTI -prefix "${pOut}" "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig"
fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(06)  | REGISTRATION(BBR) [Task <- Jump -- Anat] 
#-------------------------------------------------------------------------------------------||
if [ -f "${p_Jump}" ];then 
	if [ ! -f "${RegMtx_anat2task}.1D" ];then 
		echo "||	"	
		echo "||	(R) Registration(06)  | REGISTRATION(${RegMed}) Anatomy >> Task Data >>>>>>>>>>> "	
		echo "||	"
		cat_matvec -ONELINE "${RegMtx_jump2task}.1D" "${RegMtx_anat2jump}.1D" > "${RegMtx_anat2task}.1D"
		Des="$Tp_Task";pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}";
		rm -f ${pOut}; 3dAllineate -base ${p_TaskV01} -input ${p_T1} -final wsinc5 -1Dmatrix_apply "${RegMtx_anat2task}.1D" -prefix ${pOut}
	else
		echo "||	" 
		echo "||	(R) Registration(06)  | REGISTRATION(${RegMed}) [Task <- Jump -- Anat] ..(Exist) "
		echo "||	" 
	fi
fi


# #=========================================================================================
# #----- oO(^^)Oo -------------------------------------------[ Motion Correction :: PART II]

if [ "$IdxM" == "O" ]; then
	p_MCRT_RegMtx="${Dir_MCRT}/${FN_In}_RegMtx_3dvolreg.1D"
	p_RegO_MPar="${Dir_MCRT}/${FN_In}.par"
	if [ ! -f "${p_MCRT}" ];then
		echo "||	" 	
		echo "||	(M) Motion Correction | Data Existence (X) Conducting !!! >>>>>>>>>PART II" 

		rm -f "${p_MCRT}" "${p_MCRT_RegMtx}" "${p_RegO_MPar}"
		3dvolreg -verbose -zpad 1 -base ${base} -1Dfile "${p_RegO_MPar}" -prefix "${p_MCRT}" -cubic -1Dmatrix_save "${p_MCRT_RegMtx}" "${p_In}"
		mv ${p_MCRT} "${Dir_Tasktmp}/$(echo `basename $p_MCRT` | sed 's/.nii.gz//g' | sed 's/.nii//g')%EPI.${ImExt}";

		1dplot -sep -xlabel "Scan (@ Base ${base})" -png "${Dir_MCRT}/${FN_In}-MotionPara-Base-${base}.png" -volreg "${p_RegO_MPar}"

		# ${fslver}fsl_tsplot -i "${p_RegO_MPar}" -o "${Dir_MCRT}/${FN_In}-rot(Base_${base}).png" \
		# -t "3dvolreg estimated rotations (degree) @ Base ${base}" -u 1 --start=1 --finish=3 -a roll,pitch,yaw -w 640 -h 144 \
		
		# ${fslver}fsl_tsplot -i "${p_RegO_MPar}" -o "${Dir_MCRT}/${FN_In}-disp(Base_${base}).png"\
		# -t "3dvolreg estimated displacement (mm) @ Base ${base}" -u 1 --start=4 --finish=6 -a Superior,Left,Posterior -w 640 -h 144 \

		if [ "$Reg_Coord" == "y" ]; then
			echo "||	........................................................(With Reg: ${RegMed})" 
			echo "||	"
			3dresample -master ${p_T1_ds} -rmode Linear -prefix ${p_MCRT} -inset "${Dir_Tasktmp}/$(echo `basename $p_MCRT` | sed 's/.nii.gz//g' | sed 's/.nii//g')%EPI.${ImExt}"
		else
			RegMtx_raw2base="${Dir_MCRT}/mat.r01.vr.aff12.1D"; 
			# Name should be "mat.r01.vr.aff12.1D"
			rm -f "$RegMtx_raw2base"; cp $p_MCRT_RegMtx $RegMtx_raw2base
			RegMtx_raw2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_raw2anat_${Tp_Task}_2_${Tp_T1}"; 
	
			if [ -f "${p_Jump}" ];then
				echo "||	........................................................(With Reg: ${RegMed})" 
				echo "||	" 
				# cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" -I "${RegMtx_rs2jump}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
				#cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" -I "${RegMtx_task2jump}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
				cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" "${RegMtx_task2jump}.1D" "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			else
				echo "||	........................................................(With Reg: ${RegMed})" 
				echo "||	"
				#cat_matvec -ONELINE "${RegMtx_task2anat}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
				cat_matvec -ONELINE "${RegMtx_task2anat}.1D" "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			fi

    		# cat_matvec -ONELINE "${RegMtx_task2anat}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			# cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" -I "${RegMtx_task2jump}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			rm -f ${p_MCRT}; 3dAllineate -base ${p_T1_ds} -input "${p_In}" -final cubic -1Dmatrix_apply "${RegMtx_raw2anat}.1D" -prefix ${p_MCRT}
		fi
	else
		echo "||	(M) MotionCRT         | Data Existence (O) Named by `basename  ${p_MCRT}`   " 			
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_MCRT}"; #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	# p_MCRT="${Dir_Tasktmp}/----------"
	p_MCRT="${Dir_Tasktmp}/----------"
	# <<Assign FN>>
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	if [ "${#ID}" -eq "${#FN_In}" ];then
		p_Align="${Dir_Tasktmp}/${FN_In}_A.${ImExt}";
	else
		p_Align="${Dir_Tasktmp}/${FN_In}A.${ImExt}";
	fi

	if [ ! -f "${p_Align}" ] || [ "$IDX_Resample" == "y" ];then
		echo "||"	
		echo "||	(A) Align to native T1| REGISTRATION(${RegMed}) [Task >> ---- >> Anat]>>>>>>>>>> "	
		echo "||	"

		if [ "$Reg_Coord" == "y" ]; then
			3dresample -master ${p_T1_ds} -rmode Linear -prefix ${p_Align} -inset "${p_In}"
		elif [ -f "${RegMtx_task2anat}.1D" ];then 
			rm -f ${p_Align}; 3dAllineate -base ${p_T1_ds} -input "${p_In}" -final cubic -1Dmatrix_apply "${RegMtx_task2anat}.1D" -prefix ${p_Align}	
		fi		
		
	else
		echo "||	(A) Align to native T1| Data Existence (O) Named by `basename  ${p_Align}`   " 
	fi

	if [ -f "${p_Align}" ];then
		#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		p_In="${p_Align}"; #(Renew Dataset)
		#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		p_RegO_MPar="${Dir_Task_tmp}/Empty_RegO_MPar.txt" # Don't delete, Prepare for the motion correction
	else
		p_Align="${Dir_Task_tmp}/----------"
	fi

fi

# #=========================================================================================
# #----- oO(^^)Oo --------------------------------------------------[ Field Map Correction ]

# if [ "$IdxF" == "O" ]; then
# 	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
# 	p_FCRT="${Dir_Task}/${FN_In}F.nii.gz";
	
# # 	rm -f ${p_FCRT}
# # 	sh ????????

# 	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 	p_In="${p_FCRT}" #(Renew Dataset)
# 	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# else
# 	p_FCRT="${Dir_Task}/----------"
# fi  

#=========================================================================================
#----- oO(^^)Oo -----------------------------------------------------[ Despike & Detrend ]
if [ "$IdxD" == "O" ]; then
	DspkDtnd_Order="1"
	
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	p_DspkDtnd="${Dir_Tasktmp}/${FN_In}D${DspkDtnd_Order}.${ImExt}";
	
	if [ ! -f "${p_DspkDtnd}" ];then

		echo "||	" 	
		echo "||	(D) Despike & Detrend | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> " 	
		echo "||	"
 		rm -f ${p_DspkDtnd}
 		sh ${SDIR}/Fn_MDAP4_DspkDtnd.sh -i "${p_In}" -r "${DspkDtnd_Order}" -O "${Dir_Tasktmp}"
	else
		echo "||	(D) Despike & Detrend | Data Existence (O) Named by `basename  ${p_DspkDtnd}`   " 			
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_DspkDtnd}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	p_DspkDtnd="${Dir_Tasktmp}/${FN_In}DK.${ImExt}";
	
	if [ ! -f "${p_DspkDtnd}" ];then

		echo "||	" 	
		echo "||	(D) Despike & Detrend | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> " 	
		echo "||	"
 		rm -f ${p_DspkDtnd}
 		3dDespike -NEW -nomask -prefix "${p_DspkDtnd}" "${p_In}"
	else
		echo "||	(D) Despike & Detrend | Data Existence (O) Named by `basename  ${p_DspkDtnd}`   " 			
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_DspkDtnd}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	# p_DspkDtnd="${Dir_Tasktmp}/----------"
fi  

# #=========================================================================================
# #----- oO(^^)Oo ---------------------------------------------------[ Nuisance Regression ]
#-------------------------------------------------------------------------------------------
if [ "$IdxN" == "O" ]; then
	
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	numReg=$(head -n 1 ${p_RegO_MPar} | awk '{print NF}')


	Tmp_Mn="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_Mn.${ImExt}"; 
	Tmp_RMVL="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_RMVL.${ImExt}"; 

	p_NReg="${Dir_Tasktmp}/${FN_In}N${numReg}.${ImExt}"
	if [ ! -f "${p_NReg}" ];then
	
		echo "||	"	
		echo "||	(N) Nuisance Regress  | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> "
		echo "||	"
		#--------------------------------------------------------[Calculate Tmean]----------||
		#rm -f ${Tmp_Mn};${fslver}fslmaths "${p_In}" -Tmean "${Tmp_Mn}"

        rm -f ${Tmp_Mn}; 3dTstat -mean -prefix "${Tmp_Mn}" "${p_In}"

		#--------------------------------------------[Execute RMVL via 3dBandpass]----------||
		rm -f ${Tmp_RMVL};3dBandpass -nodetrend -notrans -ort "${p_RegO_MPar}" -prefix "${Tmp_RMVL}" -band 0 99999 -input "${p_In}"

		#------------------------------------------[Add Tmean back to RMVLed Data]----------||
		rm -f ${p_NReg};3dcalc -a "${Tmp_Mn}" -b "${Tmp_RMVL}" -expr "a+b" -prefix "${p_NReg}"

		rm -f $Tmp_Mn $Tmp_RMVL
	else
		echo "||	(N) Nuisance Regress  | Data Existence (O) Named by `basename  ${p_NReg}`   " 
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_NReg}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

else
	p_NReg="${Dir_Tasktmp}/----------"
fi  



#=========================================================================================
#----- oO(^^)Oo ----------------------------------------------[ Signal Normalize to mean ]


# FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
# # krnl_Blur="4"
# p_Nor2Mn="${Dir_Tasktmp}/${FN_In}PSC.${ImExt}";

# if [ ! -f "${p_Nor2Mn}" ];then
# 	echo "||	" 	
#     echo "||	(P) Signal change(%)  | Data Existence (X) Converting !!! >>>>>>>>>> " 
# 	echo "||	"	

# 	Tmp_Mn="${Dir_Tasktmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_Mn.${ImExt}"; 
# 	rm -f ${Tmp_Mn}; 3dTstat -mean -prefix "${Tmp_Mn}" "${p_In}"
# 	rm -f ${p_Nor2Mn};3dcalc -a "${p_In}" -b "${Tmp_Mn}" -expr '100*a/b' -prefix "${p_Nor2Mn}"
# 	# 3dBlurInMask -float -quiet -FWHM "${krnl_Blur}" -input "${p_In}" -mask "${p_T1Msk_ds}" -prefix "${p_Blur}" 
# else	
# 	echo "||	(P) Signal change(%)  | Data Existence (O) Named by `basename  ${p_Nor2Mn}`   " 
# fi 
# #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# p_In="${p_Nor2Mn}" #(Renew Dataset)
# #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#=========================================================================================
#----- oO(^^)Oo --------------------------------------------------------------[ Blurring ]

if [ "$IdxS" == "O" ]; then
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	# krnl_Blur="4"
	p_Blur="${Dir_Tasktmp}/${FN_In}S${krnl_Blur}mm.${ImExt}";
	
	if [ ! -f "${p_Blur}" ];then
		echo "||	" 	
	    echo "||	(S) Smooth            | Data Existence (X) Smoothing (${krnl_Blur} mm) !!! >>>>>>>>>> " 
		echo "||	"	
		rm -f ${p_Blur}
		#3dmerge -1blur_fwhm ${krnl_Blur} -doall -quiet -prefix "${p_Blur}" "${p_In}"
		 3dBlurInMask -float -quiet -FWHM "${krnl_Blur}" -input "${p_In}" -mask "${p_T1Msk_ds}" -prefix "${p_Blur}" 
	else	
		echo "||	(S) Smooth            | Data Existence (O) Named by `basename  ${p_Blur}`   " 
	fi 
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_Blur}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
fi  
#=========================================================================================
#----- oO(^^)Oo --------------------------------------------------[ Create Design Matrix ]

# Dimt=$(${fslver}fslinfo ${p_In} | awk 'NR==5{print $2}' ); 
Dimt="$(3dinfo -nt ${p_In})"


echo "================================================================================== "
echo "||                       General Linear Model (GLM)         "
echo "================================================================================== "


# =========================================================================================
# ----- oO(^^)Oo ---------------------------------------------------------------[ RUN GLM ]

FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')



p_Msk="${Dir_Tasktmp}/${FN_In}_Msk_byMn.${ImExt}"


p_Msktmp="${Dir_Tasktmp}/${FN_In}_Msktmp_byMn.${ImExt}"

# <<Produce Mask>>
if [ ! -f "${p_Msk}" ];then
	3dTstat -mean -prefix "${Dir_Tasktmp}/${FN_In}_Mn.${ImExt}" "${p_In}"
	rm -f "${p_Msk}"; 3dAutomask -eclip -dilate 1 -prefix "${p_Msktmp}" "${Dir_Tasktmp}/${FN_In}_Mn.${ImExt}"
	rm -f "${Dir_Tasktmp}/${FN_In}_Mn.${ImExt}" 		
fi 

if [ ! -f "${p_Msk}" ] && [ -f "${p_Msktmp}" ] && [ -f "${p_T1Msk_ds}" ];then
	rm -f ${p_Msk}
	3dcalc -a "${p_T1Msk_ds}" -b "${p_Msktmp}" -expr "ispositive(a*b)" -prefix "${p_Msk}"
fi



if [ -f "${p_Diagram}" ];then

	#DelayTime="$(echo `basename $p_Diagram` | sed 's/.txt//g'| cut -d '_' -f 4)"
	fOut="GLM_${IRF}_${FN_In}_${DelayTime}"

    p_GLM="${Dir_Tasktmp}/${fOut}.${ImExt}"
    p_Beta="${Dir_Tasktmp}/${fOut}_Beta.${ImExt}"
	p_PSG="${Dir_Tasktmp}/${fOut}_PSG.${ImExt}"

	if [ ! -f "${p_GLM}" ];then


		rm -f ${Dir_Tasktmp}/3dDeconvolve.err ${Dir_Tasktmp}/3dREMLfit.err ${Dir_Tasktmp}/Decon.REML_cmd
		rm -f ${Dir_Tasktmp}/${fOut}_* ${Dir_Tasktmp}/${fOut}*

		# <<Produce Design matrix via  3dDeconvolve>>
		3dDeconvolve -jobs 4 -float -polort 1 \
		             -input "${p_In}" -mask "${p_Msk}" \
		             -num_stimts 1 \
		             -stim_file 1 "${p_Diagram}" -stim_label 1 "${IRF}" \
		             -cbucket "${p_Beta}" \
		             -tout -rout -fout -bout -bucket "${p_GLM}" -GOFORIT \
		             -fitts "${Dir_Tasktmp}/${fOut}_fitt.${ImExt}" \
		             -x1D "${Dir_Tasktmp}/${fOut}_design" \
		             -xjpeg "${Dir_Tasktmp}/${fOut}_design.jpg"

		rm -f "${Dir_Tasktmp}/${fOut}.REML_cmd"

		if [ -f "${Dir_Tasktmp}/${fOut}_design.xmat.1D" ];then
			1dplot -dx "${TR}" -xlabel 'Time(s)' -plabel "Design Matrix with ${DelayTime} Delay" -jpgs 1000 "${Dir_Tasktmp}/DesignMtx_GLM_${IRF}_${DelayTime}Delay" "${Dir_Tasktmp}/${fOut}_design.xmat.1D"
		fi

		TS_Max="$(1d_tool.py -show_mmms -infile "${p_Diagram}" | sed -n '2p'| awk '{print $11}' | cut -d ',' -f 1)"
		TS_Min="$(1d_tool.py -show_mmms -infile "${p_Diagram}" | sed -n '2p'| awk '{print $5}' | cut -d ',' -f 1)"

		# SF=$(echo "scale=4; ${TS_Max} - ${TS_Min}" | bc)
		SF=$(echo "scale=4; ${TS_Max}*1" | bc)
		#SF="1"

		rm -f ${p_PSG}; 3dcalc -a ${p_Beta}'[2]' -b ${p_Beta}'[0]' -c "${p_Msk}" -expr "ispositive(c)*ispositive(a)*100*${SF}*a/b" -prefix ${p_PSG}


		# # <<Produce Design matrix via  3dDeconvolve>>
		# 3dDeconvolve -jobs 4 -float -polort 1 \
		#              -input "${p_In}" -mask "${p_Msk}" \
		#              -num_stimts 1 \
		#              -stim_file 1 "${p_Diagram}" -stim_label 1 'RRF' \
		#              -tout -rout -x1D_stop \
		#              -fitts "${Dir_Tasktmp}/${fOut}_fitt" \
		#              -errts "${Dir_Tasktmp}/${fOut}_rsdu" \
		#              -x1D "${Dir_Tasktmp}/${fOut}_design" \
		#              -xjpeg "${Dir_Tasktmp}/${fOut}_design.jpg"

		# # <<Produce GLM result which corrected autocorrelation by Design matrix>>       
		# 3dREMLfit -matrix "${Dir_Tasktmp}/${fOut}_design.xmat.1D" \
		#           -input "${p_In}" -mask "${p_Msk}" \
		#           -tout -rout -verb -GOFORIT \
		#           -Rbuck "${p_GLM}"


		#bash ${SDIR}/Fn_stat_GLM.sh -i "${p_In}" -r "${p_Diagram}" -m "${p_Msk}" -O "${Dir_Task}" -o "${Dir_Task}/${FN_In}" "${p_RegO_MPar}"
		
		# <<Save as tmap>>    
		pTmap="${Dir_Tasktmp}/${IRF}_${DelayTime}.${ImExt}"
		#rm -f ${pTmap}; 3dcalc -a ${p_GLM}'[3]' -b "${p_Msk}" -expr "a*ispositive(b)" -prefix ${pTmap}
		rm -f ${pTmap}; 3dcalc -a ${p_GLM}'[7]' -b "${p_Msk}" -expr "a*ispositive(b)" -prefix ${pTmap}
	else
		echo "||	    GLM Results       | Data Existence (O) Named by `basename  ${p_GLM}`   " 		
	fi


	#=========================================================================================
	#----- oO(^^)Oo ------------------------------------------------------------[ CoReg : Tmap]
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${pTmap}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#----------------------------------------[ BBR Registration : Check Results ]-----------||
	Des="T1";pOut="${Dir_Tasktmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExtOT}"; 
	#rm -f $pOut
	if [ ! -f "${pOut}" ];then 
		echo "||	"	
		echo "||	(R) Registration      | REGISTRATION(${RegMed}) Output >> $(echo `basename $pOut`) "	
		echo "||	"
		3dresample -master ${p_T1} -rmode Linear -prefix ${pOut} -inset ${p_In}
		
		# if [ "$Reg_Coord" == "y" ]; then
		# 	3dresample -master ${p_T1} -rmode Linear -prefix ${pOut} -inset ${p_In}
		# else
		# 	3dAllineate -base ${p_T1} -input ${p_In} -final trilinear -1Dmatrix_apply "${RegMtx_task2anat}.1D" -prefix ${pOut}
		# fi
		if [ -f "${pOut}" ];then 
		echo "|| "
		echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		echo "|| ...........`dirname  ${pOut}`"
		echo "|| .................`basename  ${pOut}`"
		echo "|| ---------------------------------------------------------------------------------"
		rm -f "${p_In}"; #mv "${pOut}" "${p_In}"
		else
		echo "|| "
		echo "|| ~~~~~~~~~~ [ ERROR ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		echo "|| ...........Unable to Coregister `basename  ${p_In}` to T1 space "
		echo "|| ---------------------------------------------------------------------------------"
		fi
	fi

	#=========================================================================================
	#----- oO(^^)Oo ------------------------------------------------------------[ CoReg : PSG]
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_PSG}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#----------------------------------------[ BBR Registration : Check Results ]-----------||
	#Des="T1";pOut="${Dir_Tasktmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExtOT}"; 
	Des="T1";pOut="${Dir_Tasktmp}/${IRF}_PSG_${DelayTime}%${RegMed}_${Des}.${ImExtOT}"; 
	# pTmap="${Dir_Tasktmp}/${IRF}_${DelayTime}.${ImExt}"
	#rm -f $pOut
	if [ ! -f "${pOut}" ];then 
		echo "||	"	
		echo "||	(R) Registration      | REGISTRATION(${RegMed}) Output >> $(echo `basename $pOut`) "	
		echo "||	"
		3dresample -master ${p_T1} -rmode Linear -prefix ${pOut} -inset ${p_In}
		
		# if [ "$Reg_Coord" == "y" ]; then
		# 	3dresample -master ${p_T1} -rmode Linear -prefix ${pOut} -inset ${p_In}
		# else
		# 	3dAllineate -base ${p_T1} -input ${p_In} -final trilinear -1Dmatrix_apply "${RegMtx_task2anat}.1D" -prefix ${pOut}
		# fi
		if [ -f "${pOut}" ];then 
		echo "|| "
		echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		echo "|| ...........`dirname  ${pOut}`"
		echo "|| .................`basename  ${pOut}`"
		echo "|| ---------------------------------------------------------------------------------"
		rm -f "${p_In}"; #mv "${pOut}" "${p_In}"
		else
		echo "|| "
		echo "|| ~~~~~~~~~~ [ ERROR ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		echo "|| ...........Unable to Coregister `basename  ${p_In}` to T1 space "
		echo "|| ---------------------------------------------------------------------------------"
		fi
	fi


fi

ENDTIME="$(date +"%m-%d-%Y  %r")"; 
echo "|| "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "  END : ${ENDTIME}"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| "

echo "|| "
echo "==========================={ END :: Fn_MDAS3_cvrPrep.sh  }========================= " 
echo "|| "
