%-----------------------------------------------------------------------
% Job saved on 08-May-2017 14:40:16 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6685)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.util.defs.comp{1}.inv.comp{1}.sn2def.matname = {'Y:\Program\Irene_Software\DemoData\1_dcmImport\1.2.840.113696.347054.500.2487892.20151116133318\2_T1_InvNor_1\1218807_3DVOLUME_sn.mat'};
matlabbatch{1}.spm.util.defs.comp{1}.inv.comp{1}.sn2def.vox = [NaN NaN NaN];
matlabbatch{1}.spm.util.defs.comp{1}.inv.comp{1}.sn2def.bb = [NaN NaN NaN
                                                              NaN NaN NaN];
matlabbatch{1}.spm.util.defs.comp{1}.inv.space = {'Y:\Program\Irene_Software\DemoData\1_dcmImport\1.2.840.113696.347054.500.2487892.20151116133318\2_T1_InvNor_1\1218807_3DVOLUME.nii'};
matlabbatch{1}.spm.util.defs.out{1}.pull.fnames = {'Y:\Program\Irene_Software\UI_IClinfMRI_VB\Template\MNI152_SAreaW_R30.nii'};
matlabbatch{1}.spm.util.defs.out{1}.pull.savedir.savepwd = 1;
matlabbatch{1}.spm.util.defs.out{1}.pull.interp = 4;
matlabbatch{1}.spm.util.defs.out{1}.pull.mask = 1;
matlabbatch{1}.spm.util.defs.out{1}.pull.fwhm = [0 0 0];
matlabbatch{1}.spm.util.defs.out{1}.pull.prefix = 'Inv_';
