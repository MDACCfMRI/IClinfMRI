function Fn_Mat2NiiGz(Nii_Ref,OT_FN,Mtx)
% Fn_Mat2NiiGz(Nii_Ref,OT_FN,Mtx)

Output=Nii_Ref;
Output.img(:,:,:)=0;
Output.img(:,:,:)=Mtx(:,:,:);
save_untouch_nii(Output, OT_FN);
clear Output
disp(['oO(^________^)Oo....Matlab:: ' 'Save successfully:: ' OT_FN])
