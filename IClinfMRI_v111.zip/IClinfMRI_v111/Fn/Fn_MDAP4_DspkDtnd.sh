#!/bin/sh

# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

================== { Fn_MDAP4_DspkDtnd.sh } ====================
||
||  [Purpose]: Remove the spike first, and then remove the trend from the data
||
||  [Usage]: Fn_MDAP4_DspkDtnd.sh [OPTIONS]
||       ex: Fn_MDAP4_DspkDtnd.sh  -i {p_In} -r {DTND_ord} -o {FN_DTND} -O {Dir_OT}
|| 			  
||
||  [OPTIONS]:
||            -i <p_In> : the full pathway of the input file
||            -r <DTND_ord> : the order of the detrend
||            -O <Dir_OT> : The Directory of output files
||
||	[Optional arguments]
||            -o <FN_DTND> : The filename of the output file, the default suffix is "D"
||                           Ex. the filename of the input file is "BM_011_IMF.nii.gz"
||                           Ex. the filename of the output file will be "BM_011_IMFD?.nii.gz"
||                                                                           ? indicated the detrend order
||            -O <Dir_OT> : The Directory of output files (Default is the dir of the input file)
||
===================================================================
Created by Irene Hsu on 2016.07.10 (Bash shell) 
		@ MD Anderson

EOF

exit
}

# ============================================================================[TEST]====="
# Fn_MDAP4_DspkDtnd.sh -i "${DirOT}/BM004_BN_M.nii.gz" -r "3" -O ${Dir_OT}

# ============================================================================[Help]====="
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="

#echo "Total $argn input arguments"


Opt_numb=0;
while getopts "i:r:o:O:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	case $OPTION in 
    i)
        p_In=$OPTARG
    ;;
    r)
		DTND_ord=$OPTARG
    ;;
    o)
		FN_DTND=$OPTARG
    ;;
    O)
		Dir_OT=$OPTARG
    ;;
    x)
		empty=$OPTARG
    ;;
    esac
done


# ===========================================================[Check Input arguments]====="
echo "|| "
echo "-------------------{ Examination : Fn_MDAP4_DspkDtnd.sh}-------------------------- "

ID=$(echo `basename $p_In` | cut -d '_' -f 1-2 )

if [ -z "${Dir_OT}" ];then 
	#Dir_OT=$(pwd)
	Dir_OT=$(dirname "$p_In")
fi

#cd "${Dir_OT}"


#if [ -z "${DTND_ord}" ] || [ -n "${DTND_ord}" ]; then
#	DTND_ord="3";
#fi

if [ -z "${FN_DTND}" ] || [ -n "${FN_DTND}" ]; then
	FN_DTND="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')D${DTND_ord}.nii.gz";
fi

# cd "${Dir_OT}"


# ============================================================================[Main]====="

#---------------------------------------------------------------------{ START }----------#
echo "|| "
echo "-------------------{ Information : Fn_MDAP4_DspkDtnd.sh}-------------------------- "
echo "|| "
echo "||	(1) ::  [ Input File    ] =[ $(echo `basename $(ls $p_In)`) ] "
echo "||	(2) ::  [ Output File   ] =[ ${FN_DTND} ] "
echo "||	(3) ::  [ Detrend order ] =[ ${DTND_ord} ] "
echo "||	(4) ::  [ Dir_OT ] =[ ${Dir_OT} ] "
echo "|| "
echo "-----------------------------------------------------------------------------------"
echo "|| "

# =======================================================================================#
#     { 01. Check Whether The Folder exists or not }
# =======================================================================================#

if [ -f "${Dir_OT}/${FN_DTND}" ];then 
echo "||	(D) Despike & Detrend | Data Existence (O) Named by `basename  ${FN_DTND}` " 
fi


if [ ! -f "${Dir_OT}/${FN_DTND}" ] && [ -f "${p_In}" ]; then

	Pnt_FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')
	Pnt_FN_DTND=$(echo `basename $FN_DTND` | sed 's/.nii.gz//g' | sed 's/.nii//g')

	#------------------------{ Argument to Assign Start }-------------------------#

	#declare -i DTND_ord=2

	p_OT_DSK="${Dir_OT}/${Pnt_FN_In}_DSK.nii.gz"
	p_OT_DSKSS="${Dir_OT}/${Pnt_FN_In}_DSKSS.nii.gz"
	p_OT_Avg="${Dir_OT}/${Pnt_FN_In}_AVG.nii.gz"
	p_OT_DTND_rmMn="${Dir_OT}/${Pnt_FN_DTND}_rmMn.nii.gz"
	p_OT_DTND="${Dir_OT}/${Pnt_FN_DTND}.nii.gz"

	#------------------------{ Argument to Assign END  }-------------------------#
	# ~~ 1.0 Despike
	# ~~ 1.1 Compute mean of non-zero voxels
	# ~~ 1.2 3dDetrend not only perform detrend but also remove mean simutanuously
	# ~~ 1.3 Add mean back to the signal after 3dDetrend
	#----------------------------------------------------------------------------#

	#-----{ (1) 3dDespike)   }-------------------------------------------------------------#
	#------------------------------------------------------------------------------------#

echo "|| "
echo "|| ~~~~~~~~~~ [ 01. Despike ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| ....................................... @ ${Pnt_FN_In} "
echo "-----------------------------------------------------------------------------------"


	rm -f ${p_OT_DSK}
	3dDespike -NEW -nomask -prefix "${p_OT_DSK}" "${p_In}"
	#3dDespike -ssave "${p_OT_DSKSS}" -prefix "${p_OT_DSK}" "${p_In}"

	#-----{ (2) Compute mean of non-zero voxels)   }-------------------------------------#
	#------------------------------------------------------------------------------------#

echo "|| "
echo "|| ~~~~~~~~~~ [ 02. Compute mean of non-zero voxels ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "-----------------------------------------------------------------------------------"

	
	rm -f ${p_OT_Avg}
	3dTstat -nzmean -prefix "${p_OT_Avg}" "${p_OT_DSK}"
	
	#-----{ (3) 3dDetrend remove mean simutanuously   }----------------------------------#
	#------------------------------------------------------------------------------------#

echo "|| "
echo "|| ~~~~~~~~~~ [ 03. 3dDetrend ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "-----------------------------------------------------------------------------------"

	rm -f ${p_OT_DTND_rmMn}
	3dDetrend -prefix "${p_OT_DTND_rmMn}" -polort ${DTND_ord} "${p_OT_DSK}"
	
	#-----{ (4) Add mean back to the signal after 3dDetrend   }--------------------------#
	#------------------------------------------------------------------------------------#

echo "|| "
echo "|| ~~~~~~~~~~ [ 004. Add mean back to the signal after 3dDetrend ] ~~~~~~~~~~~~~~~~"
echo "-----------------------------------------------------------------------------------"

	rm -f ${p_OT_DTND}
	3dcalc -a "${p_OT_DTND_rmMn}" -b "${p_OT_Avg}" -expr "a+b" -prefix "${p_OT_DTND}"

	rm -f ${p_OT_DTND_rmMn}
	rm -f ${p_OT_Avg}
	rm -f ${p_OT_DSK} # Remove the desipke data

fi

#-----------------------------------------------------------------------{ END }----------#

echo "|| "
echo "------------------------{ DONE !!! Fn_MDAP4_DspkDtnd.sh}-------------------------- "
echo "|| "

