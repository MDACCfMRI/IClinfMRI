function [Affine_XYZ,Mtx_ImageOrient]=Fn_DCM2Affine(HDRIn,T1,TN,NumSlice)
% ||
% ||  ==={ [Affine_XYZ,Mtx_ImageOrient]=Fn_DCM2Affine(HDRIn,T1,TN,NumSlice) }===
% ||
% ||  [Purpose]: (1) Calculate the Affine transformation matrix 
% ||             (2) Calculate the ImageOrientationPatient (0020,0037) for the view of 'Ax'/'Sag'/'Cor'
% ||
% ||  [OPTIONS]:
% ||            HDRIn : DICOM Header
% ||            T1    : triplet of values of the ImagePositionPatient field of the first header of volume.
% ||            TN    : triplet of values vector of the ImagePositionPatient field of the last header of volume.
% ||            NumSlice: number of slices of a volume along the direction of slice encoding
% ||  -(Note)------------------------------------------------------------
% ||      * Image Position (0020,0032):  the x, y, and z coordinates of the upper left hand corner of the image
% ||
% ||  ===================================================================
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright (c) 2017 The University of Texas MD Anderson Cancer Center
% ||   

% =========================================================================
%                            <Pixel Spacing(1)>
%                       |-------------------------> (X)
%           ^           |                         |  R1
%           |           |                         |  R2
%   Pixel Spacing(2)    |       Matrix(Mtx)       |
%           |           |                   |-------->  ImageOrientationPatient(1:3)   
%           V           |                   |     |
%                       |-------------------|-----|  Rn
%                       V                   |     
%                   (   Y  )                |
%                       C1 C2 ............  V  ..Cn
%                                ImageOrientationPatient(4:6)
% 
% =========================================================================

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Check the data orientation
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ViewID(:,1)=[1;0;0;0;1;0]; % FOR AXIAL VIEW (z axis)
ViewID(:,2)=[0;1;0;0;0;-1];% FOR Sagital VIEW (x axis)
ViewID(:,3)=[1;0;0;0;0;-1]; % FOR Coronal VIEW (y axis)
clear CMP;CMP=zeros(3,1);
Sign=(HDRIn.ImageOrientationPatient>0)+(HDRIn.ImageOrientationPatient<0)*-1;
ImgOrient=Sign.*(abs(HDRIn.ImageOrientationPatient)>0.5);%
%<check DICOM View>
for v=1:3 ; CMP(v)=(sum(ImgOrient==ViewID(:,v))==6); end
idxView=find(CMP==1);
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Load Pixel spacing (Scaling)
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
dRow=HDRIn.PixelSpacing(1); % Row spacing in mm (vertical spacing)
dClm=HDRIn.PixelSpacing(2); % Column spacing in mm (horizontal spacing)
dSlc=1;  % Slice 
Affine_Scaling=[ones(3,1)*dRow ones(3,1)*dClm ones(3,1)*dSlc];
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Load Direction Cosines
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% The direction cosines of the first row and the first column with respect to the patient.
DCRow=HDRIn.ImageOrientationPatient(4:6); 
DCClm=HDRIn.ImageOrientationPatient(1:3);
% DCSlc=(TN-T1)/(size(Coord_DCM,1)-1);
DCSlc=(T1-TN)/(1-NumSlice);
Affine_DC=[DCRow DCClm DCSlc];
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Mix "Direction Cosines" & "Scaling"
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Affine_RCS=Affine_DC.*Affine_Scaling;

% ImgX == Mtx Cloumn
% ImgY == Mtx Row

if (idxView==1)
    Affine_XYZ=[Affine_RCS(:,2) Affine_RCS(:,1) Affine_RCS(:,3)]; % Ax(XY)
    DCos_XYZ=[Affine_DC(:,2) Affine_DC(:,1) Affine_DC(:,3)]; 
    % (X:Mtx_Cloumn)  (Y:Mtx_Row) (Z:Slice) 
elseif (idxView==2)
    Affine_XYZ=[Affine_RCS(:,3) Affine_RCS(:,2) Affine_RCS(:,1)]; % Sag(YZ)
    DCos_XYZ=[Affine_DC(:,3) Affine_DC(:,2) Affine_DC(:,1)]; 
    % (X:Slice)  (Y:Mtx_Cloumn) (Z:Mtx_Row) 
elseif (idxView==3)
    Affine_XYZ=[Affine_RCS(:,2) Affine_RCS(:,3) Affine_RCS(:,1)]; % Cor(XZ)
    DCos_XYZ=[Affine_DC(:,2) Affine_DC(:,3) Affine_DC(:,1)]; 
    % (X:Mtx_Cloumn)  (Y:Slice) (Z:Mtx_Row) 
end

if (DCos_XYZ(3,3)>0) DCos_XYZ(:,3)=DCos_XYZ(:,3)*-1; end

Mtx_ImageOrient(1,:)=[ DCos_XYZ(:,1)' DCos_XYZ(:,2)']; 
Mtx_ImageOrient(2,:)=[ DCos_XYZ(:,2)' DCos_XYZ(:,3)'];
Mtx_ImageOrient(3,:)=[ DCos_XYZ(:,1)' DCos_XYZ(:,3)'];
