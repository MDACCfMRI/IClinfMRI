%-----------------------------------------------------------------------
% Job saved on 08-May-2017 11:28:15 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6685)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.tools.oldnorm.estwrite.subj.source = {'Y:\Program\Irene_Software\DemoData\1_dcmImport\1.2.840.113696.347054.500.2487892.20151116133318\2_T1_InvNor_2\1218807_3DVOLUME.nii,1'};
matlabbatch{1}.spm.tools.oldnorm.estwrite.subj.wtsrc = '';
matlabbatch{1}.spm.tools.oldnorm.estwrite.subj.resample = {'Y:\Program\Irene_Software\DemoData\1_dcmImport\1.2.840.113696.347054.500.2487892.20151116133318\2_T1_InvNor_2\1218807_3DVOLUME.nii,1'};
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.template = {'Y:\Program\spm12\toolbox\OldNorm\T1.nii,1'};
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.weight = '';
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.smosrc = 8;
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.smoref = 0;
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.regtype = 'mni';
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.cutoff = 25;
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.nits = 16;
matlabbatch{1}.spm.tools.oldnorm.estwrite.eoptions.reg = 1;
matlabbatch{1}.spm.tools.oldnorm.estwrite.roptions.preserve = 0;
matlabbatch{1}.spm.tools.oldnorm.estwrite.roptions.bb = [-90 -126 -72
                                                         91 91 109];
matlabbatch{1}.spm.tools.oldnorm.estwrite.roptions.vox = [2 2 2];
matlabbatch{1}.spm.tools.oldnorm.estwrite.roptions.interp = 1;
matlabbatch{1}.spm.tools.oldnorm.estwrite.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.tools.oldnorm.estwrite.roptions.prefix = 'w';
