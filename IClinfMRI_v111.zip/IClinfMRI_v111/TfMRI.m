function varargout = TfMRI(varargin)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright (c) 2017 The University of Texas MD Anderson Cancer Center
% ||   
% TFMRI MATLAB code for TfMRI.fig
%      TFMRI, by itself, creates a new TFMRI or raises the existing
%      singleton*.
%
%      H = TFMRI returns the handle to a new TFMRI or the handle to
%      the existing singleton*.
%
%      TFMRI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TFMRI.M with the given input arguments.
%
%      TFMRI('Property','Value',...) creates a new TFMRI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TfMRI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TfMRI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help TfMRI

% Last Modified by GUIDE v2.5 23-Aug-2017 22:35:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TfMRI_OpeningFcn, ...
                   'gui_OutputFcn',  @TfMRI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TfMRI is made visible.
function TfMRI_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
BtnINI(hObject, eventdata, handles);

function [handles]=BtnINI(hObject, eventdata, handles)
set(handles.Fig_TfMRI,'Name','Task fMRI');
global Idx_Execute
Idx_Execute=0;
% <Default Setting : Dir Source>
tmp_PWD=pwd;
LsWorking={tmp_PWD,'C:\Users\AHSU\RScript_Toolbox\Matalb\UI_IClinfMRI_VB'};
% LsWorking={'/mnt/data/B2/MDACC_Patients','C:\Users\AHSU\RScript_Toolbox\Matalb\UI_rsMapping\DataTest',tmp_PWD};
for s=1:numel(LsWorking)
    if (exist(LsWorking{s},'dir')==7)
        handles.DirW=LsWorking{s};
    else
        handles.DirW=pwd;
    end
end
guidata(hObject, handles);
if ~isempty(handles.DirW) && (exist(handles.DirW,'dir')==7)
    set(handles.Tx_DirW,'BackgroundColor',1*ones(1,3));
    set(handles.Tx_DirW,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_DirW,'String',handles.DirW)
end
% <Default for Img Input>
handles.pTData='';
handles.pT1='';
handles.pHRepi='';
handles.pwd=tmp_PWD;
set(handles.Tx_tData,'String',handles.pTData);
set(handles.Tx_T1,'String',handles.pT1);
set(handles.Tx_HRepi,'String',handles.pHRepi);

handles.RegRSmm=2;set(handles.PMenu_Regmm,'Value',1);
handles.FWHM=4;set(handles.Ed_FWHM,'String',num2str(handles.FWHM));
handles.Terminal=0;
% <Default Task PreProcess >
handles.TR=2;handles.tPattern='alt+z';
% <Default Task Diagram >
LsTDiagram(1).name='LETT';
LsTDiagram(1).Onset=[20 60 100 140 180 220];
LsTDiagram(1).Duration=20;

LsTDiagram(2).name='CAT';
LsTDiagram(2).Onset=[20 60 100 140 180 220];
LsTDiagram(2).Duration=20;

LsTDiagram(3).name='Sentence';
LsTDiagram(3).Onset=[20 60 100 140 180 220];
LsTDiagram(3).Duration=20;

LsTDiagram(4).name='BothHand';
LsTDiagram(4).Onset=[15 45 75 105 135 165];
LsTDiagram(4).Duration=15;

LsTDiagram(5).name='Other';
LsTDiagram(5).Onset=5;
LsTDiagram(5).Duration=5;

handles.LsTDiagram=LsTDiagram;

% Reg Setting
set(handles.RBtn_CBR,'Value',1)
set(handles.RBtn_BBR,'Value',0)
set(handles.RBtn_IBR,'Value',0)

% <Default Task PreProcess >
handles.tPrep_T=0;  handles.tPrep_M=1;  handles.tPrep_F=0;  handles.tPrep_D=0;  handles.tPrep_B=1;
set(handles.Ck_DftTPrep,'Value',1);
set(handles.Ck_tSliceT,'Value',handles.tPrep_T);
set(handles.Ck_tMCRT,'Value',handles.tPrep_M);
set(handles.Ck_tFMCRT,'Value',handles.tPrep_F);
set(handles.Ck_Despike,'Value',1);
set(handles.Ck_tDDdnt,'Value',handles.tPrep_D);
set(handles.Ck_tBlur,'Value',handles.tPrep_B);

% <Default Setting : Task Selection on LETT>
handles.TR=2;handles.TaskReps=130;
set(handles.PMenu_tName,'Value',1);
set(handles.PMenu_tOnset,'Value',2);handles.Onset=LsTDiagram(1).Onset;%handles.Onset=[20 60 100 140 180 220];
set(handles.PMenu_tDuration,'Value',2);handles.Duration=LsTDiagram(1).Duration;%handles.Duration=[20];
% PMenu_tName_Callback(hObject, eventdata, handles);
guidata(hObject, handles);


p_spm=which('spm.m');
if  ~(exist(p_spm, 'file')==2)
    set(handles.Tx_Message,'string','SPM is not detectd in PATH, Please add it !!! ','foregroundcolor',[1 0 0])
    handles.SPM=0;
else
     set(handles.Tx_Message,'string','SPM is detected in the path','foregroundcolor',[0 0 1])
     handles.SPM=1;
end

PlotTDiagram(hObject, eventdata, handles);

if (handles.SPM==1)
    BtnSetting(hObject, eventdata, handles);
    set(handles.Btn_tData,'Enable','on');
else
    BtnOff(hObject, eventdata, handles);
    set(handles.Btn_tData,'Enable','off');
end
guidata(hObject, handles);

%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [ Plot task fMRI Diagram ]
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function PlotTDiagram(hObject, eventdata, handles)
global Idx_Execute
T=handles.TR;
S=handles.Onset;
D=handles.Duration;
Scans=handles.TaskReps;
% ts=[0:0.01:(Scans-1)*T]';
ts=[T:0.01:Scans*T]';
TDiagram=zeros(numel(ts),1);
if isempty(S); S=0; end
if isempty(D); D=0; end

for ss=1:numel(S)
    idx= (ts>=S(ss)) & (ts<=S(ss)+D);
    TDiagram(idx)=ones(sum(idx),1);
end
xTicktmp=sort([S S+D]);
if (max(ts)>=max(xTicktmp))
    if (max(ts)>max(xTicktmp))
        xTicktmp=[0 xTicktmp max(ts)];
    elseif (max(ts)==max(xTicktmp))
        xTicktmp=[0 xTicktmp];
    end
    
   
    if (exist(handles.pTData,'file')==2)&&(exist(handles.pT1,'file')==2)
         XYColor=0.2*ones(1,3);
         PlotColor=0.5*[1 1 1];
    else
         XYColor=0.7*ones(1,3);
         PlotColor=0.7*[1 1 1];
    end
    
    plot(ts,TDiagram,'LineWidth',2,'Color',PlotColor,'Parent',handles.AxtProfile);
    % set(gca,'xtick',[0:D:max(ts)],'FontSize',8,'XColor', 0.2*[1 1 1]);
    
    set(gca,'xtick',xTicktmp,'XColor', XYColor);
    set(gca,'ytick',[0:1],'YColor', XYColor);grid on;
    xlim([min(ts) max(ts)]); ylim([0-0.5 1+0.5])
    set(gca,'yticklabel',{'OFF','ON'})
    xlabel('Time(s)','FontName','Lucida Sans')
    set(gca,'YGrid','off')
    if (handles.SPM==1)
        % set(handles.Tx_Message,'string', ['>> ' ],'foregroundcolor',[0 0 0])
        set(handles.Tx_Message,'string','SPM is detected in the path','foregroundcolor',[0 0 1])
    else
        set(handles.Tx_Message,'string','SPM is not detectd in PATH, Please add it !!! ','foregroundcolor',[1 0 0])
       
    end
    Idx_Execute=1;
else
    plot(ts,ones(numel(ts),1),'LineWidth',2,'Color',[1 0 0],'Parent',handles.AxtProfile);
%     hm=msgbox('The Data length and paradigm DOES NOT MATCH !', 'Error','error');
%     kids0 = findobj( hm, 'Type', 'UIControl' );kids1 = findobj( hm, 'Type', 'Text' );
%     set( [kids1],'FontName','Unicode');
 set(handles.Tx_Message,'string', ['>> The Data length and paradigm DOES NOT MATCH !' ],'foregroundcolor',[1 0 0])
Idx_Execute=0;
end
% disp(['Duration= ' num2str(D) '; Onset= ' num2str(S) '; Grid= ' num2str(xTicktmp)])

function varargout = TfMRI_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;
ffig='IClinfMRI.fig';
pfig=which(ffig);

if (exist(pfig,'file')==2)
    [DirM,~,ext]=fileparts(pfig);
else
    error(['Can not find ".fig", please check Matlab path '])
end

if isdir(DirM)
    DirFn=[DirM filesep 'Fn'];
    handles.DirFn=DirFn; guidata(hObject, handles);
%     DirDemo=[DirM filesep 'DEMO'];
    %addpath(genpath(DirFn))
    addpath(DirFn)
    addpath(DirM)
%     cd(DirM)
end


if isdir(handles.DirFn) && (isunix)
    formatBasic ='cd %s \n bash %sFn_getenv.sh -t "y"';
    ts_setting = sprintf(formatBasic,[handles.DirFn],[handles.DirFn filesep]);
    [s,ts_rst]=system(ts_setting);
    if (numel(findstr(ts_rst,'[O]'))>=1)
        handles.Terminal=1;
        MsgAFNI=strrep(['Library Setting:  ' ts_rst '!!! '], sprintf('\n'),' ');
%         set(handles.Tx_Message,'String',strrep(['Library Setting:  ' ts_rst '!!! '], sprintf('\n'),' '),'ForegroundColor',[0 0 1]);
    else
        handles.Terminal=0;
        MsgAFNI=strrep(['Missing part of links, ' ts_rst '!!! '], sprintf('\n'),' ');
%         set(handles.Tx_Message,'String',strrep(['Missing part of links, ' ts_rst '!!! '], sprintf('\n'),' '),'ForegroundColor',[1 0 0]);
    end
else
    handles.Terminal=0;
    if ~(isunix)
        MsgAFNI=['This program is only designed for the Linux system'];
        % set(handles.Tx_Message,'String',['This program is only designed for the Linux system'],'ForegroundColor',[1 0 0]);
    elseif ~isdir(handles.DirFn)
        MsgAFNI=['Missing the "Fn" folder, Please check !!! '];
        % set(handles.Tx_Message,'String',['Missing the "Fn" folder, Please check !!! '],'ForegroundColor',[1 0 0]);
    end
end

% p_spm=which('spm.m');
% if  ~(exist(p_spm, 'file')==2)
%     MsgSPM='SPM is not detectd in PATH, Please add it !!! ';
%     handles.SPM=0;
% else
%      MsgSPM='SPM is detected in the path';
%      handles.SPM=1;
% end
% guidata(hObject, handles);


if  (handles.SPM==0)
    MsgSPM='SPM is not detectd in PATH, Please add it !!! ';
else
    MsgSPM='SPM is detected in the path';
end

if (handles.SPM==1) && (handles.Terminal==1)
    set(handles.Tx_Message,'String',[MsgSPM '; ' MsgAFNI],'ForegroundColor',[0 0 1]);
else
    set(handles.Tx_Message,'String',[MsgSPM '; ' MsgAFNI],'ForegroundColor',[1 0 0]);
end


function BtnOff(hObject, eventdata, handles)
Status_OffOn='off';FColor=0.5*ones(1,3);
set(handles.Btn_tData,'Enable',Status_OffOn)
set(handles.Btn_T1,'Enable',Status_OffOn)
set(handles.Btn_HResEPI,'Enable',Status_OffOn)
set(handles.Tx_TR,'ForegroundColor',FColor);
set(handles.Ed_TR,'Enable',Status_OffOn);
set(handles.Ck_DftTPrep,'Enable',Status_OffOn);
set(handles.Tx_Pnl_taskSetting,'ForegroundColor',FColor);
set(handles.Tx_Pnl_taskPrep,'ForegroundColor',FColor);
%||-----------------------------------------------------------------------|
%||	[ Task Setting ]
%||-----------------------------------------------------------------------|
set(handles.Tx_tName,'ForegroundColor',FColor);
set(handles.PMenu_tName,'Enable',Status_OffOn)
set(handles.Tx_Onset,'ForegroundColor',FColor);
set(handles.PMenu_tOnset,'Enable',Status_OffOn)
set(handles.Tx_Duration,'ForegroundColor',FColor);
set(handles.PMenu_tDuration,'Enable',Status_OffOn)
set(handles.Tx_tData,'ForegroundColor',FColor);
set(handles.Pnl_taskSetting,'ForegroundColor',FColor);
set(handles.Pnl_taskPrep,'ForegroundColor',FColor);

set(handles.Ed_tName,'Enable',Status_OffOn)
set(handles.Ed_tOnset,'Enable',Status_OffOn)
set(handles.Ed_tDuration,'Enable',Status_OffOn)

set(handles.Btn_ExecuteTask,'Enable',Status_OffOn)

set(handles.Ck_tSliceT,'Enable',Status_OffOn);

set(handles.Tx_SliceTime1,'ForegroundColor',0.5*ones(1,3));
set(handles.Tx_SliceTime2,'ForegroundColor',0.5*ones(1,3));
set(handles.PMenu_SliceTime,'Enable',Status_OffOn);


set(handles.Ck_tMCRT,'Enable',Status_OffOn);
set(handles.Ck_tFMCRT,'Enable',Status_OffOn);
set(handles.Ck_tDDdnt,'Enable',Status_OffOn);
set(handles.Ck_Despike,'Enable',Status_OffOn');
set(handles.Ck_tBlur,'Enable',Status_OffOn);
set(handles.Ck_Coreg,'Enable',Status_OffOn);
set(handles.PMenu_Regmm,'Enable',Status_OffOn);
set(handles.BtnGrp_Reg,'ForegroundColor',FColor);
set(handles.RBtn_BBR,'Enable',Status_OffOn)
set(handles.RBtn_CBR,'Enable',Status_OffOn);
set(handles.RBtn_IBR,'Enable',Status_OffOn);
set(handles.Ed_FWHM,'Enable',Status_OffOn);
set(handles.Tx_FWHM,'ForegroundColor',FColor);

%||=======================================================================|
%|| [Button Setting]
%||=======================================================================|
function BtnSetting(hObject, eventdata, handles)
global Idx_Execute
%||-----------------------------------------------------------------------|
%||	[ Default : X / O ]
%||-----------------------------------------------------------------------|
% <Task PreProcess : on / off >

if (exist(handles.pTData,'file')==2)
    set(handles.Tx_TR,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_Pnl_taskSetting,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_Pnl_taskPrep,'ForegroundColor',0*ones(1,3));
    set(handles.Ed_TR,'Enable','on');
else
    set(handles.Tx_TR,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_Pnl_taskSetting,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_Pnl_taskPrep,'ForegroundColor',0.5*ones(1,3));
    set(handles.Ed_TR,'Enable','off');
end
%     &&(exist(handles.pT1,'file')==2)
if (exist(handles.pTData,'file')==2)
    Status_OffOn='on';FColor=0*ones(1,3);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
set(handles.Ck_DftTPrep,'Enable',Status_OffOn);
set(handles.Btn_T1,'Enable',Status_OffOn)
set(handles.Btn_HResEPI,'Enable',Status_OffOn)

% if  (get(handles.Ck_DftTPrep,'Value')==0)
%     Status_OffOn='on';FColor=0*ones(1,3);
% else
%     Status_OffOn='off';FColor=0.5*ones(1,3);
% end

%||-----------------------------------------------------------------------|
%||	[ Task Setting ]
%||-----------------------------------------------------------------------|
set(handles.Tx_tName,'ForegroundColor',FColor);
set(handles.PMenu_tName,'Enable',Status_OffOn)
set(handles.Tx_Onset,'ForegroundColor',FColor);
set(handles.PMenu_tOnset,'Enable',Status_OffOn)
set(handles.Tx_Duration,'ForegroundColor',FColor);
set(handles.PMenu_tDuration,'Enable',Status_OffOn)

set(handles.Tx_tData,'ForegroundColor',FColor);

set(handles.Pnl_taskSetting,'ForegroundColor',FColor);
set(handles.Pnl_taskPrep,'ForegroundColor',FColor);


if (get(handles.PMenu_tName,'Value')==5)
    set(handles.Ed_tName,'Enable',Status_OffOn)
else
    set(handles.Ed_tName,'Enable','off')
end

if (get(handles.PMenu_tOnset,'Value')==3)
    set(handles.Ed_tOnset,'Enable',Status_OffOn)
else
    set(handles.Ed_tOnset,'Enable','off')
end

if (get(handles.PMenu_tDuration,'Value')==3)
    set(handles.Ed_tDuration,'Enable',Status_OffOn)
else
    set(handles.Ed_tDuration,'Enable','off')
end

if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2) && (Idx_Execute==1)
    Status_OffOn='on';FColor=0*ones(1,3);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
set(handles.Btn_ExecuteTask,'Enable',Status_OffOn)

%||-----------------------------------------------------------------------|
%||	[ Preprocessing ]
%||-----------------------------------------------------------------------|
% <The function belong to slice timing >
if (get(handles.Ck_DftTPrep,'Value')==0)
    Status_OffOn='on';FColor=0*ones(1,3);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
% < Preprocessing:: Slice timing>------------------------------------------
set(handles.Ck_tSliceT,'Enable',Status_OffOn);
if  (get(handles.Ck_tSliceT,'Value')==1) && (get(handles.Ck_DftTPrep,'Value')==0)
    set(handles.Ck_tSliceT,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_SliceTime1,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_SliceTime2,'ForegroundColor',0*ones(1,3));
    set(handles.PMenu_SliceTime,'Enable','on');
else
    set(handles.Ck_tSliceT,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_SliceTime1,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_SliceTime2,'ForegroundColor',0.5*ones(1,3));
    set(handles.PMenu_SliceTime,'Enable','off');
end

% set(handles.Ck_tMCRT,'Enable','off');
% set(handles.Ck_tMCRT,'Value',1);

% < Preprocessing:: Motion Correction >------------------------------------
set(handles.Ck_tMCRT,'Enable',Status_OffOn);
    if  (get(handles.Ck_tMCRT,'Value')==1) && (get(handles.Ck_DftTPrep,'Value')==0)
        set(handles.Ck_tMCRT,'ForegroundColor',0*ones(1,3));
    else
        set(handles.Ck_tMCRT,'ForegroundColor',0.5*ones(1,3));
    end
    
% < Preprocessing:: Field Map Correction>----------------------------------
set(handles.Ck_tFMCRT,'Enable','off');
set(handles.Ck_tFMCRT,'Value',0);

% < Preprocessing:: CoReg to T1 >------------------------------------------
set(handles.Ck_Coreg,'Enable','off');
set(handles.Ck_Coreg,'Value',1);
set(handles.PMenu_Regmm,'Enable',Status_OffOn);
set(handles.BtnGrp_Reg,'ForegroundColor',FColor);
    % <RS Data && T1 && High Resolution EPI>
    if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2) && (exist(handles.pHRepi,'file')==2)
        set(handles.RBtn_BBR,'Value',1)
        set(handles.RBtn_BBR,'Enable',Status_OffOn)
    else
        set(handles.RBtn_BBR,'Enable','off')
    end
    set(handles.RBtn_CBR,'Enable',Status_OffOn);
    set(handles.RBtn_IBR,'Enable',Status_OffOn);

% < Preprocessing:: Despike >---------------------------------------------

set(handles.Ck_Despike,'Enable','off');
set(handles.Ck_Despike,'Value',1);

% < Preprocessing:: Detrend >----------------------------------------------
set(handles.Ck_tDDdnt,'Enable',Status_OffOn);
    if  (get(handles.Ck_tDDdnt,'Value')==1) && (get(handles.Ck_DftTPrep,'Value')==0)
        set(handles.Ck_tDDdnt,'ForegroundColor',0*ones(1,3));
    else
        set(handles.Ck_tDDdnt,'ForegroundColor',0.5*ones(1,3));
    end

% < Preprocessing:: Smooth >-----------------------------------------------
set(handles.Ck_tBlur,'Enable',Status_OffOn);
    if  (get(handles.Ck_tBlur,'Value')==1) && (get(handles.Ck_DftTPrep,'Value')==0)
        set(handles.Ck_tBlur,'ForegroundColor',0*ones(1,3));
        set(handles.Ed_FWHM,'Enable','on');
        set(handles.Tx_FWHM,'ForegroundColor',0*ones(1,3));
        
    else
        set(handles.Ck_tBlur,'ForegroundColor',0.5*ones(1,3));
        set(handles.Ed_FWHM,'Enable','off');
        set(handles.Tx_FWHM,'ForegroundColor',0.5*ones(1,3));
    end
% set(handles.Ed_FWHM,'Enable',Status_OffOn);
% set(handles.Tx_FWHM,'ForegroundColor',FColor);


%||-----------------------------------------------------------------------|
%||	[ Data Input ]
%||-----------------------------------------------------------------------|
% if (exist(handles.pTData,'file')==2)
%     set(handles.Btn_T1,'Enable',Status_OffOn)
% end
% 
% set(handles.Btn_HResEPI,'Enable',Status_OffOn)

%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function Btn_tData_Callback(hObject, eventdata, handles)
[handles]=BtnINI(hObject, eventdata, handles);
[fTData,DirIn] = uigetfile({'*.nii;*.img'},'Select Task-fMRI Data',handles.DirW);pTData=[DirIn fTData];
if isequal(fTData,0) && isequal(DirIn,0) 
    set(handles.Tx_tData,'String','Task-fMRI Data is not selected!');
    % handles.pTData='';
    StrTime=['0 ~ ???'  ' seconds'];
%     set(handles.Pnl_taskSetting,'Title',['Task Setting (#Vol= ??? ) >>> (' StrTime ')']);
     set(handles.Tx_Pnl_taskSetting,'string',['Task Setting (#Vol= ??? ) >>> (' StrTime ')']);
    set(handles.Tx_Message,'string', ['>>Select task-dataset' ],'foregroundcolor',[1 0 0])
else
%     set(handles.Tx_tData,'String',fTData);
    handles.pTData=pTData;
    handles.DirT=DirIn;
%     StuTData=load_untouch_nii(pTData);
%     handles.DimT=size(StuTData.img);
    StuTData=nifti(pTData);
    handles.DimT=size(StuTData.dat);

    if (numel(handles.DimT)>3)
        if (handles.DimT(4)>0)
%             if ~isempty(find(ismember(fieldnames(StuTData), 'timing')))
%             if isfield(StuTData,'timing')
            if ~isempty(getfield(StuTData, 'timing'))
                handles.TR=StuTData.timing.tspace;
            end
            set(handles.Ed_TR,'String',num2str(handles.TR))
            if (handles.TR>=3)
                set(handles.PMenu_tName,'Value',4);
                set(handles.PMenu_tOnset,'Value',1);handles.Onset=handles.LsTDiagram(4).Onset;
                set(handles.PMenu_tDuration,'Value',1);handles.Duration=handles.LsTDiagram(4).Duration;
            end
        end
        handles.TaskReps=handles.DimT(4);
        Dim= [sprintf('%3.3d',handles.DimT(1)) 'x' sprintf('%3.3d',handles.DimT(2)) 'x' sprintf('%3.3d',handles.DimT(3)) 'x' sprintf('%3.3d',handles.DimT(4))];
        set(handles.Tx_tData,'String',['[' Dim '] ' fTData]);
%         TEND=(handles.TaskReps-1)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
        TEND=(handles.TaskReps)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
        %set(handles.Pnl_taskSetting,'Title',['Task Setting (#Vol=' num2str(handles.TaskReps) ') >>> (' StrTime ')']);
         set(handles.Tx_Pnl_taskSetting,'string',['Task Setting (#Vol=' num2str(handles.TaskReps) ') >>> (' StrTime ')']);
        set(handles.Tx_Message,'string', ['>> ' ],'foregroundcolor',[0 0 0])
    end
end
guidata(hObject, handles);
BtnSetting(hObject, eventdata, handles)
PlotTDiagram(hObject, eventdata, handles)

function PMenu_SliceTime_Callback(hObject, eventdata, handles)
function PMenu_SliceTime_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Ed_TR_Callback(hObject, eventdata, handles)

if ~isempty(str2num(get(handles.Ed_TR,'String')))
    handles.TR=get(handles.Ed_TR,'String');
    set(handles.Tx_Message,'string', ['>> Set TR to ' get(handles.Ed_TR,'String') 'sec' ],'foregroundcolor',[0 0 1])
    % TEND=(handles.TaskReps-1)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
    TEND=(handles.TaskReps)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
    set(handles.Pnl_taskSetting,'Title',['Task Setting (#Vol=' num2str(handles.TaskReps) ') >>> (' StrTime ')']);
    % handles.TaskReps
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_TR,'String') 'is not a number' ],'foregroundcolor',[1 0 0])
end
function Ed_TR_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_tOnset_Callback(hObject, eventdata, handles)
if ~isempty(str2num(get(handles.Ed_tOnset,'String')))
    handles.Onset=str2num(get(handles.Ed_tOnset,'String'));
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
    BtnSetting(hObject, eventdata, handles)
    
    set(handles.Tx_Message,'string', ['>> Set ONSET to ' get(handles.Ed_tOnset,'String') 'sec(s)' ],'foregroundcolor',[0 0 1])
    
    if isempty(str2num(get(handles.Ed_tDuration,'String')))
        set(handles.Ed_tDuration,'String','5');handles.Duration=5;
        set(handles.Tx_Message,'string', ['>> Set ONSET to ' get(handles.Ed_tOnset,'String') 'sec(s), but random assign DURATION to 15 sec(s), please check !' ],'foregroundcolor',[0 0 1])
    end

else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_tOnset,'String') 'is not a numerical array' ],'foregroundcolor',[1 0 0])
end

function Ed_tOnset_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_tDuration_Callback(hObject, eventdata, handles)
if ~isempty(str2num(get(handles.Ed_tDuration,'String')))
    handles.Duration=str2num(get(handles.Ed_tDuration,'String'));
    set(handles.Tx_Message,'string', ['>> Set DURATION to ' get(handles.Ed_tDuration,'String') 'sec' ],'foregroundcolor',[0 0 1])
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
    BtnSetting(hObject, eventdata, handles)
else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_tDuration,'String') 'is not a number' ],'foregroundcolor',[1 0 0])
    set(handles.Ed_tDuration,'String',num2str(handles.Duration))
end



function Ed_tDuration_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function PMenu_tName_Callback(hObject, eventdata, handles)
% (Val)tName ::: (1)LETT ; (2)CAT;(3)Sentence;(4)BothHands; (5)Other
% (Val)tOnset ::: (1)[15 45 75 105 135 165] ; (2)[20 60 100 140 180 220];(3)Other;
% (Val)tDuration ::: (1)[15] ; (2)[20];(3)Other;
switch get(handles.PMenu_tName,'Value')
    case 1
        handles.Task='LETT'; % Dur=20; Onset : [20 60 100 140 180 220]
        set(handles.PMenu_tOnset,'Value',2) 
        set(handles.PMenu_tDuration,'Value',2) 
    case 2
        handles.Task='CAT';  % Dur=20; Onset : [20 60 100 140 180 220]
        set(handles.PMenu_tOnset,'Value',2)
        set(handles.PMenu_tDuration,'Value',2) 
    case 3
        handles.Task='Sentence';  % Dur=20; Onset : [20 60 100 140 180 220]
        set(handles.PMenu_tOnset,'Value',2)
        set(handles.PMenu_tDuration,'Value',2) 
    case 4
        handles.Task='BothHand'; % Dur=15; Onset : [15 45 75 105 135 165]
        set(handles.PMenu_tOnset,'Value',1)
        set(handles.PMenu_tDuration,'Value',1) 
    case 5
        handles.Task='Other';
        set(handles.PMenu_tOnset,'Value',3)
        set(handles.PMenu_tDuration,'Value',3) 
end
% handles.Duration
aaa=0;
LsTDiagram=handles.LsTDiagram;
handles.Duration=LsTDiagram(get(handles.PMenu_tName,'Value')).Duration;
handles.Onset=LsTDiagram(get(handles.PMenu_tName,'Value')).Onset;
set(handles.Ed_tDuration,'String',num2str(handles.Duration));
set(handles.Ed_tOnset,'String',num2str(handles.Onset));

guidata(hObject, handles);
% TDiagram(1).Duration=20;
PlotTDiagram(hObject, eventdata, handles);
BtnSetting(hObject, eventdata, handles)
% disp(['>>>> TASK = [' handles.Task ']'])
function PMenu_tName_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PMenu_tOnset_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_tOnset,'string');
selectedIndex = get(handles.PMenu_tOnset,'Value');
% selectedItem = allItems{selectedIndex};
switch get(handles.PMenu_tOnset,'Value')
    case 1
        handles.Onset=str2num(allItems{1});
    case 2
        handles.Onset=str2num(allItems{2});
    case 3
        handles.Onset=5;
end
set(handles.Ed_tOnset,'String',num2str(handles.Onset));
guidata(hObject, handles);
PlotTDiagram(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)


function PMenu_tOnset_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PMenu_tDuration_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_tDuration,'string');
selectedIndex = get(handles.PMenu_tDuration,'Value');
switch get(handles.PMenu_tDuration,'Value')
    case 1
        handles.Duration=str2num(allItems{1});
    case 2
        handles.Duration=str2num(allItems{2});
    case 3
        handles.Duration=5;
        
end
set(handles.Ed_tDuration,'String',num2str(handles.Duration));
guidata(hObject, handles);
PlotTDiagram(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)

function PMenu_tDuration_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Ed_tName_Callback(hObject, eventdata, handles)
function Ed_tName_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Btn_ExecuteTask.
function Btn_ExecuteTask_Callback(hObject, eventdata, handles)

 

[DirF,FN,ext] = fileparts(handles.pTData);FN=[FN ext];
FN=strrep(FN,'.nii.gz','');FN=strrep(FN,'.nii','');FN=strrep(FN,'.img','');

Idx=findstr(FN,'_');ID=FN(1:Idx(1)-1);Cnd=FN(Idx(1)+1:end);

if(get(handles.PMenu_tName,'Value')==5)
    Cnd=get(handles.Ed_tName,'String');
end

handles.Condition=Cnd;


% <Create Dir for Log file>
Dir_Log=[DirF filesep '0_LOG_files'];
if ~(exist(Dir_Log, 'dir')==7);mkdir(Dir_Log);end
cd(Dir_Log);diary TASK_STATUS.txt
    
p_Status=[Dir_Log filesep '=M2=(LOG)=TfMRI=' FN '===D' datestr(now,'yymmdd_THHMMSS')  '_Summary.txt'];
p_Diary=[Dir_Log filesep '=M2=(LOG)=TfMRI=' FN '===D' datestr(now,'yymmdd_THHMMSS')  '_Detail.txt'];

% 
% PrepIDX=[ 'T' num2str(handles.tPrep_T) ';'...
%     'M' num2str(handles.tPrep_M) ';'...
%     'F' num2str(handles.tPrep_F) ';'...
%     'D' num2str(handles.tPrep_D) ';'...
%     'S' num2str(handles.tPrep_B) ];


PrepIDX=[ 'T' num2str(get(handles.Ck_tSliceT,'Value')) ';'...
    'M' num2str(get(handles.Ck_tMCRT,'Value')) ';'...
    'F' num2str(get(handles.Ck_tFMCRT,'Value')) ';'...
    'D' num2str(get(handles.Ck_tDDdnt,'Value')) ';'...
    'S' num2str(get(handles.Ck_tBlur,'Value')) ];

PNT_PREP='_';
if (get(handles.Ck_tSliceT,'Value')==1); PNT_PREP=[PNT_PREP 'T'];end
if (get(handles.Ck_tMCRT,'Value')==1); PNT_PREP=[PNT_PREP 'M'];end
if (get(handles.Ck_tMCRT,'Value')==0); PNT_PREP=[PNT_PREP 'A'];end
if (get(handles.Ck_tFMCRT,'Value')==1); PNT_PREP=[PNT_PREP 'F'];end
if (get(handles.Ck_tDDdnt,'Value')==1); PNT_PREP=[PNT_PREP 'D1'];end
if (get(handles.Ck_tDDdnt,'Value')==0); PNT_PREP=[PNT_PREP 'DK'];end
if (get(handles.Ck_tBlur,'Value')==1); PNT_PREP=[PNT_PREP 'S' num2str(handles.FWHM) 'mm'];end
f_Prep=[FN PNT_PREP '.nii'];

% Calculate Timing
EstT=0;
if (get(handles.Ck_tSliceT,'Value')==1);EstT=EstT+72;end
if (get(handles.Ck_tMCRT,'Value')==1);EstT=EstT+85;end
if (get(handles.Ck_tMCRT,'Value')==0);EstT=EstT+85;end
if (get(handles.Ck_tDDdnt,'Value')==1);EstT=EstT+110 ;end
if (get(handles.Ck_tDDdnt,'Value')==0);EstT=EstT+15;end
if (get(handles.Ck_tBlur,'Value')==1); EstT=EstT+40;end

EstT=EstT+60; % For GLM

Dir_Ttmp=[DirF filesep Cnd filesep 'Fd_Temp'];
if ~(exist(Dir_Ttmp, 'dir')==7);mkdir(Dir_Ttmp); end

Dir_T=[DirF filesep Cnd];
if ~(exist(Dir_T, 'dir')==7);mkdir(Dir_T); end

% -----------------------------------------------------------<Check Result>
% p_Prep=[Dir_T filesep FN PNT_PREP '_tMap%CBR_T1' '.nii'];

cd (Dir_T)
f_StatRst=['Stat_GLM_task_' FN PNT_PREP '_tMap%*BR_T1' '.nii'];
Ck_RstFile=dir(f_StatRst);

if  (numel(Ck_RstFile)>0) f_StatRst=Ck_RstFile.name; end
p_StatRst=[Dir_T filesep f_StatRst];

% -------------------------------------------------------<Compose a Script>
if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2)
    %               <0>       <1>                        <2>     <3>     <4>     <5>    <6>     <7>
    formatBasic ='cd %s \n bash %sFn_MDAS1_taskPrep.sh -t "%s" -T "%s" -a "%s" -z "%s" -P "%s" -O "%s" -F "%s"';
    cmdStrBasic = sprintf(formatBasic,[handles.DirFn],[handles.DirFn filesep],handles.pTData,num2str(handles.TR),handles.pT1,handles.tPattern,PrepIDX,DirF,[handles.DirFn]);
    %                                        <0>     ,           <1>         ,<2> task Data ,       <3> TR      ,  <4>  pT1 ,  <5> tPattern  ,<6>PREP,<7>Script DIR
    if  (get(handles.RBtn_CBR,'Value')==1)
        cmdStrReg=sprintf('%s -c "y"',cmdStrBasic);
    elseif (get(handles.RBtn_IBR,'Value')==1)
        cmdStrReg=sprintf('%s -c "n"',cmdStrBasic);
    elseif (get(handles.RBtn_BBR,'Value')==1)
        cmdStrReg=sprintf('%s -j "%s" -c "n"',cmdStrBasic,handles.pHRepi);
    end
    
    STR_Onset=strrep(num2str(handles.Onset),'    ',' ');STR_Onset=strrep(STR_Onset,'   ',' ');STR_Onset=strrep(STR_Onset,'  ',' ');
    cmdStrTaskPar=sprintf('%s -S "%s" -D "%s"',cmdStrReg,STR_Onset,num2str(handles.Duration));
    
    if(get(handles.PMenu_tName,'Value')==5)
        cmdStrFdN=sprintf('%s -o "%s"',cmdStrTaskPar,Cnd);
    else
        cmdStrFdN=cmdStrTaskPar;
    end
    cmdStr=sprintf('%s | tee "%s"',cmdStrFdN,p_Status);
%     cmdStr=sprintf('%s | tee "%s"',cmdStrTaskPar,p_Status);
    %         cmdStr=sprintf('%s | tee "%s"',cmdStrReg,p_Status);
else
    cmdStr=sprintf('cd %s \n sh %sFn_MDAS1_taskPrep.sh',[handles.DirFn],[handles.DirFn filesep]);
end

% ----------------------------------------------------<Start preprocessing>
% -----------------------------------------------------------<Segmentation>
h = waitbar(0,['Start preprocessing...']);
set(handles.Tx_Message,'string', ['>> Starting preprocessing ! Creating folders and checking files' ],'foregroundcolor',[0 0 1])
BtnOff(hObject, eventdata, handles);set(handles.Btn_tData,'Enable','off');
waitbar(0.10,h,['[1/2] Checking Segmentation files']);
p_spm=which('spm.m');
if  (exist(p_spm, 'file')==2) 
    set(handles.Btn_ExecuteTask,'Enable','off');set(handles.Btn_ExecuteTask,'String','BUSY !!!')
    pause(0.5)

    Dir_Seg=[DirF filesep '2_T1Segment'];
    if ~(exist(Dir_Seg, 'dir')==7);mkdir(Dir_Seg); end
    cd(Dir_Seg);
    disp('|| ');disp('|| Conducting segmentation via SPM');disp('|| ');
   
    % NiiGz_T1 = load_untouch_nii(handles.pT1);
    fT1=handles.fT1;fT1=strrep(fT1,'.nii.gz','');fT1=strrep(fT1,'.nii','');fT1=strrep(fT1,'.img','');
    pT1Nii=[Dir_Seg filesep fT1 '.nii'];
    pT1Seg1=[Dir_Seg filesep 'c1' fT1 '.nii'];
     if ~(exist(pT1Nii, 'file')==2)
         copyfile(handles.pT1,pT1Nii);
%         Output=NiiGz_T1;
%         Output.img(:,:,:)=0;Output.img(:,:,:)=double(NiiGz_T1.img(:,:,:));
%         save_untouch_nii(Output, pT1Nii);
     end
    if ~(exist(pT1Seg1, 'file')==2)
        waitbar(0.11,h,['[1/2] Segmentation usually takes 5 mins.']);
        set(handles.Tx_Message,'string', ['>> Segmentation usually takes 5 mins. Once completed, the next step will automatically initiate' ],'foregroundcolor',[0 0 1])
        tstart = tic;
        addpath([handles.DirFn]);cd(Dir_Seg);Fn_batch_SPM12_Segment([fT1 '.nii']);
        telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for segmentation: ' num2str(telapsed) ' sec(s), or ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)']);disp('|| ');
    else
        waitbar(0.15,h,['[1/2] Segmentated files already exist !!']);
        set(handles.Tx_Message,'string', ['>> Segmentated files already exist  !!' ],'foregroundcolor',[0 0 1])
        disp('|| ');disp('|| Segmentated files already exist !!');disp('|| ');
    end
end

% -------------------------------------------------------------<Processing>     

system(['rm -f ' p_StatRst])

if (exist(p_StatRst)==2)
%     if numel(f_StatRst)>42
%         set(handles.Tx_Message,'String',['task-dataset exist: ' f_StatRst(end-42-1:end) '. Please move to the next module'],'ForegroundColor',[0 0 1]);
%     else
        set(handles.Tx_Message,'String',['task-dataset exist: ' f_StatRst '. Please move to the next module'],'ForegroundColor',[0 0 1]);
%     end
    disp('|| ');disp(['|| The task-dataset ' f_StatRst 'exist. Please move to the next module']);disp('|| ');
    waitbar(1,h,['[2/2] The task-dataset exist. Please move to the next module']);pause(2)
    close(h);
    BtnSetting(hObject, eventdata, handles);
else
    if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2)
        waitbar(0.5,h,['[2/2] The task-dataset processing takes about ' num2str(floor(EstT/60)+1) ' min(s)']);
        set(handles.Tx_Message,'string', ['>> The task-dataset processing takes about ' num2str(floor(EstT/60)+1) ' mins. Further details are displayed in the command window. ' ],'foregroundcolor',[0 0 1])
        pause(0.01)
        disp('|| ');disp('|| EXECUTE Bash file');disp(['>>    ' cmdStr]);disp('|| ');
        tstart = tic; system(cmdStr);telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for task-dataset processing: ' num2str(telapsed) ' sec, or ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec']); disp('|| ');
        diary off
        
        cd(Dir_Log);
        if (exist('TASK_STATUS.txt')==2)
            movefile('TASK_STATUS.txt', p_Diary);
            if (exist(p_Diary)==2);delete(p_Status); end
        end
        pause(0.1)
        set(handles.Tx_Message,'string', ['>> Done ! ' 'Computation time for task-dataset processing: ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec' ],'foregroundcolor',[0 0 1])
        set(handles.Btn_tData,'Enable','on')
        set(handles.Btn_T1,'Enable','on')
        set(handles.Btn_HResEPI,'Enable','on')
        BtnSetting(hObject, eventdata, handles)
        waitbar(1,h,['Done !']);
        
        %         set(handles.Btn_ExecuteTask,'String','Execute');set(handles.Btn_ExecuteTask,'Enable','on')
        close(h)
    else
        set(handles.Tx_Message,'String',['SPM is not detectd in PATH, Please add it !!! '],'ForegroundColor',[1 0 0]);
    end
end
set(handles.Btn_ExecuteTask,'String','Processing')

function pushbutton6_Callback(hObject, eventdata, handles)
function Btn_T1_Callback(hObject, eventdata, handles)
[fT1,DirIn] = uigetfile({'*.nii;*.img'},'Select High-Resoultion T1 Image',handles.DirT);pT1=[DirIn fT1];
if isequal(fT1,0) && isequal(DirIn,0) 
    set(handles.Tx_T1,'String','High-Resoultion T1 Image is not selected!');
    handles.pT1='';
else
    handles.pT1=pT1;
%     StuT1=load_untouch_nii(pT1);
%     handles.DimT1=size(StuT1.img);
    StuT1=nifti(pT1);
    handles.DimT1=size(StuT1.dat);

    if (numel( handles.DimT1)>3)
        handles.pT1='';
        set(handles.Tx_T1,'String',['[#Vol=' num2str(handles.DimT1(4)) '] ' 'T1 data should not be a 4D Dataset, please check!']);
    else
        handles.pT1=pT1;
        handles.StuT1=StuT1;
        handles.fT1=fT1;
        Dim= [sprintf('%3.3d',handles.DimT1(1)) 'x' sprintf('%3.3d',handles.DimT1(2)) 'x' sprintf('%3.3d',handles.DimT1(3))];
        set(handles.Tx_T1,'String',['[' Dim '] ' fT1]);
        handles.MtxT1=double(StuT1.dat);  
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);PlotTDiagram(hObject, eventdata, handles)

function Btn_HResEPI_Callback(hObject, eventdata, handles)

[fHRepi,DirIn] = uigetfile({'*.nii;*.img'},'Select High-Resolution EPI for Boundar-Based Registration',handles.DirT);pHRepi=[DirIn fHRepi];
if isequal(fHRepi,0) && isequal(DirIn,0) 
    set(handles.Tx_HRepi,'String','File is not selected!');
    handles.pHRepi='';
else
    
%     StuHRepi=load_untouch_nii(pHRepi);
%     handles.DimHRepi=size(StuHRepi.img);

    StuHRepi=nifti(pHRepi);
    handles.DimHRepi=size(StuHRepi.dat);

    Dim3DT=handles.DimT(1)*handles.DimT(2)*handles.DimT(3);
    Dim3DHRepi=handles.DimHRepi(1)*handles.DimHRepi(2)*handles.DimHRepi(3);
    Dim= [sprintf('%3.3d',handles.DimHRepi(1)) 'x' sprintf('%3.3d',handles.DimHRepi(2)) 'x' sprintf('%3.3d',handles.DimHRepi(3))];
    if (Dim3DHRepi<Dim3DT)
        handles.pHRepi='';
        set(handles.Tx_HRepi,'String',[ 'The Dimenstion of high-resoultion EPI MUST LARGER THAN that of task-dataset']);
    else
        handles.pHRepi=pHRepi;
        set(handles.Tx_HRepi,'String',['[' Dim '] ' fHRepi]);   
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles)


function Ck_DftTPrep_Callback(hObject, eventdata, handles)
if (get(handles.Ck_DftTPrep,'Value')==1)
    set(handles.Ck_tSliceT,'Value',handles.tPrep_T);
    set(handles.Ck_tMCRT,'Value',handles.tPrep_M);
    set(handles.Ck_tFMCRT,'Value',handles.tPrep_F);
    set(handles.Ck_Despike,'Value',1);
    set(handles.Ck_tDDdnt,'Value',handles.tPrep_D);
    set(handles.Ck_tBlur,'Value',handles.tPrep_B);
end
BtnSetting(hObject, eventdata, handles)

function Ck_tSliceT_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)

function Ck_tMCRT_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)

function Ck_tFMCRT_Callback(hObject, eventdata, handles)

function Ck_Coreg_Callback(hObject, eventdata, handles)

function Ck_Despike_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)

function Ck_tDDdnt_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)


function Ck_tBlur_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)

function Ed_FWHM_Callback(hObject, eventdata, handles)
FWHM=get(handles.Ed_FWHM, 'string');
if ~isnan(str2double(FWHM))
        handles.FWHM=[str2double(FWHM)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Set Smooth with ' FWHM 'mm FWHM'],'foregroundcolor',[0 0 0])
else
    set(handles.Ed_FWHM,'string',num2str(handles.FWHM))
    set(handles.Tx_Message,'string',['Check !!!   "' FWHM '"   is not a number !'],'foregroundcolor',[1 0 0])
end


% --- Executes during object creation, after setting all properties.
function Ed_FWHM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ed_FWHM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PMenu_Regmm_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_Regmm,'string');
selectedIndex = get(handles.PMenu_Regmm,'Value');
switch get(handles.PMenu_Regmm,'Value')
    case 1
        handles.RegRSmm=2;
    case 2
        handles.RegRSmm=3;
end
guidata(hObject, handles);
function PMenu_Regmm_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Btn_Exit.
function Btn_Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Btn_Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close


