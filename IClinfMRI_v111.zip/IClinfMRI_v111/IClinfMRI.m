function varargout = IClinfMRI(varargin)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright ? 2017 The University of Texas MD Anderson Cancer Center
% ||   
% ICLINFMRI MATLAB code for IClinfMRI.fig
%      ICLINFMRI, by itself, creates a new ICLINFMRI or raises the existing
%      singleton*.
%
%      H = ICLINFMRI returns the handle to a new ICLINFMRI or the handle to
%      the existing singleton*.
%
%      ICLINFMRI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ICLINFMRI.M with the given input arguments.
%
%      ICLINFMRI('Property','Value',...) creates a new ICLINFMRI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before IClinfMRI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to IClinfMRI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help IClinfMRI

% Last Modified by GUIDE v2.5 23-Jun-2017 16:11:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @IClinfMRI_OpeningFcn, ...
                   'gui_OutputFcn',  @IClinfMRI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before IClinfMRI is made visible.
function IClinfMRI_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for IClinfMRI
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
clc;
BtnINI(hObject, eventdata, handles);

% UIWAIT makes IClinfMRI wait for user response (see UIRESUME)
% uiwait(handles.Fig_IClinfMRI);
function [handles]=BtnINI(hObject, eventdata, handles)

ffig='IClinfMRI.fig';
pfig=which(ffig);

if (exist(pfig,'file')==2)
    [DirM,~,ext]=fileparts(pfig);
else
    error(['Can Not find "ffig", please check matlab path ']);
end

set(handles.Fig_IClinfMRI,'Name','IClinfMRI (1.1.1)')
% V (1.1.1) : Update the description of bash code


if isdir(DirM)
    DirFn=[DirM filesep 'Fn'];handles.DirFn=DirFn; guidata(hObject, handles);
    p_Logo=[DirFn filesep 'MDA_logo.tif'];handles.p_Logo=p_Logo;
    
    imshow(p_Logo,'Parent',handles.Ax_logo);

    DirDemo=[DirM filesep 'DEMO'];
    addpath(genpath(DirFn))
    addpath(DirM)
    %cd(DirM)
    % cd(DirDemo)
end
% <Set FIG Position>
ScreenSz = get(0,'ScreenSize');ScreenH=ScreenSz(4);
FigSz=getpixelposition(handles.Fig_IClinfMRI);FigH=FigSz(4);

FigX=10;
FigY=round((ScreenH-FigH))-33;
setpixelposition(handles.Fig_IClinfMRI,[FigX FigY FigSz(3:4)])


% --- Outputs from this function are returned to the command line.
function varargout = IClinfMRI_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;
% clc;
% ffig='IClinfMRI.fig';
% pfig=which(ffig);
% 
% if (exist(pfig,'file')==2)
%     [DirM,~,ext]=fileparts(pfig);
% else
%     error(['Can Not find "ffig", please check matlab path ']);
% end
% 
% set(handles.Fig_IClinfMRI,'Name','IClinfMRI (170601)')
% if isdir(DirM)
%     DirFn=[DirM filesep 'Fn'];handles.DirFn=DirFn; guidata(hObject, handles);
%     p_Logo=[DirFn filesep 'MDA_logo.tif'];handles.p_Logo=p_Logo;
%     
%     imshow(p_Logo,'Parent',handles.Ax_logo);
% 
%     DirDemo=[DirM filesep 'DEMO'];
%     addpath(genpath(DirFn))
%     addpath(DirM)
%     %cd(DirM)
%     % cd(DirDemo)
% end
% % <Set FIG Position>
% ScreenSz = get(0,'ScreenSize');ScreenH=ScreenSz(4);
% FigSz=getpixelposition(handles.Fig_IClinfMRI);FigH=FigSz(4);
% 
% FigX=10;
% FigY=round((ScreenH-FigH))-33;
% setpixelposition(handles.Fig_IClinfMRI,[FigX FigY FigSz(3:4)])


function Btn_DCMCategorize_Callback(hObject, eventdata, handles)
% fLOC
dcm_Import;


function Btn_SeedIDN_Callback(hObject, eventdata, handles)
% fLocalize;
TfMRI

function Btn_sGUIDrs_Callback(hObject, eventdata, handles)
% sGUIDfcMap;
RSfMRI

function Btn_CVRMap_Callback(hObject, eventdata, handles)
% cvrMap
CVRMapping

function Btn_fmri2pacs_Callback(hObject, eventdata, handles)
fmri2pacs;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
