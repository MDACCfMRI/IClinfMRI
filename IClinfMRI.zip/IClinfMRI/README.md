# IClinfMRI

Please cite the following publication if you use any of this code/script/methods in a publication:

Hsu AL, Hou P, Johnson JM, Wu CW, Noll KR, Prabhu SS, Ferguson SD, Kumar VA, Schomer DF, Hazle JD, Chen JH, Liu HL. IClinfMRI software for integrating functional MRI techniques in presurgical
mapping and clinical studies. Front Neuroinform. 2018 Mar 9;12:11. doi:10.3389/fninf.2018.00011.

------------------------------------------------------------------------
                                                            Installation
------------------------------------------------------------------------
This software requires 
(1) SPM12 v6685 (http://www.fil.ion.ucl.ac.uk/spm/software/spm12/)
(2) dcm2nii (https://www.nitrc.org/projects/dcm2nii/)
(3) AFNI (https://afni.nimh.nih.gov/)
to be installed and their functionalities verified before using IClinfMRI.

*Since AFNI is designed to run on Unix or Mac OS, those using a Windows operating system must install a virtual machine to run IClinfMRI.


After downloading this software, please unzip the IClinfMRI.zip file to a local directory. 

Under the MATLAB environmentm,
the user can click on “Set Path” and add the local directory containing IClinfMRI to the path to complete the installation

------------------------------------------------------------------------
                                                         Getting started
------------------------------------------------------------------------

In the MATLAB command window, type:

	IClinfMRI 

to opens the main GUI window. 

Key arguments specified in the functions are described in the published paper (doi:10.3389/fninf.2018.00011).

