function varargout = dcm_Import(varargin)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright (c) 2017 The University of Texas MD Anderson Cancer Center
% ||   
% DCM_IMPORT MATLAB code for dcm_Import.fig
%      DCM_IMPORT, by itself, creates a new DCM_IMPORT or raises the existing
%      singleton*.
%
%      H = DCM_IMPORT returns the handle to a new DCM_IMPORT or the handle to
%      the existing singleton*.
%
%      DCM_IMPORT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DCM_IMPORT.M with the given input arguments.
%
%      DCM_IMPORT('Property','Value',...) creates a new DCM_IMPORT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before dcm_Import_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to dcm_Import_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @dcm_Import_OpeningFcn, ...
    'gui_OutputFcn',  @dcm_Import_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before dcm_Import is made visible.
function dcm_Import_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;
% 
% global Idx_ROpt
% Idx_ROpt=[1 0 0];
% handles.DirW=pwd;
% set(handles.RBtn_S,'Value',Idx_ROpt(1));
% set(handles.RBtn_MS,'Value',Idx_ROpt(2));
% set(handles.RBtn_MSS,'Value',Idx_ROpt(3));
% 
% set(handles.Table_SubFd,'ColumnName',{'SN','ACQ Imgs','#files','Ser. Des.','Folder Name'},'ColumnEditable',false,'fontname','Lucida Sans Unicode');
% set(handles.Table_SubFd,'ColumnWidth',{'auto','auto','auto','auto','auto'});
% set(handles.Table_Att,'RowName',[],'ColumnName',{'MRN','Age','Gender','DoB','Name'},'ColumnEditable',false,'fontname','Lucida Sans Unicode');
% set(handles.Table_Att,'ColumnWidth',{'auto','auto','auto','auto','auto'});
% 
% guidata(hObject, handles);
BtnINI(hObject, eventdata, handles)


function BtnINI(hObject, eventdata, handles)
set(handles.Fig_dcm_Import,'Name','DICOM Import');

global Idx_ROpt
Idx_ROpt=[1 0 0];
handles.DirW=pwd;
set(handles.RBtn_S,'Value',Idx_ROpt(1));
set(handles.RBtn_MS,'Value',Idx_ROpt(2));
set(handles.RBtn_MSS,'Value',Idx_ROpt(3));

set(handles.Table_SubFd,'ColumnName',{'SN','ACQ Imgs','#files','Ser. Des.','Folder Name'},'ColumnEditable',false,'fontname','Lucida Sans');
set(handles.Table_SubFd,'ColumnWidth',{'auto','auto','auto','auto','auto'});
set(handles.Table_Att,'RowName',[],'ColumnName',{'MRN','Age','Gender','DoB','Name'},'ColumnEditable',false,'fontname','Lucida Sans');
set(handles.Table_Att,'ColumnWidth',{'auto','auto','auto','auto','auto'});

guidata(hObject, handles);

Status='off';Fcolor=0.5*ones(1,3);
set(handles.RBtn_S,'Enable',Status);set(handles.RBtn_MS,'Enable',Status);set(handles.RBtn_MSS,'Enable',Status);
set(handles.Pnl_folderOpt,'ForegroundColor',Fcolor);
set(handles.Ck_Rename,'Enable',Status);set(handles.Ck_Convert,'Enable',Status);set(handles.Btn_Execute,'Enable',Status);
set(handles.Table_Att,'Enable',Status);set(handles.Table_SubFd,'Enable',Status);
set(handles.Ck_Rename,'Value',1);set(handles.Ck_Convert,'Value',0);set(handles.Ck_Convert,'Enable',Status);
set(handles.Ls_cmd, 'String', {'>> '});
set(handles.Ed_ID, 'String', '');
set(handles.Ed_ID, 'Enable', Status);
set(handles.Ed_ID, 'ForegroundColor', Fcolor);
set(handles.Tx_ID, 'ForegroundColor', Fcolor);
% set(handles.Tx_Info,'string',[''],'foregroundcolor',[0 0 0])

if isfield(handles,'PatInto');  handles = rmfield( handles , 'PatInto' );end
tbl=get(handles.Table_Att,'Data'); tbl(:)={''};
set(handles.Table_Att,'Data',tbl);
if isfield(handles,'Tbl_Data');  handles = rmfield( handles , 'Tbl_Data' );end
tbl=get(handles.Table_SubFd,'Data'); tbl(:)={''};
set(handles.Table_SubFd,'Data',tbl);
set(handles.Btn_Execute,'String','Execute');

% Check Unit System
% if (isunix); set(handles.Ck_Convert,'Enable','on');set(handles.Ck_Convert,'Value',1);else set(handles.Ck_Convert,'Value',0);end
if (isunix);set(handles.Ck_Convert,'Value',1);else set(handles.Ck_Convert,'Value',0);end
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = dcm_Import_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;
clc;
ffig='IClinfMRI.fig';
pfig=which(ffig);

if (exist(pfig,'file')==2)
    [DirM,~,ext]=fileparts(pfig);
else
    error(['Can Not find "ffig", please check matlab path ']);
end

if isdir(DirM)
    DirFn=[DirM filesep 'Fn'];handles.DirFn=DirFn; guidata(hObject, handles);
%     DirDemo=[DirM filesep 'DEMO'];
    addpath(genpath(DirFn))
    addpath(DirM)
    % cd(DirM)
    % cd(DirDemo)
end


% % --- Executes on button press in Btn_DirWork.
% function Btn_DirWork_Callback(hObject, eventdata, handles)
% DirCur=pwd; DirW = uigetdir(DirCur);
% handles.DirW=DirW;guidata(hObject, handles);
% % length('abcdefghijklmnopqrstvuwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345')
% if length(DirW)>55
%     DirW=['~' DirW(end-55+2:end)];
% end
% set(handles.Tx_DirW,'String',DirW);


% --- Executes on button press in Btn_DirDCM.
function Btn_DirDCM_Callback(hObject, eventdata, handles)
BtnINI(hObject, eventdata, handles);pause(0.1)
DirDCM = uigetdir(handles.DirW,'Please Select a "Directory" that contains DICOM folder(s)');
if isnumeric(DirDCM)
if (DirDCM==0)
    DirDCM='';
end
end
handles.DirDCM=DirDCM;guidata(hObject, handles);
set(handles.Ls_cmd, 'String', {'>> '});
if ~(exist(handles.DirDCM,'dir')==7)
% if ~(exist(handles.DirDCM,'dir')==7) | (DirDCM==0)
    set(handles.Tx_Info,'string',['Please Select a "Directory" that contains DICOM folder(s)'],'foregroundcolor',[1 0 0])
    BtnINI(hObject, eventdata, handles)
elseif (exist(handles.DirDCM,'dir')==7)
    handles.DirW=DirDCM;guidata(hObject, handles);
    clear Tbl_Data
    % -------------------------------------------------------- [Folder List]
    set(handles.Ed_DirDCM,'String',DirDCM,'fontname','Lucida Sans');
    Fds = dir(DirDCM);
    Fds(~[Fds.isdir]) = [];  %remove non-directories
    Fdsname =char({Fds.name}');  
    Fds(find(Fdsname(:,1)=='.')) = [];  %remove file/directories who start with '.'
%     tf = ismember( {Fds.name}, {'.', '..'});
%     Fds(tf) = [];  %remove current and parent directory.
    lengthSerN=0;lengthSerDes=0;lengthFd=0;lengthACQImgs=0;lengthAllfiles=0;
%     d=0;
    dcmfd=0;
    clear LsRst 
    h = waitbar(0,['Examine on folder...']);
    for dd=1:numel(Fds)
        %          d=2
        files=dir([DirDCM filesep Fds(dd).name]);
        filesname =char({files.name}');  
        files(find(filesname(:,1)=='.')) = [];  %remove file/directories who start with '.'
        files([files.isdir]) = [];  %remove directories
        % pIn='C:\Users\AHSU\RScript_Toolbox\Matalb\UI_IClinfMRI_IPVL5\DEMO\01_Import\20170410\1.2.840.114350.2.412.2.798268.2.72697272.1\===(LOG)_Import_P2151183.txt';
        LsRst{dd}=[' Examine on folder ' sprintf('%03d',dd) '/' sprintf('%03d',numel(Fds)) '>>>'];
        waitbar(dd/(numel(Fds)+1),h,LsRst{dd});
        set(handles.Ls_cmd, 'String', LsRst);pause(0.1)
        if (numel(files)>0)
            % To avoid non-dcm files in the folder, probing Idx_dcm from the
            % following stript
            Cell_FNs={files.name}'; 
            Cell_Dirs=cell(size(Cell_FNs));Cell_Dirs(:)={[DirDCM filesep Fds(dd).name filesep]};
            %Cell_pFiles=cellstr([cat(1, Cell_Dirs{:}) cat(1, Cell_FNs{:})]);
            Cell_pFiles=cellstr([char(Cell_Dirs{:}) char(Cell_FNs{:})]);
%             Idx_dcm=find(~cellfun(@isempty,strfind(Cell_FNs,'.dcm'))==1);
%             if isempty(Idx_dcm)
%                 LengthFNs=cellfun(@length, Cell_FNs);UVal=unique(LengthFNs);
%                 clear count; for u=1:length(UVal) count(u)=sum(LengthFNs==UVal(u)); end; [M,I] = max(count);
%                 Idx_dcm=find(LengthFNs==UVal(I));
%             end
            if (numel(Cell_pFiles)<20);Idx_dcm=cellfun(@isdicom,Cell_pFiles);end
            if (numel(Cell_pFiles)>=20);Idx_dcm=cellfun(@isdicom,Cell_pFiles(1:20));end
            if (numel(Cell_pFiles)>50);Idx_dcm=cellfun(@isdicom,Cell_pFiles(1:50));end
            if (sum(Idx_dcm)==0);Idx_dcm=cellfun(@isdicom,Cell_pFiles); end
            %pIn=[DirDCM filesep Fds(dd).name filesep files(Idx_dcm(1)).name];
            if (sum(Idx_dcm)>0)
            pIn=Cell_pFiles{min(find(Idx_dcm==1))};
            %if isdicom(pIn)
%                 d=d+1;
                dcmfd=dcmfd+1;
                HDRIn= dicominfo(pIn);
                if (dcmfd==1)
                    %PatInto(dcmfd,:)={HDRIn.PatientID,HDRIn.PatientAge,HDRIn.PatientSex,HDRIn.PatientBirthDate,[HDRIn.PatientName.GivenName ', ' HDRIn.PatientName.FamilyName]};
                    clear PatientID;PatientID=HDRIn.PatientID;PatientID=strrep(PatientID,'_','');PatientID=strrep(PatientID,' ','');PatientID=strrep(PatientID,'-','');
                    
                    if ~isfield(HDRIn,'PatientAge'); HDRIn.PatientAge=999;end
                    if ~isfield(HDRIn,'PatientSex'); HDRIn.PatientSex='NA';end
                    if ~isfield(HDRIn,'PatientBirthDate'); HDRIn.PatientSex=99999999;end
                    if ~isfield(HDRIn,'PatientName'); HDRIn.PatientName='NA';end
                    
                    if strcmp(HDRIn.PatientName,'NA')
                        PatientName='NA';
                    else
                        if isfield(HDRIn.PatientName,'GivenName')
                            PatientName=[HDRIn.PatientName.GivenName ', ' HDRIn.PatientName.FamilyName];
                        else
                            PatientName=HDRIn.PatientName.FamilyName;
                        end
                    end

                    PatInto(dcmfd,:)={PatientID,HDRIn.PatientAge,HDRIn.PatientSex,HDRIn.PatientBirthDate,PatientName};
                    set(handles.Ed_ID,'String',PatientID,'fontname','Lucida Sans');
                end
                SerN=num2str(HDRIn.SeriesNumber);
                SerDes=HDRIn.SeriesDescription;
                SerDes=strrep(SerDes,'fMRI','');SerDes=strrep(SerDes,'-','');SerDes=strrep(SerDes,' ','');
                SerDes=strrep(SerDes,'_.','_');SerDes=strrep(SerDes,'/','');
                SerDes=strrep(SerDes,'(','');SerDes=strrep(SerDes,')','');SerDes=strrep(SerDes,'*','_STAR');
                SerDes=strrep(SerDes,'>','_');SerDes=strrep(SerDes,'+','_');SerDes=strrep(SerDes,':','_');
                SerDes=strrep(SerDes,'_','');
                if isfield(HDRIn,'ImagesInAcquisition');nImgs=HDRIn.ImagesInAcquisition;else nImgs=-1; end
                if isfield(HDRIn,'NumberOfTemporalPositions');nt=HDRIn.NumberOfTemporalPositions;else nt=1; end
                ACQImgs=num2str(nImgs*nt);
                %Allfiles=num2str(sum(Idx_dcm));
                Allfiles=num2str(numel(Cell_pFiles));
                
                if (numel(Cell_pFiles)>2*nImgs*nt)
                    Idx_dcm=cellfun(@isdicom,Cell_pFiles);
                    ACQImgs=num2str(sum(Idx_dcm));
                end
                
                % Calculte the lenght for table display
                if (length(SerN)>lengthSerN);lengthSerN=length(SerN); end
                if (length(ACQImgs)>lengthACQImgs);lengthACQImgs=length(ACQImgs); end
                if (length(Allfiles)>lengthAllfiles);lengthAllfiles=length(Allfiles); end
                %  if (length(SerDes)>lengthSerDes);lengthSerDes=length(SerDes); end
                lengthSerDes=lengthSerDes+length(SerDes);
                if (length(Fds(dd).name)>lengthFd);lengthFd=length(Fds(dd).name); end
                % Update table info
                Tbl_Data(dcmfd,:)={SerN,ACQImgs,Allfiles,SerDes,Fds(dd).name};
                
                set(handles.Table_Att,'Data',PatInto,'fontname','Lucida Sans');
                set(handles.Table_SubFd,'Data',Tbl_Data,'fontname','Lucida Sans');
                
            end
        end
        LsRst{dd}=[ LsRst{dd} 'Done'];
        set(handles.Ls_cmd, 'String', LsRst,'fontname','Lucida Sans');
    end
    waitbar(1,h,'Compelte the folder examination');
    close(h)
    if (dcmfd>0)
        lengthSerDes=round(lengthSerDes/dcmfd)+3;
        set(handles.Tx_Info,'string', [ num2str(dcmfd) ' DICOM folder(s) detected in the assigned folder' ],'foregroundcolor',[0 0 1])
        handles.PatInto=PatInto;
        handles.Tbl_Data=Tbl_Data;
        guidata(hObject, handles);
        
        set(handles.Table_Att,'Data',PatInto,'fontname','Lucida Sans');
%         set(handles.Table_Att,'ColumnWidth',{'auto','auto','auto','auto','auto'});
        set(handles.Table_Att,'ColumnWidth',{'auto','auto','auto','auto',11*length(PatInto{5})});
        set(handles.Table_SubFd,'Data',Tbl_Data,'fontname','Lucida Sans');
        set(handles.Table_SubFd,'ColumnWidth',num2cell(11*[lengthSerN+1,lengthACQImgs+2,lengthAllfiles,lengthSerDes,lengthFd]));
        % -------------------------------------------------- [Save to txt file]
        
        % <Create Dir for Log file>
        Dir_Log=[DirDCM filesep '0_LOG_files'];
        if ~(exist(Dir_Log, 'dir')==7);mkdir(Dir_Log);end
        
        p_txt=[Dir_Log filesep '=M1=(LOG)=Import_Info=' PatInto{1,1} '===D' datestr(now,'yymmdd_THHMMSS') '.txt'];
        fileID = fopen(p_txt,'w');
        StrLn='=============================================================================';
        StrLn2='-----------------------------------------------------------------------------';
        fprintf(fileID, '%40s \n',StrLn);
        fprintf(fileID, '%40s \n',['Assigbed folder: [' DirDCM ']']);
        fprintf(fileID, '%40s \n',StrLn2);
        H={'MRN','Age','Gender','DoB','Name'};
        fprintf(fileID, '%15s %8s %8s %15s %20s \n',H{1,:});
        fprintf(fileID, '%40s \n',StrLn2);
        fprintf(fileID, '%15s %8s %8s %15s %20s \n',PatInto{1,:});
        
        H={'SN','ACQ Imgs','#Imgs','Ser. Des.','Folder Name'};
%         H={'SN','Ser. Des.','Folder Name','ACQ Imgs','#Imgs'};
        fprintf(fileID, '%40s \n',StrLn);
        %     pformat=['%15s %20s \n'];
        pformat=['%' num2str(lengthSerN+1) 's ' '%' num2str(lengthACQImgs+3) 's ' '%' num2str(lengthAllfiles+3) 's ' '%' num2str(lengthSerDes+1) 's ' '%' num2str(lengthFd+1) 's ' '\n'];
        %pformat=['%' num2str(lengthSerN+1) 's %' num2str(lengthFd+1) 's \n'];
        fprintf(fileID,pformat,H{1,:});
        fprintf(fileID, '%40s \n',StrLn2);
        C = [Tbl_Data];
        [nrows,ncols] = size(C);
        for row = 1:nrows
            fprintf(fileID,pformat,C{row,:});
        end
        fprintf(fileID, '%40s \n',StrLn);
        fclose(fileID);
        
        Status='on';Fcolor=0*ones(1,3);
        set(handles.RBtn_S,'Enable',Status);set(handles.RBtn_MS,'Enable',Status);set(handles.RBtn_MSS,'Enable',Status);
        set(handles.Pnl_folderOpt,'ForegroundColor',Fcolor);
        set(handles.Ck_Rename,'Enable','off');
        set(handles.Btn_Execute,'Enable',Status);
        set(handles.Table_Att,'Enable',Status);set(handles.Table_SubFd,'Enable',Status);
        set(handles.Ed_ID, 'Enable', Status);
        set(handles.Ed_ID, 'ForegroundColor', Fcolor);
        set(handles.Tx_ID, 'ForegroundColor', Fcolor);
        set(handles.Ck_Rename,'Enable',Status);
        if (isunix);set(handles.Ck_Convert,'Enable',Status);else set(handles.Ck_Convert,'Value',0);end
    else
        set(handles.Tx_Info,'string',['NO DICOM FOLDER detected in the assigned folder'],'foregroundcolor',[1 0 0])
    end
    
end

function edit1_Callback(hObject, eventdata, handles)
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% function Btn_Import_Callback(hObject, eventdata, handles)
function Btn_Execute_Callback(hObject, eventdata, handles)
global Idx_ROpt
PatInto=handles.PatInto;
Tbl_Data=handles.Tbl_Data;
%||	---------------------------------------------< Rename (O) & Convert(O)>
if (get(handles.Ck_Rename,'Value')==1) || (get(handles.Ck_Convert,'Value')==1)
    set(handles.Btn_Execute,'Enable','off');set(handles.Btn_Execute,'String','BUSY !!!')
    set(handles.RBtn_S,'Enable','off');set(handles.RBtn_MS,'Enable','off');set(handles.RBtn_MSS,'Enable','off');
    set(handles.Ck_Rename,'Enable','off');set(handles.Ck_Convert,'Enable','off')
    
    set(handles.Tx_Info,'string',['Process takes 5-8 mins'],'foregroundcolor',[0 0 1]) 
    pause(0.05)
    disp(['-----------------------------------------------------------------'])
    clear LsRst
    % <Create Dir for Log file>
    Dir_Log=[handles.DirDCM filesep '0_LOG_files'];
    if ~(exist(Dir_Log, 'dir')==7);mkdir(Dir_Log);end
    p_Diary=[Dir_Log filesep '=M1=(LOG)=ImportStatus=' PatInto{1} '===' datestr(now,'yymmdd_THHMMSS')  '_Detail.txt'];
    
    % p_Diary=[handles.DirDCM filesep '===(LOG)_' PatInto{1} 'dcm_Import===D' datestr(now,'yymmdd_THHMMSS')  '_Detail.txt'];
    if (exist('diary','file')==2)
        delete ('diary')
    end
    cd(handles.DirDCM);
    diary DCM2NII_STATUS.txt
    disp('|| ');disp('|| Conduct DICOM Import');disp('|| ');
    tic
    h = waitbar(0,['Conduct DICOM Import']);
    
    for d=1:size(handles.Tbl_Data,1)
        % ----------------------------------------< Assign Folder Name>
        if (Idx_ROpt(1)==1) && (Idx_ROpt(2)==0) && (Idx_ROpt(3)==0)
            NewFdN=Tbl_Data{d,4};
        elseif (Idx_ROpt(1)==0) && (Idx_ROpt(2)==1) && (Idx_ROpt(3)==0)
            NewFdN=[PatInto{1} '_' Tbl_Data{d,4}];
        elseif (Idx_ROpt(1)==0) && (Idx_ROpt(2)==0) && (Idx_ROpt(3)==1)
            NewFdN=[PatInto{1} '_' Tbl_Data{d,4} '_' sprintf('%3.3d',str2num(Tbl_Data{d,1})) ];
        end
        Fd_NameORI=Tbl_Data{d,5};
        NewFdN=['DCM_' NewFdN];
        pntBar=Tbl_Data{d,5};pntBar=strrep(pntBar,'_','-');
        pntNewFdN=NewFdN;pntNewFdN=strrep(pntNewFdN,'_','-');
        %waitbar(d / [size(handles.Tbl_Data,1)+1],h,['Working on ['  sprintf('%03d',d) '/' sprintf('%03d',size(handles.Tbl_Data,1)) ']"' strrep(NewFdN,'DCM_','') '"']);
        waitbar(d / [size(handles.Tbl_Data,1)+1],h,['Working on ['  sprintf('%03d',d) '/' sprintf('%03d',size(handles.Tbl_Data,1)) ']"' pntNewFdN '"']);
        
        % =========== [Rename]=============================================
        if (get(handles.Ck_Rename,'Value')==1)
            % ----------------------------------------------< Folder Exist>
            if (exist([handles.DirDCM filesep Fd_NameORI],'dir')==7)
                if ~strcmp(Fd_NameORI,NewFdN)
                    LsRst{d}=[' Rename ' '[' Fd_NameORI ']' ' as '  '[' NewFdN '] ...  '];
                else
                    LsRst{d}=['[' Fd_NameORI ']' ' == '  '[' NewFdN '] ...  '];
                end
            else
                LsRst{d}=['Dir does NOT EXIST : ' '[' Fd_NameORI ']' '.. '];
            end
            disp(LsRst{d})
            set(handles.Ls_cmd, 'String', LsRst);pause(0.1)
            % -------------------------------------------< Folder Renaming>
            if (exist([handles.DirDCM filesep Fd_NameORI],'dir')==7)
                if ~strcmp(Fd_NameORI,NewFdN)
                    movefile([handles.DirDCM filesep Fd_NameORI],[handles.DirDCM filesep NewFdN])
                end
            end
        end
        
        % =========== [Convert]============================================
        if (get(handles.Ck_Convert,'Value')==1)
            if (exist([handles.DirDCM filesep Fd_NameORI],'dir')==7) || (exist([handles.DirDCM filesep NewFdN],'dir')==7)
                if (exist([handles.DirDCM filesep Fd_NameORI],'dir')==7)
                    DirDCMtmp=[handles.DirDCM filesep Fd_NameORI];
                elseif (exist([handles.DirDCM filesep NewFdN],'dir')==7)
                   DirDCMtmp=[handles.DirDCM filesep NewFdN];
                end
                % ----------------------------------< Convert to NIFTI>
                if (str2num(Tbl_Data{d,2})<=str2num(Tbl_Data{d,3})) && (str2num(Tbl_Data{d,2})>0)
                    
                    % fOut=[PatInto{1} '_' Tbl_Data{d,4}];
                    
                    if (Idx_ROpt(1)==1) && (Idx_ROpt(2)==0) && (Idx_ROpt(3)==0)
                        fOut=[PatInto{1} '_' Tbl_Data{d,4}];
                    elseif (Idx_ROpt(1)==0) && (Idx_ROpt(2)==1) && (Idx_ROpt(3)==0)
                        fOut=[PatInto{1} '_' Tbl_Data{d,4}];
                    elseif (Idx_ROpt(1)==0) && (Idx_ROpt(2)==0) && (Idx_ROpt(3)==1)
                        fOut=[PatInto{1} '_' Tbl_Data{d,4} sprintf('%3.3d',str2num(Tbl_Data{d,1}))];
                    end
                    
                    pOut=[handles.DirDCM filesep fOut '.nii'];
                    LsRst{d}=[''];
                    if (exist(pOut,'file')==2)
                        LsRst{d}=[LsRst{d} 'Done || NIFTI EXIST ALREADY ! ... '];pause(0.05)
                    else
                        LsRst{d}=[LsRst{d} 'Done || Convert to NIFTI ... '];pause(0.05)
                        %                <0>                        <1>    <2>     <3>    <4>
                        formatSpec ='bash %sFn_MDAP0_DCM2NII.sh -I "%s" -o "%s" -O "%s" -S "%s"';
                        cmdStr=sprintf(formatSpec,[handles.DirFn filesep],DirDCMtmp,fOut,[handles.DirDCM],[handles.DirFn filesep]);
                        %                             <0>  DirFn         ,<1> Dir DCM,<2>fOut,<3>Dir output,<4> Script Dir
                        system(cmdStr);
                        
                        if ~isempty(dir([DirDCMtmp filesep '*.nii']))
                           system(['rm -f ' DirDCMtmp filesep '*.nii'] ); 
                        end
                    end
                else
                    LsRst{d}=[LsRst{d} 'Done || No raw DICOM(s) in the assigned folder '];pause(0.1)
                end
            end
        end
        LsRst{d}=[LsRst{d} 'Done'];
        
    end
    set(handles.Ls_cmd, 'String', LsRst);
    disp(['-----------------------------------------------------------------'])
    set(handles.Btn_Execute,'String','Done !');pause(2)
    
    
    toc;disp('|| ');
    diary off
    if (exist('DCM2NII_STATUS.txt')==2)
        movefile('DCM2NII_STATUS.txt', p_Diary);
    end
    set(handles.Tx_Info,'string',['Finished. Please move to the next module'],'foregroundcolor',[0 0 1])
    close(h);
    
    set(handles.Btn_Execute,'Enable','on');set(handles.Btn_Execute,'String','Execute')
    set(handles.RBtn_S,'Enable','on');set(handles.RBtn_MS,'Enable','on');set(handles.RBtn_MSS,'Enable','on');
    
    set(handles.Ck_Rename,'Enable','on');
    if (isunix);set(handles.Ck_Convert,'Enable','on');else set(handles.Ck_Convert,'Value',0);end
    
else
    set(handles.Tx_Info,'string',['Please the option(s) you want !'],'foregroundcolor',[1 0 0])
end

% --- Executes on button press in RBtn_S.
function RBtn_S_Callback(hObject, eventdata, handles)
function RBtn_MS_Callback(hObject, eventdata, handles)
function RBtn_MSS_Callback(hObject, eventdata, handles)
function Pnl_folderOpt_SelectionChangeFcn(hObject, eventdata, handles)
global Idx_ROpt
switch get(eventdata.NewValue,'Tag')
    case 'RBtn_S'
        Idx_ROpt=[1 0 0];
    case 'RBtn_MS'
        Idx_ROpt=[0 1 0];
    case 'RBtn_MSS'
        Idx_ROpt=[0 0 1];
end
set(handles.RBtn_S,'Value',Idx_ROpt(1));
set(handles.RBtn_MS,'Value',Idx_ROpt(2));
set(handles.RBtn_MSS,'Value',Idx_ROpt(3));

function Ck_Rename_Callback(hObject, eventdata, handles)
function Ck_Convert_Callback(hObject, eventdata, handles)


function Ls_cmd_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ls_cmd_Callback(hObject, eventdata, handles)


function Ed_ID_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_ID_Callback(hObject, eventdata, handles)

set(handles.Tx_Info,'String',['Change ID from [' handles.PatInto{1} '] to [' get(handles.Ed_ID, 'string')  ']'],'fontname','Lucida Sans');
handles.PatInto{1}=get(handles.Ed_ID, 'string');
guidata(hObject, handles);
