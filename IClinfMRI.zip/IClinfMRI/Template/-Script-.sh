#!/bin/tcsh -xef

DirT="/Volumes/LINGU3_32G/UI_IClinfMRI_VB/Template"
# DirLPBA40="${DirT}/LPBA40"
cd ${DirT}
pMNI="$(ls ${DirT}/MNI152_T1_2mm_brain.nii)"
pMsk="$(ls ${DirT}/MNI152_T1_2mm_brain_mask.nii)"

#--------------[ Extract Language Related Areas from LPBA40 Template]---------------------------||
#-----------------------------------------------------------------------------------------------||

pAtlas="$(ls ${DirT}/LPBA40.FLIRT.nifti/maxprob/lpba40.flirt.avg152T1_brain.gm.label.nii.gz)"
Array1=(23 24 25 26 45 46 47 48 81 82)
Array2=(BRl23 BRr24 BRl25 BRr26 WRl45 WRr46 WRl47 WRr48 WRl81 WRr82)
Fn_Tool_[ROI_Extraction].sh -i "${pAtlas}" -n 10 -A "${Array1[@]}" "${Array2[@]}"

fOut="lpba40_LnBR_4Lbls.nii.gz"
rm -f ${fOut}; 
3dcalc -a "lpba40.flirt.avg152T1_brain.gm.label_ROI_BRl23.nii.gz" \
-b  "lpba40.flirt.avg152T1_brain.gm.label_ROI_BRr24.nii.gz" \
-c "lpba40.flirt.avg152T1_brain.gm.label_ROI_BRl25.nii.gz" \
-d  "lpba40.flirt.avg152T1_brain.gm.label_ROI_BRr26.nii.gz" \
-e "${pMsk}" -expr 'ispositive(a+b+c+d)*ispositive(e)' -prefix ${fOut}

fOut="lpba40_LnWR_6Lbls.nii.gz"
rm -f ${fOut}; 
3dcalc -a "lpba40.flirt.avg152T1_brain.gm.label_ROI_WRl45.nii.gz" \
-b "lpba40.flirt.avg152T1_brain.gm.label_ROI_WRr46.nii.gz" \
-c "lpba40.flirt.avg152T1_brain.gm.label_ROI_WRl47.nii.gz" \
-d "lpba40.flirt.avg152T1_brain.gm.label_ROI_WRr48.nii.gz" \
-e "lpba40.flirt.avg152T1_brain.gm.label_ROI_WRl81.nii.gz" \
-f "lpba40.flirt.avg152T1_brain.gm.label_ROI_WRr82.nii.gz" \
-g "${pMsk}" -expr 'ispositive(a+b+c+d+e+f)*ispositive(g)' -prefix ${fOut}


fOut="lpba40_LnAll_10Lbls.nii.gz"
rm -f ${fOut}; 
3dcalc -a "lpba40_LnBR_4Lbls.nii.gz" -b "lpba40_LnWR_6Lbls.nii.gz" \
-c "${pMsk}" -expr 'ispositive(a+b)*ispositive(c)' -prefix ${fOut}

#--------------[ Multiple Meta Result & LPBA40 Template]---------------------------------------||
#-----------------------------------------------------------------------------------------------||
# afni -orient RAI -flipim
fMeta="$(ls ${DirT}/NiiGz/language_Reverse_pFgA_z_FDR_0.01.nii.gz)"
fMetaMsk="anguage_Reverse_pFgA_z_FDR_0.01_Msk.nii.gz"
fMetaMsk_Ext="anguage_Reverse_pFgA_z_FDR_0.01_MskExtFWHM8mm.nii.gz"
# rm -f ${fMetaMsk}; 3dcalc -a "${fMeta}" -b "${pMsk}" -expr 'ispositive(a)*ispositive(b)' -prefix "${fMetaMsk}"
rm -f ${fMetaMsk_Ext}; 3dcalc -a "${fMetaMsk_Ext}" -b"${fMetaMsk_Ext}" -prefix "${fMetaMsk_Ext}" -dilate_input 2

# << Broca's >>

fLnMsk="$(ls lpba40_LnBR_4Lbls.nii.gz)"
fMetaExtMskInLnMsk="LnMetaExtMsk_IN_$(echo $fLnMsk | cut -d '.' -f 1).nii.gz"; 
rm -f ${fMetaExtMskInLnMsk}; 3dcalc -a "${fMetaMsk_Ext}" -b "${fLnMsk}" -expr 'ispositive(a)*ispositive(b)' -prefix "${fMetaExtMskInLnMsk}"

fMetaMskInLnMsk="LnMetaMsk_IN_$(echo $fLnMsk | cut -d '.' -f 1).nii.gz"; 
rm -f ${fMetaMskInLnMsk}; 3dcalc -a "${fMetaMsk}" -b "${fLnMsk}" -expr 'ispositive(a)*ispositive(b)' -prefix "${fMetaMskInLnMsk}"


# fMetaInLnMsk="LnMeta_IN_$(echo $fLnMsk | cut -d '.' -f 1).nii.gz"; 
# rm -f ${fMetaInLnMsk}; 3dcalc -a "${fMeta}"-b "${fMetaMsk_Ext}" -c "${fLnMsk}" -expr 'a*ispositive(b)' -prefix "${fMetaInLnMsk}"


# # <<Save Focus Region as mask>>
# fLnMskF="$(echo $fMetaInLnMsk | cut -d '.' -f 1)_TH9.nii.gz"; 
# 3dclust -1Dformat -nosum -1dindex 0 -1tindex 0 -2thresh -9 9 -dxyz=1 -savemask ${fLnMskF} 1.01 100 "${fMetaInLnMsk}"

# IdxCluster='2';
# fLnMskF_CS="$(echo $fMetaInLnMsk | cut -d '.' -f 1)_TH9_ClusMsk${IdxCluster}.nii.gz";
# rm -f ${fLnMskF_CS}; 3dcalc -a ${fLnMskF} -expr 'equals(a,2)' -prefix "$fLnMskF_CS"
# fMetaInLnFocusMsk="LnMeta_IN_$(echo $fLnMsk | cut -d '.' -f 1)_F.nii.gz"; 
# rm -f $fMetaInLnFocusMsk;3dcalc -a "${fMeta}" -b "${fLnMskF_CS}" -expr 'a*ispositive(b)' -prefix "${fMetaInLnFocusMsk}"

# << Wernicke's >>
# fLnMsk="$(ls lpba40_LnWR_4Lbls.nii.gz)"
# fMetaInLnMsk="LnMeta_IN_$(echo $fLnMsk | cut -d '.' -f 1).nii.gz"; 
# rm -f fMetaInLnMsk; 3dcalc -a "${fMeta}" -b "${fLnMsk}" -expr 'a*ispositive(b)' -prefix "${fMetaInLnMsk}"

fLnMsk="$(ls lpba40_LnWR_6Lbls.nii.gz)"
fMetaExtMskInLnMsk="LnMetaExtMsk_IN_$(echo $fLnMsk | cut -d '.' -f 1).nii.gz"; 
rm -f ${fMetaExtMskInLnMsk}; 3dcalc -a "${fMetaMsk_Ext}" -b "${fLnMsk}" -expr 'ispositive(a)*ispositive(b)' -prefix "${fMetaExtMskInLnMsk}"

fMetaMskInLnMsk="LnMetaMsk_IN_$(echo $fLnMsk | cut -d '.' -f 1).nii.gz"; 
rm -f ${fMetaMskInLnMsk}; 3dcalc -a "${fMetaMsk}" -b "${fLnMsk}" -expr 'ispositive(a)*ispositive(b)' -prefix "${fMetaMskInLnMsk}"


# # <<Save Focus Region as mask>>
# fLnMskF="$(echo $fMetaInLnMsk | cut -d '.' -f 1)_TH9.nii.gz"; 
# 3dclust -1Dformat -nosum -1dindex 0 -1tindex 0 -2thresh -9 9 -dxyz=1 -savemask ${fLnMskF} 1.01 100 "${fMetaInLnMsk}"

# IdxCluster='1';
# fLnMskF_CS="$(echo $fMetaInLnMsk | cut -d '.' -f 1)_TH9_ClusMsk${IdxCluster}.nii.gz";
# rm -f ${fLnMskF_CS}; 3dcalc -a ${fLnMskF} -expr "equals(a,${IdxCluster})" -prefix "$fLnMskF_CS"
# fMetaInLnFocusMsk="LnMeta_IN_$(echo $fLnMsk | cut -d '.' -f 1)_F.nii.gz"; 
# rm -f $fMetaInLnFocusMsk;3dcalc -a "${fMeta}" -b "${fLnMskF_CS}" -expr 'a*ispositive(b)' -prefix "${fMetaInLnFocusMsk}"

# fslmaths "LnFDR%2009cIN_lpba40_LnBRF.nii.gz" -add "LnFDR%2009cIN_lpba40_LnWRF.nii.gz" "LnFDR%2009cIN_lpba40_LnBFWF.nii.gz"


3dcalc -a "LnMetaExtMsk_IN_lpba40_LnBR_4Lbls.nii.gz" -expr 'a' -prefix 'MNI152_MetaExt_LangB.nii'
3dcalc -a "LnMetaExtMsk_IN_lpba40_LnWR_6Lbls.nii.gz" -expr 'a' -prefix 'MNI152_MetaExt_LangW.nii'

3dcalc -a 'MNI152_MetaExt_LangB.nii' -b 'MNI152_MetaExt_LangW.nii' -expr 'ispositive(a+b)' -prefix 'MNI152_MetaExt_LangBW.nii'

3dcalc -a "LnMetaMsk_IN_lpba40_LnBR_4Lbls.nii.gz" -expr 'a' -prefix 'MNI152_Meta_LangB.nii'
3dcalc -a "LnMetaMsk_IN_lpba40_LnWR_6Lbls.nii.gz" -expr 'a' -prefix 'MNI152_Meta_LangW.nii'
3dcalc -a 'MNI152_Meta_LangB.nii' -b 'MNI152_Meta_LangW.nii' -expr 'ispositive(a+b)' -prefix 'MNI152_Meta_LangBW.nii'

#--------------[ Generate MNI Searching Areas]-------------------------------------------------||
#----------------------------------------------------------------------------------------------||

# pLnMetaBF="$(ls ${DirT}/LnMeta_IN_lpba40_LnBR_2Lbls_TH9_ClusMsk2.nii.gz)"
# pLnMetaWF="$(ls ${DirT}/LnMeta_IN_lpba40_LnWR_4Lbls_TH9_ClusMsk1.nii.gz)"

pLnAtlasB="$(ls ${DirT}/lpba40_LnBR_2Lbls.nii.gz)"
pLnAtlasW="$(ls ${DirT}/lpba40_LnWR_4Lbls.nii.gz)"

# <<Find max meta value as the center of searching area>> --------------------------------------||

pRptB="${DirT}/TXT_ClusterRptB.txt"
pCenterB="${DirT}/TXT_CenterMassB.txt"; 
pRptW="${DirT}/TXT_ClusterRptW.txt"
pCenterW="${DirT}/TXT_CenterMassW.txt"; 

rm -f ${pRptB}; 3dclust -dxyz=1 1.01 10 ${pLnMetaBF} > ${pRptB}
rm -f ${pCenterB}; 1dcat ${pRptB}'[1..3]' | sed -n 1p > "${pCenterB}"

rm -f ${pRptW}; 3dclust -dxyz=1 1.01 10 ${pLnMetaWF} > ${pRptW}
rm -f ${pCenterW}; 1dcat ${pRptW}'[1..3]' | sed -n 1p > "${pCenterW}"

for RadiusB in 6 12 18 24
do
# RadiusB='24'
RadiusB="$(zeropad ${RadiusB} 2)"
echo "|| R = $RadiusB >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
# pSAreaB="${DirT}/SAreaB_$(echo `basename $pLnMetaBF` | sed 's/.nii.gz//g')_R${RadiusB}.nii.gz"
pSAreaB="${DirT}/MNI152_SAreaB_R${RadiusB}.nii.gz"
MR_Ori="$(echo $(sed -n 7p "${pRptB}") | cut -d '=' -f 2 | cut -d ' ' -f 2)"
rm -f ${pSAreaB}; 3dUndump -srad ${RadiusB} -master ${pMNI} -orient ${MR_Ori} -mask ${pLnAtlasB} -prefix "${pSAreaB}" -xyz ${pCenterB} 
done

for RadiusW in 12 18 24 30
do
# RadiusB='6'
RadiusW="$(zeropad ${RadiusW} 2)"
echo "|| R = $RadiusW >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
pSAreaW="${DirT}/MNI152_SAreaW_R${RadiusW}.nii.gz"
# pSAreaW="${DirT}/SAreaW_$(echo `basename $pLnMetaWF` | sed 's/.nii.gz//g')_R${RadiusW}.nii.gz"
MR_Ori="$(echo $(sed -n 7p "${pRptW}") | cut -d '=' -f 2 | cut -d ' ' -f 2)"
rm -f ${pSAreaW}; 3dUndump -srad ${RadiusW} -master ${pMNI} -orient ${MR_Ori} -mask ${pLnAtlasW} -prefix "${pSAreaW}" -xyz ${pCenterW} 
done




