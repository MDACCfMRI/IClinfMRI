
function [ImOut]=Fn_ReSlice(ImIn,outputSize)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright � 2017 The University of Texas MD Anderson Cancer Center
% ||   

% clear;

% ny=5;nx=5;nz=3; %% desired output dimensions
ny=outputSize(1);nx=outputSize(2);nz=outputSize(3); %% desired output dimensions
% ny=181;nx=217;nz=181; %% desired output dimensions
[y x z]=...
   ndgrid(linspace(1,size(ImIn,1),ny),...
          linspace(1,size(ImIn,2),nx),...
          linspace(1,size(ImIn,3),nz));
ImOut=interp3(ImIn,x,y,z,'cubic');
