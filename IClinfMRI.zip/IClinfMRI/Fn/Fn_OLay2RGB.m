function [D3_RGB]=Fn_OLay2RGB(MtxImU,MtxImO,THR,idx_sv,idx_fp,CMap)
% ||
% ||  ======={ Usage :: Fn_OLay2RGB(MtxImU,MtxImO,THR,idx_sv,idx_fp) }=====
% ||
% ||  ========Fn_OLay2RGB(MtxImU,MtxImO,THR,idx_sv,idx_fp)=================
% ||                        [1]    [2]  [3]    [4]  [5]
% ||  [Descirption]:
% ||                 MtxImU :: Underlay
% ||                 MtxImO :: Overlay
% ||                 THR :: The lower and uppter threshold of overlay colormap
% ||                        THR(1): lower threshold of overlay colormap
% ||                        THR(2): upper threshold of overlay colormap
% ||                        THR(3): the opacity of overlay colormap
% ||
% ||                 (Optional) idx_sv:: the index for saving RGB map as tif
% ||
% ||                 (Optional) idx_fp:: the index for image flipping
% ||
% ||  [DEMO]:
%               pUlay ='P10_ULay.nii.gz';pOlay = 'P10_OLay.nii.gz';
%               [DirIn,fUlay] = fileparts(pUlay);fUlay = strrep(fUlay, '.nii.gz', '');fUlay = strrep(fUlay, '.nii', '');
%               StuImU=load_untouch_nii(pUlay);MtxImU=double(StuImU.img(:,:,:));
%               [DirIn,fOlay] = fileparts(pOlay);fOlay = strrep(fOlay, '.nii.gz', '');fOlay = strrep(fOlay, '.nii', '');
%               StuImO=load_untouch_nii(pOlay);MtxImO=double(StuImO.img(:,:,:));
%               THR=[0.6 2 0.8];idx_sv='n';idx_fp='n';
%               tic;[CellD3_RGB CellD3_Gray]=Fn_OLay2RGB(MtxImU,MtxImO,THR,idx_sv,idx_fp);toc
% ||
% ||
% ||  ==========================={ Usage END }=============================
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright ? 2017 The University of Texas MD Anderson Cancer Center
% ||   

IDX_DBRes='n'; % Double Resolution

if nargin < 4
    idx_sv='n';
end

Mtx_Ulay_ORI=MtxImU;
if nargin < 6
CMap='autumn';
end


% h = figure('Name','Overlay','NumberTitle','off','units','pixels','position',[500 500 200 50],'windowstyle','modal');set(gcf,'color','w');
% uicontrol('style','text','string','Processing...','units','pixels','position',[50 10 100 30],'fontsize',12,'fontname','Century Gothic','backgroundcolor',[1 1 1]);

if(sum(size(MtxImU))~=sum(size(MtxImO)))
    disp(['||          >>>  Matrix size(Underlay) ~= Matrix size(Ovelylay)....Doing Interpolation ...'])
    clear Mtx_Olay_ORI
    [Mtx_Olay_ORI]=Fn_ReSlice(MtxImO,size(MtxImU));
else
Mtx_Olay_ORI=MtxImO;
end

if strcmp(IDX_DBRes,'y')
%     disp(['||          >>>  Double the Imaging Resolution ...'])
    
    clear Mtx_Ulay Mtx_Olay
    for n=1:size(Mtx_Ulay_ORI,3)
        Mtx_Ulay(:,:,n)=interp2(squeeze(Mtx_Ulay_ORI(:,:,n)), 1);
        Mtx_Olay(:,:,n)=interp2(squeeze(Mtx_Olay_ORI(:,:,n)), 1);
    end
else
%     disp(['||          >>>  Keep the Original Imaging Resolution ...'])
    Mtx_Ulay=Mtx_Ulay_ORI;
    Mtx_Olay=Mtx_Olay_ORI;
end

% D3ULay=Mtx_Ulay;
% D3OLay=Mtx_Olay;

% if strcmp(idx_fp,'y')
%     D3ULay=fliplr(flipud(permute(Mtx_Ulay, [2 1 3])));
%     D3OLay=fliplr(flipud(permute(Mtx_Olay, [2 1 3])));
% else
%     D3ULay=flipud(permute(Mtx_Ulay, [2 1 3]));
%     D3OLay=flipud(permute(Mtx_Olay, [2 1 3]));
% end


if strcmp(idx_fp,'y')
    D3ULay=flipud(Mtx_Ulay);
    D3OLay=flipud(Mtx_Olay);
else
    D3ULay=Mtx_Ulay;
    D3OLay=Mtx_Olay;
end

% else
%     D3_R=flipud(permute(D3_RGB{1}, [2 1 3]));

% -----------------------------------------------------------[For ColorMap]
% idx_Color=[THR(1):0.01:THR(2)];
%
% Mtx_Color=zeros(size(Mtx_Olay,1),size(Mtx_Olay,2));
% nDig=floor(size(Mtx_Color,2)/numel(idx_Color));
% clear cc_tmp cc; cc_tmp=repmat(idx_Color,[nDig 1]);cc=cc_tmp(:);
% cc=repmat(cc,[1 20]);cc=cc';
% Mtx_Color(round(size(Mtx_Color,1)/2)-10:round(size(Mtx_Color,1)/2)+9,1:size(cc,2))=cc;

% -------------------------------------------------------------------------
% SclBit=64;
% SclBit=512;
SclBit=256;
THR_l=THR(1);
THR_h=THR(2);
OLay_opacity=THR(3);
% THR_l=0.3;THR_h=1;OLay_opacity= 0.9;
NumSlice=size(D3ULay,3);
if ~isempty(findobj('name','Processing'))
    close(findobj('name','Processing'));
end
F5=figure('Name','Processing','units','pixels','position',[500 500 200 50],'windowstyle','modal');
gray_cmap=colormap(gray(SclBit));close(F5)

F5=figure('Name','Processing','units','pixels','position',[500 500 200 50],'windowstyle','modal');
if strcmp(CMap,'autumn')
    % hot_cmap=colormap(hot(SclBit));%close all;
    hot_cmap=colormap(autumn(SclBit));%close all;
elseif strcmp(CMap,'jet')
    hot_cmap=colormap(jet(SclBit));%close all;
elseif strcmp(CMap,'bluehot')
    n=0;m=SclBit;
    BlueHot = [0 1 1;0 0 1;n n n; 1 0 0;1 1 0;];
    coord = linspace(1, size(BlueHot, 1), m);
    hot_cmap = interp1(BlueHot, coord, 'linear');
%     colormap(hot_cmap);imagesc([1:m]);
end
close(F5)
% -------------------[Assign Underlay data to a round number from 1~SclBit]
% Scale_Ulay=0.5*max(max(D3ULay(:,:,round(size(D3ULay,3)/2))));

% if (min(D3ULay(:))<0)
%     D3ULay=D3ULay+abs(min(D3ULay(:)));
% end
% Scale_Ulay=0.9*max(max(D3ULay(:,:,round(size(D3ULay,3)/2))));
% Scale_Ulay=max(max(D3ULay(:,:,round(size(D3ULay,3)/2))));
% D3ULay_Btm = D3ULay ./ Scale_Ulay;
% D3ULay_Btm(D3ULay_Btm>1)=1;
% D3ULay_Top = round( (SclBit-1) * D3ULay_Btm );
% D3ULay_Nor=D3ULay_Top+1;
% D3ULay_Nor(isnan(D3ULay_Nor))=1;

clear Umin Umax
% SelectedMax=max(max(D3ULay(:)));
SelectedMax=max(max(D3ULay(:,:,round(2*size(D3ULay,3)/3))));
% SelectedMax=max(max(D3ULay(:,:,round(size(D3ULay,3)/2))));
D3ULayM=D3ULay;D3ULayM(D3ULayM>SelectedMax)=SelectedMax;
Umin=min(D3ULayM(:));Umax=max(D3ULayM(:));
D3ULay_Nor= 1+ round((SclBit-1)*(D3ULayM-Umin)/(Umax-Umin));
D3ULay_Nor(D3ULay==0)=1;
% -------------------[Assign Overlay data to a round number from 1~SclBit]
% D3OLay_tmp=D3OLay;
% D3OLay_tmp(find(D3OLay<THR_l))=0;
% D3OLay_tmp(find(D3OLay>THR_h))=THR_h;
% D3OLay_Nor= 1+  round((SclBit-1) * D3OLay_tmp/max(D3OLay_tmp(:)));
% D3OLay_Nor(isnan(D3OLay_Nor))=1;

clear Umin Umax
D3OLayM=D3OLay;
D3OLayM(D3OLay<=THR_l)=THR_l;
D3OLayM(D3OLay>=THR_h)=THR_h;
Umin=min(D3OLayM(:));Umax=max(D3OLayM(:));
% Umin=THR_l;Umax=THR_h; 
D3OLay_Nor=1+round((SclBit-1)*(D3OLayM-Umin)/(Umax-Umin));D3OLay_Nor(isnan(D3OLay_Nor))=1;
% D3OLay_Nor=1+round((SclBit-1)*(D3OLayM-Umin)/(Umax));
% D3OLay_Thr=D3OLay.*( D3OLay >= THR_l );
D3OLay_Thr=( D3OLay >= THR_l );

% clear D3ULay_RGB D3OLay_RGB D3_RGB D3_Gray
% for RGB_dim = 1:3
%     D3ULay_RGB{RGB_dim} = reshape( gray_cmap(D3ULay_Nor, RGB_dim), size(D3ULay_Nor));
%     D3OLay_RGB{RGB_dim} = reshape( hot_cmap(D3OLay_Nor, RGB_dim), size(D3OLay_Nor));
%     D3_RGB{RGB_dim}=(D3OLay_Thr==0).* D3ULay_RGB{RGB_dim} + ...
%         (D3OLay_Thr>0).* ( (1-OLay_opacity) * D3ULay_RGB{RGB_dim} + (OLay_opacity)  * D3OLay_RGB{RGB_dim} );
%     D3_Gray{RGB_dim}=D3_RGB{RGB_dim};D3_Gray{RGB_dim}(D3OLay>THR_l)=1;
% end

clear  D3ULay_RGB D3OLay_RGB D3_RGB D3_Gray
for RGB_dim = 1:3
    D3ULay_RGB(:,:,:,RGB_dim) = reshape( gray_cmap(D3ULay_Nor, RGB_dim), size(D3ULay_Nor));
    D3OLay_RGB(:,:,:,RGB_dim) = reshape( hot_cmap(D3OLay_Nor, RGB_dim), size(D3OLay_Nor));
    D3_RGB(:,:,:,RGB_dim)=(D3OLay_Thr==0).* D3ULay_RGB(:,:,:,RGB_dim) + ...
        (D3OLay_Thr>0).* ( (1-OLay_opacity) * D3ULay_RGB(:,:,:,RGB_dim) + (OLay_opacity)  * D3OLay_RGB(:,:,:,RGB_dim) );
%     D3_Gray{RGB_dim}=D3_RGB{RGB_dim};D3_Gray{RGB_dim}(D3OLay>THR_l)=1;
end
% figure(5);imshow(D3_RGB(:,:,10))
%  D3_RGB(:,:,:,RGB_dim) = reshape( hot_cmap(D3_OLayT, RGB_dim), size(D3_OLayT));

% clear D3_R D3_G D3_B CellD3_RGB
% 
% if strcmp(idx_fp,'y')
%     D3_R=fliplr(flipud(permute(D3_RGB{1}, [2 1 3])));
%     D3_G=fliplr(flipud(permute(D3_RGB{2}, [2 1 3])));
%     D3_B=fliplr(flipud(permute(D3_RGB{3}, [2 1 3])));
%     
%     D3_GR=fliplr(flipud(permute(D3_Gray{1}, [2 1 3])));
%     D3_GG=fliplr(flipud(permute(D3_Gray{2}, [2 1 3])));
%     D3_GB=fliplr(flipud(permute(D3_Gray{3}, [2 1 3])));
% else
%     D3_R=flipud(permute(D3_RGB{1}, [2 1 3]));
%     D3_G=flipud(permute(D3_RGB{2}, [2 1 3]));
%     D3_B=flipud(permute(D3_RGB{3}, [2 1 3]));
%     
%     D3_GR=flipud(permute(D3_Gray{1}, [2 1 3]));
%     D3_GG=flipud(permute(D3_Gray{2}, [2 1 3]));
%     D3_GB=flipud(permute(D3_Gray{3}, [2 1 3]));
% end
% 
% 
% % D3_GR=D3_R;D3_GG=D3_G;D3_GB=D3_B;
% % 
% % D3_GR(D3OLay>THR_l)=1;D3_GG(D3OLay>THR_l)=1;D3_GB(D3OLay>THR_l)=1;
% 
% % CellD3_RGB{1}=D3_R;
% % CellD3_RGB{2}=D3_G;
% % CellD3_RGB{3}=D3_B;
% for n=1:NumSlice
%     CellD3_RGB{n}(:,:,1)=D3_R(:,:,n);
%     CellD3_RGB{n}(:,:,2)=D3_G(:,:,n);
%     CellD3_RGB{n}(:,:,3)=D3_B(:,:,n);
%     
%     CellD3_Gray{n}(:,:,1)=D3_GR(:,:,n);
%     CellD3_Gray{n}(:,:,2)=D3_GG(:,:,n);
%     CellD3_Gray{n}(:,:,3)=D3_GB(:,:,n);
%     
%     if strcmp(idx_sv,'y')
%         SPECICAL=['R(' num2str(THR(1)) '-' num2str(THR(2)) ')'] ;
%         Fd_TIF=['TIF_RGB_' SPECICAL]; %Fd_TIF=[fOlay '_RGB' SPECICAL];
%         if ~(exist(Fd_TIF,'dir')==7);mkdir(Fd_TIF);end
%         % ftif=[Fd_TIF filesep fOlay SPECICAL '_' sprintf('%3.3d',SliceN) '.tif'];
%         ftif=[Fd_TIF filesep SPECICAL '_' sprintf('%3.3d',n) '.tif'];
%         % imwritefliplr((D2_RGB),ftif);
%         imwrite(CellD3_RGB{n},ftif);
%         disp(['||          >>>  Producing the RGB Image(s) ... ' sprintf('%3.3d',n) '/' sprintf('%3.3d',NumSlice)])
%     end
% 
% end

% close(h)
% figure(1); imagesc(MtxImU(:,:,91));colormap('gray')
% figure(1); imagesc(CellD3_RGB{91});colormap('gray')

