#!/bin/sh

# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

||  =================={ Usage :: Fn_MDAP0_DCM2NII.sh }===================================
||   
||  [Purpose]:  
||
||  [Usage]: Fn_MDAP0_DCM2NII.sh [OPTIONS]
||       ex: Fn_MDAP0_DCM2NII.sh  -I "Dir_In" -o "FN_OT" -O "Dir_OT" -S "SDIR"
|| 			  
||
||  [OPTIONS]:
||            -I <Dir_In> : The Directory of the DICOM Folder
||            -S <SDIR>   : The Directory of the Scipt Folder
||
||	[Optional aguments]
||            -o <FN_OT> : The output filename (Defualt is the Done_foldername)
||            -O <Dir_OT> : The Directory of output files (default : parent dir of the DICOM folder)
||
||  -----------------------------------------------------------------------------------
||  Note: DICOM Order = [RAI]. When opening data with RAI coordinate using MANGO,  
||                              the Data Orientatio will show "X(-),Y(-),Z(+)"
||
||   (0,0)
||      ---------COLUMN-------> X [1,0,0]
||     |      
||     |        Anterior    
||     |            ^
||     |            |
||     R            | 
||     O   Right<---|---> Left
||     W            |
||     |            |
||     |            v
||     |        Posterior
||     | 
||     v
|| Y[0,1,0]
||
||  ===================================================================================
Created by Irene Hsu on 2017.05.01 (Bash shell) 
		@ MD Anderson

EOF
exit
}

#if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; # echo "||"; echo "|| fsl verson = [${fslver}]";echo "||"
  



#p_INI=$(ls $(echo `dirname $(which Fn_MDA_P0_DCM2NII.sh)`)/dcm2nii_NIFTI_GZ.ini)

# ============================================================================[TEST]====="
# p_In="/Users/ailing/0_Research/MD_Anderson/GUI_MDA/DEMO/BM_004/1_BN"
# DirOT="/Users/ailing/0_Research/MD_Anderson/GUI_MDA/DEMO/BM_004"
# Fn_MDA_P0_DCM2NII.sh -I "${p_In}" -o "BM004_BN" -O "${DirOT}"

DEMO="X"
if [ "${DEMO}" == "O" ]; then
SDIR='/mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn'
DirO='/mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/1.2.840.113696.347054.500.2487892.20151116133318'
DirDCM='/mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/1.2.840.113696.347054.500.2487892.20151116133318/1.2.840.113619.2.312.6945.201728.17564.1447675097.917'
fOut='P04_3DVOLUME_RPI'
# bash ${SDIR}/Fn_MDAP0_DCM2NII.sh -I "${DirDCM}" -o "${fOut}" -O "${DirO}"
sudo bash ${SDIR}/Fn_MDAP0_DCM2NII.sh -I "${DirDCM}" -o "${fOut}" -O "${DirO}" -S "${SDIR}"

bash /mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn/Fn_MDAP0_DCM2NII.sh -I /mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/1.2.840.113696.347054.500.2487892.20151116133318/1.2.840.113619.2.312.6945.201728.17564.1447675097.917 -o P04_3DVOLUME_RAI -O /mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/1.2.840.113696.347054.500.2487892.20151116133318 -S /mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn


# bash /mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn/Fn_MDAP0_DCM2NII.sh -I "${DirDCM}" -o "${fOut}" -O "${DirO}" -S "${SDIR}"


fi

# ============================================================================[Help]====="
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="
argn="${#}" # number of all input arguments
#argcon=${@} # all contents of the input arguments
#echo "Total $argn input arguments"

Opt_numb=0;
while getopts "I:o:O:S:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
	
    I)
        Dir_In=$OPTARG
    ;;
    o)
		FN_Assigned=$OPTARG
    ;;
    O)
		Dir_OT=$OPTARG
    ;;
    S)
		SDIR=$OPTARG
	;;
    x)
		empty=$OPTARG
    ;;
    esac
done


# ============================================================================[Main]====="

#---------------------------------------------------------------------{ START }----------#
# =======================================================================================#
#     { 01. Check the existence of Dir_OT }
# =======================================================================================#

if [ -z "${Dir_OT}" ];then 
	#Dir_OT=$(pwd)
	Dir_OT=$(dirname "$Dir_In")
fi

if [ -z "${FN_Assigned}" ];then 
	FN_Assigned="$(echo `basename $Dir_In`).nii"
else
	FN_Assigned="$(echo `basename $FN_Assigned` | sed 's/.nii.gz//g' | sed 's/.nii//g').nii";
fi


if [ -z "${SDIR}" ];then 
	# SDIR="/home/ahsu/Script"
	# SDIR=$(find $HOME -name 'Fn_MDAP0_DCM2NII.sh' | sed 's/\/Fn_MDAP0_DCM2NII.sh//g' )
	#SDIR=$(find $PWD -name 'Fn_MDAP0_DCM2NII.sh' | sed 's/\/Fn_MDAP0_DCM2NII.sh//g' ); #echo "|| $SDIR"
	SDIR='---';
fi


p_INI="${SDIR}/dcm2nii_NIFTI_GZ.ini"

echo "|| "
echo "==========================={ Infor: Fn_MDA_P0_DCM2NII.sh }======================== "
echo "|| "
BYellow='\033[1;33m';BRed='\033[1;31m';NC='\033[0m'

if [ ! -d "${SDIR}" ];then 
	echo -e "||	(0) ::  [ Script Dir] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo "||	(0) ::  [ Script Dir] =[ ${SDIR} ] "
fi

if [ ! -f "${p_INI}" ];then 
	echo -e "||	(0) ::  [ INI File  ] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo "||	(0) ::  [ INI File  ] =[ ${p_INI} ] "
fi

if [ ! -d "${Dir_In}" ];then 
	echo -e "||	(1) ::  [ DCM Folder] =[ ${BRed}NOT EXIST${NC} ]"
else
	echo "||	(1) ::  [ DCM Folder] =[ ${Dir_In} ] "
	echo "||	(2) ::  [ Dir_OT    ] =[ ${Dir_OT} ] "
	echo "||	(3) ::  [ Filename  ] =[ ${FN_Assigned} ] "
fi

if [ ! -d "${Dir_In}" ] || [ ! -f "${p_INI}" ] || [ ! -d "${SDIR}" ];then
    echo "|| ";echo -e ">>>>>>>>>>>>>>>>>>>> ${BRed}Lask of Files, Please Check !! ${NC} >>>>>>>>>>>>>>>>>>>>>>>>>>>>>";echo "|| "
    exit 1
else
	echo "|| ";echo "||	>> EXECUTING >>> ";echo "|| "
fi

echo "|| "
echo "================================================================================== "
echo "|| "




# =======================================================================================#
#     { 2. Convert DICOM to NIFTI  }
# =======================================================================================#
# cd ${Dir_In}

pOut="${Dir_OT}/${FN_Assigned}"

if [ -f "${pOut}" ];then
	 echo "|| ";echo "|| Data [ ${FN_Assigned} ] Exist Already ! ";echo "|| "
else
	echo "|| "
	echo "||>>>>> { DICOM to NIFTI } "

	rm -f ${Dir_In}*.nii
	rm -f ${Dir_In}*.nii.gz
	rm -f ${Dir_In}*.txt
	# dcm2nii -n y -b "${p_INI}" ${Dir_In}/*
	dcm2nii -b ${p_INI} ${Dir_In}
	# dcm2nii -b ${p_INI} ${Dir_In}/MR*
	# dcm2nii -b ${p_INI} *.*


	# if [ -f "$(ls ${Dir_In}/*.IMA | head -n1)" ];then  
	#  	echo "|| "
	#  	echo "||>>>>> With Extension"
	# 	echo "|| "
	# 	dcm2nii -b ${p_INI} ${Dir_In}/*.IMA
	# else
	# 	echo "|| "
	# 	echo "|| >>>>> NOT Extention"
	# 	echo "|| "
	# 	dcm2nii -b ${p_INI} ${Dir_In}/*
	# 	#dcm2nii -b ${p_INI} *.*
	# fi
	# =======================================================================================#
	#     { 3. Transform NIFTI files to be an analysed format }
	# =======================================================================================#

	#pIn="$(ls ${Dir_In}/*.nii.gz | head -n1)";
	pIn="$(ls ${Dir_In}/*.nii | head -n1)";

	echo "||";echo "||.......Convert to = [ $(echo `basename $pIn`) ]";echo "||"


	FN_In="$(echo `basename $pIn`)";  echo "$FN_In"
	fTmp="TMP_${FN_In}.nii"
	# fTmp="TMP_$(echo `basename $Dir_In`).nii.gz"
	pTmp="${Dir_OT}/${fTmp}"

	#mv "${FN_In}" "${FN_OT}" # Rename files to the assign File name
	cp "${pIn}" "${pTmp}"  # Rename files to the assign File name

	# mv "${Dir_In}/${FN_OT}" "${Dir_OT}/${FN_OT}" 


	echo "|| "
	echo "||>>>>> { Header Deoblique } " 
	3drefit -deoblique "${pTmp}" 
	3dresample -orient RAI -inset "${pTmp}" -prefix "${Dir_OT}/r${fTmp}"
	# 3dresample -orient RPI -inset "${pTmp}" -prefix "${Dir_OT}/r${fTmp}"

	# echo "|| "
	# echo "||>>>>> { (3) Reorient Header for Displaying Purpose (PART II) } "
	# ${fslver}fslreorient2std "${Dir_OT}/r${fTmp}" "${Dir_OT}/ar${fTmp}"
	# rm -f "${Dir_OT}/${fTmp}" "${Dri_OT}/r${fTmp}"
	# mv "${Dir_OT}/ar${fTmp}" "${pOut}"

	rm -f "${pTmp}" 
	mv "${Dir_OT}/r${fTmp}" "${pOut}"

	# mv "${Dir_OT}/ar${FN_OT}" "${Dir_OT}"

	# if [ ! -z "${FN_Assigned}" ];then 
	# 	FN_Assigned="$(echo `basename $FN_Assigned` | sed 's/.nii.gz//g' | sed 's/.nii//g').nii.gz";
	# fi

	rm -f ${Dir_In}/*.nii.gz
	rm -f ${Dir_In}/*.nii
fi

echo "|| "
# echo "======================={ END :: Fn_MDAP0_DCM2NII.sh  }================================" 
echo "______________________________________________________________________________________" 
echo "|| "




