#!/bin/bash

usage() {
    cat<<EOF

================== { Fn_stat_GLM.sh } ====================
||
||  [Purpose]: Linear Regression of 1st-level fMRI analysis with 1D time series
||
||  [Usage]: Fn_stat_GLM.sh [OPTIONS] <regressors[1..N]>
||
||  [OPTIONS]:
||            -i <data> : input dataset
||            -r <reference> : Experimental paradigm or seed time course (Only accept single file)
||            -m <mask file> : binary file for masking the brain (optional)
||            -o <output> : name of output file would be Stat_GLM_<output>.nii.gz
||            -O <Dir_OT> : The Directory of output files
||  [Notice]: <regressors>: Optional, and multiple regressor files are acceptable.
||
===================================================================
Created by Changwei W. Wu,PhD on 2014.1025 (Bash shell)
    @ Physiological Rhythms Laboratory, GIBME, National Central University
Modified on 2015.1121

EOF
exit
}
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi
#======================={ Parameters to change }==========================#

CPU_core=('4');

#=========================================================================#

argn="${#}" # number of all input arguments
#argcon=${@} # all contents of the input arguments
if [ "${argn}" -lt "4" ];then
    echo '|| '
    echo '|| Not enough inputs! please at least assign <data>, <output name> and <1D reference>.'
    echo '|| '
    exit 2
fi

Opt_numb=0;
while getopts "i:o:r:m:O:c" OPTION
do
    Opt_numb=$(echo ${Opt_numb}+2 |bc)
#echo $OPTION
#echo $OPTARG
    case $OPTION in
    i)
        data=$OPTARG
    ;;
    o)
        output=$OPTARG
    ;;
    r)
        ref_file=$OPTARG
    ;;
    m)
        mask=$OPTARG
    ;;
    O)
        Dir_OT=$OPTARG
    ;;
    c)
        contrast=$OPTARG
    ;;
    esac
done


output=$(echo `basename $output` | sed 's/.nii.gz//g'| sed 's/.nii//g')

if [ -z "${Dir_OT}" ];then 
    Dir_OT=$(pwd)
    # Dir_OT=$(dirname "$p_In")
fi

echo "|| "
echo "-------------------{ Examination : Fn_stat_GLM.sh}-------------------------------- "
echo "|| "
echo "||    (1) ::  [ total arguments  ] =[ $argn ] "
echo "||    (2) ::  [ option arguments ] =[ ${Opt_numb} ] "


if [ -z $ref_file ] || [ -z $data ] || [ ! -f $ref_file ] || [ ! -f $data ]; then
    echo

    echo "********* No Data or Reference info, the program CANNOT BE EXECUTED !!! ********** "
    echo "||"
    echo "||    Please remember to assign your Data, or the Reference 1D file(s) ! "
    echo "||"
    echo
    exit 3
fi

# Count the reference number and combine all regressors into one file
ref_numb="${#ref_file[@]}"
shft_numb=$(echo ${argn}-${Opt_numb}|bc)

echo "||    (3) ::  [ Regressor file(s)] =[ ${shft_numb} ] "
echo "-----------------------------------------------------------------------------------"

if [ "${shft_numb}" -eq 0 ];then

    echo "|| "
    echo "|| ~~~~~~~~~~ [ Summary ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    echo "|| ........................${ref_numb} reference －{ ${ref_file} }, no covariates. "
    echo "-----------------------------------------------------------------------------------"

    echo
elif [ "${shft_numb}" -gt 0 ];then
    rm -f ${Dir_OT}/all_regressors.txt
    ############[ Combine all covariates into single txt file ]############
    shift ${Opt_numb}
    1dcat ${@} > ${Dir_OT}/all_regressors.txt
    regr_numb=`awk 'NR==1{print NF}' ${Dir_OT}/all_regressors.txt`

    echo "|| "
    echo "|| ~~~~~~~~~~ [ Summary ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    echo "|| ........................${ref_numb} reference + ${regr_numb} covariate(s)."
    echo "-----------------------------------------------------------------------------------"
fi

#---------------{ Default Settings }---------------#
if [[ -z "$contrast" ]]; then
    contrast=1
fi
if [[ -z "${output}" ]]; then
    output='TEMP'
fi

#======================={ Create Mask if none exists }==========================#
if [ -z $mask ] || [ ! -f "$mask" ]; then
    echo "|| Creating a Temporary Mask ! "
    rm -f ${Dir_OT}/temp-mas*.nii.gz
    fslmaths "${data}" -Tmean "${Dir_OT}/temp-mask-mean.nii.gz"
    #threshold=`fslstats "temp-mask-mean.nii.gz" -P 15`
    #fslmaths "temp-mask-mean.nii.gz" -thr $threshold -bin "temp-mask.nii.gz"
    #3dAutomask -eclip -dilate 1 -prefix "temp-mask.nii.gz" "temp-mask-mean.nii.gz"
    3dcalc -a ${Dir_OT}/temp-mask-mean.nii.gz -expr 'bool(a)' -prefix ${Dir_OT}/temp-mask.nii.gz
    rm -f ${Dir_OT}/temp-mask-mean.nii.gz
    mask=$(ls -t ${Dir_OT}/temp-mask.nii.gz | awk 'NR==1')
    orig_mask='none'
fi

#=============================={Begin of Program}============================#
################
# 3dDeconvolve #
################

    ############[ Print-out Design matrix for 3dDeconvolve ]############

    rm -f ${Dir_OT}/design.txt ${Dir_OT}/temp_glm*.txt
    echo "-num_stimts ${ref_numb} " >> ${Dir_OT}/design.txt
    for ((i=0; i<${ref_numb}; i=i+1))
    do
        n=`echo $i+1|bc`
        echo "-stim_file ${n} ${ref_file[$i]} -stim_label ${n} ${ref_name[$i]} " >> ${Dir_OT}/design.txt
    done
    unset i n

    if [ "${ref_numb}" -gt "1" ] && [ "${contrast}" ];then
        glm=`echo ${cont_numb}/2|bc`
        echo "-num_glt ${glm} " >> ${Dir_OT}/design.txt
        zero_regr=$(echo `1deval -expr 0 -num ${regr_numb}`)
        for ((i=0; i<${glm}; i=i+1))
        do
            n=`echo $i+1|bc`
            ng=`echo ${i}*2|bc`
            nm=`echo ${n}*2-1|bc`
            echo "0 0 ${contrast[$ng]} ${zero_regr}" > ${Dir_OT}/temp_glm${n}.txt
            echo "-glt 1 temp_glm${n}.txt -glt_label ${n} ${contrast[$nm]}" >> ${Dir_OT}/design.txt
        done
        unset i n ng nm
    fi

############[ Begin of Main ]############ 

        # rm -f Stat_GLM_${output}* Stat_GLM_${output}_rsdu* Stat_GLM_${output}_fitt* Decon* Decon.REML_cmd
        rm -f ${Dir_OT}/Stat_GLM_${output}* ${Dir_OT}/Stat_GLM_${output}_rsdu* ${Dir_OT}/Stat_GLM_${output}_fitt* ${Dir_OT}/Decon* ${Dir_OT}/Decon.REML_cmd

        if [ -f "${Dir_OT}/all_regressors.txt" ] && [ -f "${mask}" ];then

        echo "|| "
        echo "|| ~~~~~~~~~~ [ Regress out nuissance covariates with mask ] ~~~~~~~~~~~~~~~~~~~~~~"
        echo "-----------------------------------------------------------------------------------"

        3dDeconvolve -jobs ${CPU_core} -float \
            -input "${data}" -mask "${mask}" \
            -ortvec ${Dir_OT}/all_regressors.txt "Regressors" \
            $(grep '-' ${Dir_OT}/design.txt) \
            -tout -rout -x1D_stop\
            -fitts "${Dir_OT}/Stat_GLM_${output}_fitt" \
            -errts "${Dir_OT}/Stat_GLM_${output}_rsdu" \
            -x1D "${Dir_OT}/Stat_GLM_${output}_design" \
            -xjpeg "${Dir_OT}/Stat_GLM_${output}_design.jpg"

        elif [ ! -f "all_regressors.txt" ] && [ -f "${mask}" ];then

        echo "|| "
        echo "|| ~~~ [ Mask deployed. No covariate or something wrong with covariate inputs ] ~~~"
        echo "-----------------------------------------------------------------------------------"

        3dDeconvolve -jobs ${CPU_core} -float \
            -input "${data}" -mask "${mask}" \
            $(grep '-' ${Dir_OT}/design.txt) \
            -tout -rout -x1D_stop\
            -fitts "${Dir_OT}/Stat_GLM_${output}_fitt" \
            -errts "${Dir_OT}/Stat_GLM_${output}_rsdu" \
            -x1D "${Dir_OT}/Stat_GLM_${output}_design" \
            -xjpeg "${Dir_OT}/Stat_GLM_${output}_design.jpg"

        elif [ -f "${Dir_OT}/all_regressors.txt" ] && [ ! -f "${mask}" ];then

        echo "|| "
        echo "|| ~~~~~~~~~~ [ Regress out nuissance covariates WITHOUT mask. ] ~~~~~~~~~~~~~~~~~~"
        echo "-----------------------------------------------------------------------------------"

        3dDeconvolve -jobs ${CPU_core} -float \
            -input "${data}" \
            -ortvec ${Dir_OT}/all_regressors.txt "Regressors" \
            $(grep '-' ${Dir_OT}/design.txt) \
            -tout -rout -x1D_stop\
            -fitts "${Dir_OT}/Stat_GLM_${output}_fitt" \
            -errts "${Dir_OT}/Stat_GLM_${output}_rsdu" \
            -x1D "${Dir_OT}/Stat_GLM_${output}_design" \
            -xjpeg "${Dir_OT}/Stat_GLM_${output}_design.jpg"

        elif [ ! -f "all_regressors.txt" ] && [ ! -f "${mask}" ];then

        echo "|| "
        echo "|| ~~~~~~~~~~ [ NO mask & NO covariates !!! ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        echo "-----------------------------------------------------------------------------------"

        3dDeconvolve -jobs ${CPU_core} -float \
            -input "${data}" \
            $(grep '-' ${Dir_OT}/design.txt) \
            -tout -rout -x1D_stop\
            -fitts "${Dir_OT}/Stat_GLM_${output}_fitt" \
            -errts "${Dir_OT}/Stat_GLM_${output}_rsdu" \
            -x1D "${Dir_OT}/Stat_GLM_${output}_design" \
            -xjpeg "${Dir_OT}/Stat_GLM_${output}_design.jpg"
        fi
        3dREMLfit -matrix "${Dir_OT}/Stat_GLM_${output}_design.xmat.1D" \
            -input "${data}" -mask "${mask}" \
            -tout -rout -verb -GOFORIT \
            -Rerrts "${Dir_OT}/Stat_GLM_${output}_rsdu.nii.gz" \
            -Rbuck "${Dir_OT}/Stat_GLM_${output}"
        temp=$(ls -t ${Dir_OT}/Stat_GLM_${output}*.HEAD | awk 'NR==1')
        3dcalc -a ${temp} -expr "a" -datum float -prefix "${Dir_OT}/Stat_GLM_${output}.nii.gz"
        rm -f ${Dir_OT}/Decon* ${Dir_OT}/Decon.REML_cmd temp_glm*.txt ${Dir_OT}/design.txt design.txt ${Dir_OT}/Stat_GLM_${output}_design.xmat.1D ${Dir_OT}/Stat_GLM_${output}+????.???? 0
        rm -f ${Dir_OT}/all_regressors.txt

#####[ Fittings and Errors ]#####(should be included in 3dREMLfit above)
#            -Rfitts "Stat_GLM_${output}_fitt_rsdu.nii.gz" \
#            -Rerrts "Stat_GLM_${output}_rsdu_rsdu.nii.gz" \

############[ End of Main ]############

# if [ ${orig_mask} == 'none' ];then
#     rm -f ${mask}
# fi

if [ "${orig_mask}" == "none" ];then
    rm -f ${mask}
fi

temp=$(ls -t ${Dir_OT}/Stat_GLM_${output}* | awk 'NR==1')

echo "|| "
echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| ...........`dirname  ${temp}`"
echo "|| .................`basename  ${temp}`"
echo "-----------------------------------------------------------------------------------"
echo "|| "
echo "------------------------{ DONE !!! Fn_stat_GLM.sh}-------------------------------- "
echo "|| "
unset mask Nregr n i temp out1 out2

################## {End of Program} ##################