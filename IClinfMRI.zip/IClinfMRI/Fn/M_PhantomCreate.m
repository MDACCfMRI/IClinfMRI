% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright � 2017 The University of Texas MD Anderson Cancer Center
% ||   
clear;clc
[fOlay,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select one Ref Nii');pOlay=[DirIn fOlay];
Stu=load_untouch_nii(pOlay);Mtx=0*double(Stu.img(:,:,:));

nROW=size(Mtx,1);
nClm=size(Mtx,2);
nSlice=size(Mtx,3);
PntSz=[num2str(nROW) 'x' num2str(nClm) 'x' num2str(nSlice)];
W=15;
Phantom=zeros(nROW,nROW);
Phantom(1:(nROW/2),1:(nROW/2))=nROW/4;Phantom(1:(nROW/2),(nROW/2)+1:end)=-1*nROW/4;
Phantom((nROW/2)+1:end,1:(nROW/2))=-1*nROW/8;Phantom((nROW/2)+1:end,(nROW/2)+1:end)=nROW/8;

Phantom(1:W,:)=repmat([-1*(nROW/2):1:(nROW/2)-1],W,1);
Phantom(end+1-W:end,:)=repmat([(nROW/2)-1:-1:-1*(nROW/2)],W,1);

Phantom(:,1:W)= repmat([-1*(nROW/2):1:(nROW/2)-1]',1,W);
Phantom(:,end+1-W:end)=repmat([(nROW/2)-1:-1:-1*(nROW/2)]',1,W);
BlueHot = [0 1 1;0 0 1;0 0 0; 1 0 0;1 1 0;];
coord = linspace(1, size(BlueHot, 1), nROW);
% BlueHot2=interp1(BlueHot, coord, 'linear');
% figure(5); colormap(interp1(BlueHot, coord, 'linear'));imagesc(Phantom);caxis([-1*(nROW/2) (nROW/2)-1]);%axis('xy')

Phantom3D=repmat(Phantom,1,1,nSlice);

Fn_Mat2NiiGz(Stu,['Phantom_' PntSz],Phantom3D)


% Phantom=zeros(256,256);
% Phantom(1:128,1:128)=64;Phantom(1:128,129:end)=-64;
% Phantom(129:end,1:128)=-32;Phantom(129:end,129:end)=32;
% W=30;
% Phantom(1:W,:)=repmat([-128:1:127],W,1);
% Phantom(end+1-W:end,:)=repmat([127:-1:-128],W,1);
% 
% Phantom(:,1:W)= repmat([-128:1:127]',1,W);
% Phantom(:,end+1-W:end)=repmat([127:-1:-128]',1,W);
% BlueHot = [0 1 1;0 0 1;0 0 0; 1 0 0;1 1 0;];
% coord = linspace(1, size(BlueHot, 1), 256);
% figure(5)
% colormap(interp1(BlueHot, coord, 'linear'));imagesc(Phantom);caxis([-128 127]);%axis('xy')