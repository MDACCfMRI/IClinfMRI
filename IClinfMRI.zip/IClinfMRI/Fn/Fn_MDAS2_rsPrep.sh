#!/bin/sh


# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

||  =================={ Usage :: Fn_MDAS2_rsPrep.sh }====================================
||   
||  [Purpose]:  
||
||  [Usage]: Fn_MDAS2_rsPrep.sh [OPTIONS]
||       ex: Fn_MDAS2_rsPrep.sh -r "p_RS" -T "TR" -a "p_T1" -l "p_Lesion" -j "p_Jump" -c 'y' -g 'n' -h 'n' -z "alt+z" -O "Dir_OT"
|| 			  
||
||  [OPTIONS]:
||            -r <p_RS> : The fullpath of the resing-state fMRI data
||            -a <p_T1> : The fullpath of the "T1w" stucture image
||            -l <p_Lesion> : The fullpath of the lesion mask at the space of T1w image
||            -c <y/n> : when the high resolution EPI is non-avaliable, 
||                       the data will be registered based on its coordinated (default='y')
||            -j <p_Jump> : The fullpath of the resing-state fMRI data
||            -g <y/n> : add an extra nuisance regressor of the global signal (default='n')
||            -h <y/n> : Calculate ReHo before Smooth (default='n')
||            -s <FWHM> : smooth with ?? mm FWHM (default='4')
||            -v <vsize> : Register to T1 with ?? voxel size  (default='2')
||
||	[Optional aguments]
||            -P <PREPIDX> : Preprocessing Index [Unit: seconds] (default MDA FAS : -P 'T1;M1;F0;D1;N1;B1;S1')
||            -z <tPattern> : the tpattern of slice timing correction (default : -z 'alt+z')
||            -O <Dir_OT> : The Directory of output files (default : parent dir of the Task folder)
|| 
||  --------------------------------------------------------------------------------------
||	[Suggest Thresholds] : z=1.96(p<0.05), z=2.58(p<0.01), z=2.81(p<0.005), z=3.29(p<0.001)
||  ======================================================================================
Created by Irene Hsu on 2018.08.22 (Bash shell) @ MD Anderson

EOF
exit
}

# ============================================================================[Help]====="
if [ -z "$1" ]; then
# if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="
argn="${#}" # number of all input arguments
#argcon=${@} # all contents of the input arguments

# echo "Total $argn input arguments"

Opt_numb=0;
while getopts "r:T:a:l:j:c:g:h:P:z:B:s:v:F:O:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
    r)
        p_RS=$OPTARG
    ;;
    T)
        TR=$OPTARG
    ;;
    a)
        p_T1=$OPTARG
    ;;
    l)
        p_Lesion=$OPTARG
    ;;
    j)
        p_Jump=$OPTARG
    ;;
    c)
        Reg_Coord=$OPTARG
    ;;
    g)
        NR_Global=$OPTARG
    ;;
    h)
        Idx_ReHo=$OPTARG
    ;;
    P)
		PrepIdx=$OPTARG
    ;;
    z)
		tpattern=$OPTARG
    ;; 
    B)
		Range_BP=$OPTARG
    ;; 
    s)
		krnl_Blur=$OPTARG
    ;;  
    v)
		vsize=$OPTARG
    ;;    
    F)
		SDIR=$OPTARG
	;;
    O)
		Dir_OT=$OPTARG
    ;;
    x)
		empty=$OPTARG
    ;;
    esac
done

DEMO="X"
if [ "${DEMO}" == "O" ]; then

IIDD="20171222" # 

DirM="/Volumes/AiLing_YM_1T/MDA/IClinfMRI_DemoData/Test_20171222"
DirS="/Users/ailing/Dropbox/Projects_MDA/IClinfMRI/Fn"



p_T1="$(ls ${DirM}/${IIDD}_3DVolumePre.nii)"
# p_Lesion="$(ls ${DirM}/${IIDD}*_3DVOLUME_Lesion.nii.gz)"
# p_Jump="$(ls ${DirM}/${IIDD}*BOTHHANDS_V01.nii.gz)"

p_RS="$(ls ${DirM}/${IIDD}_Resting.nii)"
cd $DirM

bash ${DirS}/Fn_MDAS2_rsPrep.sh -r "$p_RS" -T "2" -a "$p_T1" -z "alt+z" -c 'y' -g 'y' -B '0.01-0.10' -F "${DirS}" -h 'y' -P 'T1;M1;F0;D1;N1;B1;S1'


TimeStamp="$(date +"D%m%d_T%H%M%S")";p_Status="${DirM}/===(LOG)_${IIDD}_REST===${TimeStamp}.txt"; rm -f $p_Status
## <BBR>
# bash ${DirS}/Fn_MDAS2_rsPrep.sh -r "$p_RS" -T "2" -a "$p_T1" -l "$p_Lesion" -j "$p_Jump" -z "alt+z" -P 'T1;M1;F0;D1;N1;B1;S1' 2>&1 | tee ${p_Status}

## <CBR>#
# bash ${DirS}/Fn_MDAS2_rsPrep.sh -r "$p_RS" -T "2" -a "$p_T1" -l "$p_Lesion" -z "alt+z" -c 'y' -g 'y' -P 'T1;M0;F0;D0;N0;B0;S0' 2>&1 | tee ${p_Status}

bash ${DirS}/Fn_MDAS2_rsPrep.sh -r "$p_RS" -T "2" -a "$p_T1" -l "$p_Lesion" -z "alt+z" -c 'y' -g 'y' -F "${DirS}" -h 'y' -P 'T1;M1;F0;D1;N1;B1;S1' 2>&1 | tee ${p_Status}

## <IBR>
# bash ${DirS}/Fn_MDAS2_rsPrep.sh -r "$p_RS" -T "2" -a "$p_T1" -l "$p_Lesion" -z "alt+z" -c 'n' -g 'y' -P 'T1;M1;F0;D1;N1;B1;S1' 2>&1 | tee ${p_Status}

fi

# =======================================================================================#
# 	  { 00. Assignment }
# =======================================================================================#
ImExt='nii.gz'
# ImExt='nii'
ImExtOT='nii'
#if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; # echo "||"; echo "|| fsl verson = [${fslver}]";echo "||"

n_subS="$(grep -o "_" <<< "$(echo `basename ${p_RS}` | sed 's/.nii.gz//g' | sed 's/.nii//g')" | wc -l)";
n_subS=$(echo "$n_subS + 1" | bc)
ID=$(echo `basename $p_RS` | sed 's/.nii.gz//g'| sed 's/.nii//g')
# TaskN=$(echo $ID | sed 's/.nii.gz//g'| sed 's/.nii//g' | cut -d '_' -f $n_subS)
# PID=$(echo $ID | sed "s/_${TaskN}//g" )

PID=$(echo $ID | cut -d '_' -f 1 )
TaskN=$(echo $ID | sed 's/.nii.gz//g'| sed 's/.nii//g' | sed "s/${PID}_//g")



# =======================================================================================#
#     { 00. Check the existence of input variables }
# =======================================================================================#

# DesignMtx="${PID}_DesignMtx_${TaskN}_SPM"

# -------------------------------------------------------------------- [Preprocessing IDX]
if [ -z "${PrepIdx}" ];then 
	PrepIdx='T1;M1;F0;D1;N1;B1;S1';
fi

# ---------------------------------------------------------- [tpattern for slicing Timing]
if [ -z "${tpattern}" ];then 
	tpattern='alt+z';
fi

# -------------------------------------------------------------------- [Preprocessing IDX]
if [ -z "${Reg_Coord}" ];then 
	Reg_Coord='y';
fi

if [ -z "${Idx_ReHo}" ];then 
	Idx_ReHo='n';
fi

if [ -z "${Range_BP}" ];then 
	Range_BP='0.01-0.08';
fi
	Freq_low="$(echo $Range_BP | cut -d '-' -f 1)";
	Freq_high="$(echo $Range_BP | cut -d '-' -f 2)";

#  	Freq_low="0.01"; Freq_high="0.08"
# 	pnt_F1=$(echo $Freq_low | cut -d '.' -f 2);pnt_F2=$(echo $Freq_high | cut -d '.' -f 2);pnt_F="${pnt_F1}${pnt_F2}"


if [ -z "${krnl_Blur}" ];then 
	krnl_Blur='4';
fi

if [ -z "${vsize}" ];then 
	vsize='2';
fi

# --------------------------------------------------------------------- [Check Output Dir]
if [ -z "${Dir_OT}" ];then 
	#Dir_OT=$(pwd)
	Dir_OT=$(dirname "$p_RS")
fi

# Fd_TASK='1_TASK'
Dir_RS="${Dir_OT}/${TaskN}" # Update an new Folder
Dir_RS_tmp="${Dir_OT}/${TaskN}/Fd_Temp" # Update an new Folder

Dir_Reg="${Dir_OT}/1_RegMtx" # Update an new Folder
Dir_Seg="${Dir_OT}/2_T1Segment" # Update an new Folder

if [ ! -d "${Dir_RS}" ];then 
	mkdir -p "${Dir_RS}"
fi

if [ ! -d "${Dir_Reg}" ];then 
	mkdir -p "${Dir_Reg}"
fi

if [ ! -d "${Dir_Seg}" ];then 
	mkdir -p "${Dir_Seg}"
fi

if [ ! -d "${Dir_RS_tmp}" ];then 
	mkdir -p "${Dir_RS_tmp}"
fi



# --------------------------------------------------------- [Check Output p_Jump & p_Seed]
if [ -z "${p_Jump}" ];then 
	p_Jump="${Dir_Reg}/----------"
fi

if [ -z "${NR_Global}" ];then 
	# p_Seed="${Dir_Reg}/----------"
	NR_Global='n'
fi

# ------------------------------------------------------------------- [Namimg RegMtx Name]


if [ -f "${p_RS}" ];then
	Tp_RS=$(echo `basename $(ls $p_RS)` | cut -d "_" -f2 | sed 's/.nii.gz//g' | sed 's/.nii//g')
fi

if [ -f "${p_T1}" ];then
	Tp_T1=$(echo `basename $(ls $p_T1)` | cut -d "_" -f2 | sed 's/.nii.gz//g' | sed 's/.nii//g')
else
	Tp_T1="-----"
fi


if [ -f "${p_Jump}" ];then 
	Tp_Jump=$(echo `basename $(ls $p_Jump)` | cut -d "_" -f2 | sed 's/.nii.gz//g' | sed 's/.nii//g')
	RegMed="BBR"
	Reg_Coord='n';
	if [ "$(3dinfo -nt ${p_Jump})" -gt "1" ]; then
	#if [ "$(${fslver}fslinfo ${p_Jump} | awk 'NR==5{print $2}' )" -gt "1" ]; then

		p_JumpV01="${Dir_RS_tmp}/$(echo `basename $p_Jump` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Vol_01.${ImExt}"
		
		if [ ! -f "${p_JumpV01}" ];then
			#${fslver}fslroi "${p_Jump}" "${p_JumpV01}" 0 1
			3dcalc -a ${p_Jump}'[0]' -expr 'a' -prefix "${p_JumpV01}"
		fi
	elif [ "$(3dinfo -nt ${p_Jump})" -eq "1" ]; then
	#elif [ "$(${fslver}fslinfo ${p_Jump} | awk 'NR==5{print $2}' )" -eq "1" ]; then
		p_JumpV01=${p_Jump}
	fi
else
	if [ "$Reg_Coord" == "y" ]; then
		RegMed="CBR"
		Tp_Jump="Coordinate-Based Resampling"
	else
		RegMed="IBR"
		Tp_Jump="Intensity-Based Registration"
	fi
fi

# if [ -f "${p_Seed}" ];then
# 	Tp_Seed=$(echo `basename $(ls $p_Seed)` | cut -d "_" -f4-8 | sed 's/.nii.gz//g' | sed 's/.nii//g')
# 	IdxC="O"
# else
# 	Tp_Seed="-----"
# 	IdxC="-"
# fi

# ========================================================================[CheckBox]====="
#=========================================================================================
# ------------------------------------------------------------------------ [(F) Field Map]
# IdxF="-"
# ----------------- [(T) SliceT, (M) MCRT, (F)Field Map, (D) Despike & Detrend,(S) Smooth]
# if [ -f "${p_Task}" ]; then
# IdxT="O"; IdxM="O"; IdxD="O"; IdxS="O"; IdxP="O";IdxV="O"
# else
# IdxT="-"; IdxM="-"; IdxD="-"; IdxS="-"; IdxP="-";IdxV="-"
# fi



# ---------------------------------------------------------------------------------------#
# --------------------------{ Calculate number of substring ';' of the given filename}---#
# ---------------------------------------------------------------------------------------#

# PrepIdx='T0;M1;F0;D1;S1'
if [ -f "${p_RS}" ]; then
	n_ele=$(grep -o ";" <<< "$(echo $PrepIdx)" | wc -l);n_ele=$(echo "$n_ele + 1" | bc) ; 

	for i in `seq 1 $n_ele`
	do
		PREPNm=$(echo $PrepIdx | cut -d ';' -f $i | cut -c 1)
		PREPYN=$(echo $PrepIdx | cut -d ';' -f $i | cut -c 2)
		# echo "Now to  ${PREPNm} = [${PREPYN}]"

		if [ "$PREPNm" = "T" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxT="O" ;  else  IdxT="-";  fi ; fi
		if [ "$PREPNm" = "M" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxM="O" ;  else  IdxM="-";  fi ; fi
		if [ "$PREPNm" = "F" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxF="O" ;  else  IdxF="-";  fi ; fi
		if [ "$PREPNm" = "D" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxD="O" ;  else  IdxD="-";  fi ; fi
		if [ "$PREPNm" = "N" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxN="O" ;  else  IdxN="-";  fi ; fi
		if [ "$PREPNm" = "B" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxB="O" ;  else  IdxB="-";  fi ; fi
		if [ "$PREPNm" = "S" ]; then  if [ "$PREPYN" -eq "1" ]; then  IdxS="O" ;  else  IdxS="-";  fi ; fi
	done
fi

IdxF="-" ; # Unsupport this function yet
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# cd $Dir_OT #(BE CAREFUL THIS ROW SHOULD BE DELETED at IPVL5 TERMINAL)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ============================================================================[Main]====="

NOWTIME="$(date +"%m-%d-%Y  %r")"; 
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "  Date : ${NOWTIME}"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| "

if [ -z "${SDIR}" ];then 
	SDIR=$(find $PWD -name 'Fn_MDAS2_rsPrep.sh' | sed 's/\/Fn_MDAS2_rsPrep.sh//g' ); #echo "|| $SDIR"
# SDIR=$(find $PWD -name 'Fn_MDAS2_rsPrep.sh' | sed 's/\/Fn_MDAS2_rsPrep.sh//g' ); #echo "$SDIR"
# SDIR=$(find $HOME -name 'Fn_MDAP0_Download.sh' | sed 's/\/Fn_MDAP0_Download.sh//g' ); #echo "$SDIR"
fi


if [ -z "${SDIR}" ];then SDIR='---'; fi ; echo "|| $SDIR"

if [ -d "${SDIR}" ];then TDIR="$(echo `dirname $SDIR`)/Template";else TDIR='---'; fi ; #echo "|| $SDIR"	



# SDIR='/Volumes/AiLing_YM_1T/MDA_IrsMap/-Script-'
# SDIR=$(find $HOME -name 'Fn_MDAP0_Download.sh' | sed 's/\/Fn_MDAP0_Download.sh//g' ); #echo "$SDIR"

echo "|| "
echo "==========================={ Information Fn_MDAS2_rsPrep.sh}====================== "
echo "|| "
echo "||    (0) ::  [ Script Dir        ] =[ ${SDIR} ] "
echo "||    (1) ::  [ REST Data | TR (s)] =[ `basename $p_RS` (${Tp_RS})| TR= ${TR} (s) ] "
echo "||            [ Calucate ReHo     ] =[ ${Idx_ReHo} ] "
echo "||    (2) ::  [ T1 Anatomy        ] =[ $(echo `basename $(ls $p_T1)`)  (${Tp_T1})] "
echo "||    (3) ::  [ Jumping  (${RegMed})    ] =[ $(echo `basename  $p_Jump`)  (${Tp_Jump})] "
echo "||    (4) ::  [ Nusiance Regressor] =[ Global Average  (${NR_Global})] "
echo "||    (5) ::  [ Output Dir        ] =[ ${Dir_OT} ] "
echo "||    -------------------------------------------------------------------------- "
# echo "||	(4) ::  [ FDR(z)   ] =[ ${TH} ] "
echo "|| >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
echo "||    >>> [${IdxT}] (T) Slice Timing  (tpattern = $tpattern)    "
echo "||    >>> [${IdxM}] (M) MotionCRT & Register to T1 with voxel size of ${vsize} mm  "
echo "||    >>> [${IdxF}] (F) FiledMapCRT       "
echo "||    >>> [${IdxD}] (D) Despike & 3rd Detrend   " 
echo "||    >>> [${IdxN}] (N) Nuisance Regression   " 
echo "||    >>> [${IdxB}] (B) Bandpass   ${Freq_low}-${Freq_high} Hz" 
echo "||    >>> [${IdxS}] (S) Smooth with ${krnl_Blur} mm FWHM "
# echo "||	>>> [${IdxC}] (C) Connectivity Mapping         "									
echo "================================================================================== "
echo "|| "

if [ ! -f "${p_RS}" ] || [ ! -f "${p_T1}" ] || [ ! -d "${SDIR}" ];then
    echo "|| ";echo "|| Lask Files, Please Check !!!";echo "|| "
	if [ ! -f "${p_RS}" ];then echo "|| RS Data NOT EXIST"; fi
	if [ ! -f "${p_T1}" ];then echo "|| T1 Data NOT EXIST"; fi
	if [ ! -d "${SDIR}" ];then echo "|| SDIR NOT EXIST"; fi
    exit 1
else
	echo "|| EXECUTING >>> ";echo "|| "
fi

# if [ ! -f "${p_RS}" ] || [ ! -f "${p_T1}" ] || [ ! -f "${p_Jump}" ]; then
#     echo "|| Lask Files, Please Check !!!"
#     exit 1
# fi

# #-----------------------------------------------------------------{ START: T1 }----------#
rm -f ${Dir_OT}/===Now_to_Stage_*.txt
ttStamp="$(date +"%H%M%S")"; PNTStage="01_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ -f "${p_T1}" ];then
	cp $p_T1 ${Dir_Reg}
#if [ ! -f "${p_NReg}" ] && [ -f "${p_T1}" ];then
	fT1="$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g' )";

	# if [ ! -f "${Dir_Seg}/${fT1}.nii" ];then 
	# 	cp $p_T1 "${Dir_Seg}/${fT1}.nii.gz"
	# 	gzip -d "${Dir_Seg}/${fT1}.nii.gz"
	# fi

	# if [ ! -f "${Dir_Seg}/${fT1}.nii" ];then 
	# 	if [ -f "$(echo `dirname $p_T1`)/${fT1}.nii" ];then
	# 		cp $p_T1 "${Dir_Seg}/${fT1}.nii"
	# 	fi
	# 	if [ -f "$(echo `dirname $p_T1`)/${fT1}.nii.gz" ];then
	# 		cp $p_T1 "${Dir_Seg}/${fT1}.nii.gz"
	# 		gzip -d "${Dir_Seg}/${fT1}.nii.gz"
	# 	fi
	# fi	

	if [ ! -f "${Dir_Seg}/${fT1}.nii" ];then 
		3dcalc -a "${p_T1}" -expr 'a' -prefix "${Dir_Seg}/${fT1}.nii"
		# cp $p_T1 "${Dir_Seg}/${fT1}.${ImExt}"
		# gzip -d "${Dir_Seg}/${fT1}.${ImExt}"
	fi

	if [ ! -f "${Dir_Seg}/c1${fT1}.nii" ];then 
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) SPM Segmentation >>>>>>>>>>>>>> " 
		echo "||	"
		matlab -nodisplay -r "addpath('$SDIR');cd('${Dir_Seg}');Fn_batch_SPM12_Segment('${fT1}.nii');quit;"; stty echo
	else
		echo "||	(*) T1 Segmentation   | Data Existence (O) SPM Segmentation >>>>>>>>>>>>>> " 

	fi


	if [ -d "${TDIR}" ] && [ ! -f "${Dir_Seg}/Inv_MNI152_T1_2mm_brain.nii" ];then
		echo "||	" 	
		echo "||	(*) Inv(Normalization)| Data Existence (X) SPM Inv(Normalization) >>>>>>>> " 
		echo "||	"
		matlab -nodisplay -r "addpath('$SDIR');cd('${Dir_Seg}');Fn_batch_SPM12_InvNor('${fT1}.nii');quit;"; stty echo
	fi ; 

	#-----------------------------------------------------[ Assign Filenames ]----------||
	p_T1_MskHead="${Dir_Seg}/${fT1}_Msk_Head.${ImExt}"
	p_T1_MskBrn="${Dir_Seg}/${fT1}_Msk_Brain.${ImExt}"
	p_T1_Brn="${Dir_Seg}/${fT1}_Brain.${ImExt}"
	p_T1_MskWM="${Dir_Seg}/${fT1}_Msk_WM.${ImExt}"
	p_T1_MskCSF="${Dir_Seg}/${fT1}_Msk_CSF.${ImExt}"
	p_T1_MskAFNI="${Dir_Seg}/${fT1}_aMsk.${ImExt}"


	# Create a rough T1 Mask by afni
	if [ ! -f "${p_T1_MskAFNI}" ];then 
		rm -f "${p_T1_MskAFNI}"
		3dAutomask -dilate 1 -prefix "${p_T1_MskAFNI}" "${p_T1}"
	fi
	#-----------------------------------------------------[ Create Head Mask ]----------||
	if [ ! -f "${p_T1_MskHead}" ];then 
		echo "||	" 
		echo "||	(*) T1 Segmentation   | Data Existence (X) Create Head Mask >>>>>>>>>>>>>> " 		
		echo "||	"

		Type="Head"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}"; rm -f "${p_Tmp}" "${p_T1_MskHead}"
		3dcalc -a "${Dir_Seg}/c1${fT1}.nii" -b "${Dir_Seg}/c2${fT1}.nii" -c "${Dir_Seg}/c3${fT1}.nii" -d "${Dir_Seg}/c4${fT1}.nii" -e "${Dir_Seg}/c5${fT1}.nii" \
			   -expr 'ispositive(a+b+c+d+e-0.8)' -prefix "${p_Tmp}" -datum float
		3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskHead}" -fill_holes -fill_dirs xy -dilate_input 1 -3;rm -f "${p_Tmp}"
		3dmerge -dxyz=1 -1clust 1 20 -prefix "${p_Tmp}" "${p_T1_MskHead}"; rm -f "${p_T1_MskHead}"
		#mv "${p_Tmp}" "${p_T1_MskHead}"
		#${fslver}fslmaths "${p_T1_MskAFNI}" -mul "${p_Tmp}" "${p_T1_MskHead}"; rm -f "${p_Tmp}"
		3dcalc -a "${p_T1_MskAFNI}" -b "${p_Tmp}" -expr 'ispositive(a)*ispositive(b)' -prefix "${p_T1_MskHead}";rm -f "${p_Tmp}"

	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Create Head Mask >>>>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_MskHead}`"
		
	fi

	#-----------------------------------------------------[ Create Brain Mask ]----------||
	if [ ! -f "${p_T1_MskBrn}" ];then  
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) Create Brain Mask >>>>>>>>>>>>> " 
		echo "||	"
		Type="Brain"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}";
		3dcalc -a "${Dir_Seg}/c1${fT1}.nii" -b "${Dir_Seg}/c2${fT1}.nii" -c "${Dir_Seg}/c3${fT1}.nii" -expr 'ispositive(a+b+c-0.3)' -prefix "${p_Tmp}" 
		3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskBrn}" -fill_holes -fill_dirs xy -dilate_input 2 -3; rm -f ${p_Tmp}
		3dmerge -dxyz=1 -1clust 1 20 -prefix "${p_Tmp}" "${p_T1_MskBrn}"; rm -f "${p_T1_MskBrn}"
		# mv "${p_Tmp}" "${p_T1_MskBrn}"; rm -f "${p_Tmp}"
		#${fslver}fslmaths "${p_T1_MskAFNI}" -mul "${p_Tmp}" "${p_T1_MskBrn}"; rm -f "${p_Tmp}"
		3dcalc -a "${p_T1_MskAFNI}" -b "${p_Tmp}" -expr 'ispositive(a)*ispositive(b)' -prefix "${p_T1_MskBrn}";rm -f "${p_Tmp}"
	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Create Brain Mask >>>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_MskBrn}`"
		
	fi
	#-----------------------------------------------------[ Create T1 Brain  ]-----------||

	if [ ! -f "${p_T1_Brn}" ];then 
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) Mask out Non-Brain >>>>>>>>>>>> "
		echo "||	"
		#rm -f ${p_T1_Brn}
		3dcalc -a "${p_T1}" -b "${p_T1_MskBrn}" -expr 'a*b' -prefix "${p_T1_Brn}"
	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Mask out Non-Brain >>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_Brn}`"
		
	fi
	#------------------------------------------------------[ Create WM Mask  ]-----------||
	if [ ! -f "${p_T1_MskWM}" ];then 
		echo "||	" 	
		echo "||	(*) T1 Segmentation   | Data Existence (X) Create WM Mask  >>>>>>>>>>>>>>> "	
		echo "||	"

		Type="WM"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}"; rm -f "${p_Tmp}" "${p_T1_MskWM}"
		3dcalc -a ${p_T1_MskAFNI} -b "${Dir_Seg}/c2${fT1}.nii" -expr 'ispositive(a)*ispositive(b-0.9999)' -prefix "${p_Tmp}"
		3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskWM}" -fill_holes -fill_dirs xy -dilate_input 1 -3;rm -f "${p_Tmp}"

		# <Make sure WM mask is not empty>
		nVxlinMsk="$(3dmaskave -mask "${p_T1_MskWM}" -quiet -sum -mrange 1 1 "${p_T1_MskWM}")"
		if [ -z "$nVxlinMsk" ]; then nVxlinMsk="0"; fi
		if [ "${nVxlinMsk}" -eq "0" ]; then
			echo "||	" 
			echo "||	(*) T1 Segmentation   | Modify Threshold of WM  Mask from 0.9999 to 0.99 > "	
			echo "||	"
			Type="WM"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}"; rm -f "${p_Tmp}" "${p_T1_MskWM}"
			3dcalc -a ${p_T1_MskAFNI} -b "${Dir_Seg}/c2${fT1}.nii" -expr 'ispositive(a)*ispositive(b-0.99)' -prefix "${p_Tmp}"
			3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskWM}" -fill_holes -fill_dirs xy -dilate_input 1 -3;rm -f "${p_Tmp}"
		fi

		# Type="WM"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.nii.gz"; rm -f "${p_Tmp}" "${p_T1_MskWM}"
		# 3dcalc -a "${Dir_Seg}/c2${fT1}.nii" -expr 'ispositive(a-0.9999)' -prefix "${p_Tmp}"
		# 3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskWM}" -fill_holes -fill_dirs xy -dilate_input 1 -2;rm -f "${p_Tmp}"
		# ${fslver}fslmaths "${p_T1_MskWM}" -kernel sphere "2" -ero -fillh "${p_T1_MskWM}"; 
		# ${fslver}fslmaths "${p_T1_MskAFNI}" -mul "${p_T1_MskWM}" "${p_T1_MskWM}"; 
		if  [ -f "${p_Lesion}" ];then 	
			echo "||	..............................................................Lesion Exclusion "	
			echo "||	"
			3dcalc -a "${p_T1_MskWM}" -b "${p_Lesion}" -expr "ispositive(a-b)" -prefix "${p_Tmp}"; rm -f "${p_T1_MskWM}"
			mv "${p_Tmp}" "${p_T1_MskWM}"
		fi
	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Create WM Mask  >>>>>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_MskWM}`"
		
	fi
	# #------------------------------------------------------[ Create CSF Mask  ]-----------||
	if [ ! -f "${p_T1_MskCSF}" ];then 
		echo "||	" 
		echo "||	(*) T1 Segmentation   | Data Existence (X) Create CSF Mask  >>>>>>>>>>>>>> "	
		echo "||	"

		Type="CSF"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}"; rm -f "${p_Tmp}" "${p_T1_MskCSF}"
		3dcalc -a ${p_T1_MskAFNI} -b "${Dir_Seg}/c3${fT1}.nii" -expr 'ispositive(a)*ispositive(b-0.9999)' -prefix "${p_Tmp}"
		#3dcalc -a ${p_T1_MskAFNI} -b "${Dir_Seg}/c3${fT1}.nii" -expr 'ispositive(a)*ispositive(b-0.99)' -prefix "${p_Tmp}"
		3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskCSF}" -fill_holes -fill_dirs xy -dilate_input 1 -3;rm -f "${p_Tmp}"

		## <Make sure CSF mask is not empty>
		nVxlinMsk="$(3dmaskave -mask "${p_T1_MskCSF}" -quiet -sum -mrange 1 1 "${p_T1_MskCSF}")"
		if [ -z "$nVxlinMsk" ]; then nVxlinMsk="0"; fi
		if [ "${nVxlinMsk}" -eq "0" ]; then
			echo "||	" 
			echo "||	(*) T1 Segmentation   | Modify Threshold of CSF Mask from 0.9999 to 0.99 > "	
			echo "||	"
			Type="CSF"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.${ImExt}"; rm -f "${p_Tmp}" "${p_T1_MskCSF}"
			3dcalc -a ${p_T1_MskAFNI} -b "${Dir_Seg}/c3${fT1}.nii" -expr 'ispositive(a)*ispositive(b-0.99)' -prefix "${p_Tmp}"
			3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskCSF}" -fill_holes -fill_dirs xy -dilate_input 1 -3;rm -f "${p_Tmp}"
		fi

		# Type="CSF"; p_Tmp="${Dir_Seg}/TMP_${fT1}_Msk_${Type}.nii.gz"; rm -f "${p_Tmp}" "${p_T1_MskCSF}"
		# 3dcalc -a "${Dir_Seg}/c3${fT1}.nii" -expr 'ispositive(a-0.9999)' -prefix "${p_Tmp}"
		# 3dmask_tool -input "${p_Tmp}" -prefix "${p_T1_MskCSF}" -fill_holes -fill_dirs xy -dilate_input 1 -2;rm -f "${p_Tmp}"
		# ${fslver}fslmaths "${p_T1_MskCSF}" -kernel sphere "2" -ero -fillh "${p_T1_MskCSF}"; 
		# ${fslver}fslmaths "${p_T1_MskAFNI}" -mul "${p_T1_MskCSF}" "${p_T1_MskCSF}"; 
		if  [ -f "${p_Lesion}" ];then 
			echo "||	..............................................................Lesion Exclusion "	
			echo "||	"
			3dcalc -a "${p_T1_MskCSF}" -b "${p_Lesion}" -expr "ispositive(a-b)" -prefix "${p_Tmp}"; rm -f "${p_T1_MskCSF}"
			mv "${p_Tmp}" "${p_T1_MskCSF}"
		fi
	else
		echo "||"
		echo "||	(*) T1 Segmentation   | Data Existence (O) Create CSF Mask  >>>>>>>>>>>>>> "
		echo "||	    ......................Named by `basename  ${p_T1_MskCSF}`"
	fi
fi
# echo "================================================================================== "
echo "||"
echo "---------------------------------------------------------------------------------- "
echo "||"
#---------------------------------[ Downsample T1 Resolution ]----------------------------------||
#-----------------------------------------------------------------------------------------------||
# vsize="3.0"
VPVAssign="$(echo ${vsize}*${vsize}*${vsize} | bc)"
IDX_Resample='n'
if [ -f "${p_T1}" ];then
	p_T1_ds="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ds.${ImExt}"; 
	p_T1Msk_ds="${Dir_Reg}/$(echo `basename $p_T1_MskBrn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ds.${ImExt}"; 
	#DimIn="$(echo "$(${fslver}fslinfo ${p_T1_ds} | awk 'NR==2{print $2}')*$(${fslver}fslinfo ${p_T1_ds} | awk 'NR==3{print $2}')*$(${fslver}fslinfo ${p_T1_ds} | awk 'NR==4{print $2}')" | bc)"
	# DimIn="$(3dinfo -nijk ${p_T1_ds})"
	
	if [ -f "${p_T1_ds}" ];then 
		VPVIn="$(3dinfo -voxvol ${p_T1_ds})" # 
		if [ "$(echo "$VPVIn != $VPVAssign" | bc -l)" -eq 1 ]; then IDX_Resample='y';rm -f ${p_T1_ds};fi
	fi
	if [ ! -f "${p_T1_ds}" ]; then
		3dresample -dxyz ${vsize} ${vsize} ${vsize} -rmode Linear -prefix ${p_T1_ds} -inset ${p_T1}
	fi

	if [ -f "${p_T1Msk_ds}" ];then 
		VPVIn="$(3dinfo -voxvol ${p_T1Msk_ds})" # 
		if [ "$(echo "$VPVIn != $VPVAssign" | bc -l)" -eq 1 ]; then IDX_Resample='y';rm -f ${p_T1Msk_ds};fi
	fi
	if [ ! -f "${p_T1Msk_ds}" ]; then
		3dresample -dxyz ${vsize} ${vsize} ${vsize} -rmode Linear -prefix ${p_T1Msk_ds} -inset ${p_T1_MskBrn}
	fi
fi
#------------------------------------------------------------{ START :rs-fMRI }----------#

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
p_In="${p_RS}" #(Renew Dataset)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
#=========================================================================================
#----- oO(^^)Oo ----------------------------------------------------------[ Slice Timing ]
# echo "||	>>> [${IdxT}] (T) Slice Timing      | "
# echo "||	>>> [${IdxM}] (M) MotionCRT         | "
# echo "||	>>> [${IdxF}] (F) FiledMapCRT       | " 
# echo "||	>>> [${IdxD}] (D) Despike & Detrend | " 
# echo "||	>>> [${IdxS}] (S) Smooth            | "	

ttStamp="$(date +"%H%M%S")"; PNTStage="02_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxT" == "O" ]; then
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	if [ "${#ID}" -eq "${#FN_In}" ];then
		p_Tshift="${Dir_RS_tmp}/${FN_In}_T.${ImExt}";
	else
		p_Tshift="${Dir_RS_tmp}/${FN_In}T.${ImExt}";
	fi
	
	if [ ! -f "${p_Tshift}" ];then
		echo "||	" 	
		echo "||	(T) Slice Timing      | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> " 	
		echo "||	"
		rm -f ${p_Tshift}
		# 3dTshift -TR ${TR} -slice 0 -tpattern 'alt+z' -prefix ${p_Tshift} ${p_In}
		3dTshift -TR ${TR} -slice 0 -tpattern ${tpattern} -prefix ${p_Tshift} ${p_In}
		
	else
		echo "||	" 
		echo "||	(T) Slice Timing      | Data Existence (O) Named by `basename  ${p_Tshift}`   " 
		echo "||	" 
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_Tshift}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	p_Tshift="${Dir_RS_tmp}/----------"
fi

# #=========================================================================================
# #----- oO(^^)Oo --------------------------[ Motion Correction :: PART I. Extract Base Img]
ttStamp="$(date +"%H%M%S")"; PNTStage="03_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxM" == "O" ]; then
	# <<Make Dir>>
	Dir_MCRT="${Dir_RS}/Fd_MCRT_${PID}"
	if [ ! -d "${Dir_MCRT}" ];then mkdir -p "${Dir_MCRT}";fi
	# <<Assign FN>>
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	if [ "${#ID}" -eq "${#FN_In}" ];then
		p_MCRT="${Dir_RS_tmp}/${FN_In}_M.${ImExt}";
	else
		p_MCRT="${Dir_RS_tmp}/${FN_In}M.${ImExt}";
	fi

	if [ ! -f "${p_MCRT}" ];then
		echo "||	" 	
		echo "||	(M) Motion Correction | Data Existence (X) Conducting !!! >>>>>>>>>>PART I" 
		echo "||	........................................................(Extract Base Img)" 
		echo "||	"
	fi

	#<<Examine each imaging run for outliers>>
	p_MCRT_outlier="${Dir_MCRT}/$(echo `basename $p_MCRT` | sed 's/.nii.gz//g')_outlier.txt";
	if [ ! -f "${p_MCRT_outlier}" ];then
		rm -f ${p_MCRT_outlier}; 3dToutcount -automask -range "${p_In}" > ${p_MCRT_outlier}
	fi
	base=`cat ${p_MCRT_outlier} | perl -0777an -F"\n" -e '$i=0; $small=999999; map {/\s*(\d+)/; if ($small > $1) {$small = $1; $ind=$i}; $i++;} @F; print $ind'`
else
	base='0'
fi
 
if [ "$(3dinfo -nt ${p_In})" -gt "1" ]; then
	if [ "$IdxM" == "O" ]; then
		# p_RSV01="${Dir_RS}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V$(zeropad ${base} 3).nii.gz"
		p_RSV01="${Dir_MCRT}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V`printf "%03d" ${base}`.${ImExt}"
	else
		p_RSV01="${Dir_RS_tmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_V`printf "%03d" ${base}`.${ImExt}"
	fi
	if [ ! -f "${p_RSV01}" ];then 3dcalc -a ${p_In}"[${base}]" -expr 'a' -prefix "${p_RSV01}"; fi

 	# ${fslver}fslroi "${p_In}" "${p_RSV01}" ${base} 1
fi
 
#-------------------------------------------------------------------------------------
# CoRegister Segments to REST Space (BBR, IBR, CBR)
#-------------------------------------------------------------------------------------
ttStamp="$(date +"%H%M%S")"; PNTStage="04_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}


# RegMtx_rs2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_rs2anat_${Tp_RS}_2_${Tp_T1}.mat"; 
# RegMtx_anat2rs="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2rs_${Tp_T1}_2_${Tp_RS}.mat";  
RegMtx_rs2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_rs2anat_${Tp_RS}_2_${Tp_T1}"; 
RegMtx_anat2rs="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2rs_${Tp_T1}_2_${Tp_RS}";  

#-------------------------------------------------------------------------------------------||
#----------------------------------------------[ IBR Registration : RS to ANAT  ]-----------||
# if [ ! -f "${p_Jump}" ];then 
# 	if [ ! -f "${RegMtx_rs2anat}.1D" ];then 
# 		echo "||	"	
# 		echo "||	(N) Nuisance Regress  | REGISTRATION(${RegMed}) Resting >> Anatomy Data >>>>>>>> "	
# 		echo "||	"
# 		flirt -ref ${p_T1} -in ${p_RSV01} -cost normmi -searchcost normmi -dof 6 -omat "${RegMtx_rs2anat}"
# 	else
# 		echo "||	(N) Nuisance Regress  | REGISTRATION(${RegMed}) Resting >> Anatomy Data  (Exist) "
# 	fi

# fi
#-------------------------------------------------------------------------------------------||
#----------------------------------------------[ BBR Registration : RS to ANAT  ]-----------||
if [ -f "${p_Jump}" ];then 
	cp $p_Jump ${Dir_Reg}
	# RegMtx_rs2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_rs2jump_${Tp_RS}_2_${Tp_Jump}.mat"; 
	# RegMtx_jump2rs="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2rs_${Tp_Jump}_2_${Tp_RS}.mat"; 
	RegMtx_rs2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_rs2jump_${Tp_RS}_2_${Tp_Jump}"; 
	RegMtx_jump2rs="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2rs_${Tp_Jump}_2_${Tp_RS}"; 
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(01)  | REGISTRATION(BBR) [Rest >> Jump -- ----] 
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_rs2jump}.1D" ];then 
		echo "||"	
		echo "||	(R) Registration(01)  | REGISTRATION(${RegMed}) [Rest >> Jump -- ----]>>>>>>>>>> "	
		echo "||	"		
		Des="Jump";pOut="${Dir_Reg}/$(echo `basename $p_RS` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${Des}.${ImExt}"; 
	
		cd $Dir_Reg
		rm -f "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*
		rm -f "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D"
		rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D"
		Des="Jump";pOut="${Dir_Reg}/$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${Des}.${ImExt}"; 
		align_epi_anat.py -dset2to1 -dset2 ${p_RSV01} -dset1 ${p_JumpV01} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
		rm -f ${pOut}; 3dAFNItoNIFTI -prefix "${pOut}" "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig"

		rm -f "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*		
		mv "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_rs2jump}.1D"
	else
		echo "||"
		echo "||	(R) Registration(01)  | REGISTRATION(${RegMed}) [Rest >> Jump -- ----] ..(Exist) "
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(02)  | REGISTRATION(BBR) [Rest << Jump -- ----] 
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_jump2rs}.1D" ];then 
		echo "||	" 	
		echo "||	(R) Registration(02)  | REGISTRATION(${RegMed}) [Rest << Jump -- ----] >>>>>>>>> "	
		echo "||	"		
		#convert_xfm -inverse "${RegMtx_rs2jump}" -omat "${RegMtx_jump2rs}"
		mv "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_jump2rs}.1D"
	else
		echo "||	" 
		echo "||	(R) Registration(02)  | REGISTRATION(${RegMed}) [Rest << Jump -- ----] ..(Exist) "
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(03)  | REGISTRATION(BBR) [---- -- Jump >> Anat] 
#-------------------------------------------------------------------------------------------||
	# RegMtx_jump2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2anat_${Tp_Jump}_2_${Tp_T1}"; # Updata ".mat" later
	# RegMtx_anat2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2jump_${Tp_T1}_2_${Tp_Jump}.mat"; 

	RegMtx_jump2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_jump2anat_${Tp_Jump}_2_${Tp_T1}"; # Updata ".mat" later
	RegMtx_anat2jump="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2jump_${Tp_T1}_2_${Tp_Jump}"; 

	if [ ! -f "${RegMtx_jump2anat}.1D" ];then 
		echo "||	"	
		echo "||	(R) Registration(03)  | REGISTRATION(${RegMed}) [---- -- Jump >> Anat] ......... "	
		echo "||	"
		# epi_reg --epi="${p_JumpV01}" --t1="${p_T1}" --t1brain="${p_T1_Brn}" --out="${RegMtx_jump2anat}"
		rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
		rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D"
		rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
		rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig".*
		rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D"

		rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
		rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig".*
		rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D"

		CMDis="$(@Center_Distance -dset ${p_T1} ${p_JumpV01})"
		if [ `echo "${CMDis} > 5" | bc` -eq 1 ] && [ `echo "${CMDis} <= 20" | bc` -eq 1 ]; then
			align_epi_anat.py -anat2epi -epi2anat -big_move -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		elif [ `echo "${CMDis} > 20" | bc` -eq 1 ] && [ `echo "${CMDis} <= 45" | bc` -eq 1 ]; then
			align_epi_anat.py -anat2epi -epi2anat -giant_move -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		elif [ `echo "${CMDis} > 46" | bc` -eq 1 ]; then
			align_epi_anat.py -anat2epi -epi2anat -ginormous_move -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		else
			align_epi_anat.py -anat2epi -epi2anat -anat ${p_T1_Brn} -anat_has_skull no -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -anat_has_skull yes -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr' 
		fi
		#epi_reg --epi="${p_JumpV01}" --t1="${p_T1}" --t1brain="${p_T1_Brn}" --out="${RegMtx_jump2anat}"
		#align_epi_anat.py -anat2epi -epi2anat -anat ${p_T1} -save_skullstrip -suffix _al_${RegMed} -epi ${p_JumpV01} -epi_base 0 -epi_strip 3dAutomask -giant_move -volreg off -tshift off -save_resample -Allineate_opts '-weight_frac 1.0 -maxrot 6 -maxshf 10 -VERB -warp shr'
			# shift_only         *OR* sho =  3 parameters
			# shift_rotate       *OR* shr =  6 parameters
			# shift_rotate_scale *OR* srs =  9 parameters
			# affine_general     *OR* aff = 12 parameters

		mv "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_jump2anat}.1D"

		Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"; 
		#mv ${RegMtx_jump2anat}.nii.gz ${pOut}
		# flirt -ref "${p_T1}" -in "${p_Jump}" -applyxfm -init "${Tr_jump2t1}" -interp "sinc" -out "${pOut}"
		#RegMtx_jump2anat="$(ls ${RegMtx_jump2anat}.mat)" # Update 
		rm -f ${pOut}; 3dAllineate -base ${p_T1} -input ${p_JumpV01} -final wsinc5 -1Dmatrix_apply "${RegMtx_jump2anat}.1D" -prefix ${pOut}

		if [ -f "${pOut}" ];then 
			rm -f "$(echo `basename $p_JumpV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
			rm -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
			rm -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}+orig".*
	    fi

	else
		# RegMtx_jump2anat="$(ls ${RegMtx_jump2anat}.mat)" 
		# RegMtx_jump2anat="$(ls ${RegMtx_jump2anat}.1D)" 
		echo "||	" 
		echo "||	(R) Registration(03)  | REGISTRATION(${RegMed}) [---- -- Jump >> Anat] ..(Exist) "
		echo "||	" 	
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(04)  | REGISTRATION(BBR) [---- -- Jump << Anat]  
#-------------------------------------------------------------------------------------------||
	if [ ! -f "${RegMtx_anat2jump}.1D" ];then 
		echo "||	"	
		# echo "||	(N) Nuisance Regress  | REGISTRATION(${RegMed}) Anatomy >> Jumping Data >>>>>>>> "	
		echo "||	(R) Registration(04)  | REGISTRATION(${RegMed}) ---- -- [Jump << Anat] ......... "	
		echo "||	"
		#convert_xfm -inverse "${RegMtx_jump2anat}" -omat "${RegMtx_anat2jump}"
		#mv "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_anat2jump}.1D"
	
		if [ -f "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" ];then 
			mv "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_anat2jump}.1D"
		fi

		if [ -f "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" ];then 
			mv "$(echo `basename $p_T1_Brn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_${RegMed}_mat.aff12.1D" "${RegMtx_anat2jump}.1D"
		fi

	else
		echo "||	" 
		echo "||	(R) Registration(04)  | REGISTRATION(${RegMed}) [---- -- Jump << Anat] ..(Exist) "	
		echo "||	" 
	fi
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(05)  | REGISTRATION(BBR) [Rest -- Jump -> Anat] ..(Exist) 
#-------------------------------------------------------------------------------------------||
	#rm -f "${RegMtx_rs2anat}.1D"
	# echo "||	(RegMtx_rs2anat).....${RegMtx_rs2anat} "
	# echo "||	(RegMtx_anat2rs).....${RegMtx_anat2rs} "
	# echo "||	(RegMtx_jump2anat).....${RegMtx_jump2anat} "
	# echo "||	(RegMtx_rs2jump).....${RegMtx_rs2jump} "
	if [ ! -f "${RegMtx_rs2anat}.1D" ];then 
		echo "||	"	
		echo "||	(R) Registration(05)  | REGISTRATION(${RegMed}) [Rest -- Jump -> Anat] ......... "
		echo "||	"
		#convert_xfm -omat "${RegMtx_rs2anat}" -concat "${RegMtx_jump2anat}" "${RegMtx_rs2jump}"
		#cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" -I "${RegMtx_rs2jump}.1D" > "${RegMtx_rs2anat}.1D"
		#cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" "${RegMtx_rs2jump}.1D" > "${RegMtx_rs2anat}.1D"

		if [ -f "${RegMtx_jump2anat}.1D" ] && [ -f "${RegMtx_rs2jump}.1D" ];then 
			cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" "${RegMtx_rs2jump}.1D" > "${RegMtx_rs2anat}.1D"
		else
			if [ ! -f "${RegMtx_jump2anat}.1D" ];then 
				echo "||	"	
				echo "||	(R) Registration(05)  | lack  ${RegMtx_jump2anat}.1D"
				echo "||	"
			fi
			if [ ! -f "${RegMtx_rs2jump}.1D"  ];then 
				echo "||	"	
				echo "||	(R) Registration(05)  | lack  ${RegMtx_rs2jump}.1D"
				echo "||	"
			fi
		fi


	else
		echo "||	" 
		echo "||	(R) Registration(05)  | REGISTRATION(${RegMed}) [Rest -- Jump -> Anat] ..(Exist) "
		echo "||	" 
	fi
	Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"
	# rm -f ${pOut}
	if [ ! -f "${pOut}" ];then 
		3dAllineate -base ${p_T1} -input ${p_RSV01} -final wsinc5 -1Dmatrix_apply "${RegMtx_rs2anat}.1D" -prefix ${pOut}	
		if [ -f "${pOut}" ];then 
			echo "|| "
			echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
			echo "|| ...........`dirname  ${pOut}`"
			echo "|| .................`basename  $(ls ${pOut})`"
			echo "|| ---------------------------------------------------------------------------------"
		fi
	fi
fi
#-------------------------------------------------------------------------------------------||
#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(01)  | REGISTRATION(CBR/IBR) 
#-------------------------------------------------------------------------------------------||
#-------------------------------------------------------------------------------------------||
if [ ! -f "${p_Jump}" ];then 
	echo "||"	
	echo "||	(R) Registration(01)  | REGISTRATION(${RegMed}) [Rest >> ---- >> Anat]>>>>>>>>>> "	
	echo "||	"	
if [ "$Reg_Coord" == "y" ]; then
	Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}";
	if [ ! -f "${pOut}" ];then 
		3dresample -master ${p_T1} -rmode Linear -prefix ${pOut} -inset ${p_RSV01}
	fi
else	
	if [ ! -f "${RegMtx_rs2anat}.1D" ];then 
		cp $p_RSV01 ${Dir_Reg}
		cd $Dir_Reg
		rm -f "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*
		rm -f "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D"
		align_epi_anat.py -dset2to1 -dset2 ${p_RSV01} -dset1 ${p_T1} -dset1_strip 3dAutomask -dset2_strip 3dAutomask -volreg off -tshift off -suffix _al -cost 'nmi' 
		mv "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_rs2anat}.1D"
		mv "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al_mat.aff12.1D" "${RegMtx_anat2rs}.1D"

		Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"; 
		rm -f ${pOut}; 3dAllineate -base ${p_T1} -input ${p_RSV01} -final wsinc5 -1Dmatrix_apply "${RegMtx_rs2anat}.1D" -prefix ${pOut}
		#3dAFNItoNIFTI -prefix "${pOut}" "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig"
		Des="REST";pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"; 
		rm -f ${pOut}; 3dAllineate -base ${p_RSV01} -input ${p_T1} -final wsinc5 -1Dmatrix_apply "${RegMtx_anat2rs}.1D" -prefix ${pOut}

		rm -f "$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')_al+orig".*		
	fi
fi
fi

#-------------------------------------------------------------------------------------------||
# ||	(R) Registration(06)  | REGISTRATION(BBR) [Rest <- Jump -- Anat] ..(Exist) 
#-------------------------------------------------------------------------------------------||
if [ -f "${p_Jump}" ];then 
if [ ! -f "${RegMtx_anat2rs}.1D" ];then 
	echo "||	"	
	echo "||	(R) Registration(06)  | REGISTRATION(${RegMed}) [Rest <- Jump -- Anat] ......... "
	echo "||	"
	#convert_xfm -inverse "${RegMtx_rs2anat}" -omat "${RegMtx_anat2rs}"
	#cat_matvec -ONELINE "${RegMtx_jump2rs}.1D" -I "${RegMtx_anat2jump}.1D" > "${RegMtx_anat2rs}.1D"
	cat_matvec -ONELINE "${RegMtx_jump2rs}.1D" "${RegMtx_anat2jump}.1D" > "${RegMtx_anat2rs}.1D"
	Des="REST";pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.${ImExt}"; 
	rm -f ${pOut}; 3dAllineate -base ${p_RSV01} -input ${p_T1} -final wsinc5 -1Dmatrix_apply "${RegMtx_anat2rs}.1D" -prefix ${pOut}
else
	echo "||	" 
	echo "||	(R) Registration(06)  | REGISTRATION(${RegMed}) [Rest <- Jump -- Anat] ..(Exist) "
	echo "||	" 
fi
fi

#-------------------------------[  Output WM and CSF Mask (Resample) ]-----------||

p_MskWM_ds="${Dir_Reg}/$(echo `basename $p_T1_MskWM` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ds.${ImExt}"; 
p_MskCSF_ds="${Dir_Reg}/$(echo `basename $p_T1_MskCSF` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ds.${ImExt}"; 

if [ -f "${p_MskWM_ds}" ];then 
	VPVIn="$(3dinfo -voxvol ${p_MskWM_ds})"
	if [ "$(echo "$VPVIn != $VPVAssign" | bc -l)" -eq 1 ]; then IDX_Resample='y';rm -f ${p_MskWM_ds};fi
fi
if [ ! -f "${p_MskWM_ds}" ]; then
	3dresample -dxyz ${vsize} ${vsize} ${vsize} -rmode NN -prefix ${p_MskWM_ds} -inset ${p_T1_MskWM}
	echo "||"
	echo "|| ~~~~~~~~~~ [ WM Mask @ ${vsize}x${vsize}x${vsize} T1  ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	echo "|| ...........`dirname  ${p_MskWM_ds}`"
	echo "|| .................`basename  $(ls ${p_MskWM_ds})`"
	echo "|| ---------------------------------------------------------------------------------"
fi

if [ -f "${p_MskCSF_ds}" ];then 
	VPVIn="$(3dinfo -voxvol ${p_MskCSF_ds})"
	if [ "$(echo "$VPVIn != $VPVAssign" | bc -l)" -eq 1 ]; then IDX_Resample='y';rm -f ${p_MskCSF_ds};fi
fi
if [ ! -f "${p_MskCSF_ds}" ]; then
	3dresample -dxyz ${vsize} ${vsize} ${vsize} -rmode NN -prefix ${p_MskCSF_ds} -inset ${p_T1_MskCSF}
	echo "||"
	echo "|| ~~~~~~~~~~ [ CSF Mask @ ${vsize}x${vsize}x${vsize} T1 ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	echo "|| ...........`dirname  ${p_MskCSF_ds}`"
	echo "|| .................`basename  $(ls ${p_MskCSF_ds})`"
	echo "|| ---------------------------------------------------------------------------------"
fi
# #=========================================================================================
# #----- oO(^^)Oo -------------------------------------------[ Motion Correction :: PART II]

ttStamp="$(date +"%H%M%S")"; PNTStage="05_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxM" == "O" ]; then
	
	p_MCRT_RegMtx="${Dir_MCRT}/${FN_In}_RegMtx_3dvolreg.1D"
	p_RegO_MPar="${Dir_MCRT}/${FN_In}.par"
	if [ ! -f "${p_MCRT}" ] || [ "$IDX_Resample" == "y" ];then
		echo "||	" 	
		echo "||	(M) Motion Correction | Data Existence (X) Conducting !!! >>>>>>>>>PART II" 
		echo "||	........................................................(With Registration)" 
		echo "||	"

		rm -f "${p_MCRT}" "${p_MCRT_RegMtx}" "${p_RegO_MPar}"
		3dvolreg -verbose -zpad 1 -base ${base} -1Dfile "${p_RegO_MPar}" -prefix "${p_MCRT}" -cubic -1Dmatrix_save "${p_MCRT_RegMtx}" "${p_In}"
		mv ${p_MCRT} "${Dir_MCRT}/$(echo `basename $p_MCRT` | sed 's/.nii.gz//g' | sed 's/.nii//g')%EPI.${ImExt}";

		1dplot -sep -xlabel "Scan (@ Base ${base})" -png "${Dir_MCRT}/${FN_In}-MotionPara-Base-${base}.png" -volreg "${p_RegO_MPar}"

		# ${fslver}fsl_tsplot -i "${p_RegO_MPar}" -o "${Dir_MCRT}/${FN_In}-rot(Base_${base}).png" \
		# -t "3dvolreg estimated rotations (degree) @ Base ${base}" -u 1 --start=1 --finish=3 -a roll,pitch,yaw -w 640 -h 144 \
		
		# ${fslver}fsl_tsplot -i "${p_RegO_MPar}" -o "${Dir_MCRT}/${FN_In}-disp(Base_${base}).png"\
		# -t "3dvolreg estimated displacement (mm) @ Base ${base}" -u 1 --start=4 --finish=6 -a Superior,Left,Posterior -w 640 -h 144 \
	
		# RegMtx_raw2base="$(ls ${Dir_Task}/Fd_MCRT_${ID}*/${ID}*_3dvolreg.1D)" 
		
		if [ "$Reg_Coord" == "y" ]; then
			3dresample -master ${p_T1_ds} -rmode Linear -prefix ${p_MCRT} -inset "${Dir_MCRT}/$(echo `basename $p_MCRT` | sed 's/.nii.gz//g' | sed 's/.nii//g')%EPI.${ImExt}"
		else
			RegMtx_raw2base="${Dir_MCRT}/mat.r01.vr.aff12.1D"; # Name should be "mat.r01.vr.aff12.1D"
			rm -f "$RegMtx_raw2base"; cp $p_MCRT_RegMtx $RegMtx_raw2base
			RegMtx_raw2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_raw2anat_${Tp_RS}_2_${Tp_T1}"; 
	    	# cat_matvec -ONELINE "${RegMtx_task2anat}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			if [ -f "${p_Jump}" ];then 
				#cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" -I "${RegMtx_rs2jump}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
				cat_matvec -ONELINE "${RegMtx_jump2anat}.1D" "${RegMtx_rs2jump}.1D" "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			else
				#cat_matvec -ONELINE "${RegMtx_rs2anat}.1D" -I "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
				cat_matvec -ONELINE "${RegMtx_rs2anat}.1D" "${RegMtx_raw2base}" > "${RegMtx_raw2anat}.1D"
			fi
			rm -f ${p_MCRT}; 3dAllineate -base ${p_T1_ds} -input "${p_In}" -final cubic -1Dmatrix_apply "${RegMtx_raw2anat}.1D" -prefix ${p_MCRT}
		fi
	
	else
		echo "||	(M) Motion Correction | Data Existence (O) Named by `basename  ${p_MCRT}`   " 			
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_MCRT}"; #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	p_MCRT="${Dir_RS}/----------"
	# <<Assign FN>>
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	if [ "${#ID}" -eq "${#FN_In}" ];then
		p_Align="${Dir_RS_tmp}/${FN_In}_A.${ImExt}";
	else
		p_Align="${Dir_RS_tmp}/${FN_In}A.${ImExt}";
	fi

	if [ ! -f "${p_Align}" ] || [ "$IDX_Resample" == "y" ];then
		echo "||"	
		echo "||	(A) Align to native T1| REGISTRATION(${RegMed}) [Rest >> ---- >> Anat]>>>>>>>>>> "	
		echo "||	"

		if [ "$Reg_Coord" == "y" ]; then
			3dresample -master ${p_T1_ds} -rmode Linear -prefix ${p_Align} -inset "${p_In}"
		elif [ -f "${RegMtx_rs2anat}.1D" ];then 
			rm -f ${p_Align}; 3dAllineate -base ${p_T1_ds} -input "${p_In}" -final cubic -1Dmatrix_apply "${RegMtx_rs2anat}.1D" -prefix ${p_Align}	
		fi		
		
	else
		echo "||	(A) Align to native T1| Data Existence (O) Named by `basename  ${p_Align}`   " 
	fi

	if [ -f "${p_Align}" ];then
		#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		p_In="${p_Align}"; #(Renew Dataset)
		#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		p_RegO_MPar="${Dir_RS_tmp}/Empty_RegO_MPar.txt" # Don't delete, Prepare for the motion correction
	else
		p_Align="${Dir_RS_tmp}/----------"
	fi

fi

if [ -f "${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig.HEAD" ];then 
	pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns.${ImExt}"; 
	3dAFNItoNIFTI -prefix "${pOut}" "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ns+orig"
fi
# #=========================================================================================
# #----- oO(^^)Oo --------------------------------------------------[ Field Map Correction ]
ttStamp="$(date +"%H%M%S")"; PNTStage="06_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxF" == "O" ]; then
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	p_FCRT="${Dir_RS_tmp}/${FN_In}F.${ImExt}";

	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_FCRT}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	p_FCRT="${Dir_RS}/----------"
fi  

# #=========================================================================================
# #----- oO(^^)Oo -----------------------------------------------------[ Despike & Detrend ]
ttStamp="$(date +"%H%M%S")"; PNTStage="07_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxD" == "O" ]; then
	DspkDtnd_Order="1"
	
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	p_DspkDtnd="${Dir_RS_tmp}/${FN_In}D${DspkDtnd_Order}.${ImExt}";
	
	if [ ! -f "${p_DspkDtnd}" ] || [ "$IDX_Resample" == "y" ];then

		echo "||	" 	
		echo "||	(D) Despike & Detrend | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> " 	
		echo "||	"
 		rm -f ${p_DspkDtnd}
 		bash ${SDIR}/Fn_MDAP4_DspkDtnd.sh -i "${p_In}" -r "${DspkDtnd_Order}" -O "${Dir_RS_tmp}"
	else
		echo "||	(D) Despike & Detrend | Data Existence (O) Named by `basename  ${p_DspkDtnd}`   " 			
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_DspkDtnd}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else

	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	p_DspkDtnd="${Dir_RS_tmp}/${FN_In}DK.${ImExt}";
	
	if [ ! -f "${p_DspkDtnd}" ];then

		echo "||	" 	
		echo "||	(D) Despike           | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> " 		
		echo "||	"
 		rm -f ${p_DspkDtnd}
 		3dDespike -NEW -nomask -prefix "${p_DspkDtnd}" "${p_In}"
	else
		echo "||	(D) Despike           | Data Existence (O) Named by `basename  ${p_DspkDtnd}`   " 			
	fi
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_DspkDtnd}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#p_DspkDtnd="${Dir_Task_tmp}/----------"
fi  


# #=========================================================================================
# #----- oO(^^)Oo ---------------------------------------------------[ Nuisance Regression ]
#-------------------------------------------------------------------------------------------
ttStamp="$(date +"%H%M%S")"; PNTStage="08_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxN" == "O" ]; then
	
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	if [ -f "${p_T1}" ];then
		if [ "$NR_Global" == "y" ]; then
			numReg="9"
		else
			numReg="8"
		fi
	else
		numReg="6"
	fi
	p_NReg="${Dir_RS_tmp}/${FN_In}N${numReg}.${ImExt}"

	#------------------------------------------------[ BBR Registration : Check Results ]-----------||
	# Des="T1";pOut="${Dir_Reg}/$(echo `basename $p_RSV01` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.nii.gz"; 
	# if [ ! -f "${pOut}" ];then 
	# 	echo "||	"	
	# 	echo "||	(N) Nuisance Regress  | REGISTRATION(${RegMed}) Output >> $(echo `basename $pOut`) "	
	# 	echo "||	"
	# 	rm -f ${pOut}; flirt -ref "${p_T1}" -in "${p_RSV01}" -applyxfm -init "${RegMtx_rs2anat}" -interp "trilinear" -out "${pOut}"
	# fi

	# Des="REST";pOut="${Dir_Reg}/$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${RegMed}_${Des}.nii.gz"; 
	# if [ ! -f "${pOut}" ];then 
	# 	echo "||	"	
	# 	echo "||	(N) Nuisance Regress  | REGISTRATION(${RegMed}) Output >> $(echo `basename $pOut`) "	
	# 	echo "||	"
	# 	rm -f ${pOut}; flirt -ref "${p_RSV01}" -in "${p_T1}" -applyxfm -init "${RegMtx_anat2rs}" -interp "trilinear" -out "${pOut}"
	# fi

	#-------------------------------------------------------------------------------------
	# Do Nuisance Regressor
	#-------------------------------------------------------------------------------------
 
	p_RegO_ALL="${Dir_RS_tmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_RegOut_ALL.txt";
	rm -f $p_RegO_ALL
	# ls $p_RegO_ALL
	# ls $p_RegO_MPar
	if [ ! -f "${p_RegO_ALL}" ];then
		echo "||	" 	
		echo "||	(N) Nuisance Regress  | REGRESSOR PREPARATION >>>>>>>>>>>>>>>>>>>>>>>>>>>> "	
		echo "||	"
 
		p_RegO_Global="${Dir_RS_tmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_RegOut_Global.txt";
		p_RegO_WM="${Dir_RS_tmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_RegOut_WM.txt"; 
		p_RegO_CSF="${Dir_RS_tmp}/$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_RegOut_CSF.txt";

		rm -f "${p_RegO_WM}" "${p_RegO_CSF}" "${p_RegO_Global}"
		3dmaskave -mask "${p_MskWM_ds}" -mrange 1 1 -quiet "${p_In}" > "${p_RegO_WM}"
		3dmaskave -mask "${p_MskCSF_ds}" -mrange 1 1 -quiet "${p_In}" > "${p_RegO_CSF}"


		nVxlinMskWM="$(3dmaskave -mask "${p_MskWM_ds}" -quiet -sum -mrange 1 1 "${p_MskWM_ds}")"
		nVxlinMskCSF="$(3dmaskave -mask "${p_MskCSF_ds}" -quiet -sum -mrange 1 1 "${p_MskCSF_ds}")"
		if [ -z "$nVxlinMskWM" ]; then nVxlinMskWM="0"; fi
		if [ -z "$nVxlinMskCSF" ]; then nVxlinMskCSF="0"; fi



			#statements
		echo "|| "
		echo "|| >>>>>>>>>>>>> Regressing out (Motion) + ( WM ) + ( CSF ) + (Global)"
		echo "|| "


		if [ "$NR_Global" == "y" ]; then
			echo "|| >>>>>>>>>>>>> $(ls $p_T1Msk_ds)"
			3dmaskave -mask "${p_T1Msk_ds}" -mrange 1 1 -quiet "${p_In}" > "${p_RegO_Global}"
			#1dcat ${p_RegO_MPar} ${p_RegO_WM} ${p_RegO_CSF} ${p_RegO_Global} > ${p_RegO_ALL}

			if [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( O  ) + (  O  ) + (   O  )"
				1dcat ${p_RegO_MPar} ${p_RegO_WM} ${p_RegO_CSF} ${p_RegO_Global} > ${p_RegO_ALL}

			elif [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( O  ) + (  -  ) + (   O  )"
				1dcat ${p_RegO_MPar} ${p_RegO_WM} ${p_RegO_Global} > ${p_RegO_ALL}

			elif [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( -  ) + (  O  ) + (   O  )"
				1dcat ${p_RegO_MPar} ${p_RegO_CSF} ${p_RegO_Global} > ${p_RegO_ALL}
				
			elif [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( -  ) + (  -  ) + (   O  )"
				1dcat ${p_RegO_MPar} ${p_RegO_Global} > ${p_RegO_ALL}

			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   -  ) + ( O  ) + (  O  ) + (   O  )"
				1dcat ${p_RegO_WM} ${p_RegO_CSF} ${p_RegO_Global} > ${p_RegO_ALL}
			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   -  ) + ( O  ) + (  -  ) + (   O  )"
				1dcat ${p_RegO_WM} ${p_RegO_Global} > ${p_RegO_ALL}

			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   -  ) + ( -  ) + (  O  ) + (   O  )"
				1dcat ${p_RegO_CSF} ${p_RegO_Global} > ${p_RegO_ALL}
				
			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   -  ) + ( -  ) + (  -  ) + (   O  )"
				1dcat ${p_RegO_Global} > ${p_RegO_ALL}
			fi

			rm -f "${p_RegO_Global}"
		else
			#1dcat ${p_RegO_MPar} ${p_RegO_WM} ${p_RegO_CSF} > ${p_RegO_ALL}
			if [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( O  ) + (  O  ) + (   -  )"
				1dcat ${p_RegO_MPar} ${p_RegO_WM} ${p_RegO_CSF} > ${p_RegO_ALL}

			elif [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( O  ) + (  -  ) + (   -  )"
				1dcat ${p_RegO_MPar} ${p_RegO_WM} > ${p_RegO_ALL}

			elif [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( -  ) + (  O  ) + (   -  )"
				1dcat ${p_RegO_MPar} ${p_RegO_CSF} > ${p_RegO_ALL}

			elif [ -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( -  ) + (  -  ) + (   -  )"
				1dcat ${p_RegO_MPar} > ${p_RegO_ALL}

			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( O  ) + (  O  ) + (   -  )"
				1dcat ${p_RegO_WM} ${p_RegO_CSF} > ${p_RegO_ALL}

			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -gt "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( O  ) + (  -  ) + (   -  )"
				1dcat ${p_RegO_WM} > ${p_RegO_ALL}

			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -gt "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( -  ) + (  O  ) + (   -  )"
				1dcat ${p_RegO_CSF} > ${p_RegO_ALL}

			elif [ ! -f "${p_RegO_MPar}" ] && [ "${nVxlinMskWM}" -eq "0" ] && [ "${nVxlinMskCSF}" -eq "0" ]; then
				echo "|| >>>>>>>>>>>>> Regressing out (   O  ) + ( -  ) + (  -  ) + (   -  )"
				echo "" > ${p_RegO_ALL}
			fi
		fi

		echo "|| "

		rm -f "${p_RegO_WM}" "${p_RegO_CSF}"
	# 	3dmaskave -mask "${ID}_SeedSphere_${TaskN}.nii.gz" -mrange 1 1 -quiet "${p_preRS}" > "${RegSeed}"
	else
		echo "||	(N) Nuisance Regress  | REGRESSOR PREPARATION  (Exist) >>>>>>>>>>>>>>>>>>> "	
	fi

	numReg=$(head -n 1 ${p_RegO_ALL} | awk '{print NF}')


	Tmp_Mn="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_Mn.${ImExt}"; 
	Tmp_RMVL="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_RMVL.${ImExt}"; 

	p_NReg="${Dir_RS_tmp}/${FN_In}N${numReg}.${ImExt}"
	# if [ "${numReg}" -gt "0" ];then
		if [ ! -f "${p_NReg}" ] || [ "$IDX_Resample" == "y" ];then
		
			echo "||	"	
			echo "||	(N) Nuisance Regress  | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> "
			echo "||	"
			#--------------------------------------------------------[Calculate Tmean]----------||
			#rm -f ${Tmp_Mn};${fslver}fslmaths "${p_In}" -Tmean "${Tmp_Mn}"

	        rm -f ${Tmp_Mn}; 3dTstat -mean -prefix "${Tmp_Mn}" "${p_In}"

			#--------------------------------------------[Execute RMVL via 3dBandpass]----------||
			rm -f ${Tmp_RMVL};3dBandpass -nodetrend -notrans -ort "${p_RegO_ALL}" -prefix "${Tmp_RMVL}" -band 0 99999 -input "${p_In}"

			#------------------------------------------[Add Tmean back to RMVLed Data]----------||
			rm -f ${p_NReg};3dcalc -a "${Tmp_Mn}" -b "${Tmp_RMVL}" -expr "a+b" -prefix "${p_NReg}"

			rm -f $Tmp_Mn $Tmp_RMVL
		else
			echo "||	(N) Nuisance Regress  | Data Existence (O) Named by `basename  ${p_NReg}`   " 
		fi
		#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		p_In="${p_NReg}" #(Renew Dataset)
		#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# fi
else
	p_NReg="${Dir_RS_tmp}/----------"
fi  


# #=========================================================================================
# #----- oO(^^)Oo -----------------------------------------------------[ Bandpass filtering ]
ttStamp="$(date +"%H%M%S")"; PNTStage="09_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

if [ "$IdxB" == "O" ]; then
	
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')
	
#	Freq_low="0.01"; Freq_high="0.10"
# 	Freq_low="0.01"; Freq_high="0.08"
	pnt_F1=$(echo $Freq_low | cut -d '.' -f 2);pnt_F2=$(echo $Freq_high | cut -d '.' -f 2);pnt_F="${pnt_F1}${pnt_F2}"
	
	#p_BandPass="${Dir_OT}/${FN_In}P.nii.gz";
	p_BandPass="${Dir_RS_tmp}/${FN_In}B${pnt_F}.${ImExt}";
	
	if [ ! -f "${p_BandPass}" ] || [ "$IDX_Resample" == "y" ];then
		echo "||	" 	
		echo "||	(B) Bandpass filter   | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> "
		echo "||	"

		Tmp_Mn="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_Mn.${ImExt}"; rm -f $Tmp_Mn
		Tmp_BandPass="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_Tmp_BandPass.${ImExt}"; rm -f $Tmp_BandPass
   
		#--------------------------------------------------------[Calculate Tmean]----------||
		#${fslver}fslmaths "${p_In}" -Tmean "${Tmp_Mn}"
		rm -f ${Tmp_Mn}; 3dTstat -mean -prefix "${Tmp_Mn}" "${p_In}"

		#--------------------------------------------[Execute RMVL via 3dBandpass]----------||

		3dBandpass -nodetrend -dt "$TR" -band "$Freq_low" "$Freq_high" -prefix "${Tmp_BandPass}" -input "${p_In}"
		# 3dBandpass -nodetrend -dt "2" -band "0.01" "0.08" -prefix "${Tmp_BandPass}" -input "${p_In}"

		#----------------------------------------[Add Tmean back to BandPass Data]----------||
		rm -f ${p_BandPass};
		3dcalc -a "${Tmp_Mn}" -b "${Tmp_BandPass}" -expr "a+b" -prefix "${p_BandPass}"

		rm -f $Tmp_Mn $Tmp_BandPass
	else
		echo "||	(B) Bandpass filter   | Data Existence (O) Named by `basename  ${p_BandPass}`   " 	
	fi 
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_BandPass}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
else
	p_BandPass="${Dir_RS_tmp}/----------"
fi  


#=========================================================================================
#----- oO(^^)Oo ------------------------------------------------------------------[ ReHo ]

if [ "$Idx_ReHo" == "y" ]; then

	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	if [ "$(echo "$vsize >= 3" | bc -l)" -eq 1 ]; then NNeigh='1'; else NNeigh='2';fi
	pReHo="${Dir_RS_tmp}/${FN_In}_ReHo${NNeigh}N.${ImExt}"; 
	pReHo_atT1="${Dir_RS}/${FN_In}_ReHo${NNeigh}N%T1_${RegMed}.${ImExtOT}"
	if [ ! -f "${pReHo}" ] || [ "$IDX_Resample" == "y" ];then
			echo "||	" 	
			echo "||	(*) ReHo Calculation  | Data Existence (X) Conducting !!! >>>>>>>>>>>>>>>> "
			echo "||	"
			bash ${SDIR}/Fn_3DReHo.sh -i "${p_In}" -m "${p_T1Msk_ds}" -N ${NNeigh} -o "${pReHo}" 
	else
			echo "||	" 	
			echo "||	(*) ReHo Calculation  | Data Existence (O) Named by `basename  ${pReHo}`   "
			echo "||	"
	fi
	if [ ! -f "${pReHo_atT1}" ] || [ "$IDX_Resample" == "y" ];then
		3dresample -master ${p_T1} -prefix "${pReHo_atT1}" -inset ${pReHo}
	fi

	pMetaMsk="${Dir_Seg}/Inv_MNI152_Meta_LangB.nii"
	pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskBroca.${ImExtOT}"

	# pMetaMsk="${Dir_Seg}/Inv_MNI152_SAreaB_R24.nii"
	# pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskBroca_R24.nii.gz"
	if [ -d "${TDIR}" ] && [ ! -f "${pReHo_MskbyMeta}" ] && [ -f "${pMetaMsk}" ] && [ -f "${pReHo_atT1}" ];then
	
	echo "||	(*) ReHo Calculation  | Mask by Meta Analysis Results (Broca)>>>>>>>>>>>>>>>>>> "
	echo "||	"
		rm -f ${pReHo_MskbyMeta}; 3dcalc -a "${pReHo_atT1}" -b "${pMetaMsk}" -expr 'a*ispositive(b-0.8)' -prefix "${pReHo_MskbyMeta}"
	fi



	pMetaMsk="${Dir_Seg}/Inv_MNI152_MetaExt_LangB.nii"
	pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskBrocaExt.${ImExtOT}"

	# pMetaMsk="${Dir_Seg}/Inv_MNI152_SAreaB_R24.nii"
	# pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskBroca_R24.nii.gz"
	if [ -d "${TDIR}" ] && [ ! -f "${pReHo_MskbyMeta}" ] && [ -f "${pMetaMsk}" ] && [ -f "${pReHo_atT1}" ];then
	
	echo "||	(*) ReHo Calculation  | Mask by Meta Analysis Results (Broca)>>>>>>>>>>>>>>>>>> "
	echo "||	"
		rm -f ${pReHo_MskbyMeta}; 3dcalc -a "${pReHo_atT1}" -b "${pMetaMsk}" -expr 'a*ispositive(b-0.8)' -prefix "${pReHo_MskbyMeta}"
	fi

	pMetaMsk="${Dir_Seg}/Inv_MNI152_Meta_LangW.nii"
	pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskWernicke.${ImExtOT}"
	# pMetaMsk="${Dir_Seg}/Inv_MNI152_SAreaW_R30.nii"
	# pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskWernicke_R30.nii.gz"

	if [ -d "${TDIR}" ] && [ ! -f "${pReHo_MskbyMeta}" ] && [ -f "${pMetaMsk}" ] && [ -f "${pReHo_atT1}" ];then
		echo "||	(*) ReHo Calculation  | Mask by Meta Analysis Results (Wernicke)>>>>>>>>>>> "
		echo "||	"
		rm -f ${pReHo_MskbyMeta}; 3dcalc -a "${pReHo_atT1}" -b "${pMetaMsk}" -expr 'a*ispositive(b-0.8)' -prefix "${pReHo_MskbyMeta}"
	fi


	pMetaMsk="${Dir_Seg}/Inv_MNI152_MetaExt_LangW.nii"
	pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskWernickeExt.${ImExtOT}"
	# pMetaMsk="${Dir_Seg}/Inv_MNI152_SAreaW_R30.nii"
	# pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskWernicke_R30.nii.gz"

	if [ -d "${TDIR}" ] && [ ! -f "${pReHo_MskbyMeta}" ] && [ -f "${pMetaMsk}" ] && [ -f "${pReHo_atT1}" ];then
		echo "||	(*) ReHo Calculation  | Mask by Meta Analysis Results (Wernicke)>>>>>>>>>>> "
		echo "||	"
		rm -f ${pReHo_MskbyMeta}; 3dcalc -a "${pReHo_atT1}" -b "${pMetaMsk}" -expr 'a*ispositive(b-0.8)' -prefix "${pReHo_MskbyMeta}"
	fi

	pMetaMskB="${Dir_Seg}/Inv_MNI152_Meta_LangB.nii"
	pMetaMskW="${Dir_Seg}/Inv_MNI152_Meta_LangW.nii"
	pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskLanguage.${ImExtOT}"

	# pMetaMskB="${Dir_Seg}/Inv_MNI152_SAreaB_R24.nii"
	# pMetaMskW="${Dir_Seg}/Inv_MNI152_SAreaW_R30.nii"
	# pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_Msk_BR24_WR30.nii.gz"
	if [ -d "${TDIR}" ] && [ ! -f "${pReHo_MskbyMeta}" ] && [ -f "${pMetaMskB}" ] && [ -f "${pMetaMskW}" ] && [ -f "${pReHo_atT1}" ];then
		echo "||	"
		echo "||	(*) ReHo Calculation  | Mask by Meta Analysis Results (Language)>>>>>>>>>>>> "
		echo "||	"
		rm -f ${pReHo_MskbyMeta}; 3dcalc -a "${pReHo_atT1}" -b "${pMetaMskB}" -c "${pMetaMskW}" -expr 'a*ispositive(b+c-0.8)' -prefix "${pReHo_MskbyMeta}"
	fi

	pMetaMskB="${Dir_Seg}/Inv_MNI152_MetaExt_LangB.nii"
	pMetaMskW="${Dir_Seg}/Inv_MNI152_MetaExt_LangW.nii"
	pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_MskLanguageExt.${ImExtOT}"

	# pMetaMskB="${Dir_Seg}/Inv_MNI152_SAreaB_R24.nii"
	# pMetaMskW="${Dir_Seg}/Inv_MNI152_SAreaW_R30.nii"
	# pReHo_MskbyMeta="${Dir_RS}/$(echo `basename $pReHo_atT1` | sed 's/.nii.gz//g'| sed 's/.nii//g')_Msk_BR24_WR30.nii.gz"
	if [ -d "${TDIR}" ] && [ ! -f "${pReHo_MskbyMeta}" ] && [ -f "${pMetaMskB}" ] && [ -f "${pMetaMskW}" ] && [ -f "${pReHo_atT1}" ];then
		echo "||	"
		echo "||	(*) ReHo Calculation  | Mask by Meta Analysis Results (Language)>>>>>>>>>>>> "
		echo "||	"
		rm -f ${pReHo_MskbyMeta}; 3dcalc -a "${pReHo_atT1}" -b "${pMetaMskB}" -c "${pMetaMskW}" -expr 'a*ispositive(b+c-0.8)' -prefix "${pReHo_MskbyMeta}"
	fi
fi

#=========================================================================================
#----- oO(^^)Oo --------------------------------------------------------------[ Blurring ]
ttStamp="$(date +"%H%M%S")"; PNTStage="10_of_10"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

# || [ "$IDX_Resample" == "y" ]

if [ "$IdxS" == "O" ]; then
	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

	# if [ "$Idx_ReHo" == "y" ]; then
	# 	if [ "$(echo "$vsize >= 3" | bc -l)" -eq 1 ]; then NNeigh='1'; else NNeigh='2';fi
	# 	pReHo="${Dir_RS}/${FN_In}_ReHo${NNeigh}N.nii.gz"; 
	# 	if [ ! -f "${pReHo}" ] || [ "$IDX_Resample" == "y" ];then
	# 			bash ${SDIR}/Fn_3DReHo.sh -i "${p_In}" -m "${p_T1Msk_ds}" -N ${NNeigh} -o "${pReHo}" 
	# 		fi
	# 	if [ ! -f "${Dir_RS}/${FN_In}_ReHo${NNeigh}N%T1_${RegMed}.nii.gz" ] || [ "$IDX_Resample" == "y" ];then
	# 		3dresample -master ${p_T1} -prefix "${Dir_RS}/${FN_In}_ReHo2N%T1_${RegMed}.nii.gz" -inset ${pReHo}
	# 	fi
	# fi

	# krnl_Blur="4"
	p_Blur="${Dir_RS_tmp}/${FN_In}S${krnl_Blur}mm.${ImExt}";
	
	if [ ! -f "${p_Blur}" ] || [ "$IDX_Resample" == "y" ];then
		echo "||	" 	
	    echo "||	(S) Smooth            | Data Existence (X) Smoothing (${krnl_Blur} mm) !!! >>>>>>>>>> " 
		echo "||	"	

		rm -f ${p_Blur}
		3dmerge -1blur_fwhm ${krnl_Blur} -doall -quiet -prefix "${p_Blur}" "${p_In}"
	else	
		echo "||	(S) Smooth            | Data Existence (O) Named by `basename  ${p_Blur}`   " 
	fi 
	
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	p_In="${p_Blur}" #(Renew Dataset)
	#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
fi  


#=========================================================================================
#----- oO(^^)Oo ------------------------------------------------------------[ FC Mapping ]


# if [ "$IdxC" == "O" ]; then
# 	FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g'| sed 's/.nii//g')

# 	p_FCZ="${Dir_RS}/${FN_In}CZ_${Tp_Seed}%T1.nii.gz";
# 	p_FCR="${Dir_RS}/${FN_In}CR_${Tp_Seed}%T1.nii.gz";
	
# 	if [ ! -f "${p_FCZ}" ];then
# 		echo "||	" 	
# 	    echo "||	(C) Connectivity      | Data Existence (X) Seed @ (${Tp_Seed}) !!! >>>>>>>>>> " 
# 		echo "||	"	

# 		rm -f ${p_FC}

# 	#--------------------------[ Register Seed Mask to REST space & Extract Time Series ]-----------||

# 		fslmaths "${p_Seed}" -mul "${p_T1_MskBrn}" "${p_Seed}"
# 		p_RS_Seed="${Dir_RS}/$(echo `basename $p_Seed` | sed 's/.nii.gz//g'| sed 's/.nii//g')%REST.nii.gz"
# 		if [ ! -f "${p_RS_Seed}" ];then 
# 			echo "||	"	
# 			echo "||	(C) Connectivity      | REGISTER Seed to REST SPACE !!! >>>>>>>>>> " 	
# 			echo "||	"
# 			rm -f ${p_RS_Seed}; flirt -ref "${p_RSV01}" -in "${p_Seed}" -applyxfm -init "${RegMtx_anat2rs}" -interp "nearestneighbour" -out "${p_RS_Seed}"
# 		fi

# 		p_Seed_ts="${FN_In}_SeedTimeSeries_${Tp_Seed}.txt"
# 		p_Glb_Msk="$(ls ${Dir_RS}/Fd_MCRT_${ID}*/${ID}*_T_01_Msk.nii.gz)"
# 		3dmaskave -mask "${p_RS_Seed}" -mrange 1 1 -quiet "${p_In}" > "${p_Seed_ts}"

# 	#----------------------------------------------------[ Calculate Correlation Coef  ]-----------||

# 	rm -f ${Dir_RS}/Stat_CCC_${FN_In}_${ROI_lbl}_* ${Dir_RS}/Stat_CCC_${FN_In}_${ROI_lbl}.nii.gz
#     3dfim+ -input "${p_In}" \
#             -ideal_file "${p_Seed_ts}" \
#             -out 'All' \
#             -fim_thr 0 \
#             -mask "${p_Glb_Msk}" \
#             -bucket "${Dir_RS}/Stat_CCC_${FN_In}_${Tp_Seed}.nii.gz"

#     pCCC="$(ls ${Dir_RS}/Stat_CCC_${FN_In}_${Tp_Seed}.nii.gz)"
# 	pStatCorrR="${Dir_RS}/Stat_CCR_${FN_In}_${Tp_Seed}.nii.gz"; rm -f ${pStatCorrR}*
# 	pStatCorrZ="${Dir_RS}/Stat_CCZ_${FN_In}_${Tp_Seed}.nii.gz"; rm -f ${pStatCorrZ}*
		
# 	3dcalc -a ${pCCC}'[5]' -expr "a" -prefix "${pStatCorrR}"
# 	3dcalc -a ${pCCC}'[5]' -expr "0.5*log((1+a)/(1-a))" -datum float -prefix "${pStatCorrZ}"
# 	#cp $pStatCorrZ $p_FC


# 	# flirt -ref "${p_T1}" -in "${pStatCorrR}" -applyxfm -init "${RegMtx_rs2anat}" -interp "trilinear" -out "${p_FCR}"
# 	# flirt -ref "${p_T1}" -in "${pStatCorrZ}" -applyxfm -init "${RegMtx_rs2anat}" -interp "trilinear" -out "${p_FCZ}"

# 	3dAllineate -base ${p_T1} -input ${pStatCorrZ} -final trilinear -1Dmatrix_apply "${RegMtx_rs2anat}.1D" -prefix ${p_FCZ}


# 	else	
# 		echo "||	(C) Connectivity      | Data Existence (O) Named by `basename  ${p_FCZ}`   " 
# 	fi 
	
# fi  



# p_OT="${Dir_OT}/Stat_GLM_${PID}_${TaskN}_FDR.nii.gz"

# if [ -f "${p_In}" ] && [ ! -f "${p_OT}" ];then
# 	echo "||	" 	
#     echo "||	(4) FDR Correction    | Data Existence (X) Creating !!! >>>>>>>>>>>>>>>>>> " 
# 	echo "||	"	
# 	3dFDR -input $p_In[3] -mask ${p_Msk} -prefix ${p_OT}

# 	echo "|| "
# 	echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
# 	echo "|| ...........`dirname  ${p_OT}`"
# 	echo "|| .................`basename  ${p_OT}`"
# 	echo "-----------------------------------------------------------------------------------"
# fi

ttStamp="$(date +"%H%M%S")"; PNTStage="DONE"; p_Stages="${Dir_OT}/===Now_to_Stage_${PNTStage}=${ttStamp}==.txt"; echo "$PNTStage" > ${p_Stages}

ENDTIME="$(date +"%m-%d-%Y  %r")"; 

# echo "|| "
# echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
# echo "  Remove unnecessary Data"
# mv ${Dir_RS}/*T.nii.gz "${Dir_RS_tmp}"
# mv ${Dir_RS}/*TM.nii.gz "${Dir_RS_tmp}"
# mv ${Dir_RS}/*TMD3.nii.gz "${Dir_RS_tmp}"
# mv ${Dir_RS}/*TMD3N?.nii.gz "${Dir_RS_tmp}"

# mv ${Dir_RS}/*TMD3N?B????.nii.gz "${Dir_RS_tmp}"
# mv ${Dir_RS}/*TMD3N*_ReHo?N.nii.gz "${Dir_RS_tmp}"
# echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
# echo "|| "

echo "|| "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "  END : ${ENDTIME}"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| "

rm -f ${Dir_OT}/===Now_to_Stage_*.txt
				
echo "|| "
echo "==========================={ END :: Fn_MDAS2_rsPrep.sh  }========================= " 
echo "|| "
