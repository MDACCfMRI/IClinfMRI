function [D3_RGB]=Fn_fMRIConf(MtxImU,MtxfMRI,MtxCVR,THRf,THRc,idx_sv,idx_fp,CMap)
% ||
% ||  ==================={ Usage :: Fn_fMRIConf }==========================
% ||
% ||  =====Fn_OLay2RGB(MtxImU,MtxfMRI,MtxCVR,THRf,THRc,idx_sv,idx_fp,CMap)==========
% ||                      [1]   [2]    [3]    [4]  [5]   [6]   [7]    [8]
% ||  [Descirption]:
% ||                 MtxImU :: Underlay
% ||                 MtxfMRI :: fMRI Result (Overlay)
% ||                 MtxCVR :: CVR Result (for indicating confidence)
% ||                 THRf :: The lower and uppter threshold of overlay colormap
% ||                        THR(1): lower threshold of overlay colormap
% ||                        THR(2): upper threshold of overlay colormap
% ||                        THR(3): the opacity of overlay colormap
% ||                 THRc :: The lower and uppter threshold of overlay colormap
% ||                        THR(1): lower threshold of overlay colormap
% ||                        THR(2): upper threshold of overlay colormap
% ||                        THR(3): the opacity of overlay colormap
% ||
% ||                 (Optional) idx_sv:: the index for saving RGB map as tif
% ||
% ||                 (Optional) idx_fp:: the index for image flipping
% ||
% ||  [DEMO]:
%               THR=[0.6 2 0.8];idx_sv='n';idx_fp='n';
%               tic;[CellD3_RGB CellD3_Gray]=Fn_OLay2RGB(MtxImU,MtxImO,THR,idx_sv,idx_fp);toc
% ||
% ||            ~~ Written by Ai-Ling Irene Hsu on 2017.06.27 ~~
% ||   Copyright � 2017 The University of Texas MD Anderson Cancer Center
% ||  ==========================={ Usage END }=============================

% IDX_DBRes='n'; % Double Resolution

if nargin < 6
    idx_sv='n';
end


if nargin < 8
CMap='autumn';
end

SclBit=256;
F5=figure('Name','Processing','units','pixels','position',[500 500 200 50],'windowstyle','modal');
cmap_gray=colormap(gray(SclBit));close(F5)

F5=figure('Name','Processing','units','pixels','position',[500 500 200 50],'windowstyle','modal');
% cmap_hot=colormap(autumn(SclBit));close(F5)
if strcmp(CMap,'autumn')
    cmap_hot=colormap(autumn(SclBit));%close all;
elseif strcmp(CMap,'jet')
    cmap_hot=colormap(jet(SclBit));%close all;
elseif strcmp(CMap,'bluehot')
    n=0;m=SclBit;
    BlueHot = [0 1 1;0 0 1;n n n; 1 0 0;1 1 0;];
    coord = linspace(1, size(BlueHot, 1), m);
    cmap_hot = interp1(BlueHot, coord, 'linear');
end
close(F5)

cmap_Dblue=repmat([0 32 96]/256,[SclBit 1]);


MtxfMRI_ORI=MtxfMRI;
if(sum(size(MtxImU))~=sum(size(MtxfMRI_ORI)))
    disp(['||          >>>  Matrix size(Underlay) ~= Matrix size(Ovelylay)....Doing Interpolation ...'])
    clear MtxfMRI
    [MtxfMRI]=Fn_ReSlice(MtxfMRI_ORI,size(MtxImU));
else
    MtxfMRI=MtxfMRI_ORI;
end

MtxCVR_ORI=MtxCVR;
if(sum(size(MtxImU))~=sum(size(MtxCVR_ORI)))
    disp(['||          >>>  Matrix size(Underlay) ~= Matrix size(Ovelylay)....Doing Interpolation ...'])
    clear MtxCVR
    [MtxCVR]=Fn_ReSlice(MtxCVR_ORI,size(MtxImU));
else
    MtxCVR=MtxCVR_ORI;
end

if strcmp(idx_fp,'y')
    D3ULay=flipud(MtxImU);
    D3fMRI=flipud(MtxfMRI);
    D3CVR=flipud(MtxCVR);
else
    D3ULay=MtxImU;
    D3fMRI=MtxfMRI;
    D3CVR=MtxCVR;
end


SclBit=256;

% OLay_opacity=THRf(3);

% OLay_OpaCVR=0.3;
% OLay_OpafMRI=0.8;
% OLay_OpaCVR=0.3;
OLay_OpaCVR=THRc(3);
OLay_OpafMRI=THRf(3);

% -------------------[Assign Underlay data to a round number from 1~SclBit]
clear Umin Umax
SelectedMax=max(max(D3ULay(:,:,round(2*size(D3ULay,3)/3))));
D3ULayM=D3ULay;D3ULayM(D3ULayM>SelectedMax)=SelectedMax;
Umin=min(D3ULayM(:));Umax=max(D3ULayM(:));
D3ULay_Nor= 1+ round((SclBit-1)*(D3ULayM-Umin)/(Umax-Umin));
D3ULay_Nor(D3ULay==0)=1;
% -------------------[Assign Overlay fMRI to a round number from 1~SclBit]
THR_l=THRf(1);THR_h=THRf(2);
clear Umin Umax
D3fMRIM=D3fMRI;
D3fMRIM(D3fMRI<THR_l)=THR_l;
D3fMRIM(D3fMRI>THR_h)=THR_h;
Umin=min(D3fMRIM(:));Umax=max(D3fMRIM(:));
D3fMRI_Nor=1+round((SclBit-1)*(D3fMRIM-Umin)/(Umax-Umin));D3fMRI_Nor(isnan(D3fMRI_Nor))=1;
D3fMRI_Thr=( D3fMRI >= THR_l );

% -------------------[Assign Overlay CVR to a round number from 1~SclBit]
THR_l=THRc(1);THR_h=THRc(2);
clear Umin Umax
D3CVRM=D3CVR;
D3CVRM(D3CVR<THR_l)=THR_l;
D3CVRM(D3CVR>THR_h)=THR_h;
Umin=min(D3CVRM(:));Umax=max(D3CVRM(:));
D3CVR_Nor=1+round((SclBit-1)*(D3CVRM-Umin)/(Umax-Umin));D3CVR_Nor(isnan(D3CVR_Nor))=1;
D3CVR_Thr=( D3CVR >= THR_l );

clear  D3ULay_RGB D3OLay_RGB D3_RGB D3_Gray
for RGB_dim = 1:3
    D3ULay_RGB(:,:,:,RGB_dim) = reshape( cmap_gray(D3ULay_Nor, RGB_dim), size(D3ULay_Nor));
    D3CVR_RGB(:,:,:,RGB_dim) = reshape( cmap_Dblue(D3CVR_Nor, RGB_dim), size(D3CVR_Nor));
    D3fMRI_RGB(:,:,:,RGB_dim) = reshape( cmap_hot(D3fMRI_Nor, RGB_dim), size(D3fMRI_Nor));
    
    % <Method 1> Cool Result
%     D3_RGB(:,:,:,RGB_dim)=(D3CVR_Thr==0).* D3ULay_RGB(:,:,:,RGB_dim) +...
%         (D3CVR_Thr>0).*(D3fMRI_Thr==0).* ( (1-OLay_OpaCVR) * D3ULay_RGB(:,:,:,RGB_dim) + (OLay_OpaCVR)  * D3CVR_RGB(:,:,:,RGB_dim) )+...
%         (D3fMRI_Thr>0).* ( (1-OLay_OpafMRI) * D3ULay_RGB(:,:,:,RGB_dim) +(OLay_OpafMRI)  * D3fMRI_RGB(:,:,:,RGB_dim));
%     

    % <Method 2> Liu Want this
        D3_RGB(:,:,:,RGB_dim)=((D3CVR_Thr+D3fMRI_Thr)==0).* D3ULay_RGB(:,:,:,RGB_dim) +...
            (D3CVR_Thr>0).*(D3fMRI_Thr==0).*  ( (1-OLay_OpaCVR) * D3ULay_RGB(:,:,:,RGB_dim) + (OLay_OpaCVR)  * D3CVR_RGB(:,:,:,RGB_dim) )+...
        (D3fMRI_Thr>0).*( (1-OLay_OpafMRI) * D3ULay_RGB(:,:,:,RGB_dim) +(OLay_OpafMRI)  * D3fMRI_RGB(:,:,:,RGB_dim));


end


% SliceZ=62;
% hIm=imshow((permute(squeeze(D3_RGB(:,:,SliceZ,:)), [2 1 3])));
%  
% ImCVRMsk=squeeze(D3CVR_Thr(:,:,SliceZ))';
% [B,L]=bwboundaries(ImCVRMsk);
%  for k=1:length(B)
%      boundary=B{k};
%      hold on; plot(boundary(:,2),boundary(:,1),'color',cmap_Dblue(1,:),'LineWidth',1);
%  end


