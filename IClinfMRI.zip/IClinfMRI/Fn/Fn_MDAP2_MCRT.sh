#!/bin/sh

# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

================== { Fn_MDAP2_MCRT.sh } ====================
||
||  [Purpose]: (1)Execute Motion Correction on Input data  
||             (2)Move the downstrean products to the assigned folder 
||
||  [Usage]  : Fn_MDAP2_MCRT.sh -i p_In -o output.nii.gz -F FolderName -O Dir_OT
||         ex: Fn_MDAP2_MCRT.sh -i p_In
||         ex: Fn_MDAP2_MCRT.sh -i p_In -o output.nii.gz -F Fd_MCRT -O Dir_OT 
||
||  [OPTIONS]:
||            -i <Input> : The pathway of the input file
||
||	[Optional arguments]
||            -o <Output> : the filename of the output file
||            -F <Fd_MCRT> : the filename of the output file
||            -O <Dir_OT> : The Directory of output files
||
===================================================================
Created by Irene Hsu on 2016.07.10 (Bash shell) 
		@ MD Anderson
EOF

exit
}


# ============================================================================[TEST]====="
# Fn_MDAP2_MCRT.sh -i "${DirOT}/BM004_BN.nii.gz"


# ============================================================================[Help]====="
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="

#echo "Total $argn input arguments"

Opt_numb=0;
while getopts "i:o:F:O:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
	
    i)
        p_In=$OPTARG
    ;;
    o)
		FN_MCRT=$OPTARG
    ;;
    F)
		Fd_MCRT=$OPTARG
    ;;
    O)
		Dir_OT=$OPTARG
    ;;
    x)
		empty=$OPTARG
    ;;
    esac
done

# ===========================================================[Check Input arguments]====="
if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; echo "|| fslver = [${fslver}]"

if [ -z "${Dir_OT}" ];then 
	#Dir_OT=$(pwd)
	Dir_OT=$(dirname "$p_In")
fi


# if [ -z "${FN_MCRT}" ] || [ -n "${FN_MCRT}" ]; then
if [ -z "${FN_MCRT}" ] ; then
	substr="_I.nii.gz"
	if [[ $p_In == *"$substr"* ]] ; then
		FN_MCRT="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')M.nii.gz";
	else
		FN_MCRT="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_M.nii.gz";
	fi
else
	FN_MCRT="$(echo `basename $FN_MCRT`)";
fi


if [ -z "${Fd_MCRT}" ] || [ -n "${Fd_MCRT}" ]; then
	ID="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')";
# 	ID="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g' | cut -d '_' -f 1-2)";
	Fd_MCRT="Fd_MCRT_${ID}"
fi


# ============================================================================[Main]====="

#---------------------------------------------------------------------{ START }----------#
echo "|| "
echo "|| "
echo "-------------------{ Information : Fn_MDAP2_MCRT.sh}------------------------------ "
echo "|| "
echo "||	(1) ::  [ Input File ] =[ $(echo `basename $(ls $p_In)`) ] "
echo "||	(2) ::  [ New Folder ] =[ ${Fd_MCRT} ] "
echo "||	(3) ::  [ Output FN  ] =[ ${FN_MCRT} ] "
echo "||	(4) ::  [ Output Dir ] =[ ${Dir_OT} ] "
echo "|| "
echo "-----------------------------------------------------------------------------------"
echo "|| "

# =======================================================================================#
#     { 01. Parameter Setting }
# =======================================================================================#

FN_In=$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')
FN_MCRT=$(echo `basename $FN_MCRT` | sed 's/.nii.gz//g' | sed 's/.nii//g')

# FN_00_CNG_FMT="${FN_In}_00_Flt.nii.gz"
FN_Vol_01="${FN_MCRT}_Vol_01.nii.gz"
FN_EPI_BET="${FN_In}_BET"
FN_EPI_Msk="${FN_In}_01_Msk"
FN_Vol_01_MaskOut="${FN_MCRT}_Vol_01_MaskOut.nii.gz"

# =======================================================================================#
#     { 02. Change data format of rsfMRI data }
# =======================================================================================#

# cd ${Dir_OT}

# echo "|| "
# echo "|| -----{ 00. Change data format of rsfMRI data }-----"

# fslmaths ${p_In} ${FN_00_CNG_FMT} -odt float


# =======================================================================================#
#     { 03. Motion Correction = MCRT }
# =======================================================================================# 

echo "|| "
echo "|| ~~~~~~~~~~ [ 01. Do Motion Correction ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "-----------------------------------------------------------------------------------"

#~~~~~~~~
# AFNI
#~~~~~~~~
rm -f "${FN_MCRT}_outlier.txt"
3dToutcount -automask -range "${p_In}" > "${Dir_OT}/${FN_MCRT}_outlier.txt"

# base='0'
base=`cat ${Dir_OT}/${FN_MCRT}_outlier.txt | perl -0777an -F"\n" -e '$i=0; $small=999999; map {/\s*(\d+)/; if ($small > $1) {$small = $1; $ind=$i}; $i++;} @F; print $ind'`
# 3dvolreg -base ${base} -1Dfile "${Dir_OT}/${FN_MCRT}.par" -prefix "${Dir_OT}/${FN_MCRT}.nii.gz" "${p_In}"

rm -f "${Dir_OT}/${FN_MCRT}_RegMtx_3dvolreg.1D"

3dvolreg -verbose -zpad 1 -base ${base} \
         -1Dfile "${Dir_OT}/${FN_MCRT}.par" -prefix "${Dir_OT}/${FN_MCRT}.nii.gz" \
         -cubic \
         -1Dmatrix_save "${Dir_OT}/${FN_MCRT}_RegMtx_3dvolreg.1D" \
         "${p_In}"

#~~~~~~~~
# FSL
#~~~~~~~~
# mcflirt -in "${p_In}" -out "${FN_MCRT}" -refvol 0 -mats -plots -rmsrel -rmsabs -stats -stages 4

	#------{ 01-1 Check Whether The Folder exists or not}------------------------#
	if [ -d "${Dir_OT}/$Fd_MCRT" ];then
		echo "|| "
		echo "|| The Folder Exists :: [ ${Dir_OT}/${Fd_MCRT} ] "
	else
		mkdir -p "${Dir_OT}/${Fd_MCRT}"
	fi
	#------{ 01-2 Move the downstrean products to the assigned folder }-----------#
	mv ${Dir_OT}/${FN_MCRT}_* ${Dir_OT}//${Fd_MCRT}
# 	mv ${FN_MCRT}.mat ./${Fd_MCRT}/${FN_MCRT}.mat
	mv ${Dir_OT}/${FN_MCRT}.par ${Dir_OT}//${Fd_MCRT}

	${fslver}fsl_tsplot -i "${Dir_OT}/${Fd_MCRT}/${FN_MCRT}.par" \
	-t "3dvolreg estimated rotations (degree) @ Base ${base}" -u 1 --start=1 --finish=3 -a roll,pitch,yaw -w 640 -h 144 \
	-o "${Dir_OT}//${Fd_MCRT}/${FN_MCRT}-rot.png"

	${fslver}fsl_tsplot -i "${Dir_OT}/${Fd_MCRT}/${FN_MCRT}.par" \
	-t "3dvolreg estimated displacement (mm) @ Base ${base}" -u 1 --start=4 --finish=6 -a Superior,Left,Posterior -w 640 -h 144 \
	-o "${Dir_OT}//${Fd_MCRT}/${FN_MCRT}-disp.png"


# 1d_tool.py -infile "./${Fd_MCRT}/${FN_MCRT}.par"            \
#                     -select_cols '3..5' \
#                     -write dis.par


# 	fsl_tsplot -i "./${Fd_MCRT}/${FN_MCRT}.par" \
# 	-t 'MCFLIRT estimated rotations (radians)' -u 1 --start=1 --finish=3 -a x,y,z -w 640 -h 144 \
# 	-o "./${Fd_MCRT}/${FN_MCRT}-rot.png"

# 	fsl_tsplot -i "./${Fd_MCRT}/${FN_MCRT}.par" \
# 	-t 'MCFLIRT estimated translations (mm)' -u 1 --start=4 --finish=6 -a x,y,z -w 640 -h 144 \
# 	-o "./${Fd_MCRT}/${FN_MCRT}-trans.png"

# 	fsl_tsplot -i "./${Fd_MCRT}/${FN_MCRT}_abs.rms","./${Fd_MCRT}/${FN_MCRT}_rel.rms" \
# 	-t 'MCFLIRT estimated mean displacement (mm)' -u 1 -w 640 -h 144 -a absolute,relative \
# 	-o "./${Fd_MCRT}/${FN_MCRT}-disp.png"


#-----{ 02. Extract The First Volume in EPI }--------------------------------------------#
echo "||"
echo "|| ~~~~~~~~~~ [ 02. Extract The First Volume ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "|| ....................................... @ ${FN_In} "
echo "-----------------------------------------------------------------------------------"


fslroi "${Dir_OT}/${FN_MCRT}.nii.gz" ${Dir_OT}/${FN_Vol_01} ${base} 1
# fslroi "${Dir_OT}/${FN_MCRT}.nii.gz" ${Dir_OT}/${FN_Vol_01} 0 1

#-----{ 03. BET on EPI }-----------------------------------------------------------------#
# echo "|| "
# echo "|| -----{ 03. Extract The First Volume in ${FN_In} }-----"

bet "${Dir_OT}/${FN_Vol_01}" "${Dir_OT}/${FN_EPI_BET}" -R -f 0.2 -g 0 -m
rm -f "${Dir_OT}/${FN_EPI_BET}.nii.gz" # Save mask, delete others
mv ${Dir_OT}/${FN_EPI_BET}_mask.nii.gz "${Dir_OT}/${FN_EPI_Msk}.nii.gz" # Rename files to the assign File name

#-----{ 04. Apply EPI Mask on Vol_01 }---------------------------------------------------#
# echo "|| "
# echo "|| -----{ 04. Apply EPI Mask on ${FN_Vol_01} }-----"

fslmaths ${Dir_OT}/${FN_Vol_01} -mul "${Dir_OT}/${FN_EPI_Msk}.nii.gz" ${Dir_OT}/${FN_Vol_01_MaskOut}

#-----{ 05. Calculate FD }---------------------------------------------------------------#

# echo "|| "
# echo "|| -----{ 05. Calculate FD  }-----"
# 
# fsl_motion_outliers -i "${p_In}" -o "./${Fd_MCRT}/${FN_In}_Confd.txt" -m "${FN_EPI_Msk}.nii.gz" --fd \
# -s "./${Fd_MCRT}/${FN_In}_FD.txt" \
# -p "./${Fd_MCRT}/${FN_In}_FD_PNG.png" 
# 
# rm -f "${FN_00_CNG_FMT}"
# rm -f "${FN_Vol_01}"

mv "${Dir_OT}/${FN_EPI_Msk}.nii.gz" "${Dir_OT}//${Fd_MCRT}"

#-----------------------------------------------------------------------{ END }----------#

echo "|| "
echo "------------------------{ DONE !!! Fn_MDAP2_MCRT.sh}------------------------------ "
echo "|| "
