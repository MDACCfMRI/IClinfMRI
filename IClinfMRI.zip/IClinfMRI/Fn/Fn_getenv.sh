#!/bin/sh


# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

||  =================={ Usage :: Fn_getenv.sh }====================================
||   
||  [Purpose]: get the enviroment setting of FSL and AFNI
||
||  [Usage]: bash Fn_getenv.sh -t 'y'
||
||  ===============================================================================
Created by Irene Hsu on 2017.04.26 (Bash shell) @ MD Anderson

EOF
exit
}
# ============================================================================[Help]====="
if [ -z "$1" ]; then
# if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi
# ======================================================================[Get Option]====="
Opt_numb=0;
while getopts "t:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
    t)
        status_test=$OPTARG
    ;;
    x)
		empty=$OPTARG
    ;;
    esac
done
# =================================================================[Default Setting]====="
if [ -z "${status_test}" ];then 
	status_test='y';
fi
# ============================================================================[MAIN]====="
# echo "testing on afni [$status_afni], fsl [$status_fsl]"

# if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; 
# if [ -f "$(which ${fslver}fslmaths)" ];then Pass_fsl='O';else Pass_fsl='X';fi; 
if [ -f "$(which 3dcalc)" ];then Pass_afni='O';else Pass_afni='X';fi; 

if [ -z "${LD_PRELOAD}" ];then 
	Pass_matlablib='X';else Pass_matlablib='O'
fi


if [ "$status_test" == "y" ]; then
# echo "[FSL]=[$Pass_fsl]; [AFNI]=[$Pass_afni]; [Matlab Library of LD_PRELOAD]=[$Pass_matlablib]"
echo "[AFNI]=[$Pass_afni]; [Matlab Library of LD_PRELOAD]=[$Pass_matlablib]"
fi

