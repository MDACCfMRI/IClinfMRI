%-----------------------------------------------------------------------
% Job saved on 04-Feb-2018 22:56:14 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6685)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.util.defs.comp{1}.def = {'/Volumes/LING128G/Proposal_TestDataP3/P1_DICRCP06/2_T1Segment/iy_P1_3DVolumePre.nii'};
matlabbatch{1}.spm.util.defs.out{1}.pull.fnames = {'/Volumes/LING128G/Proposal_TestDataP3/P1_DICRCP06/2_T1Segment/avg152T1_brain.nii'};
matlabbatch{1}.spm.util.defs.out{1}.pull.savedir.savepwd = 1;
matlabbatch{1}.spm.util.defs.out{1}.pull.interp = 0;
matlabbatch{1}.spm.util.defs.out{1}.pull.mask = 1;
matlabbatch{1}.spm.util.defs.out{1}.pull.fwhm = [0 0 0];
matlabbatch{1}.spm.util.defs.out{1}.pull.prefix = 'Inv_';
