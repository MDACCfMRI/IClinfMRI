#!/bin/sh

# ===========================================================================[Usage]====="
usage() {
    cat<<EOF

==========================================================================================
||  Script
||    Fn_3DReHo.sh
||
||  Aim
||    Conduct 3DReHo with 1- or 2-neighbors
||  Input
||     -i : Time-series 4D Dataset
||     -m : Global Mask (Ex. Brain Mask)
||     -N : 1 or 2 neighbors 
||  Input(Option) 
||     -o : Output filename 
||
||  Example
||    Fn_3DReHo.sh -i "input.nii" -m "mask.nii" -N '1' -o "output.nii" 
||  
==========================================================================================
Created by Irene Hsu on 2017.03.09 (Bash shell) 
		@ MD Anderson
EOF

exit
}

# ============================================================================[TEST]====="
DEMO="X"
if [ "$DEMO" == "O" ]; then

IIDD="P04"
DirS="/mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn"
DirM="/mnt/YDIR/Program/Irene_Software/DemoData/${IIDD}"
p_RSPrep="$(ls ${DirM}/REST/${IIDD}_REST_TMD3N9B0108.nii.gz)"
p_Msk="$(ls ${DirM}/1_RegMtx/${IIDD}_3DVOLUME_Msk_Brain_ds.nii.gz)"
# sh Fn_3DReHo.sh -i "${p_RSPrep}" -m "${p_Msk}" -N '1' -O "${DirM}"
bash ${DirS}/Fn_3DReHo.sh -i "${p_RSPrep}" -m "${p_Msk}" -N '2' -O "${DirReHo}"
# pReHO="${DirReHo}/$(echo `basename $p_RSPrep` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ReHo27.nii.gz";
# 3dReHo -inset "${p_RSPrep}" -mask "${p_Msk}" -nneigh '27' -prefix "${pReHO}"
fi


# ============================================================================[Help]====="
if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

#if [ -f "$(which fslinfo)" ];then fslver='';else fslver='fsl5.0-';fi; echo "||"; echo "|| fsl verson = [${fslver}]";echo "||"
# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="

#echo "Total $argn input arguments"

Opt_numb=0;
while getopts "i:m:N:o:O:Z:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
    i)
        pIn=$OPTARG
    ;;
    m)
        pMsk=$OPTARG
    ;;
    N)
        neigh=$OPTARG
    ;;
    o)
		pOut=$OPTARG
    ;;
    O)
		DirO=$OPTARG
    ;;
    x)
		empty=$OPTARG
    ;;
    esac
done

# ===========================================================[Check Input arguments]====="


if [ -z "${DirO}" ];then 
	DirO="$(dirname "$pIn")"
fi

if [ -z "${pOut}" ];then 
    pOut="${DirO}/$(echo `basename $pIn` | sed 's/.nii.gz//g' | sed 's/.nii//g')_ReHo${neigh}N.nii";
else
	DirO="$(dirname "$pOut")"
	if [ ${#DirO} -le 3 ]; then
		DirO="$(dirname "$pIn")"
	fi
fi

if [ "$neigh" == "1" ]; then
 DiaBox='3'
fi
if [ "$neigh" == "2" ]; then
 DiaBox='5'
fi


# if [ -z "${FN_MCRT}" ] || [ -n "${FN_MCRT}" ]; then
# if [ -z "${fOut}" ] ; then
# 	fOut="$(echo `basename $p_In` | sed 's/.nii.gz//g' | sed 's/.nii//g')_CC.nii.gz";
# else
# 	fOut="$(echo `basename $fOut`)";
# fi

# ============================================================================[Main]====="

#---------------------------------------------------------------------{ START }----------#
# echo "|| "
#nt=`${fslver}fslnvols ${pIn}` ; 

nt="$(3dinfo -nt ${pIn})"

echo "================================================================================== "
echo "|| Calculating ReHo >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
echo "||    [ Data  ] =[ $(echo `basename $(ls $pIn)`) (#vol=${nt})] "
echo "||    [ Mask  ] =[ $(echo `basename $(ls $pMsk)`) ] "
echo "||    [ Neigh ] =[ ${neigh} Neihgbors (= Diameter ${DiaBox} voxels) ] "
# echo "||	(2) ::  [ Output FN  ] =[ ${fOut} ] "
echo "||    [ Dir   ] =[ ${DirO} ] "
# echo "|| "
echo "---------------------------------------------------------------------------------- "
# echo "|| "

# =======================================================================================#
#     { 01. Parameter Setting }
# =======================================================================================#


# Dir_T1=$(dirname "$p_T1")

# Dir_RstCmp="${Dir_T1}/3_ResultCMP" # Update an new Folder
# if [ ! -d "${Dir_RstCmp}" ];then 
#   mkdir -p "${Dir_RstCmp}"
# fi

#=========================================================================================
#----- oO(^^)Oo ------------------------------------------------------------[ FC Mapping ]

if [ -z "${pIn}" ];then 
echo "|| Not enough Input ! Please Check"
fi

if [ ! -z "${pIn}" ];then 
fIn=$(echo `basename $pIn` | sed 's/.nii.gz//g'| sed 's/.nii//g')

rm "${pOut}"
if [ "$neigh" == "1" ]; then
3dReHo -mask ${pMsk} -inset ${pIn} -prefix "${pOut}" -nneigh '27'
     
fi

if [ "$neigh" == "2" ]; then
3dReHo -mask ${pMsk} -inset ${pIn} -prefix "${pOut}" -neigh_RAD '3.1'        
fi


# pRank="${DirO}/${fIn}_Rank.nii.gz"
# pRankMn="${DirO}/${fIn}_RankMn.nii.gz"

# echo "||"
# echo "||	Computing ranks >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ";
# 3dTsort -overwrite -prefix ${pRank} -rank ${pIn}

# echo "||"
# echo "||	Computing mean ranks >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ";

# ${fslver}fslmaths "${pRank}" -kernel boxv ${DiaBox} -fmean "${pRankMn}"

# echo "||"
# echo "||	Prepare constants >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ";

# Con1=$(echo "scale=20; ${nt}*${nt}*${nt}-${nt}"|bc); 
# Con2=$(echo "scale=20; 3*(${nt}+1)/(${nt}-1)"|bc); 

# ${fslver}fslmaths ${pRankMn} -sqr -Tmean -mul ${nt} -mul 12 -div ${Con1} -sub ${Con2} ${pOut}
# ${fslver}fslmaths "${pOut}" -mul "${pMsk}" "${pOut}"

# rm -f ${pRank} ${pRankMn}

fi

echo "---------------------------------------------------------------------------------- "
echo "||    [Output] =[ $(ls ${pOut}) ] "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ "

