function Fn_batch_SPM12_Segment(Input_T1)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright � 2017 The University of Texas MD Anderson Cancer Center
% ||   
% Input_T1=''/mnt/data/home/ahsu/UI_IClinfMRI_AFNI/DEMO/P04/1_RegMtx/P04_3DVOLUME.nii'';
Dir_spm=which('spm.m');
Dir_spm=fileparts(Dir_spm);

Dir_T1=(pwd); 

% spm('defaults','PET');
% spm_jobman('initcfg');

% Input_T1='s02_T1_Anatomy_ReO.nii'

% [Dir_spm filesep 'tpm' filesep 'TPM.nii']

% ============================================== [READ JOB TEMPLATE] ======
clear C
p_DoS=which('Fn_batch_SPM12_Segment_JOB.m');
%// Read lines from input file
fid = fopen(p_DoS, 'r');
C = textscan(fid, '%s', 'Delimiter', '\n');
fclose(fid); C=C{1};
% ============================================ [REPLACE JOB CONTENT] ======
clear Ls_RP
Ls_RP={'matlabbatch{1}.spm.spatial.preproc.channel.vols'};
Idx = find(~cellfun(@isempty,strfind(C, Ls_RP{1})));

C{Idx}=[ Ls_RP{1} '= {''' Dir_T1 filesep Input_T1 ',1''};' ];

clear Ls_RP
Ls_RP={'matlabbatch{1}.spm.spatial.preproc.tissue(1).tpm'...
    'matlabbatch{1}.spm.spatial.preproc.tissue(2).tpm'...
    'matlabbatch{1}.spm.spatial.preproc.tissue(3).tpm'...
    'matlabbatch{1}.spm.spatial.preproc.tissue(4).tpm'...
    'matlabbatch{1}.spm.spatial.preproc.tissue(5).tpm'...
    'matlabbatch{1}.spm.spatial.preproc.tissue(6).tpm' };

for r=1:numel(Ls_RP)
    Idx=strfind(C, Ls_RP{r});
    Idx = find(~cellfun(@isempty,Idx));
    C{Idx}=[ Ls_RP{r} '= {''' Dir_spm  filesep 'tpm' filesep 'TPM.nii' ',' num2str(r) '''};' ];
end
% ================================================= [WRITE JOB TEMP] ======
p_JOB=['TEMP_JOB.m']; 

if (exist(p_JOB,'file')==2)
    delete (p_JOB)
end
fid=fopen(p_JOB,'wt');
[nrows,ncols] = size(C);
for row = 1:nrows
    fprintf(fid, '%s \n',C{row,:});
end
fclose(fid);

nrun = 1; % enter the number of runs here
jobfile = {p_JOB};
jobs = repmat(jobfile, 1, nrun);
inputs = cell(0, nrun);
for crun = 1:nrun
end
% spm('defaults', 'PET');
spm_jobman('run', jobs, inputs{:});


