
function [Onset,Duration]=Fn_CountDPara2OnsetT(CountDPara_Str,TR,Rep)

% [Onset,Duration]=Fn_CountDPara2OnsetT(CountDPara_Str,3,70)
% TR=3; Rep=70;
totalT=TR*Rep;

% CVR Paradigm
% -------------------------------------------------------------------------
% P01: (1) 2:57-43, (2) 1:57-43, (3) 0:57-43
% [Onset,Duration]=Fn_CountDPara2OnsetT({'00:02:57','00:02:43','00:01:57','00:01:43','00:00:57','00:00:43'},3,70);
% >>>>> CountDPara_Str={'00:02:57','00:02:43','00:01:57','00:01:43','00:00:57','00:00:43'};
%  [Onset,Duration]=Fn_CountDPara2OnsetT(CountDPara_Str,3,70)
% -------------------------------------------------------------------------
% P03: (1) 2:57-44, (2) 1:55-44, (3) 0:56-43
% [Onset,Duration]=Fn_CountDPara2OnsetT({'00:02:57','00:02:44','00:01:55','00:01:44','00:00:56','00:00:43'},3,70);
% -------------------------------------------------------------------------
% P04: (1) 2:57-44, (2) 1:55-44, (3) 0:56-43.
% [Onset,Duration]=Fn_CountDPara2OnsetT({'00:02:57','00:02:44','00:01:55','00:01:44','00:00:56','00:00:43'},3,70);
% -------------------------------------------------------------------------


for n=1:numel(CountDPara_Str)
    [Y, M, D, H, MN, S] = datevec(CountDPara_Str{n});
    CountDPara_Time(n)=H*3600+MN*60+S;
end
clear Para_Time
Para_Time=totalT*ones(size(CountDPara_Time))-CountDPara_Time;

idx_odd=[1:2:numel(CountDPara_Str)];
idx_even=[2:2:numel(CountDPara_Str)];

Onset=Para_Time(idx_odd);
Duration=Para_Time(idx_even)-Para_Time(idx_odd);


Display_Str=['Onset:[' num2str(Onset) ']; Duration:[' num2str(Duration) ']'];
disp(Display_Str)


