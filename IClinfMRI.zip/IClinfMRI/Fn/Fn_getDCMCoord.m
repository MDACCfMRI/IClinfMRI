function [Affine_XYZ,Mtx_ImageOrient,Coord]=Fn_getDCMCoord

% clear 

[fDCM,DirIn] = uigetfile({'*.dcm;*'},'Select ONE DICOM file',pwd);pDCM=[DirIn fDCM];


HDRIn= dicominfo(pDCM);HDRIn.PixelSpacing

ViewID(:,1)=[1;0;0;0;1;0]; % FOR AXIAL VIEW (z axis)
ViewID(:,2)=[0;1;0;0;0;-1];% FOR Sagital VIEW (x axis)
ViewID(:,3)=[1;0;0;0;0;-1]; % FOR Coronal VIEW (y axis)
clear CMP;CMP=zeros(3,1);
Sign=(HDRIn.ImageOrientationPatient>0)+(HDRIn.ImageOrientationPatient<0)*-1;
ImgOrient=Sign.*(abs(HDRIn.ImageOrientationPatient)>0.5);%
%<check DICOM View>
for v=1:3 ; CMP(v)=(sum(ImgOrient==ViewID(:,v))==6); end
idxView=find(CMP==1);
ImgOrient=HDRIn.ImageOrientationPatient;

files=dir([DirIn]);
files([files.isdir]) = [];  %remove non-directories
Cell_FNs={files.name}';
Cell_Dirs=cell(size(Cell_FNs));Cell_Dirs(:)={[DirIn filesep]};
Cell_pFiles=cellstr([char(Cell_Dirs{:}) char(Cell_FNs{:})]);
IIdx_dcm=cellfun(@isdicom,Cell_pFiles);
Cell_pDCMs=Cell_pFiles(IIdx_dcm);


%<Get Q form from DICOM files>
clear Coord
nSlice=numel(Cell_pDCMs);
for n=1:nSlice
    clear HDRTemp
    HDRTemp= dicominfo(Cell_pDCMs{n});
    if isfield(HDRTemp, 'SliceLocation')
        Coord(n,:)=[HDRTemp.ImagePositionPatient' HDRTemp.SliceLocation HDRTemp.InstanceNumber HDRTemp.ImageOrientationPatient'];
    else
        Coord(n,:)=[HDRTemp.ImagePositionPatient' 999 HDRTemp.InstanceNumber HDRTemp.ImageOrientationPatient'];
    end
     
end
% Coord_SagT1=Coord;

HDRT1= dicominfo(Cell_pDCMs{1});HDRTN= dicominfo(Cell_pDCMs{nSlice});
CT1=HDRT1.ImagePositionPatient;CTN=HDRTN.ImagePositionPatient;

[Affine_XYZ,Mtx_ImageOrient]=Fn_DCM2Affine(HDRIn,CT1,CTN,nSlice);

DirIn


% qform_DCM=[Affine_XYZ CT1];


% TF=Affine_XYZ; % Transformation matrix
% OS=CT1; % Offset
% Mtx3D=ones(176,192,192);
% 
% %     if (qform_DCM(3,4)>0); loc=fliplr([1:size(Mtx3D,3)]); else loc=[1:size(Mtx3D,3)];end % AX
% 
%  if (qform_DCM(1,4)>0); loc=fliplr([1:size(Mtx3D,1)]); else loc=[1:size(Mtx3D,1)];end % Sag
% % RAI is supposed to % PAY ATTENTION
% 
% clear Coord_AxTEST
% for ss=1:128
% 
% % XYZ=TF*[0 0 loc(ss)-1]'+OS;% Ax
% XYZ=TF*[loc(ss)-1 0 0]'+OS; %Sag
% Coord_SagTEST(ss,:)=XYZ';
% end


% Affine_XYZ*[0 0 1]'+DCM_offset


%         