function [View idxView]=Fn_CheckDcmView(pDCM)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright � 2017 The University of Texas MD Anderson Cancer Center
% ||   
% pDCM=LsCheck{1};
%<check DICOM View>
Ls_View3={'Ax','Sag','Cor'};

HDRIn= dicominfo(pDCM);
ViewID(:,1)=[1;0;0;0;1;0]; % FOR AXIAL VIEW
ViewID(:,2)=[0;1;0;0;0;-1];% FOR Sagital VIEW
ViewID(:,3)=[1;0;0;0;0;-1]; % FOR Coronal VIEW
clear CMP
CMP=zeros(3,1);
Sign=(HDRIn.ImageOrientationPatient>0)+(HDRIn.ImageOrientationPatient<0)*-1;
ImgOrient=Sign.*(abs(HDRIn.ImageOrientationPatient)>0.5);%
for v=1:3 ; CMP(v)=(sum(ImgOrient==ViewID(:,v))==6); end
idxView=find(CMP==1);
View=Ls_View3{idxView}