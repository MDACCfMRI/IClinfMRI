#!/bin/sh


usage() {
    cat<<EOF

||  =================={ Usage :: Fn_CoReg.sh }====================================
||   
||  [Purpose]:  
||
||  [Usage]: Fn_CoReg.sh [OPTIONS]
||       ex: Fn_CoReg.sh -a "p_T1" -f "p_FLAIR" -S "SDIR" -O "Dir_OT"
|| 			  
||  [OPTIONS]:
||            -a <p_T1> : The fullpath of the "T1w" stucture image
||            -f <p_FLAIR> : The fullpath of the lesion mask at the space of T1w image
||            -c <cost> : cost function  (default='lpa')
||            -S <SDIR>   : The Directory of the Script Folder
||
||	[Optional aguments]
||            -O <Dir_OT> : The Directory of output files (default : parent dir of the Task folder)
|| 
||  ======================================================================================
Created by Irene Hsu on 2017.05.09 (Bash shell) @ MD Anderson

EOF
exit
}

# ============================================================================[Help]====="
if [ -z "$1" ]; then
# if [ -z "$1" ] || [ "$1" == '-help' ]; then
    usage
    exit 1
fi

# ===========================================================================[Check]====="

argn="${#}" # number of all input arguments
argcon=${@} # all contents of the input arguments

#echo "|| $argcon"

if [ "${argn}" -lt "1" ];then
    echo '|| '
    echo '|| Not enough inputs! '
    echo '|| '
    exit 2
fi

# ==========================================================================[Option]====="
argn="${#}" # number of all input arguments
#argcon=${@} # all contents of the input arguments

# echo "Total $argn input arguments"

Opt_numb=0;
while getopts "a:f:c:S:O:x" OPTION
do
	Opt_numb=$(echo ${Opt_numb}+2 |bc)
	#echo "[Opt_numb] = [$Opt_numb]"
	
	case $OPTION in 
    a)
        p_T1=$OPTARG
    ;;
    f)
        p_FLAIR=$OPTARG
    ;;
    c)
        cost=$OPTARG
    ;; 
    S)
		SDIR=$OPTARG
    ;;
    O)
		Dir_OT=$OPTARG
    ;;
    x)
		empty=$OPTARG
    ;;
    esac
done

DEMO="X"
if [ "${DEMO}" == "O" ]; then
SDIR='/mnt/YDIR/Program/Irene_Software/UI_IClinfMRI_VB/Fn'
DirM="/mnt/YDIR/Program/Irene_Software/DemoData/1_dcmImport/TEST_CoReg"
p_T1="$(ls ${DirM}/1218807_3DVOLUME.nii.gz)"
p_FLAIR="$(ls ${DirM}/1218807_2MMFLAIR.nii.gz)"

bash ${SDIR}/Fn_CoReg.sh -a "$p_T1" -f "$p_FLAIR" -S "$SDIR"

# costF="nmi";
# costF="lpa";
# costF="lpc";
# costF="ls";
# costF="crM";


fi

# =======================================================================================#
# 	  { 00. Assignment }
# =======================================================================================#
ImExt='nii'
n_subS="$(grep -o "_" <<< "$(echo `basename ${p_T1}` | sed 's/.nii.gz//g' | sed 's/.nii//g')" | wc -l)";
n_subS=$(echo "$n_subS + 1" | bc)
ID=$(echo `basename $p_T1` | sed 's/.nii.gz//g'| sed 's/.nii//g')
Moda=$(echo $ID | sed 's/.nii.gz//g'| sed 's/.nii//g' | cut -d '_' -f $n_subS)
PID=$(echo $ID | sed "s/_${Moda}//g" )


n_subS="$(grep -o "_" <<< "$(echo `basename ${p_FLAIR}` | sed 's/.nii.gz//g' | sed 's/.nii//g')" | wc -l)";
n_subS=$(echo "$n_subS + 1" | bc)
ID=$(echo `basename $p_FLAIR` | sed 's/.nii.gz//g'| sed 's/.nii//g')
Modf=$(echo $ID | sed 's/.nii.gz//g'| sed 's/.nii//g' | cut -d '_' -f $n_subS)

# ------------------------------------------------------------------ [Check out parameter]
if [ -z "${cost}" ];then 
	cost='lpa';
fi

if [ -z "${Dir_OT}" ];then 
	Dir_OT=$(dirname "$p_T1")
fi

if [ -z "${SDIR}" ];then 
SDIR=$(find $PWD -name 'Fn_MDAS2_rsPrep.sh' | sed 's/\/Fn_MDAS2_rsPrep.sh//g' ); #echo "$SDIR"
if [ -z "${SDIR}" ];then SDIR='---';fi
fi


echo "|| "
echo "==========================={ Information Fn_CoReg.sh}=============================== "
echo "|| "

BYellow='\033[1;33m';BRed='\033[1;31m';NC='\033[0m'

if [ ! -d "${SDIR}" ];then 
 echo -e "||	(0) ::  [ Script Dir] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo "||	(0) ::  [ Script Dir] =[ ${SDIR} ] "
fi


if [ ! -f "${p_T1}" ];then 
 echo -e "||	(1) ::  [ T1 Data   ] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo  "||	(1) ::  [ T1 Data   ] =[ `basename $p_T1` (${Moda})] "
fi

if [ ! -f "${p_FLAIR}" ];then 
 echo -e "||	(2) ::  [ Data 2    ] =[ ${BRed}NOT EXIST${NC} ] "
else
	echo  "||	(2) ::  [ Data 2    ] =[ `basename $p_FLAIR` (${Modf})] "
fi

echo  "||	(3) ::  [ Cost fun. ] =[ $cost ] "

echo "||	(*) ::  [ Output Dir] =[ ${Dir_OT} ] "
echo "||	-------------------------------------------------------------------------- "

Dir_Reg="${Dir_OT}/1_RegMtx" # Update an new Folder
if [ ! -d "${Dir_Reg}" ];then mkdir -p "${Dir_Reg}";fi
cd $Dir_Reg

Des="T1";pOut="${Dir_OT}/$(echo `basename $p_FLAIR` | sed 's/.nii.gz//g' | sed 's/.nii//g')%${Des}_${cost}.${ImExt}"; 

if [ ! -f "${pOut}" ];then 

	Suf="_${cost}"
	# align_epi_anat.py -dset2to1 -dset2 ${p_FLAIR} -dset1 ${p_T1} -dset2_strip 3dAutomask -dset1_strip 3dAutomask -volreg off -tshift off -suffix "${Suf}" -cost "${cost}" 
	

		CMDis="$(@Center_Distance -dset ${p_T1} ${p_FLAIR})"
		echo "||	-------------------------------------------------------------------------- "
		echo "||	(*) ::  [ CenterDis ] =[ (${CMDis})] "
		echo "||	-------------------------------------------------------------------------- "
		if [ `echo "${CMDis} > 5" | bc` -eq 1 ] && [ `echo "${CMDis} <= 20" | bc` -eq 1 ]; then
			align_epi_anat.py -dset2to1 -big_move -dset2 ${p_FLAIR} -dset1 ${p_T1} -dset2_strip 3dAutomask -dset1_strip 3dAutomask -volreg off -tshift off -suffix "${Suf}" -cost "${cost}" 
		elif [ `echo "${CMDis} > 20" | bc` -eq 1 ] && [ `echo "${CMDis} <= 45" | bc` -eq 1 ]; then
			align_epi_anat.py -dset2to1 -giant_move -dset2 ${p_FLAIR} -dset1 ${p_T1} -dset2_strip 3dAutomask -dset1_strip 3dAutomask -volreg off -tshift off -suffix "${Suf}" -cost "${cost}" 

		elif [ `echo "${CMDis} > 46" | bc` -eq 1 ]; then 
			align_epi_anat.py -dset2to1 -ginormous_move -dset2 ${p_FLAIR} -dset1 ${p_T1} -dset2_strip 3dAutomask -dset1_strip 3dAutomask -volreg off -tshift off -suffix "${Suf}" -cost "${cost}" 
		else
			align_epi_anat.py -dset2to1 -dset2 ${p_FLAIR} -dset1 ${p_T1} -dset2_strip 3dAutomask -dset1_strip 3dAutomask -volreg off -tshift off -suffix "${Suf}" -cost "${cost}" 
		fi



	RegTmp_anat2anat="$(echo `basename $p_FLAIR` | sed 's/.nii.gz//g' | sed 's/.nii//g')${Suf}_mat.aff12.1D"

	RegMtx_anat2anat="${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2anat_${Modf}_2_${Moda}.1D";
	if [ -f "${RegTmp_anat2anat}" ];then 
		mv "${RegTmp_anat2anat}" "${RegMtx_anat2anat}"
		rm -f ${pOut}; 3dAllineate -base ${p_T1} -input ${p_FLAIR} -final wsinc5 -1Dmatrix_apply "${RegMtx_anat2anat}" -prefix ${pOut}
		rm -f "$(echo `basename $p_FLAIR` | sed 's/.nii.gz//g' | sed 's/.nii//g')${Suf}+orig.BRIK"
		rm -f "$(echo `basename $p_FLAIR` | sed 's/.nii.gz//g' | sed 's/.nii//g')${Suf}+orig.HEAD"
		mv "$(echo `basename $p_T1` | sed 's/.nii.gz//g' | sed 's/.nii//g')${Suf}_mat.aff12.1D" "${Dir_Reg}/RegMtx_${RegMed}_${PID}_anat2anat_${Moda}_2_${Modf}.1D"
		if [ -f "${pOut}" ];then 
			echo "||	" 
			echo "|| ~~~~~~~~~~ [ OUTPUT ] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
			echo "|| ...........`dirname  ${pOut}`"
			echo "|| .................`basename  ${pOut}`"
			echo "|| --------------------------------------------------------------------------------"
		fi
	fi
else
	echo "||	" 
	echo "||	Coregistied data exist already ! ........................................... "
	echo "||	" 
fi

 






