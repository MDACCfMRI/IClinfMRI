function varargout = RSfMRI(varargin)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright (c) 2017 The University of Texas MD Anderson Cancer Center
% ||   
% RSFMRI MATLAB code for RSfMRI.fig
%      RSFMRI, by itself, creates a new RSFMRI or raises the existing
%      singleton*.
%
%      H = RSFMRI returns the handle to a new RSFMRI or the handle to
%      the existing singleton*.
%
%      RSFMRI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RSFMRI.M with the given input arguments.
%
%      RSFMRI('Property','Value',...) creates a new RSFMRI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RSfMRI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RSfMRI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RSfMRI

% Last Modified by GUIDE v2.5 26-Jan-2018 17:52:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RSfMRI_OpeningFcn, ...
                   'gui_OutputFcn',  @RSfMRI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RSfMRI is made visible.
function RSfMRI_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
% UIWAIT makes RSfMRI wait for user response (see UIRESUME)
% uiwait(handles.Fig_RSfMRI);
BtnINI(hObject, eventdata, handles);

function [handles]=BtnINI(hObject, eventdata, handles)
set(handles.Fig_RSfMRI,'Name','Seed-based rs-fMRI analysis with guidance')
handles.DirW=pwd;
handles.DispCase=0;
% <Default for Img Input>
handles.pRSData='';
handles.pT1='';
handles.pAnat='';
handles.pAnat2T1='';
handles.pHRepi='';
handles.pTMap='';
handles.pRSMap='';
handles.pT1_Lesion='';
handles.p_Prep='';
set(handles.Btn_rsData,'Enable','on');
% <Default RS PreProcess >
handles.TR=2;handles.tPattern='alt+z';handles.SeedR=4;
% <Default: Disp >
global SeedXYZV ImSetUlay ImSetUlay_BU ImSetOlay ImSetOlay_BU ImSetOlayRS ImSetOlayRS_BU
global gbl_p_Prep gbl_p_Seed IDX_sPreview IDX_flipUD
global ImSetUlay_Buffer 

gbl_p_Prep='';
gbl_p_Seed='';

SeedXYZV=[];
ImSetUlay=[200 6000];ImSetUlay_Buffer=ImSetUlay;
ImSetOlay=[3 8 1];
ImSetOlayRS=[0.7 1.5 1];
ImSetUlay_BU=ImSetUlay;
ImSetOlay_BU=ImSetOlay;
ImSetOlayRS_BU=ImSetOlayRS;
IDX_sPreview=0;
IDX_flipUD=0;
handles.CMap='autumn';
handles.CMapRS='autumn';
handles.cAUTO=1;
handles.ClickLR='L';
handles.Bandpass_Range=[0.01 0.08];
handles.FWHM=4;
handles.SeedR=6;
handles.RegRSmm=2;
handles.RSMethod='Pearson';
handles.Terminal=0;
% <Default: Clean Text Area>
set(handles.Tx_rsData,'String','');
set(handles.Tx_T1,'String','');
set(handles.Tx_Anats,'String','');
set(handles.Tx_Lesion,'String','');
set(handles.Tx_HRepi,'String','');
set(handles.Tx_PrepData,'String','');
set(handles.Tx_tMap,'String','');
set(handles.Tx_rsMap,'String','');
% <Default: Para Setting>
set(handles.Ed_TR,'String',num2str(handles.TR));
set(handles.Ed_Rmm,'String',num2str(handles.SeedR));
set(handles.Ed_FWHM,'String',num2str(handles.FWHM));
set(handles.Ed_BP1,'String',num2str(handles.Bandpass_Range(1)));
set(handles.Ed_BP2,'String',num2str(handles.Bandpass_Range(2)));
set(handles.PMenu_Regmm,'Value',1);
set(handles.PMenu_RSMethod,'Value',1);
set(handles.PMenu_SliceTime,'Value',1);
% <Default: Disp Setting>
set(handles.Ed_aWmin,'String',num2str(ImSetUlay(1)));
set(handles.Ed_aWMax,'String',num2str(ImSetUlay(2)));
set(handles.Ed_tTH,'String',num2str(ImSetOlay(1)));
set(handles.Ed_tWMax,'String',num2str(ImSetOlay(2)));
set(handles.Ed_tOpt,'String',num2str(ImSetOlay(3)));
set(handles.Sd_tOpt,'Value',ImSetOlay(3));

set(handles.Ed_rsTH,'String',num2str(ImSetOlayRS(1)));
set(handles.Ed_rsWMax,'String',num2str(ImSetOlayRS(2)));
set(handles.Ed_rsOpt,'String',num2str(ImSetOlayRS(3)));
set(handles.Sd_rsOpt,'Value',ImSetOlayRS(3));
% <Default: Resting Processing >
handles.Prep_T=1;  handles.Prep_M=1;  handles.Prep_F=0;  handles.Prep_R=1;
    set(handles.RBtn_CBR,'Value',1)
    set(handles.RBtn_BBR,'Value',0)
    set(handles.RBtn_IBR,'Value',0)
handles.Prep_D=1; handles.Prep_N=1;  handles.Prep_B=1;  handles.Prep_S=1;  
handles.Prep_NR_Global=0;
set(handles.Ck_ReHo,'Value',1)

% <Default: Seed Option >
set(handles.RBtn_SeedXYZ,'Value',1)
set(handles.RBtn_SeedMask,'Value',0)

% ~~~~~~~~~~~~~~~~~
% handles update
% ~~~~~~~~~~~~~~~~
guidata(hObject, handles);


set(handles.Ck_DftPrep,'Value',1);
set(handles.Ck_SliceT,'Value',handles.Prep_T);
set(handles.Ck_MCRT,'Value',handles.Prep_M);
set(handles.Ck_FMCRT,'Value',handles.Prep_F);
set(handles.Ck_Despike,'Value',1);
set(handles.Ck_DDdnt,'Value',handles.Prep_D);
set(handles.Ck_NReg,'Value',handles.Prep_N);
    set(handles.Ck_NR_Global,'Value',handles.Prep_NR_Global);
set(handles.Ck_Bandpass,'Value',handles.Prep_B);
set(handles.Ck_Blur,'Value',handles.Prep_S);
set(handles.Ck_Coreg,'Value',handles.Prep_R);
BtnSetting(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)
set(handles.Btn_rsData,'Enable','on');


% function [handles]=DispCase(hObject, eventdata, handles)
% 
% if ~(exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
%     handles.DispCase=0;
% elseif (exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
%     handles.DispCase=1;
% elseif (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
%     handles.DispCase=2;
% elseif (exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxTMap')==1) && (isfield(handles,'MtxRSMap')==1)
%     handles.DispCase=3;
% elseif (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxTMap')==1) && (isfield(handles,'MtxRSMap')==1)
%     handles.DispCase=4;
% end
% guidata(hObject, handles);
%  disp(['||  (Corrected)Case: ' num2str(handles.DispCase)])


function BtnOff(hObject, eventdata, handles)
Status_OffOn='off';FColor=0.5*ones(1,3);
set(handles.Ck_DftPrep,'Enable',Status_OffOn);
%||-----------------------------------------------------------------------|
%||	[ Preprocessing ]
%||-----------------------------------------------------------------------|
set(handles.Ck_SliceT,'Enable',Status_OffOn);
set(handles.Tx_SliceTime1,'ForegroundColor',0.5*ones(1,3));
set(handles.Tx_SliceTime2,'ForegroundColor',0.5*ones(1,3));
set(handles.PMenu_SliceTime,'Enable','off');
set(handles.Ck_MCRT,'Enable','off');
set(handles.Ck_FMCRT,'Enable','off');
set(handles.Ck_Coreg,'Enable','off');
set(handles.Ck_Despike,'Enable','off');
set(handles.BtnGrp_Reg,'ForegroundColor',FColor);
set(handles.RBtn_CBR,'Enable',Status_OffOn);
set(handles.PMenu_Regmm,'Enable',Status_OffOn);
set(handles.RBtn_CBR,'Enable',Status_OffOn)
set(handles.RBtn_BBR,'Enable',Status_OffOn)
set(handles.RBtn_IBR,'Enable',Status_OffOn);
set(handles.Ck_DDdnt,'Enable',Status_OffOn);
set(handles.Ck_NReg,'Enable',Status_OffOn);
set(handles.Ck_NR_Global,'Enable',Status_OffOn);
set(handles.Ck_Bandpass,'Enable',Status_OffOn);

set(handles.Ed_BP1,'Enable',Status_OffOn);
set(handles.Ed_BP2,'Enable',Status_OffOn);
set(handles.Tx_BP1,'ForegroundColor',0.5*ones(1,3));
set(handles.Tx_BP2,'ForegroundColor',0.5*ones(1,3));
set(handles.Tx_BP3,'ForegroundColor',0.5*ones(1,3));

set(handles.Ck_Blur,'Enable',Status_OffOn);
set(handles.Ed_FWHM,'Enable',Status_OffOn);
set(handles.Tx_FWHM,'ForegroundColor',FColor);
set(handles.PMenu_RSMethod,'Enable',Status_OffOn);
%||-----------------------------------------------------------------------|
%||	[ Data Input ]
%||-----------------------------------------------------------------------|
% set(handles.Btn_rsData,'Enable',Status_OffOn);
set(handles.Tx_TR,'ForegroundColor',FColor);
set(handles.Ed_TR,'Enable',Status_OffOn);
set(handles.Btn_T1,'Enable',Status_OffOn);
set(handles.Btn_Anats,'Enable',Status_OffOn);
set(handles.Btn_Lesion,'Enable',Status_OffOn);
set(handles.Btn_HRepi,'Enable',Status_OffOn);
set(handles.Btn_tMap,'Enable',Status_OffOn);
set(handles.Btn_PrepData,'Enable',Status_OffOn);
set(handles.Btn_rsMap,'Enable',Status_OffOn);
set(handles.Tx_SliceZ,'ForegroundColor',FColor);
set(handles.Ed_SliceZ,'Enable',Status_OffOn);
set(handles.Sd_SliceZ,'Enable',Status_OffOn);
set(handles.Btn_Preprocess,'Enable',Status_OffOn);
set(handles.Btn_SPreview,'Enable',Status_OffOn);
set(handles.Btn_GMaping,'Enable',Status_OffOn);
set(handles.Ck_ReHo,'Enable',Status_OffOn);
set(handles.RBtn_SeedXYZ,'Enable',Status_OffOn);
set(handles.RBtn_SeedMask,'Enable',Status_OffOn);
set(handles.Tx_SeedR,'ForegroundColor',FColor);
set(handles.Tx_Rmm,'ForegroundColor',FColor);
set(handles.Ed_Rmm,'Enable',Status_OffOn);

set(handles.Tx_SeedXYZ,'ForegroundColor',FColor);
set(handles.Ed_Cx,'Enable',Status_OffOn);
set(handles.Ed_Cy,'Enable',Status_OffOn);
set(handles.Ed_Cz,'Enable',Status_OffOn);

set(handles.Btn_rsMap,'ForegroundColor',FColor);
% < Anatomy Setting>
set(handles.Pnl_aSetting,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'ForegroundColor',FColor);
set(handles.Tx_aWMax,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'Enable',Status_OffOn);
set(handles.Tx_aWMax,'Enable',Status_OffOn);
set(handles.Ed_aWmin,'Enable',Status_OffOn);
set(handles.Ed_aWMax,'Enable',Status_OffOn);
set(handles.PMenu_Anats,'Enable',Status_OffOn);

% < Task Result Setting>
set(handles.Pnl_tRst,'ForegroundColor',FColor);
set(handles.Tx_tTH,'ForegroundColor',FColor);
set(handles.Tx_tWMax,'ForegroundColor',FColor);
set(handles.Tx_tOpt,'ForegroundColor',FColor);
set(handles.Ed_tTH,'Enable',Status_OffOn);
set(handles.Ed_tWMax,'Enable',Status_OffOn);
set(handles.Ed_tOpt,'Enable',Status_OffOn);
set(handles.Sd_tOpt,'Enable',Status_OffOn);
set(handles.PMenu_tCMap,'Enable',Status_OffOn);
set(handles.Tx_AxtMap,'Visible',Status_OffOn);

% < Resting Result Setting>
set(handles.Pnl_rsRst,'ForegroundColor',FColor);
set(handles.Tx_rsTH,'ForegroundColor',FColor);
set(handles.Tx_rsWMax,'ForegroundColor',FColor);
set(handles.Tx_rsOpt,'ForegroundColor',FColor);
set(handles.Ed_rsTH,'Enable',Status_OffOn);
set(handles.Ed_rsWMax,'Enable',Status_OffOn);
set(handles.Ed_rsOpt,'Enable',Status_OffOn);
set(handles.Sd_rsOpt,'Enable',Status_OffOn);
set(handles.PMenu_rsCMap,'Enable',Status_OffOn);
set(handles.Tx_AxrsMap,'Visible',Status_OffOn);

% --- Outputs from this function are returned to the command line.
function varargout = RSfMRI_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;
clc;
ffig='IClinfMRI.fig';
pfig=which(ffig);

if (exist(pfig,'file')==2)
    [DirM,~,ext]=fileparts(pfig);
else
    error(['Can Not find ".fig", please check Matlab path ']);
end

if isdir(DirM)
    DirFn=[DirM filesep 'Fn'];handles.DirFn=DirFn; guidata(hObject, handles);
    DirDemo=[DirM filesep 'DEMO'];
    addpath(genpath(DirFn))
    addpath(DirM)
    % cd(DirM)
    % cd(DirDemo)
end

if isdir(handles.DirFn) && (isunix)
    formatBasic ='cd %s \n bash %sFn_getenv.sh -t "y"';
    ts_setting = sprintf(formatBasic,[handles.DirFn],[handles.DirFn filesep]);
    [s,ts_rst]=system(ts_setting);
    if (numel(findstr(ts_rst,'[O]'))>=1)
        handles.Terminal=1;
        MsgAFNI=strrep(['Library Setting:  ' ts_rst '!!! '], sprintf('\n'),' ');
%         set(handles.Tx_Message,'String',strrep(['Library Setting:  ' ts_rst '!!! '], sprintf('\n'),' '),'ForegroundColor',[0 0 1]);
    else
        handles.Terminal=0;
        MsgAFNI=strrep(['Missing part of links, ' ts_rst '!!! '], sprintf('\n'),' ');
%         set(handles.Tx_Message,'String',strrep(['Missing part of links, ' ts_rst '!!! '], sprintf('\n'),' '),'ForegroundColor',[1 0 0]);
    end
else
    handles.Terminal=0;
    if ~(isunix)
        MsgAFNI=['This program is only designed for the Linux system'];
        % set(handles.Tx_Message,'String',['This program is only designed for the Linux system'],'ForegroundColor',[1 0 0]);
    elseif ~isdir(handles.DirFn)
        MsgAFNI=['Missing the "Fn" folder, Please check !!! '];
        % set(handles.Tx_Message,'String',['Missing the "Fn" folder, Please check !!! '],'ForegroundColor',[1 0 0]);
    end
end

p_spm=which('spm.m');
if  ~(exist(p_spm, 'file')==2)
    MsgSPM='SPM is not detectd in PATH, Please add it !!! ';
    handles.SPM=0;
else
     MsgSPM='SPM is detected in the path';
     handles.SPM=1;
end
guidata(hObject, handles);

if (handles.SPM==1) && (handles.Terminal==1)
    set(handles.Tx_Message,'String',[MsgSPM '; ' MsgAFNI],'ForegroundColor',[0 0 1]);
else
    set(handles.Tx_Message,'String',[MsgSPM '; ' MsgAFNI],'ForegroundColor',[1 0 0]);
end

if (handles.SPM==1)
    BtnSetting(hObject, eventdata, handles);
    set(handles.Btn_rsData,'Enable','on');
else
    BtnOff(hObject, eventdata, handles);
    set(handles.Btn_rsData,'Enable','off');
end

% <Set FIG Position>
ScreenSz = get(0,'ScreenSize');ScreenH=ScreenSz(4);
FigSz=getpixelposition(handles.Fig_RSfMRI);FigH=FigSz(4);
FigX=235;
FigY=round((ScreenH-FigH)/2);
setpixelposition(handles.Fig_RSfMRI,[FigX FigY FigSz(3:4)])




function Ck_DftPrep_Callback(hObject, eventdata, handles)

if (get(handles.Ck_DftPrep,'Value')==1)
    handles.FWHM=4;
    handles.RegRSmm=2;
    handles.RSMethod='Pearson';
    % <Default: Para Setting>
    set(handles.Ed_FWHM,'String',num2str(handles.FWHM));
    set(handles.PMenu_Regmm,'Value',1);
    set(handles.PMenu_SliceTime,'Value',1);
    set(handles.PMenu_RSMethod,'Value',1);
    
    set(handles.Ck_SliceT,'Value',handles.Prep_T);
    set(handles.Ck_MCRT,'Value',handles.Prep_M);
    set(handles.Ck_FMCRT,'Value',handles.Prep_F);
    set(handles.Ck_Despike,'Value',1);
    set(handles.Ck_DDdnt,'Value',handles.Prep_D);
    set(handles.Ck_NReg,'Value',handles.Prep_N);
        set(handles.Ck_NR_Global,'Value',handles.Prep_NR_Global);
    set(handles.Ck_Bandpass,'Value',handles.Prep_B);
    set(handles.Ck_Blur,'Value',handles.Prep_S);
    set(handles.Ck_Coreg,'Value',handles.Prep_R);
        set(handles.RBtn_CBR,'Value',1)
        set(handles.RBtn_BBR,'Value',0)
        set(handles.RBtn_IBR,'Value',0)
    set(handles.Ck_ReHo,'Value',1)
    
end
BtnSetting(hObject, eventdata, handles);
%||=======================================================================|
%|| [Button Setting]
%||=======================================================================|
function BtnSetting(hObject, eventdata, handles)
global ImSetUlay SeedXYZV gbl_p_Prep gbl_p_Seed ImSetOlayRS ImSetOlay
global ImSetUlay_Buffer

switch get(handles.PMenu_Anats,'Value')
    case 1
         ImSetUlay_Buffer(1,:)=ImSetUlay;
    case 2
         ImSetUlay_Buffer(2,:)=ImSetUlay;
end

set(handles.Ed_rsTH, 'string',num2str(ImSetOlayRS(1)));
set(handles.Ed_rsWMax, 'string',num2str(ImSetOlayRS(2)));

set(handles.Ed_BP1,'String', sprintf('%.2f',handles.Bandpass_Range(1)));
set(handles.Ed_BP2,'String', sprintf('%.2f',handles.Bandpass_Range(2)));



%||-----------------------------------------------------------------------|
%||	[ Default : X / O ]
%||-----------------------------------------------------------------------|
if (exist(handles.pRSData,'file')==2)&&(exist(handles.pT1,'file')==2)
    set(handles.Ck_DftPrep,'Enable','on');
else
    set(handles.Ck_DftPrep,'Enable','off');
end

if (get(handles.Ck_DftPrep,'Value')==0)
    % No Default
    Status_OffOn='on';FColor=0*ones(1,3);
elseif (get(handles.Ck_DftPrep,'Value')==1)
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
    
%||-----------------------------------------------------------------------|
%||	[ Preprocessing ]
%||-----------------------------------------------------------------------|
set(handles.Ck_SliceT,'Enable',Status_OffOn);
    % <The function belong to slice timing >
    if  (get(handles.Ck_SliceT,'Value')==1) && (get(handles.Ck_DftPrep,'Value')==0)
        set(handles.Ck_SliceT,'ForegroundColor',0*ones(1,3));
        set(handles.Tx_SliceTime1,'ForegroundColor',0*ones(1,3));
        set(handles.Tx_SliceTime2,'ForegroundColor',0*ones(1,3));
        set(handles.PMenu_SliceTime,'Enable','on');
    else
         set(handles.Ck_SliceT,'ForegroundColor',0.5*ones(1,3));
        set(handles.Tx_SliceTime1,'ForegroundColor',0.5*ones(1,3));
        set(handles.Tx_SliceTime2,'ForegroundColor',0.5*ones(1,3));
        set(handles.PMenu_SliceTime,'Enable','off');
    end
    
% < Preprocessing:: Motion Correction>-------------------------------------
set(handles.Ck_MCRT,'Enable',Status_OffOn);
    if  (get(handles.Ck_MCRT,'Value')==1) && (get(handles.Ck_DftPrep,'Value')==0)
        set(handles.Ck_MCRT,'ForegroundColor',0*ones(1,3));
    else
        set(handles.Ck_MCRT,'ForegroundColor',0.5*ones(1,3));
    end
    
% set(handles.Ck_FMCRT,'Enable',Status_OffOn);
% set(handles.Ck_MCRT,'Enable','off');
set(handles.Ck_FMCRT,'Enable','off');
set(handles.Ck_Coreg,'Enable','off');
set(handles.Ck_Despike,'Enable','off');
set(handles.BtnGrp_Reg,'ForegroundColor',FColor);
set(handles.RBtn_CBR,'Enable',Status_OffOn);
set(handles.PMenu_Regmm,'Enable',Status_OffOn);
    % <RS Data && T1 && High Resolution EPI>
    if (exist(handles.pRSData,'file')==2) && (exist(handles.pT1,'file')==2) && (exist(handles.pHRepi,'file')==2)
        set(handles.RBtn_BBR,'Value',1)
        set(handles.RBtn_BBR,'Enable',Status_OffOn)
    else
        set(handles.RBtn_BBR,'Enable','off')
    end
    set(handles.RBtn_IBR,'Enable',Status_OffOn);

% < Preprocessing:: Detrend >----------------------------------------------
set(handles.Ck_DDdnt,'Enable',Status_OffOn);
    if  (get(handles.Ck_DDdnt,'Value')==1) && (get(handles.Ck_DftPrep,'Value')==0)
        set(handles.Ck_DDdnt,'ForegroundColor',0*ones(1,3));
    else
        set(handles.Ck_DDdnt,'ForegroundColor',0.5*ones(1,3));
    end
% < Preprocessing:: Nuisance Regression >----------------------------------
set(handles.Ck_NReg,'Enable',Status_OffOn);
    if  (get(handles.Ck_NReg,'Value')==1) && (get(handles.Ck_DftPrep,'Value')==0)
        set(handles.Ck_NReg,'ForegroundColor',0*ones(1,3));
        set(handles.Ck_NR_Global,'Enable','on');
        if  (get(handles.Ck_NR_Global,'Value')==1) 
            set(handles.Ck_NR_Global,'ForegroundColor',0*ones(1,3));
        else
            set(handles.Ck_NR_Global,'ForegroundColor',0.5*ones(1,3));
        end
    else
        set(handles.Ck_NReg,'ForegroundColor',0.5*ones(1,3));
        set(handles.Ck_NR_Global,'Enable','off');
        set(handles.Ck_NR_Global,'ForegroundColor',0.5*ones(1,3));
        set(handles.Ck_NR_Global,'Value',0);
    end
% < Preprocessing:: Bandpass >---------------------------------------------
set(handles.Ck_Bandpass,'Enable',Status_OffOn);
 if  (get(handles.Ck_Bandpass,'Value')==1) && (get(handles.Ck_DftPrep,'Value')==0)
    set(handles.Ck_Bandpass,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_BP1,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_BP2,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_BP3,'ForegroundColor',0*ones(1,3));
    set(handles.Ed_BP1,'Enable','on');
    set(handles.Ed_BP2,'Enable','on');
 else
    set(handles.Ck_Bandpass,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_BP1,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_BP2,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_BP3,'ForegroundColor',0.5*ones(1,3));
    set(handles.Ed_BP1,'Enable','off');
    set(handles.Ed_BP2,'Enable','off');
 end
 
% < Preprocessing:: Smooth >-----------------------------------------------
set(handles.Ck_Blur,'Enable',Status_OffOn);
    if  (get(handles.Ck_Blur,'Value')==1) && (get(handles.Ck_DftPrep,'Value')==0)
        set(handles.Ck_Blur,'ForegroundColor',0*ones(1,3));
        set(handles.Ed_FWHM,'Enable','on');
        set(handles.Tx_FWHM,'ForegroundColor',0*ones(1,3));
    else
        set(handles.Ck_Blur,'ForegroundColor',0.5*ones(1,3));
        set(handles.Ed_FWHM,'Enable','off');
        set(handles.Tx_FWHM,'ForegroundColor',0.5*ones(1,3));
    end

set(handles.PMenu_RSMethod,'Enable',Status_OffOn);

%||-----------------------------------------------------------------------|
%||	[ Data Input ]
%||-----------------------------------------------------------------------|
% <OFF all the button selection>
Status_OffOn='off';FColor=0.5*ones(1,3);
set(handles.Btn_rsData,'Enable','on');
set(handles.Tx_TR,'ForegroundColor',FColor);
set(handles.Ed_TR,'Enable',Status_OffOn);
set(handles.Btn_T1,'Enable',Status_OffOn);
set(handles.Btn_Anats,'Enable',Status_OffOn);
set(handles.Btn_Lesion,'Enable',Status_OffOn);
set(handles.Btn_HRepi,'Enable',Status_OffOn);
set(handles.Btn_PrepData,'Enable',Status_OffOn);
set(handles.Btn_tMap,'Enable',Status_OffOn);
set(handles.Btn_SeedMsk,'Enable',Status_OffOn);
set(handles.Tx_SeedMask,'ForegroundColor',FColor);

set(handles.Tx_SliceZ,'ForegroundColor',FColor);
set(handles.Ed_SliceZ,'Enable',Status_OffOn);
set(handles.Sd_SliceZ,'Enable',Status_OffOn);
set(handles.Btn_Preprocess,'Enable',Status_OffOn);

set(handles.RBtn_SeedXYZ,'Enable',Status_OffOn);
set(handles.RBtn_SeedMask,'Enable',Status_OffOn);
set(handles.Btn_SPreview,'Enable',Status_OffOn);
set(handles.Btn_GMaping,'Enable',Status_OffOn);
set(handles.Ck_ReHo,'Enable',Status_OffOn);
set(handles.Tx_SeedR,'ForegroundColor',FColor);
set(handles.Tx_Rmm,'ForegroundColor',FColor);
set(handles.Ed_Rmm,'Enable',Status_OffOn);

set(handles.Tx_SeedXYZ,'ForegroundColor',FColor);
set(handles.Ed_Cx,'Enable',Status_OffOn);
set(handles.Ed_Cy,'Enable',Status_OffOn);
set(handles.Ed_Cz,'Enable',Status_OffOn);

set(handles.Btn_rsMap,'ForegroundColor',FColor);

set(handles.Tx_AxtMap,'Visible',Status_OffOn);
set(handles.Tx_AxrsMap,'Visible',Status_OffOn);

% <Turn the button ON according to the specific condition>
% <RS Data ONLY>
if (exist(handles.pRSData,'file')==2)
    set(handles.Tx_TR,'ForegroundColor',0*ones(1,3));
    set(handles.Ed_TR,'Enable','on');
    set(handles.Btn_T1,'Enable','on');
end
% <RS Data && T1>
if (exist(handles.pRSData,'file')==2) && (exist(handles.pT1,'file')==2)
    Status_OffOn='on';FColor=0*ones(1,3);
    set(handles.Btn_Lesion,'Enable',Status_OffOn);
    set(handles.Btn_Anats,'Enable',Status_OffOn);
    if (get(handles.Ck_Coreg,'Value')==1)
        set(handles.Btn_HRepi,'Enable',Status_OffOn);
    end
    set(handles.Btn_tMap,'Enable','on');
    set(handles.Btn_rsMap,'Enable','on');
    set(handles.Tx_SliceZ,'ForegroundColor',FColor);
    set(handles.Ed_SliceZ,'Enable',Status_OffOn);
    set(handles.Sd_SliceZ,'Enable',Status_OffOn);
    set(handles.Ck_ReHo,'Enable',Status_OffOn);
    set(handles.Btn_Preprocess,'Enable',Status_OffOn);

    set(handles.Ed_aWmin,'string',num2str(ImSetUlay(1)))
    set(handles.Ed_aWMax,'string',num2str(ImSetUlay(2)))

    
    set(handles.Ed_tTH,'string',num2str(ImSetOlay(1)))
    set(handles.Ed_tWMax,'string',num2str(ImSetOlay(2)))
  

    if (exist(gbl_p_Prep,'file')==2) 
        set(handles.Tx_SeedXYZ,'ForegroundColor',FColor);

        set(handles.RBtn_SeedXYZ,'Enable',Status_OffOn);
        set(handles.RBtn_SeedMask,'Enable',Status_OffOn);
        
        
        if (get(handles.RBtn_SeedMask,'Value')==1)
            set(handles.RBtn_SeedMask,'ForegroundColor',0*ones(1,3));
            set(handles.Btn_SeedMsk,'Enable','on');
            set(handles.Btn_SeedMsk,'ForegroundColor',0*ones(1,3));
            set(handles.Btn_SPreview,'Enable','off');
            set(handles.RBtn_SeedXYZ,'ForegroundColor',0.5*ones(1,3));
            set(handles.Tx_SeedMask,'ForegroundColor',0*ones(1,3));
            
        elseif (get(handles.RBtn_SeedXYZ,'Value')==1)
            set(handles.RBtn_SeedXYZ,'ForegroundColor',0*ones(1,3));
            set(handles.Ed_Cx,'Enable',Status_OffOn);
            set(handles.Ed_Cy,'Enable',Status_OffOn);
            set(handles.Ed_Cz,'Enable',Status_OffOn);
            set(handles.Btn_SeedMsk,'Enable','off');
            set(handles.RBtn_SeedMask,'ForegroundColor',0.5*ones(1,3));
            set(handles.Btn_SPreview,'Enable','on'); 
            set(handles.Tx_Rmm,'ForegroundColor',FColor);
            set(handles.Tx_SeedR,'ForegroundColor',FColor);
            set(handles.Ed_Rmm,'Enable',Status_OffOn);
            set(handles.Tx_SeedMask,'ForegroundColor',0.5*ones(1,3));
        end
        
    end

%     if (exist(gbl_p_Seed,'file')==2) && (exist(gbl_p_Prep,'file')==2)
    if (exist(gbl_p_Seed,'file')==2) || ~isempty(SeedXYZV)
        %     if ~isempty(SeedXYZV) && (exist(gbl_p_Prep,'file')==2)
        %set(handles.Btn_SPreview,'Enable',Status_OffOn);
        set(handles.Btn_GMaping,'Enable',Status_OffOn);
        set(handles.PMenu_RSMethod,'Enable',Status_OffOn);
%         set(handles.Tx_Rmm,'ForegroundColor',FColor);
%         set(handles.Tx_SeedR,'ForegroundColor',FColor);
%         set(handles.Ed_Rmm,'Enable',Status_OffOn);
    end
end

%||-----------------------------------------------------------------------|
%||	[ Imaging Setting ]
%||-----------------------------------------------------------------------|

% < Anatomy Setting>
if (exist(handles.pRSData,'file')==2) && (exist(handles.pT1,'file')==2)
    Status_OffOn='on';FColor=0*ones(1,3);

    if (exist(handles.pAnat2T1, 'file')==2)
        set(handles.PMenu_Anats,'String',strvcat('High-Res T1','Other Anat'))
        set(handles.PMenu_Anats,'Enable','on');
        if (get(handles.PMenu_Anats,'Value')==1)
             PNT_Under='High-Res T1';
        else
             PNT_Under='Other Anat';
        end
    else
        set(handles.PMenu_Anats,'Value',1);  PNT_Under='High-Res T1';
        set(handles.PMenu_Anats,'Enable','off');
    end
     set(handles.Tx_AxtMap,'String',PNT_Under);
    set(handles.Tx_AxrsMap,'String',PNT_Under);
    
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
    set(handles.Tx_AxtMap,'String','');
    set(handles.Tx_AxrsMap,'String','');
end
set(handles.Pnl_aSetting,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'ForegroundColor',FColor);
set(handles.Tx_aWMax,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'Enable',Status_OffOn);
set(handles.Tx_aWMax,'Enable',Status_OffOn);
set(handles.Ed_aWmin,'Enable',Status_OffOn);
set(handles.Ed_aWMax,'Enable',Status_OffOn);
set(handles.Tx_AxtMap,'Visible',Status_OffOn);
set(handles.Tx_AxrsMap,'Visible',Status_OffOn);

% < Task Result Setting>
if (exist(handles.pTMap,'file')==2) && (exist(handles.pT1,'file')==2)
    Status_OffOn='on';FColor=0*ones(1,3);
    set(handles.Tx_AxtMap,'String',[PNT_Under ' + Guidance Map']);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
set(handles.Pnl_tRst,'ForegroundColor',FColor);
set(handles.Tx_tTH,'ForegroundColor',FColor);
set(handles.Tx_tWMax,'ForegroundColor',FColor);
set(handles.Tx_tOpt,'ForegroundColor',FColor);
set(handles.Ed_tTH,'Enable',Status_OffOn);
set(handles.Ed_tWMax,'Enable',Status_OffOn);
set(handles.Ed_tOpt,'Enable',Status_OffOn);
set(handles.Sd_tOpt,'Enable',Status_OffOn);
set(handles.PMenu_tCMap,'Enable',Status_OffOn);

% < Resting Result Setting>
if (exist(handles.pRSMap,'file')==2) && (exist(handles.pT1,'file')==2)
    Status_OffOn='on';FColor=0*ones(1,3);
    if isfield(handles,'rsSeed') && (get(handles.RBtn_SeedXYZ,'Value')==1)
        rsSeed=handles.rsSeed(1:3);
        PNT_IJK=['X ' sprintf('%3.3d',rsSeed(1)) ', Y ' sprintf('%3.3d',rsSeed(2)) ', Z ' sprintf('%3.3d',rsSeed(3)) ];
        set(handles.Tx_AxrsMap,'String',[PNT_Under '+ FC Map seeding @ ' PNT_IJK]);
    elseif (get(handles.RBtn_SeedMask,'Value')==1)
        set(handles.Tx_AxrsMap,'String',[PNT_Under '+ FC Map seeding @ Mask' ]);
    end
%     if ~isempty(SeedXYZV)
%         c_Mtx=SeedXYZV(1:3);
%         PNT_IJK=['I ' sprintf('%3.3d',c_Mtx(1)) ', J ' sprintf('%3.3d',c_Mtx(2)) ', K ' sprintf('%3.3d',c_Mtx(3)) ];
%         set(handles.Tx_AxrsMap,'String',[PNT_Under '+ rs-result with seed @ ' PNT_IJK]);
%     end
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
set(handles.Pnl_rsRst,'ForegroundColor',FColor);
set(handles.Tx_rsTH,'ForegroundColor',FColor);
set(handles.Tx_rsWMax,'ForegroundColor',FColor);
set(handles.Tx_rsOpt,'ForegroundColor',FColor);
set(handles.Ed_rsTH,'Enable',Status_OffOn);
set(handles.Ed_rsWMax,'Enable',Status_OffOn);
set(handles.Ed_rsOpt,'Enable',Status_OffOn);
set(handles.Sd_rsOpt,'Enable',Status_OffOn);
set(handles.PMenu_rsCMap,'Enable',Status_OffOn);


% set(handles.PMenu_rsCMap,'Enable','off');r
% if (exist(handles.pRSData,'file')==2) &&(exist(handles.pT1,'file')==2) &&(exist(handles.pHRepi,'file')==2)
% end

function WBUFcn(hObject, eventdata, handles)
hFig=handles.Fig_RSfMRI;
try
    switch get(hFig,'SelectionType')
        case 'normal' %right-click,ctrl+left button,
        case 'alt' %right-click,ctrl+left button,
            G=get(hFig,'userdata');
    end
    handles.ClickLR='L';
    guidata(hObject, handles);
    set(hFig,'WindowButtonMotionFcn',{@AxtMap_MouseMoveFcn,handles}) 
    
end;

function WinLvl(~, ~, handles)
hFig=handles.Fig_RSfMRI;
G=get(hFig,'userdata');
set(hFig,'userdata',G);
set(hFig,'WindowButtonMotionFcn',{@AxtMap_MouseMoveFcn,handles});
set(hFig,'WindowButtonDownFcn',{@AxtMap_ButtonDownFcn,handles})
set(hFig,'WindowButtonUpFcn',{@WBUFcn,handles}) 


function AdjWL(hObject, eventdata, handles)
global ImSetUlay
hFig=handles.Fig_RSfMRI;
G=get(hFig,'userdata');
G.cp=get(handles.AxtMap,'currentpoint');
G.x=G.cp(1,1);G.y=G.cp(1,2);
G.xinit = G.initpnt(1,1);
G.yinit = G.initpnt(1,2);
G.dx = G.x-G.xinit;G.dy = G.y-G.yinit;
G.clim = G.initClim+G.initClim(2).*[G.dx G.dy]./128;
try
    switch get(hFig,'SelectionType')
        case 'normal'
            handles.ClickLR='L';
        case 'alt' 
            set(handles.AxtMap,'Clim',round(G.clim));
            ImSetUlay=caxis(handles.AxtMap); 
    end;
    guidata(hObject, handles); 
    set(handles.Ed_aWmin,'string',num2str(ImSetUlay(1)));
    set(handles.Ed_aWMax,'string',num2str(ImSetUlay(2)));
    DispIm(hObject, eventdata, handles);
end;

%||=======================================================================|
%|| [Display :: Window/Level]
%||=======================================================================|
function AxtMap_ButtonDownFcn(hObject, eventdata, handles)
global SeedXYZV ImSetUlay gbl_p_Prep gbl_p_Seed IDX_sPreview IDX_flipUD

if (exist(handles.pT1,'file')==2) && (exist(gbl_p_Prep,'file')==2) && (get(handles.RBtn_SeedXYZ,'Value')==1)
    hFig=handles.Fig_RSfMRI;
%     try
        switch get(hFig,'SelectionType')
            case 'normal' % Left-Click
                handles.ClickLR='L';
                oldunits = get(handles.AxtMap, 'Units');
                C = round(get (handles.AxtMap, 'CurrentPoint'));C = round(C(1,1:2));
                Crs = round(get (handles.AxrsMap, 'CurrentPoint'));Crs = round(Crs(1,1:2));
                SliceZ=round(get(handles.Sd_SliceZ, 'Value'));
                %disp(['C=[' num2str(C) '],  Crs=[' num2str(Crs) ']'])
                if (C(1)>0) && (C(1)<size(handles.MtxT1,2)) && (C(2)>0) && (C(2)<size(handles.MtxT1,1))
                    IDX_SHOWXYZ='O';
                    COORD=C;
                elseif (Crs(1)>0) && (Crs(1)<size(handles.MtxT1,2)) && (Crs(2)>0) && (Crs(2)<size(handles.MtxT1,1))
                    IDX_SHOWXYZ='O';
                    COORD=Crs;
                else
                    IDX_SHOWXYZ='X';
                end

                if strcmp(IDX_SHOWXYZ,'O')
                    % Extract Seed Information based on the underlay and overlay
                    if (exist(handles.pTMap,'file')==2) && ~(exist(handles.pRSMap,'file')==2)
                         if (IDX_flipUD==1)
                            ZMap=round(100*flipud(handles.MtxTMap(:,:,SliceZ)'))/100;
                         else
                            ZMap=round(100*(handles.MtxTMap(:,:,SliceZ)'))/100;
                         end
                        SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                        PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
                    elseif ~(exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                         if (IDX_flipUD==1)
                            ZMap=round(100*flipud(handles.MtxRSMap(:,:,SliceZ)'))/100;
                         else
                            ZMap=round(100*(handles.MtxRSMap(:,:,SliceZ)'))/100;
                         end
                        SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                        PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
                    elseif (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                        if (IDX_flipUD==1)
                            ZMap=round(100*flipud(handles.MtxTMap(:,:,SliceZ)'))/100;
                            RSMap=round(100*flipud(handles.MtxRSMap(:,:,SliceZ)'))/100;
                        else
                            ZMap=round(100*(handles.MtxTMap(:,:,SliceZ)'))/100;
                            RSMap=round(100*(handles.MtxRSMap(:,:,SliceZ)'))/100;
                        end
                        SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1)) RSMap(COORD(2),COORD(1))];
                        PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4)) ', ' sprintf('%3.2f',SeedXYZV(5))];
                    else
                        if (IDX_flipUD==1)
                            ZMap=flipud( handles.MtxT1(:,:,SliceZ)');
                        else
                            ZMap=( handles.MtxT1(:,:,SliceZ)');
                        end   
                        SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                        PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
                    end
                    
                    if ~isempty(SeedXYZV)
                        if (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                            set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value(t)] = [' PNT_SeedXYZV '];  '...
                                'Current @ [x,y,z,value(t),value(rs)] = [' PNT_SeedXYZV  ']'],'ForegroundColor',[0 0 0]);
                        else
                            set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value] = [' PNT_SeedXYZV '];  '...
                                'Current @ [x,y,z,value] = [' PNT_SeedXYZV  ']'],'ForegroundColor',[0 0 0]);
                        end 
                        set(handles.Ed_Cx,'string',sprintf('%3.3d',SeedXYZV(1)));
                        set(handles.Ed_Cy,'string',sprintf('%3.3d',SeedXYZV(2)));
                        set(handles.Ed_Cz,'string',sprintf('%3.3d',SeedXYZV(3)));
                        
                        % Reset Seed and MtxSeed
                        gbl_p_Seed='';
                        if isfield(handles,'MtxSeed')
                            rmfield(handles,'MtxSeed');
                        end

                    else
                        if (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                            set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value(t),value(rs)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                        else
                            set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                        end
                    end
                    IDX_sPreview=0;
                    guidata(hObject, handles);
                    BtnSetting(hObject, eventdata, handles);
                    DispIm(hObject, eventdata, handles)
                end
            case 'alt' % Right-click
                set(hFig,'WindowButtonMotionFcn',{@AdjWL,handles})
                G=get(hFig,'userdata');
                G.initpnt=get(handles.AxtMap,'currentpoint');
                G.initClim = [ImSetUlay(1) ImSetUlay(2)];
                set(hFig,'userdata',G);
        end
        guidata(hObject, handles);
%     end
end

function AxtMap_MouseMoveFcn(hObject, eventdata, handles)
global SeedXYZV IDX_flipUD
if (exist(handles.pT1,'file')==2)
    if strcmp(handles.ClickLR,'L')
        oldunits = get(handles.AxtMap, 'Units');
        C = round(get (handles.AxtMap, 'CurrentPoint'));C = round(C(1,1:2));
        Crs = round(get (handles.AxrsMap, 'CurrentPoint'));Crs = round(Crs(1,1:2));

        
        SliceZ=round(get(handles.Sd_SliceZ, 'Value'));
        
        if (IDX_flipUD==1)
            MapTEMP=flipud( handles.MtxT1(:,:,SliceZ)');
        else
            MapTEMP=( handles.MtxT1(:,:,SliceZ)');
        end

         if (C(1)>0) && (C(1)<size(MapTEMP,2)) && (C(2)>0) && (C(2)<size(MapTEMP,1))
             IDX_SHOWXYZ='O';
             COORD=C;
         elseif (Crs(1)>0) && (Crs(1)<size(MapTEMP,2)) && (Crs(2)>0) && (Crs(2)<size(MapTEMP,1))
             IDX_SHOWXYZ='O';
             COORD=Crs;
         else
             IDX_SHOWXYZ='X';
         end

         if strcmp(IDX_SHOWXYZ,'O')
             if (exist(handles.pTMap,'file')==2) && ~(exist(handles.pRSMap,'file')==2)
                 if (IDX_flipUD==1)
                     ZMap=round(100*flipud(handles.MtxTMap(:,:,SliceZ)'))/100;
                 else
                     ZMap=round(100*(handles.MtxTMap(:,:,SliceZ)'))/100;
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
            elseif ~(exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                         if (IDX_flipUD==1)
                            ZMap=round(100*flipud(handles.MtxRSMap(:,:,SliceZ)'))/100;
                         else
                            ZMap=round(100*(handles.MtxRSMap(:,:,SliceZ)'))/100;
                         end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
             elseif (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                 if (IDX_flipUD==1)
                     ZMap=round(100*flipud(handles.MtxTMap(:,:,SliceZ)'))/100;
                     RSMap=round(100*flipud(handles.MtxRSMap(:,:,SliceZ)'))/100;
                 else
                     ZMap=round(100*(handles.MtxTMap(:,:,SliceZ)'))/100;
                     RSMap=round(100*(handles.MtxRSMap(:,:,SliceZ)'))/100;
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1)) RSMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4)) ', ' sprintf('%3.2f',CurrentXYZV(5))];
             else
                 if (IDX_flipUD==1)
                     ZMap=flipud( handles.MtxT1(:,:,SliceZ)');
                 else
                     ZMap=( handles.MtxT1(:,:,SliceZ)');
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
             end
             
             if ~isempty(SeedXYZV)
                 PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
                 
                 if (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                     set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value(t)] = [' PNT_SeedXYZV '];  '...
                         'Current @ [x,y,z,value(t),value(rs)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 else
                     set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value] = [' PNT_SeedXYZV '];  '...
                         'Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 end     
             else
                 if (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
                     set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value(t),value(rs)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 else
                     set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 end
             end    
         end
    end
end
%||=======================================================================|
%|| [Display :: DispIm ]
%||=======================================================================|
function Cal_MtxT1M(hObject, eventdata, handles)
global ImSetUlay ImSetUlay_BU MtxT1M IDX_flipUD
MtxT1M=handles.MtxT1; % M: Modulated
if (sum(ImSetUlay==ImSetUlay_BU)<2)
    MtxT1M(MtxT1M<ImSetUlay(1))=ImSetUlay(1);
    MtxT1M(MtxT1M>ImSetUlay(2))=ImSetUlay(2);
end
if (IDX_flipUD==1)
    MtxT1M=flipud(permute(MtxT1M(:,:,:), [2 1 3]));
else
    MtxT1M=(permute(MtxT1M(:,:,:), [2 1 3]));
end

function Cal_MtxRGB(hObject, eventdata, handles)
global ImSetUlay ImSetUlay_BU ImSetOlay ImSetOlay_BU ImSetOlayRS ImSetOlayRS_BU CMapRS_BU IDX_NewSeed
global TMap_RGB RSMap_RGB MtxT1M CMap_BU IDX_flipUD
IDX_OLayT=(sum(ImSetUlay==ImSetUlay_BU))+sum(ImSetOlay==ImSetOlay_BU);
IDX_OLayRS=(sum(ImSetUlay==ImSetUlay_BU)+sum(ImSetOlayRS==ImSetOlayRS_BU));


MtxT1M=handles.MtxT1; % M: Modulated
if (sum(ImSetUlay==ImSetUlay_BU)<2) || (sum(ImSetOlay==ImSetOlay_BU)<3) || (sum(ImSetOlayRS==ImSetOlayRS_BU)<3) || ~strcmp(CMapRS_BU,handles.CMapRS) || (IDX_NewSeed==1)
    MtxT1M(MtxT1M<ImSetUlay(1))=ImSetUlay(1);
    MtxT1M(MtxT1M>ImSetUlay(2))=ImSetUlay(2);
end

% Cal_MtxT1M(hObject, eventdata, handles)
% <Re-Calcuate RGB : T Map>
if (sum(ImSetUlay==ImSetUlay_BU)<2) || (sum(ImSetOlay==ImSetOlay_BU)<3) || ~strcmp(CMap_BU,handles.CMap)
    %if (IDX_OLayT<5) || ~strcmp(CMap_BU,handles.CMap)
    if ~(isfield(handles,'MtxTMap')==1)
        MtxTMap=MtxT1M;MtxTMap(:)=0;
    else
        MtxTMap=handles.MtxTMap;
    end
    [TMap_RGB]=Fn_OLay2RGB(MtxT1M,MtxTMap,ImSetOlay,'n','n',handles.CMap);
    
    
    %[TMap_RGB]=Fn_OLay2RGB(MtxT1M,handles.MtxTMap,ImSetOlay,'n','n',handles.CMap);
    ImSetOlay_BU=ImSetOlay;CMap_BU=handles.CMap;
    if (IDX_flipUD==1)
        TMap_RGB=flipud(permute(TMap_RGB, [2 1 3 4]));
    else
        TMap_RGB=(permute(TMap_RGB, [2 1 3 4]));
    end
end
if (sum(ImSetUlay==ImSetUlay_BU)<2) || (sum(ImSetOlayRS==ImSetOlayRS_BU)<3) || ~strcmp(CMapRS_BU,handles.CMapRS) || (IDX_NewSeed==1)
    if ~(exist(handles.pRSMap,'file')==2)
        MtxRSMap=MtxT1M;MtxRSMap(:)=0;
    else
        MtxRSMap=handles.MtxRSMap;
    end
    [RSMap_RGB]=Fn_OLay2RGB(MtxT1M,MtxRSMap,ImSetOlayRS,'n','n',handles.CMapRS);
    ImSetOlayRS_BU=ImSetOlayRS;CMapRS_BU=handles.CMapRS;
    IDX_NewSeed=0;
    if (IDX_flipUD==1)
        RSMap_RGB=flipud(permute(RSMap_RGB, [2 1 3 4]));
    else
        RSMap_RGB=(permute(RSMap_RGB, [2 1 3 4]));
    end
end



function DispIm(hObject, eventdata, handles)
global SeedXYZV ImSetUlay ImSetUlay_BU ImSetOlay ImSetOlay_BU CMap_BU CMapRS_BU  ImSetOlayRS ImSetOlayRS_BU IDX_NewSeed
global TMap_RGB RSMap_RGB
global IDX_sPreview IDX_flipUD
global MtxT1M gbl_p_Seed
%||	--------------------------------------< Display :: NO ANY GIVEN Images>
%||	---------------------------------------<Anat(X) && TMap(X) && RSMap(X)>
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');

SliceZ=str2double(get(handles.Ed_SliceZ,'string'));
switch handles.DispCase
    case 0
        imshow(  zeros(256,256),[0 5000],'Parent',handles.AxtMap);
        imshow(  zeros(256,256),[0 5000],'Parent',handles.AxrsMap);
    case 1
        imshow( squeeze(MtxT1M(:,:,SliceZ)),ImSetUlay,'Parent',handles.AxtMap);
        imshow( squeeze(MtxT1M(:,:,SliceZ)),ImSetUlay,'Parent',handles.AxrsMap);
        
        if (get(handles.RBtn_SeedXYZ,'Value')==1) && ~isempty(SeedXYZV)
            if (SeedXYZV(3)==round(SliceZ))
                C=SeedXYZV;
                hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
                hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
            end
        end
        
        if (exist(gbl_p_Seed,'file')==2)
            %if ~isempty(SeedXYZV)
            if (isfield(handles,'MtxSeed')==1)
                %         if (isfield(handles,'MtxSeed')==1) && (IDX_sPreview==1)
                hold(handles.AxtMap,'on');hold(handles.AxrsMap,'on');
                if (IDX_flipUD==1)
                    ImSeed=flipud(squeeze(handles.MtxSeed(:,:,SliceZ))');
                else
                    ImSeed=(squeeze(handles.MtxSeed(:,:,SliceZ))');
                end
                [BB,LL]=bwboundaries(ImSeed,'noholes');
                for kk=1:length(BB)
                    boundary2=BB{kk};
                    plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',2,'Parent',handles.AxtMap);
                    plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',2,'Parent',handles.AxrsMap);
                end
%                 if ~isempty(SeedXYZV)
%                     if (SeedXYZV(3)==round(SliceZ)) && (get(handles.RBtn_SeedXYZ,'Value')==1)
%                         C=SeedXYZV;
%                         hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
%                         hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
%                     end
%                 end
%             else
%                 if ~isempty(SeedXYZV)
%                     if (SeedXYZV(3)==round(SliceZ)) && (get(handles.RBtn_SeedXYZ,'Value')==1)
%                         C=SeedXYZV;
%                         hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
%                         hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
%                         %hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 1 1],'markersize', 20,'Parent',handles.AxrsMap);
%                     end
%                 end
            end
        end
        WinLvl(hObject, eventdata, handles)
    case 2
        imshow(squeeze(TMap_RGB(:,:,SliceZ,:)),'Parent',handles.AxtMap);
        imshow(squeeze(RSMap_RGB(:,:,SliceZ,:)),'Parent',handles.AxrsMap);
        WinLvl(hObject, eventdata, handles)
        
        if (get(handles.RBtn_SeedXYZ,'Value')==1) && ~isempty(SeedXYZV)
            if (SeedXYZV(3)==round(SliceZ))
                C=SeedXYZV;
                hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
                hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
            end
        end
        
        
        if (exist(gbl_p_Seed,'file')==2)
            if (isfield(handles,'MtxSeed')==1)
                %             if (isfield(handles,'MtxSeed')==1) && (IDX_sPreview==1)
                hold(handles.AxtMap,'on');hold(handles.AxrsMap,'on');
                if (IDX_flipUD==1)
                    ImSeed=flipud(squeeze(handles.MtxSeed(:,:,SliceZ))');
                else
                    ImSeed=(squeeze(handles.MtxSeed(:,:,SliceZ))');
                end
                [BB,LL]=bwboundaries(ImSeed,'noholes');
                for kk=1:length(BB)
                    boundary2=BB{kk};
                    plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',2,'Parent',handles.AxtMap);
                    plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',2,'Parent',handles.AxrsMap);
                end
%                 if ~isempty(SeedXYZV)
%                     if (SeedXYZV(3)==round(SliceZ)) && (get(handles.RBtn_SeedXYZ,'Value')==1)
%                         C=SeedXYZV;
%                         hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
%                         hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
%                     end
%                 end
%             else
%                 if ~isempty(SeedXYZV)
%                     if (SeedXYZV(3)==round(SliceZ)) && (get(handles.RBtn_SeedXYZ,'Value')==1)
%                         C=SeedXYZV;
%                         hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
%                         hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
%                         %hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 1 1],'markersize', 20,'Parent',handles.AxrsMap);
%                     end
%                 end
            end
        end
        guidata(hObject, handles);
end
if (exist(handles.pT1_Lesion,'file')==2)
    hold(handles.AxtMap,'on');
    if (IDX_flipUD==1)
        ImLesion=flipud(squeeze(handles.MtxT1_Lesion(:,:,SliceZ))');
    else
        ImLesion=squeeze(handles.MtxT1_Lesion(:,:,SliceZ))';
    end
    
    [B,L]=bwboundaries(ImLesion,'noholes');
    for k=1:length(B)
        boundary=B{k};
        plot(boundary(:,2),boundary(:,1),'r','LineWidth',1,'Parent',handles.AxtMap);
    end
end
BtnSetting(hObject, eventdata, handles)

% if ~(exist(handles.pT1,'file')==2)
%     imshow(  zeros(256,256),[0 5000],'Parent',handles.AxtMap);
%     imshow(  zeros(256,256),[0 5000],'Parent',handles.AxrsMap);
% elseif (exist(handles.pT1,'file')==2)
%     SliceZ=str2double(get(handles.Ed_SliceZ,'string'));
%     %||	------------------------< Display ::Anat(O) && TMap(X) && RSMap(X)>
%     if ~(isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
%         if (handles.cAUTO==1)
%             if (IDX_flipUD==1)
%                 %hIm=imshow(  flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),'Parent',handles.AxtMap);
%                 hIm=imshow(  flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxtMap);
%                 hIm2=imshow(  flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxrsMap);
%             else
%                 %                 hIm=imshow(  (squeeze(handles.MtxT1(:,:,SliceZ))'),'Parent',handles.AxtMap);
%                 hIm=imshow(  (squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxtMap);
%                 hIm2=imshow(  (squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxrsMap);
%             end
%             caxis(handles.AxtMap,'auto');
%             caxis(handles.AxrsMap,'auto');
%             ImSetUlay=caxis(handles.AxtMap);BtnSetting(hObject, eventdata, handles)
%             handles.cAUTO=2; guidata(hObject, handles);
%         elseif (handles.cAUTO==2)
%             if (IDX_flipUD==1)
%                 hIm=imshow(  flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxtMap);
%                 hIm2=imshow(  flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxrsMap);
%             else
%                 hIm=imshow(  (squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxtMap);
%                 hIm2=imshow(  (squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxrsMap);
%             end
%         end
% %         set(handles.AxtColorBar,'Visible','off')
% %         set(handles.AxrsColorBar,'Visible','off')
%         WinLvl(hObject, eventdata, handles)
%         %||	--------------------< Display ::Anat(O) && TMap(?) && RSMap(?)>
%     elseif (isfield(handles,'MtxTMap')==1) || (isfield(handles,'MtxRSMap')==1)
%         MtxT1M=handles.MtxT1; % M: Modulated
%         if (sum(ImSetUlay==ImSetUlay_BU)<2)
%            MtxT1M(MtxT1M<ImSetUlay(1))=ImSetUlay(1);
%            MtxT1M(MtxT1M>ImSetUlay(2))=ImSetUlay(2);
%         end
%         IDX_OLayT=(sum(ImSetUlay==ImSetUlay_BU))+sum(ImSetOlay==ImSetOlay_BU);
%         IDX_OLayRS=(sum(ImSetUlay==ImSetUlay_BU)+sum(ImSetOlayRS==ImSetOlayRS_BU));
%         % <Re-Calcuate RGB : T Map>
%         if (isfield(handles,'MtxTMap')==1)
%             if (IDX_OLayRS<5) || (IDX_OLayT<5) || ~strcmp(CMap_BU,handles.CMap)
%             %if (IDX_OLayT<5) || ~strcmp(CMap_BU,handles.CMap)
%                 [TMap_RGB]=Fn_OLay2RGB(MtxT1M,handles.MtxTMap,ImSetOlay,'n','n',handles.CMap);
%                 ImSetOlay_BU=ImSetOlay;CMap_BU=handles.CMap;
%             end
%         end
%         % <Re-Calcuate RGB : RS Map>
%         if (isfield(handles,'MtxRSMap')==1)
%             if (IDX_OLayRS<5) || (IDX_OLayT<5) || ~strcmp(CMapRS_BU,handles.CMapRS) || (IDX_NewSeed==1)
%             %if (IDX_OLayRS<5) || ~strcmp(CMapRS_BU,handles.CMapRS) || (IDX_NewSeed==1)
%                 [RSMap_RGB]=Fn_OLay2RGB(MtxT1M,handles.MtxRSMap,ImSetOlayRS,'n','n',handles.CMapRS);
%                 ImSetOlayRS_BU=ImSetOlayRS;CMapRS_BU=handles.CMapRS;
%                 IDX_NewSeed=0;
%             end
%         end
%         ImSetUlay_BU=ImSetUlay;
%         %||	--------------------< Display ::Anat(O) && TMap(O) && RSMap(X)>
%         if (isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
%             if (IDX_flipUD==1)
%                 hIm=imshow(flipud(permute(squeeze(TMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxtMap);
%                 hIm2=imshow(  flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxrsMap);
%             else
%                 hIm=imshow((permute(squeeze(TMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxtMap);
%                 hIm2=imshow(  (squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxrsMap);
%             end
%         %||	--------------------< Display ::Anat(O) && TMap(X) && RSMap(O)>
%         elseif ~(isfield(handles,'MtxTMap')==1) && (isfield(handles,'MtxRSMap')==1)
%             if (IDX_flipUD==1)
%                 hIm=imshow(flipud(squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxtMap);
%                 hIm2=imshow(flipud(permute(squeeze(RSMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxrsMap);
%             else
%                 hIm=imshow((squeeze(handles.MtxT1(:,:,SliceZ))'),ImSetUlay,'Parent',handles.AxtMap);
%                 hIm2=imshow((permute(squeeze(RSMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxrsMap);
%             end
% %             set(handles.AxtColorBar,'Visible','off')
% %             set(handles.AxrsColorBar,'Visible','off')
%         %||	--------------------< Display ::Anat(O) && TMap(O) && RSMap(O)>    
%         elseif (isfield(handles,'MtxTMap')==1) && (isfield(handles,'MtxRSMap')==1)
%             if (IDX_flipUD==1)
%                 hIm=imshow(flipud(permute(squeeze(TMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxtMap);
%                 hIm2=imshow(flipud(permute(squeeze(RSMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxrsMap);
%             else
%                 hIm=imshow((permute(squeeze(TMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxtMap);
%                 hIm2=imshow((permute(squeeze(RSMap_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxrsMap);
%             end
%         end 
%     end
%     WinLvl(hObject, eventdata, handles)
%     if (exist(handles.pT1_Lesion,'file')==2)
%         hold(handles.AxtMap,'on');
%         ImLesion=flipud(squeeze(handles.MtxT1_Lesion(:,:,SliceZ))');
%         [B,L]=bwboundaries(ImLesion,'noholes');
%         for k=1:length(B)
%             boundary=B{k};
%             plot(boundary(:,2),boundary(:,1),'r','LineWidth',1,'Parent',handles.AxtMap);
%         end
%     end
%     if ~isempty(SeedXYZV)
%         if (isfield(handles,'MtxSeed')==1) && (IDX_sPreview==1)
%             hold(handles.AxtMap,'on');hold(handles.AxrsMap,'on');
%             if (IDX_flipUD==1)
%                 ImSeed=flipud(squeeze(handles.MtxSeed(:,:,SliceZ))');
%             else
%                 ImSeed=(squeeze(handles.MtxSeed(:,:,SliceZ))');
%             end
%             [BB,LL]=bwboundaries(ImSeed,'noholes');
%             for kk=1:length(BB)
%                 boundary2=BB{kk};
%                 plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',1,'Parent',handles.AxtMap);
%                 plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',1,'Parent',handles.AxrsMap);
%             end
%             if (SeedXYZV(3)==round(SliceZ))
%                 C=SeedXYZV;
%                 hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
%             end
%         else
%             if (SeedXYZV(3)==round(SliceZ))
%                 C=SeedXYZV;
%                 hold(handles.AxtMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxtMap);
%                 hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxrsMap);
%                 %hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 1 1],'markersize', 20,'Parent',handles.AxrsMap);
%             end
%         end
%     end
%     guidata(hObject, handles);BtnSetting(hObject, eventdata, handles)
% end

function Ck_SliceT_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function PMenu_SliceTime_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_SliceTime,'string');
selectedIndex = get(handles.PMenu_SliceTime,'Value');
% selectedItem = allItems{selectedIndex};

switch get(handles.PMenu_SliceTime,'Value')
    case 1
        handles.tPattern='alt+z';
    case 2
        handles.tPattern='alt+z2';
    case 3
        handles.tPattern='alt-z';
    case 4
        handles.tPattern='alt-z2';
    case 5
        handles.tPattern='seq+z';
    case 6
        handles.tPattern='seq-z';
end
guidata(hObject, handles);

function PMenu_SliceTime_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ck_MCRT_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function Ck_DDdnt_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function Ck_Blur_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function Ck_FMCRT_Callback(hObject, eventdata, handles)
function Ck_NReg_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function Ck_NR_Global_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function Ck_Bandpass_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
function Ck_Coreg_Callback(hObject, eventdata, handles)


function Btn_rsData_Callback(hObject, eventdata, handles)
[fRSData,DirIn] = uigetfile({'*.nii'},'Select Rs-fMRI Data',handles.DirW);pRSData=[DirIn fRSData];
if isequal(fRSData,0) && isequal(DirIn,0) 
    set(handles.Tx_rsData,'String','Rs-fMRI Data is not selected!');
    handles.pRSData='';
else
    handles.pRSData=pRSData;
    handles.DirRS=DirIn;
    %StuRSData=load_untouch_nii(pRSData);
    StuRSData=nifti(pRSData);
%     handles.DimRS=size(StuRSData.img);
    handles.DimRS=size(StuRSData.dat);
    if (numel(handles.DimRS)>3)
        if (handles.DimRS(4)>0)
            %handles.TR=StuRSData.hdr.dime.pixdim(5);
%             if isfield(StuRSData,'timing')
            if ~isempty(getfield(StuRSData, 'timing'))
                handles.TR=StuRSData.timing.tspace;
            end
            set(handles.Ed_TR,'String',num2str(handles.TR))
        end
        handles.RSReps=handles.DimRS(4);
        set(handles.Tx_rsData,'String',['[#Vol=' num2str(handles.RSReps) '] ' fRSData]);
    else
        handles.pRSData='';
        handles.RSReps=0;
        set(handles.Tx_rsData,'String',['[#Vol=' num2str(handles.RSReps) '] ' 'Selected rs-dataset is not 4D dataset, please check!']);
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles)

function [handles]=DispCase(hObject, eventdata, handles)
if ~(exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
    handles.DispCase=0;
elseif (exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
    handles.DispCase=1;
    Cal_MtxT1M(hObject, eventdata, handles);
elseif (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxTMap')==1) && ~(isfield(handles,'MtxRSMap')==1)
    handles.DispCase=2;
%     Cal_MtxT1M(hObject, eventdata, handles);
    Cal_MtxRGB(hObject, eventdata, handles);
elseif (exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxTMap')==1) && (isfield(handles,'MtxRSMap')==1)
    handles.DispCase=2;
%     Cal_MtxT1M(hObject, eventdata, handles);
    Cal_MtxRGB(hObject, eventdata, handles);
elseif (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxTMap')==1) && (isfield(handles,'MtxRSMap')==1)
    handles.DispCase=2;
%     Cal_MtxT1M(hObject, eventdata, handles);
    Cal_MtxRGB(hObject, eventdata, handles);
end
guidata(hObject, handles);
%  disp(['||  (Corrected)Case: ' num2str(handles.DispCase)])


function Btn_T1_Callback(hObject, eventdata, handles)
global IDX_flipUD ImSetUlay
[fT1,DirIn] = uigetfile({'*.nii'},'Select High-Resoultion T1 Image',handles.DirRS);pT1=[DirIn fT1];
if isequal(fT1,0) && isequal(DirIn,0)
    set(handles.Tx_T1,'String','High-Resoultion T1 Image is not selected!');
    handles.pT1='';
else
    handles.pT1=pT1;
    StuT1=nifti(pT1);
    handles.DimT1=size(StuT1.dat);
    if (numel( handles.DimT1)>3)
        handles.pT1='';
        set(handles.Tx_T1,'String',['[#Vol=' num2str(handles.DimT1(4)) '] ' 'T1 data should not be a 4D dataset, please check!']);
    else
        handles.pT1=pT1;
        handles.StuT1=StuT1;
        handles.fT1=fT1;
        Dim= [sprintf('%3.3d',handles.DimT1(1)) 'x' sprintf('%3.3d',handles.DimT1(2)) 'x' sprintf('%3.3d',handles.DimT1(3))];

        handles.qform=StuT1.mat;
        if (handles.qform(2,2)<0); IDX_flipUD=0;else IDX_flipUD=1; end
%         if isfield(StuT1.hdr.hist,'srow_x') && isfield(StuT1.hdr.hist,'srow_y') && isfield(StuT1.hdr.hist,'srow_z')
%             qform=[StuT1.hdr.hist.srow_x; StuT1.hdr.hist.srow_y; StuT1.hdr.hist.srow_z];
%             if (qform(2,2)<0); IDX_flipUD=0;else IDX_flipUD=1; end
%         end

        set(handles.Tx_T1,'String',['[' Dim '] ' fT1]);
        handles.MtxT1=double(StuT1.dat);

        % <Initial Setting : Dir Z>
        numSteps=handles.DimT1(3);
        SliceZ=round(2*numSteps/3);% SliceZ = cell2mat(varargin(1));
        set(handles.Ed_SliceZ,'string',num2str(SliceZ));
        set(handles.Sd_SliceZ, 'min', 1); set(handles.Sd_SliceZ, 'max', numSteps);
        set(handles.Sd_SliceZ, 'Value', SliceZ); % Somewhere between max and min.
        set(handles.Sd_SliceZ, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
        % <Initial Setting : Adjust ImSetUlay>
        ImSetUlay=[min(min(handles.MtxT1(:,:,SliceZ))) round(0.6*max(max(handles.MtxT1(:,:,SliceZ))))];
    end
end
guidata(hObject, handles);% BtnSetting(hObject, eventdata, handles);
set(handles.Tx_Message,'String',['Loading & Displaying Images >>> '],'ForegroundColor',[1 0 0]); pause(0.1);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles);BtnSetting(hObject, eventdata, handles);
set(handles.Tx_Message,'String',['>> '],'ForegroundColor',[0 0 0]); 


function Btn_Lesion_Callback(hObject, eventdata, handles)

[fT1_Lesion,DirIn] = uigetfile({'*.nii;*.img'},'Select Lesion Mask matching the Resolution of High-Res T1 Image',handles.DirRS);pT1_Lesion=[DirIn fT1_Lesion];
if isequal(fT1_Lesion,0) && isequal(DirIn,0) 
    set(handles.Tx_Lesion,'String','File is not selected!');
    handles.pT1_Lesion='';
else
    StuT1_Lesion=nifti(pT1_Lesion);
    handles.DimT1_Lesion=size(StuT1_Lesion.dat);
    if (numel(handles.DimT1_Lesion)>3)
        handles.pT1_Lesion='';
        set(handles.Tx_Lesion,'String',['[#Vol=' num2str(handles.DimT1_Lesion(4)) '] ' 'Lesion mask should not be a 4D Dataset, please check!']);
    else
        
        Dim= [sprintf('%3.3d',handles.DimT1_Lesion(1)) 'x' sprintf('%3.3d',handles.DimT1_Lesion(2)) 'x' sprintf('%3.3d',handles.DimT1_Lesion(3))];
        set(handles.Tx_Lesion,'String',['[' Dim '] ' fT1_Lesion]);
        
        if (    sum(handles.DimT1==handles.DimT1_Lesion)==3  )
            handles.pT1_Lesion=pT1_Lesion;
            handles.MtxT1_Lesion=logical(StuT1_Lesion.dat(:,:,:)); 
        else
            set(handles.Tx_Lesion,'String',['[' Dim '] ' 'Lesion mask SHOULD BE at the smae space of T1 data, please check!']);
        end
            
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)


function Btn_HRepi_Callback(hObject, eventdata, handles)

[fHRepi,DirIn] = uigetfile({'*.nii;*.img'},'Select High-Resolution EPI for Boundar-Based Registration',handles.DirRS);pHRepi=[DirIn fHRepi];
if isequal(fHRepi,0) && isequal(DirIn,0) 
    set(handles.Tx_HRepi,'String','Data is not selected!');
    handles.pHRepi='';
else
    
    StuHRepi=nifti(pHRepi);
    handles.DimHRepi=size(StuHRepi.dat);
    
    Dim3DRS=handles.DimRS(1)*handles.DimRS(2)*handles.DimRS(3);
    Dim3DHRepi=handles.DimHRepi(1)*handles.DimHRepi(2)*handles.DimHRepi(3);
    Dim= [sprintf('%3.3d',handles.DimHRepi(1)) 'x' sprintf('%3.3d',handles.DimHRepi(2)) 'x' sprintf('%3.3d',handles.DimHRepi(3))];

    if (Dim3DHRepi<Dim3DRS)
        handles.pHRepi='';
        set(handles.Tx_HRepi,'String',[ 'The dimenstion of high-resoultion EPI MUST LARGER THAN that of rs-dataset']);
    else
        handles.pHRepi=pHRepi;
        set(handles.Tx_HRepi,'String',['[' Dim '] ' fHRepi]);   
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles)


function Btn_tMap_Callback(hObject, eventdata, handles)

[fTMap,DirIn] = uigetfile({'*.nii;*.img'},'Select Guidance Map',handles.DirRS);pTMap=[DirIn fTMap];
if isequal(fTMap,0) && isequal(DirIn,0) 
    set(handles.Tx_tMap,'String','Data not selected!');
    handles.pTMap='';
    
    F='DimTMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
    F='MtxTMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
    handles.cAUTO=2;
else
    
    StuTMap=nifti(pTMap);
    handles.DimTMap=size(StuTMap.dat);
    
%     StuTMap=load_untouch_nii(pTMap);
%     handles.DimTMap=size(StuTMap.img);
    
    Dim3DTMap=handles.DimTMap(1)*handles.DimTMap(2)*handles.DimTMap(3);
    Dim3DT1=handles.DimT1(1)*handles.DimT1(2)*handles.DimT1(3);
    Dim= [sprintf('%3.3d',handles.DimTMap(1)) 'x' sprintf('%3.3d',handles.DimTMap(2)) 'x' sprintf('%3.3d',handles.DimTMap(3))];

    if (Dim3DTMap==Dim3DT1)
        handles.pTMap=pTMap;
        %Mtxtemp=(double(StuTMap.img));
        Mtxtemp=double(StuTMap.dat);
        if (numel(size(Mtxtemp))==3)
            handles.MtxTMap=Mtxtemp;
            set(handles.Tx_tMap,'String',['[' Dim '] ' fTMap],'foregroundcolor',[0 0 0]);
            global ImSetOlay
            ImSetOlay(1)=round(mean(handles.MtxTMap(:))*100)/100;
            if ImSetOlay(1)<0.5
                ImSetOlay(1)=0.5;
            end
            ImSetOlay(2)=round((max(handles.MtxTMap(:))-std(handles.MtxTMap(:)))*100)/100;
        else
            handles.pTMap='';
            strDIM=strrep( num2str(size(Mtxtemp)),' ','x');
            strDIM=strrep(strDIM,'xxxx','x');strDIM=strrep(strDIM,'xxx','x');strDIM=strrep(strDIM,'xx','x');
            set(handles.Tx_tMap,'String',[ 'Dimenstion is [' strDIM '], choose the 3D image instead' ],'foregroundcolor',[1 0 0]);
        end
    else
        handles.pTMap='';
        set(handles.Tx_tMap,'String',[ 'The Dimenstion of task result MUST at T1 Space'],'foregroundcolor',[1 0 0]);
    end
end
[handles]=DispCase(hObject, eventdata, handles);
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)


% function edit1_Callback(hObject, eventdata, handles)
% function edit1_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% function edit2_Callback(hObject, eventdata, handles)
% function edit2_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end


%||=======================================================================|
%|| [Anatomical Window Range: Min/Max]
%||=======================================================================|

function Ed_aWmin_Callback(hObject, eventdata, handles)
global ImSetUlay
StrMin=get(handles.Ed_aWmin, 'string');
StrMax=get(handles.Ed_aWMax, 'string');

if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        ImSetUlay=[str2double(StrMin) str2double(StrMax)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Change anatomical window(Max) to ' StrMax])
%          [handles]=DispCase(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)
       
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
    else
        set(handles.Tx_Message,'string',['Check !!!  "Max" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end
function Ed_aWmin_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_aWMax_Callback(hObject, eventdata, handles)
global ImSetUlay
StrMin=get(handles.Ed_aWmin, 'string');
StrMax=get(handles.Ed_aWMax, 'string');

if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        ImSetUlay=[str2double(StrMin) str2double(StrMax)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Change anatomical window(Max) to ' StrMax])
        
        
               
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
        
%         [handles]=DispCase(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)

    else
        set(handles.Tx_Message,'string',['Check !!!  "Max" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end
function Ed_aWMax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%||=======================================================================|
%|| [Task Result Display Setting]
%||=======================================================================|
%||-------------------------------------------------------------Edit : MIN|
function Ed_tTH_Callback(hObject, eventdata, handles)
global ImSetOlay
StrMin=get(handles.Ed_tTH, 'string');
StrMax=get(handles.Ed_tWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlay(1)=str2double(StrMin);
        set(handles.Tx_Message,'string',['Change Threshold to ' StrMin])
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
    else
        set(handles.Tx_Message,'string',['Check !!!  "window(min)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMin '"   is not a number !'])
end
function Ed_tTH_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%||-------------------------------------------------------------Edit : MAX|
function Ed_tWMax_Callback(hObject, eventdata, handles)
global ImSetOlay
StrMin=get(handles.Ed_tTH, 'string');
StrMax=get(handles.Ed_tWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlay(2)=str2double(StrMax);

        set(handles.Tx_Message,'string',['Change Window(Max) to ' StrMax])
       
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)

    else
        set(handles.Tx_Message,'string',['Check !!!  "Window(Max)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end
function Ed_tWMax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%||-------------------------------------------------------Slider : OPacity|
function Sd_tOpt_Callback(hObject, eventdata, handles)
global ImSetOlay 
ImSetOlay(3)=round(10*get(handles.Sd_tOpt, 'Value'))/10;
set(handles.Sd_tOpt, 'Value',ImSetOlay(3))
set(handles.Ed_tOpt, 'string',num2str(ImSetOlay(3)))
set(handles.Tx_Message,'string',['Set up Opacity to ' num2str(ImSetOlay(3))])
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
% [handles]=DispCase(hObject, eventdata, handles);pause(0.01);
% DispIm(hObject, eventdata, handles)
       
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Sd_tOpt_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
%||---------------------------------------------------------Edit : OPacity|
function Ed_tOpt_Callback(hObject, eventdata, handles)
global ImSetOlay

if isnan(str2double(get(handles.Ed_tOpt, 'string')))
    set(handles.Ed_tOpt, 'string','0.8')
else
    ImSetOlay(3)=round(10*str2double(get(handles.Ed_tOpt, 'string')))/10;
    set(handles.Sd_tOpt,'Value',ImSetOlay(3));
end

set(handles.Tx_Message,'string',['Set up Opacity to ' num2str(ImSetOlay(3))])
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');pause(0.1)
% DispIm(hObject, eventdata, handles)

h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Ed_tOpt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%||-------------------------------------------------------PMenu : Colormap|
function PMenu_tCMap_Callback(hObject, eventdata, handles)
switch get(handles.PMenu_tCMap,'Value')
    case 1
        handles.CMap='autumn';
        handles.CMapRS='autumn';
        set(handles.PMenu_rsCMap,'Value',1)

    case 2
        handles.CMap='jet';
        handles.CMapRS='jet';
        set(handles.PMenu_rsCMap,'Value',2)

    case 3
        handles.CMap='bluehot';
        handles.CMapRS='bluehot';
        set(handles.PMenu_rsCMap,'Value',3)

end
guidata(hObject, handles);
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
% [handles]=DispCase(hObject, eventdata, handles);pause(0.01)
% DispIm(hObject, eventdata, handles)

h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function PMenu_tCMap_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%||=======================================================================|
%|| [Resting Result Display Setting]
%||=======================================================================|
function Ed_rsTH_Callback(hObject, eventdata, handles)
global ImSetOlayRS
StrMin=get(handles.Ed_rsTH, 'string');
StrMax=get(handles.Ed_rsWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlayRS(1)=str2double(StrMin);
        set(handles.Tx_Message,'string',['Change Threshold to ' StrMin])
%         BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
%         [handles]=DispCase(hObject, eventdata, handles);pause(0.01)
%         DispIm(hObject, eventdata, handles)
       
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)

    else
        set(handles.Tx_Message,'string',['Check !!!  "window(min)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMin '"   is not a number !'])
end
function Ed_rsTH_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_rsWMax_Callback(hObject, eventdata, handles)
global ImSetOlayRS
StrMin=get(handles.Ed_rsTH, 'string');
StrMax=get(handles.Ed_rsWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlayRS(2)=str2double(StrMax);
        set(handles.Tx_Message,'string',['Change Window(Max) to ' StrMax])
%         BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
%         [handles]=DispCase(hObject, eventdata, handles);pause(0.01)
%         DispIm(hObject, eventdata, handles)
       
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)

    else
        set(handles.Tx_Message,'string',['Check !!!  "window(min)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end
function Ed_rsWMax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Sd_rsOpt_Callback(hObject, eventdata, handles)
global ImSetOlayRS
ImSetOlayRS(3)=round(10*get(handles.Sd_rsOpt, 'Value'))/10;
set(handles.Sd_rsOpt, 'Value',ImSetOlayRS(3))
set(handles.Ed_rsOpt, 'string',num2str(ImSetOlayRS(3)))
set(handles.Tx_Message,'string',['Set up Opacity to ' num2str(ImSetOlayRS(3))])
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');pause(0.01)
% [handles]=DispCase(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)
       
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Sd_rsOpt_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function Ed_rsOpt_Callback(hObject, eventdata, handles)
global ImSetOlayRS

if isnan(str2double(get(handles.Ed_rsOpt, 'string')))
    set(handles.Ed_rsOpt, 'string','0.8')
else
    ImSetOlayRS(3)=round(10*str2double(get(handles.Ed_rsOpt, 'string')))/10;
    set(handles.Sd_rsOpt,'Value',ImSetOlayRS(3));
end

set(handles.Tx_Message,'string',['Set up Opacity to ' num2str(ImSetOlayRS(3))])
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
% [handles]=DispCase(hObject, eventdata, handles);pause(0.01)
% DispIm(hObject, eventdata, handles)

       
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Ed_rsOpt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function PMenu_rsCMap_Callback(hObject, eventdata, handles)
% switch get(handles.PMenu_rsCMap,'Value')
%     case 1
%         handles.CMapRS='autumn';
%     case 2
%         handles.CMapRS='jet';
%     case 3
%         handles.CMapRS='bluehot';
% end
% guidata(hObject, handles);
% DispIm(hObject, eventdata, handles)

switch get(handles.PMenu_rsCMap,'Value')
    case 1
        handles.CMap='autumn';
        handles.CMapRS='autumn';
         set(handles.PMenu_tCMap,'Value',1)
    case 2
        handles.CMap='jet';
        handles.CMapRS='jet';
        set(handles.PMenu_tCMap,'Value',2)
    case 3
        handles.CMap='bluehot';
        handles.CMapRS='bluehot';
        set(handles.PMenu_tCMap,'Value',3)
end
guidata(hObject, handles);
% BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
% [handles]=DispCase(hObject, eventdata, handles);pause(0.01)
% DispIm(hObject, eventdata, handles)
       
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)


function PMenu_rsCMap_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Btn_Preprocess_Callback(hObject, eventdata, handles)
global gbl_p_Prep glb_Dir_RS

[DirF,FN,ext] = fileparts(handles.pRSData);FN=[FN ext];
FN=strrep(FN,'.nii.gz','');FN=strrep(FN,'.nii','');FN=strrep(FN,'.img','');

Idx=findstr(FN,'_');ID=FN(1:Idx(1)-1);Cnd=FN(Idx(1)+1:end);
handles.Condition=Cnd;


Dir_Log=[DirF filesep '0_LOG_files'];
if ~(exist(Dir_Log, 'dir')==7)
    mkdir(Dir_Log);
end

p_Status=[Dir_Log filesep '=M3=(LOG)=sGuideFCPrep=' FN '===D' datestr(now,'yymmdd_THHMMSS')  '_Summary.txt'];
p_Diary=[Dir_Log filesep '=M3=(LOG)=sGuideFCPrep=' FN '===D' datestr(now,'yymmdd_THHMMSS')  '_Detail.txt'];

PrepIDX=[ 'T' num2str(get(handles.Ck_SliceT,'Value')) ';'...
    'M' num2str(get(handles.Ck_MCRT,'Value')) ';'...
    'F' num2str(get(handles.Ck_FMCRT,'Value')) ';'...
    'D' num2str(get(handles.Ck_DDdnt,'Value')) ';'...
    'N' num2str(get(handles.Ck_NReg,'Value')) ';'...
    'B' num2str(get(handles.Ck_Bandpass,'Value')) ';'...
    'S' num2str(get(handles.Ck_Blur,'Value')) ];

PNT_PREP='_';
if (get(handles.Ck_SliceT,'Value')==1); PNT_PREP=[PNT_PREP 'T'];end
if (get(handles.Ck_MCRT,'Value')==1); PNT_PREP=[PNT_PREP 'M'];end
if (get(handles.Ck_MCRT,'Value')==0); PNT_PREP=[PNT_PREP 'A'];end
if (get(handles.Ck_FMCRT,'Value')==1); PNT_PREP=[PNT_PREP 'F'];end
if (get(handles.Ck_DDdnt,'Value')==1); PNT_PREP=[PNT_PREP 'D1'];end
if (get(handles.Ck_DDdnt,'Value')==0); PNT_PREP=[PNT_PREP 'DK'];end


Dir_RStmp=[DirF filesep Cnd filesep 'Fd_Temp'];
if ~(exist(Dir_RStmp, 'dir')==7);mkdir(Dir_RStmp); end

if (get(handles.Ck_NReg,'Value')==1);
%     if (get(handles.Ck_NR_Global,'Value')==1)
%         PNT_PREP=[PNT_PREP 'N9'];
%     else
%         PNT_PREP=[PNT_PREP 'N8'];
%     end

    if (get(handles.Ck_MCRT,'Value')==1) && (get(handles.Ck_NR_Global,'Value')==1)
        PNT_PREP=[PNT_PREP 'N9'];
    elseif (get(handles.Ck_MCRT,'Value')==1) && (get(handles.Ck_NR_Global,'Value')==0)
        PNT_PREP=[PNT_PREP 'N8'];
    elseif (get(handles.Ck_MCRT,'Value')==0) && (get(handles.Ck_NR_Global,'Value')==1)
        PNT_PREP=[PNT_PREP 'N3'];
    elseif (get(handles.Ck_MCRT,'Value')==0) && (get(handles.Ck_NR_Global,'Value')==0)
        PNT_PREP=[PNT_PREP 'N2'];
    end
    
    p_Preptest=[Dir_RStmp filesep FN PNT_PREP '.nii.gz'];
    if ~(exist(p_Preptest)==2)
        f = dir(  fullfile(Dir_RStmp,[FN PNT_PREP(1:end-1) '*.nii.gz']));
        if ~isempty(f)
            UD_PNT_PREP=f(1).name;
            UD_PNT_PREP=strrep(UD_PNT_PREP,FN,'');
            UD_PNT_PREP=strrep(UD_PNT_PREP,'.nii.gz','');
            PNT_PREP=UD_PNT_PREP;
        end
    end
end


%if (get(handles.Ck_Bandpass,'Value')==1); PNT_PREP=[PNT_PREP 'B0108'];end


fB1=sprintf('%.2f',handles.Bandpass_Range(1));idxB1=findstr(fB1,'.'); if ~isempty(idxB1); fB1=fB1(idxB1+1:end);end
fB2=sprintf('%.2f',handles.Bandpass_Range(2));idxB2=findstr(fB2,'.'); if ~isempty(idxB2); fB2=fB2(idxB2+1:end);end
if (get(handles.Ck_Bandpass,'Value')==1); PNT_PREP=[PNT_PREP 'B' fB1 fB2];end

      
if (get(handles.Ck_Blur,'Value')==1); PNT_PREP=[PNT_PREP 'S' num2str(handles.FWHM) 'mm'];end
% f_Prep=[FN PNT_PREP '.nii'];
f_Prep=[FN PNT_PREP '.nii.gz'];



Dir_RS=[DirF filesep Cnd];
if ~(exist(Dir_RS, 'dir')==7);mkdir(Dir_RS); end
glb_Dir_RS=Dir_RS;

p_Prep=[Dir_RStmp filesep f_Prep];
handles.p_Prep=p_Prep;guidata(hObject, handles);
gbl_p_Prep=p_Prep;


% Calculate Timing
EstT=0;
if (get(handles.Ck_SliceT,'Value')==1);EstT=EstT+72;end
if (get(handles.Ck_MCRT,'Value')==1);EstT=EstT+85;end
if (get(handles.Ck_MCRT,'Value')==0);EstT=EstT+85;end
if (get(handles.Ck_DDdnt,'Value')==1);EstT=EstT+110 ;end
if (get(handles.Ck_DDdnt,'Value')==0);EstT=EstT+15;end
if (get(handles.Ck_NReg,'Value')==1);EstT=EstT+65;end
if (get(handles.Ck_Bandpass,'Value')==1); EstT=EstT+65;end
if (get(handles.Ck_Blur,'Value')==1); EstT=EstT+40;end
 

if (exist(handles.pRSData,'file')==2) && (exist(handles.pT1,'file')==2)
     
%     %               <0>                      <1>     <2>     <3>     <4>     <5>
%     formatBasic ='cd %s \n bash %sFn_MDAS2_rsPrep.sh -r "%s" -T "%s" -a "%s" -z "%s" -P "%s" -s "%s" -v "%s"';
%     cmdStrBasic = sprintf(formatBasic,[handles.DirFn],[handles.DirFn filesep],handles.pRSData,num2str(handles.TR),handles.pT1,handles.tPattern,PrepIDX,num2str(handles.FWHM),num2str(handles.RegRSmm));
%     %                                     <0>          ,   <1> RSData  ,       <2> TR      ,  <3>  pT1 ,  <4> tPattern  ,<5>PREP
    %                                           <1>     <2>     <3>     <4>    <5>      <6>     <7>     <8>
    formatBasic ='bash %sFn_MDAS2_rsPrep.sh -r "%s" -T "%s" -a "%s" -z "%s" -P "%s" -s "%s" -v "%s" -F "%s"';
    cmdStrBasic = sprintf(formatBasic,[handles.DirFn filesep],handles.pRSData,num2str(handles.TR),handles.pT1,handles.tPattern,PrepIDX,num2str(handles.FWHM),num2str(handles.RegRSmm),[handles.DirFn]);
    %                                ,     <0>   Bash Fn     ,   <1> RSData  ,       <2> TR      ,  <3>  pT1 ,  <4> tPattern  ,<5>PREP,      <6>FWHM        ,     <7> voxel size     ,<8>Script DIR

if (exist(handles.pT1_Lesion,'file')==2)
        cmdStrL=sprintf('%s -l "%s"',cmdStrBasic,handles.pT1_Lesion);
    else
        cmdStrL=cmdStrBasic;
    end
    
    if (get(handles.RBtn_IBR,'Value')==1)
        cmdStrReg=sprintf('%s -c "n"',cmdStrL);
    elseif (get(handles.RBtn_CBR,'Value')==1)
        cmdStrReg=sprintf('%s -c "y"',cmdStrL);
    elseif (get(handles.RBtn_BBR,'Value')==1)
        cmdStrReg=sprintf('%s -j "%s" -c "n"',cmdStrL,handles.pHRepi);
    end
    
    if (get(handles.Ck_NR_Global,'Value')==1)
        cmdStrNGlb=sprintf('%s -g "y"',cmdStrReg);
    else
        cmdStrNGlb=sprintf('%s -g "n"',cmdStrReg);
    end
    
    if (get(handles.Ck_ReHo,'Value')==1)
        cmdStrReHo=sprintf('%s -h "y"',cmdStrNGlb);
    else
        cmdStrReHo=sprintf('%s -h "n"',cmdStrNGlb);
    end
    
    %cmdStr=sprintf('%s | tee "%s"',cmdStrReHo,p_Status);
    
    if (get(handles.Ck_Bandpass,'Value')==1)
        cmdStrBP=sprintf('%s -B "%s"',cmdStrReHo,[sprintf('%.2f',handles.Bandpass_Range(1)) '-' sprintf('%.2f',handles.Bandpass_Range(2))]);
    else
        cmdStrBP=cmdStrReHo;
    end
    
    cmdStr=sprintf('%s | tee "%s"',cmdStrBP,p_Status);
else
    cmdStr=sprintf('cd %s \n bash %sFn_MDAS2_rsPrep.sh',[handles.DirFn],[handles.DirFn filesep]);
end


cd(Dir_Log); if (exist('diary','file')==2); delete ('diary'); end
diary REST_STATUS.txt
h = waitbar(0,['Start preprocessing...']);

set(handles.Tx_Message,'string', ['>> Starting preprocessing ! Creating folders and checking files' ],'foregroundcolor',[0 0 1])

BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
set(handles.Btn_Preprocess,'Enable','off');set(handles.Btn_Preprocess,'String','BUSY !!!')
pause(0.5)

% -------------------------------------------------------<Anat Coreg to T1>
if (exist(handles.pAnat,'file')==2) && (exist(handles.pT1,'file')==2)
    if ~(exist(handles.pAnat2T1, 'file')==2)
        waitbar(0.01,h,['[1/4] Aligning Anat to T1 usually takes 2 mins.']);
        set(handles.Tx_Message,'string', ['>> Aligning Anat to T1 usually takes 2 mins. Once completed, the next step will automatically initiate' ],'foregroundcolor',[0 0 1])
        %                  <0>              <1>     <2>     <3>
        formatCoReg ='bash %sFn_CoReg.sh -a "%s" -f "%s" -S "%s"';
        cmdStrCoReg = sprintf(formatCoReg,[handles.DirFn filesep],handles.pT1,handles.pAnat,handles.DirFn);
        %                                     <0>      ,  <1>  pT1 , <2> pFLAIR  ,<3> SDIR
        disp('|| ');disp('|| EXECUTE Bash CoReg');disp(['>>    ' cmdStrCoReg]);disp('|| ');
        pause(0.1)
        tstart = tic; system(cmdStrCoReg);telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for Coreg: ' num2str(telapsed) ' sec(s), or ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)']); disp('|| ');
    else
        set(handles.Tx_Message,'string', ['>> Coreg btw Anat and T1 already exist !!' ],'foregroundcolor',[0 0 1])
        waitbar(0.07,h,['[1/4] Anat has aligned to T1 already.']);
    end
end
% -----------------------------------------------------------<Segmentation>
waitbar(0.07,h,['[2/4] Checking Segmentation files']);
p_spm=which('spm.m');
if  (exist(p_spm, 'file')==2) && (handles.Terminal==1)
    set(handles.Tx_Message,'string', ['>> Checking Segmentation files' ],'foregroundcolor',[0 0 1])
    
    BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
    set(handles.Btn_Preprocess,'Enable','off');set(handles.Btn_Preprocess,'String','BUSY !!!')
    pause(0.5)

    Dir_Seg=[DirF filesep '2_T1Segment'];
    if ~(exist(Dir_Seg, 'dir')==7);mkdir(Dir_Seg); end
    cd(Dir_Seg);
    disp('|| ');disp('|| Conducting segmentation via SPM');disp('|| ');
   
    % NiiGz_T1 = load_untouch_nii(handles.pT1);
    fT1=handles.fT1;fT1=strrep(fT1,'.nii.gz','');fT1=strrep(fT1,'.nii','');fT1=strrep(fT1,'.img','');
    pT1Nii=[Dir_Seg filesep fT1 '.nii'];
    pT1Seg1=[Dir_Seg filesep 'c1' fT1 '.nii'];
     if ~(exist(pT1Nii, 'file')==2)
         copyfile(handles.pT1,pT1Nii);
%         Output=NiiGz_T1;
%         Output.img(:,:,:)=0;Output.img(:,:,:)=double(NiiGz_T1.img(:,:,:));
%         save_untouch_nii(Output, pT1Nii);
     end
    if ~(exist(pT1Seg1, 'file')==2)
        waitbar(0.07,h,['[2/4] Segmentation usually takes 5 mins.']);
        set(handles.Tx_Message,'string', ['>> Segmentation usually takes 5 mins. Once completed, the next step will automatically initiate' ],'foregroundcolor',[0 0 1])
        tstart = tic;
        addpath([handles.DirFn]);cd(Dir_Seg);Fn_batch_SPM12_Segment([fT1 '.nii']);
        telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for segmentation: ' num2str(telapsed) ' sec(s), or ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)']);disp('|| ');
    else
        waitbar(0.25,h,['[2/4] Segmentated files already exist !!']);
        set(handles.Tx_Message,'string', ['>> Segmentated files already exist  !!' ],'foregroundcolor',[0 0 1])
        disp('|| ');disp('|| Segmentated files already exist !!');disp('|| ');
    end
% ----------------------------------------<Meta Mask Inverse Normalization>
    pMNI_Inv=[Dir_Seg filesep 'Inv_MNI152_T1_2mm_brain.nii'];
    if ~(exist(pMNI_Inv, 'file')==2)
        waitbar(0.25,h,['[3/4] Inverse-normalization usually takes 1 mins']);
        set(handles.Tx_Message,'string', ['>> Inverse-normalization usually takes 1 mins. Once completed, the next step will automatically initiate' ],'foregroundcolor',[0 0 1])
        tstart = tic;
        addpath([handles.DirFn]);cd(Dir_Seg);Fn_batch_SPM12_InvNor([fT1 '.nii']);
        telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for Inverse-normalization: ' num2str(telapsed) ' sec(s), or ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)']);disp('|| ');
    else
        waitbar(0.27,h,['[3/4] Inverse-normalized files already exist  !!']);
        set(handles.Tx_Message,'string', ['>> Inverse-normalized files already exist  !!' ],'foregroundcolor',[0 0 1])
        disp('|| ');disp('|| Inverse-normalized files already exist !!');disp('|| ');
    end
end

% ----------------------------------------------------------<Preprocessing>
if (exist(p_Prep)==2)
%     if numel(f_Prep)>42
%         set(handles.Tx_Message,'String',['Preprocessed rs-dataset exist: ' f_Prep(end-42-1:end) ', Choose the seed on left canvas'],'ForegroundColor',[0 0 1]);
%     else
%         set(handles.Tx_Message,'String',['Preprocessed rs-dataset exist: ' f_Prep ', Choose the seed on left canvas'],'ForegroundColor',[0 0 1]);
%     end
%    set(handles.Tx_Message,'String',['Preprocessed rs-dataset exist. "Set a seed by left-clicking the mouse on canvas"'],'ForegroundColor',[0 0 1]);
             set(handles.Tx_Message,'String',['Preprocessed rs-dataset(' f_Prep ') exist. "Set a seed by left-clicking the mouse on canvas"'],'ForegroundColor',[0 0 1]);
             set(handles.Tx_PrepData,'String',f_Prep,'ForegroundColor',[0 0 1]);
    BtnSetting(hObject, eventdata, handles);
else
    if  (exist(p_spm, 'file')==2) && (handles.Terminal==1)
%        set(handles.Tx_Message,'string', ['>> The rs-dataset preprocessing takes about 15 mins. Further details are displayed in the command window.' ],'foregroundcolor',[0 0 1])
        set(handles.Tx_Message,'string', ['>> The rs-dataset preprocessing takes about ' num2str(floor(EstT/60)+1)  ' mins. Further details are displayed in the command window.' ],'foregroundcolor',[0 0 1])

        set(handles.Tx_PrepData,'String',['Processing....'],'ForegroundColor',[1 0 0]);
        
        
       handles.pRSMap='';
       guidata(hObject, handles);
       set(handles.Tx_rsMap,'String',['']);
       BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');pause(0.01)
       [handles]=DispCase(hObject, eventdata, handles);
       DispIm(hObject, eventdata, handles);BtnSetting(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','on');
        
        disp('|| ');disp('|| EXECUTE Bash file');disp(['>>    ' cmdStr]);disp('|| '); 
        pause(0.1)
        % waitbar(0.27,h,['[4/4] The rs-dataset preprocessing takes about 17 mins.']);
        waitbar(0.27,h,['[4/4] The rs-dataset preprocessing takes about ' num2str(floor(EstT/60)+1) ' min(s)']);
        tstart = tic; system(cmdStr);telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for rs-dataset preprocessing: ' num2str(telapsed) ' sec(s), or ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)']); disp('|| ');
        diary off
        
        cd(Dir_Log);
        if (exist('REST_STATUS.txt')==2)
            movefile('REST_STATUS.txt', p_Diary);
        end
        pause(0.01)
        set(handles.Tx_Message,'string', ['>> Done ! ' ' Computation time for rs-dataset preprocessing: ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)' ],'foregroundcolor',[0 0 1])
        set(handles.Btn_Preprocess,'String','Execute');set(handles.Btn_Preprocess,'Enable','on')
        
        if (exist(p_Prep)==2)
%             if numel(f_Prep)>42
%                 set(handles.Tx_Message,'String',['Preprocessed rs-dataset already exist:' f_Prep(end-42-1:end) ',Choose the seed on left canvas'],'ForegroundColor',[1 0 0]);
%             else
%                 set(handles.Tx_Message,'String',['Preprocessed rs-dataset already exist: ' f_Prep ',Choose the seed on left canvas'],'ForegroundColor',[1 0 0]);
%             end
             
             % set(handles.Tx_Message,'String',['Preprocessed rs-dataset exist. "Set a seed by left-clicking the mouse on canvas"'],'ForegroundColor',[0 0 1]);
             set(handles.Tx_Message,'String',['Preprocessed rs-dataset(' f_Prep ') exist. "Set a seed by left-clicking the mouse on canvas"'],'ForegroundColor',[0 0 1]);
             set(handles.Tx_PrepData,'String',f_Prep,'ForegroundColor',[0 0 1]);

        else
             set(handles.Tx_Message,'String',['UNABLE to preprocess rs-dataset, please check LOG file'],'ForegroundColor',[1 0 0]);
        end
        waitbar(1,h,['[4/4] The rs-dataset preprocessing is completed.']);
        BtnSetting(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','on');
        cd(handles.DirW)  
    else
        set(handles.Tx_Message,'String',['SPM is not detectd in PATH, Please add it !!! '],'ForegroundColor',[1 0 0]);
    end
end
set(handles.Btn_Preprocess,'String','Preprocess');
close(h)

function MakeSeed(hObject, eventdata, handles)
global SeedXYZV gbl_p_Prep IDX_flipUD gbl_p_Seed gbl_SeedInfo
if (get(handles.RBtn_SeedXYZ,'Value')==1)
    if ~isempty(SeedXYZV) && (exist(handles.pT1,'file')==2) && isfield(handles,'StuT1') && (exist(gbl_p_Prep,'file')==2)
        [DirF,FN,ext] = fileparts(handles.pRSData);FN=[FN ext];
        FN=strrep(FN,'.nii.gz','');FN=strrep(FN,'.nii','');FN=strrep(FN,'.img','');
        [DirPrep,f_Prep,ext] = fileparts(gbl_p_Prep);f_Prep=[f_Prep ext];
        Idx=findstr(f_Prep,'.nii.gz'); if ~isempty(Idx); f_Prep=f_Prep(1:Idx-1); end
        
        PNT_Prep=f_Prep;PNT_Prep=strrep(PNT_Prep,FN,'');

        StuT1=handles.StuT1;
        R=handles.SeedR;
        c_Mtx=SeedXYZV(1:3);
        
        dx=abs(StuT1.mat(1,1));dy=abs(StuT1.mat(2,2));dz=abs(StuT1.mat(3,3));
        nx=handles.DimT1(1);ny=handles.DimT1(2);nz=handles.DimT1(3);
        
        gx=0:dx:(nx-1)*dx;
        gy=0:dy:(ny-1)*dy;
        gz=0:dz:(nz-1)*dz;
        
        [xx,yy,zz]=meshgrid(gx,gy,gz);
        MtxSeed=zeros(size(xx));
        MtxSeed(c_Mtx(1),c_Mtx(2),c_Mtx(3))=1;
        MtxSeed=fliplr(permute(MtxSeed, [2 1 3])); % Transform back to Nii Read-in
        [J,I,K] = ind2sub(size(xx),find(MtxSeed==1));
        
        PNT_IJK=[sprintf('%3.3d',I) '_' sprintf('%3.3d',J) '_' sprintf('%3.3d',K) '_V' sprintf('%3.2f',SeedXYZV(4))];
        PNT_XYZ=[sprintf('%3.3d',c_Mtx(1)) '_' sprintf('%3.3d',c_Mtx(2)) '_' sprintf('%3.3d',c_Mtx(3)) '_V' sprintf('%3.2f',SeedXYZV(4))];
        PNT_Rmm=['_R' num2str(R) 'mm'];
        Center=[gx(c_Mtx(1)) gy(c_Mtx(2)) gz(c_Mtx(3))];
        
        fOut=handles.fT1;
        Idx=findstr(fOut,'.nii.gz'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
        Idx=findstr(fOut,'.img'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
        Idx=findstr(fOut,'.nii'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
        %pSeed= [handles.DirRS filesep fOut '_XYZ_' PNT_XYZ '.nii.gz'];
        pSeed= [DirPrep filesep 'Seed_XYZ_' PNT_XYZ PNT_Rmm  '%' fOut '.nii'];
        if (exist(pSeed,'file')==2)
            set(handles.Tx_Message,'String',['Data Exist :' fOut '_XYZ_' PNT_XYZ '.nii.gz'],'ForegroundColor',[0 0 0]);
        else
            % Cartesian coordinates (x-x0)^2 + (y-y0)^2 + (z-z0)^2 = r^2
            % A1=(xx-Center(1)).^2;A2=(yy-Center(2)).^2; A3=(zz-Center(3)).^2; A4=A1+A2+A3; A5=double(A4<=R^2);A6=fliplr(permute(A5, [2 1 3]));
            R_Square=(xx-Center(1)).^2 + (yy-Center(2)).^2 + (zz-Center(3)).^2;
            VOI=double(R_Square<=R^2);
            
            if (IDX_flipUD==1)
                VOI=fliplr(permute(VOI, [2 1 3]));
            else
                VOI=(permute(VOI, [2 1 3]));
            end
            
            % Save to Nii
            %         Output=StuT1;
            %         Output.img(:,:,:)=0;
            %         Output.img(:,:,:)=VOI(:,:,:);
            %         save_untouch_nii(Output,pSeed);
            spmV=spm_vol(handles.pT1);
            ima=spm_read_vols(spmV);
            ima=VOI(:,:,:);
            spmV.fname=pSeed;
            spm_write_vol(spmV,ima);
            StuImU=nifti(spmV.fname);
            set(handles.Tx_Message,'String',['Please wait ! Generating seed :' fOut '_XYZ_' PNT_XYZ PNT_Rmm '.nii.gz'],'ForegroundColor',[1 0 0]);
        end
        gbl_p_Seed=pSeed;
        gbl_SeedInfo=['XYZ_' PNT_XYZ PNT_Rmm];
    end
end


function Btn_GMaping_Callback(hObject, eventdata, handles)
global SeedXYZV IDX_NewSeed gbl_p_Prep glb_Dir_RS IDX_flipUD gbl_p_Seed gbl_SeedInfo
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[DirF,FN,ext] = fileparts(handles.pRSData);FN=[FN ext];
FN=strrep(FN,'.nii.gz','');FN=strrep(FN,'.nii','');FN=strrep(FN,'.img','');
h = waitbar(0.01,['Start Mapping...']);

handles.pRSMap='';
guidata(hObject, handles);
set(handles.Tx_rsMap,'String',['']);
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles);BtnSetting(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','on');
pause(0.01)
% gbl_p_Seed
if  (exist(handles.pT1,'file')==2) && isfield(handles,'StuT1') && (exist(gbl_p_Prep,'file')==2)
    waitbar(0.05,h,['[1/3] Generating a Seed']);
    set(handles.Tx_Message,'String',['>> Calcuating functional mapping... '],'ForegroundColor',[1 0 0]); pause(0.1);
    [DirPrep,f_Prep,ext] = fileparts(gbl_p_Prep);f_Prep=[f_Prep ext];
    Idx=findstr(f_Prep,'.nii.gz'); if ~isempty(Idx); f_Prep=f_Prep(1:Idx-1); end
    
    PNT_Prep=f_Prep;PNT_Prep=strrep(PNT_Prep,FN,'');
     
    fOut=handles.fT1;
    Idx=findstr(fOut,'.nii.gz'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
    Idx=findstr(fOut,'.img'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
    Idx=findstr(fOut,'.nii'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end

    if (get(handles.RBtn_SeedXYZ,'Value')==1) && ~isempty(SeedXYZV)
        MakeSeed(hObject, eventdata, handles)
        
        if (exist(gbl_p_Seed,'file')==2)
            Stu_Seed=nifti(gbl_p_Seed);
            handles.MtxSeed=logical(Stu_Seed.dat(:,:,:));
            [DirSeed,f_Seed,ext] = fileparts(gbl_p_Seed);f_Seed=[f_Seed ext];
            set(handles.Tx_SeedMask,'String',f_Seed,'ForegroundColor',0.5*[1 1 1]);
            guidata(hObject, handles);
        end
    end
end


if  (exist(gbl_p_Seed,'file')==2) && (exist(handles.pT1,'file')==2) && isfield(handles,'StuT1') && (exist(gbl_p_Prep,'file')==2)
    Dir_Log=[DirF filesep '0_LOG_files'];
    if ~(exist(Dir_Log, 'dir')==7)
        mkdir(Dir_Log);
    end

    pRSMap=[glb_Dir_RS filesep 'STAT_'  gbl_SeedInfo '_' PNT_Prep '.nii'];
    pRSMap_Z=[glb_Dir_RS filesep 'STAT_'  gbl_SeedInfo '_' PNT_Prep '_CRZ%T1.nii'];  
    
    if (exist(pRSMap)==2) ;delete(pRSMap); end
    if (exist(pRSMap_Z)==2) ;delete(pRSMap_Z); end
    pMsk=[DirF filesep '1_RegMtx' filesep fOut '_Msk_Brain_ds.nii.gz'];
    
    waitbar(0.5,h,['[2/3] Calculating may take 60 sec(s) ']);
    % --------------------------------------------------<Execute Bash Code>
    if ~(exist(pRSMap,'file')==2) && (exist(pMsk,'file')==2) && (handles.Terminal==1)
        set(handles.Tx_Message,'String',['Please wait ! Calculating functional map via the given seed may take 60 sec(s) '],'ForegroundColor',[1 0 0]);

        p_Diary=[Dir_Log filesep '=M3=(LOG)=sGuideFC=' FN '_FCMapping_Seedat_' gbl_SeedInfo '===' '.txt'];
        
        %         ${DirS}/Fn_SeedCorrMap.sh -i $pIn -a $pT1 -s $pSeed -m ${p_T1Msk_ds} -o ${pGLM} -Z 'y';

        %  GLM:         <0>                     <1>    <2>      <3>    <4>     <5>
%         formatSpec ='sh %sFn_SeedCorrMap.sh -i "%s" -a "%s" -s "%s" -m "%s" -o "%s" -Z "y" ';

        %  Pearson        <0>                     <1>    <2>      <3>     <4>     <5>            <6>
        formatSpec ='bash %sFn_SeedCorrMap.sh -i "%s" -a "%s" -s "%s" -m "%s" -o "%s" -Z "y" -M "%s"';
        %                    <0>            ,<1> prep       ,   <2>T1   ,Seed ,Mask,Output,    <6>Method                                    
        cmdStr = sprintf(formatSpec,[handles.DirFn filesep],gbl_p_Prep,handles.pT1,gbl_p_Seed,pMsk,pRSMap,handles.RSMethod);
                
        set(handles.Btn_GMaping,'Enable','off');set(handles.Btn_GMaping,'String','BUSY !!!');pause(0.5)
        diary on
        diary Mapping_STATUS.txt
        disp('|| ');disp('|| ');disp('|| EXECUTE');disp(['>>    ' cmdStr]);disp('|| ');disp('|| '); 
        tic;system(cmdStr);toc
        diary off
        movefile('Mapping_STATUS.txt', p_Diary);pause(0.1)
        set(handles.Btn_GMaping,'String','FC Mapping');set(handles.Btn_GMaping,'Enable','on')
    end
    
waitbar(0.8,h,['[3/3] Loading the functional maping on the panel ']);    
    % -----------------------<Link the result from Bash Code to visuallize>
    if (exist(pRSMap_Z,'file')==2)
    %if (exist(pRSMap,'file')==2) && (exist(pRSMap_Z,'file')==2)
        IDX_NewSeed=1;
        [DirIn,name,ext] = fileparts(pRSMap_Z);fRSMap=[name ext];
%         StuRSMap=load_untouch_nii(pRSMap_Z);
%         handles.DimRSMap=size(StuRSMap.img);
        StuRSMap=nifti(pRSMap_Z);
        handles.DimRSMap=size(StuRSMap.dat);
        if (numel( handles.DimRSMap)>3)
            handles.pRSMap='';
            set(handles.Tx_rsMap,'String',['[#Vol=' num2str(handles.DimRSMap(4)) '] ' 'RS Map Image should not be a 4D Dataset, please check!']);
        else
            handles.pRSMap=pRSMap_Z;
            Dim= [sprintf('%3.3d',handles.DimRSMap(1)) 'x' sprintf('%3.3d',handles.DimRSMap(2)) 'x' sprintf('%3.3d',handles.DimRSMap(3))];
            if numel(fRSMap)>80
                %set(handles.Tx_rsMap,'String',['Maps :: [' Dim ']  ... ' fRSMap(end-59-1:end)]);
                set(handles.Tx_rsMap,'String',[fRSMap(end-79-1:end)]);
            else
                %set(handles.Tx_rsMap,'String',['Maps :: [' Dim ']  ... ' fRSMap]);
                set(handles.Tx_rsMap,'String',[fRSMap]);
            end
            handles.MtxRSMap=double(StuRSMap.dat);
            global ImSetOlayRS
            ImSetOlayRS(1)=round(mean(handles.MtxRSMap(:))*100)/100;
            if (ImSetOlayRS(1)<0.7); ImSetOlayRS(1)=0.7; end
            ImSetOlayRS(2)=round((max(handles.MtxRSMap(:))-std(handles.MtxRSMap(:)))*100)/100;
            
            % <Analysis Filename strucure>
            if ~isempty(findstr(fRSMap,'STAT_XYZ_'))
                idx_us=findstr(fRSMap,'_');
                if numel(idx_us)>5
                    XX=str2num(fRSMap(idx_us(2)+1:idx_us(3)-1));
                    YY=str2num(fRSMap(idx_us(3)+1:idx_us(4)-1));
                    ZZ=str2num(fRSMap(idx_us(4)+1:idx_us(5)-1));
                    VV=str2num(fRSMap(idx_us(5)+2:idx_us(6)-1));
                    if isnumeric(XX) && isnumeric(YY) && isnumeric(ZZ) && isnumeric(VV)
                        handles.rsSeed=[XX YY ZZ VV];
                    end
                end
            end
            
            
        end
    else
        if ~(exist(pRSMap,'file')==2); STATUS_RSMAP='(X)';else STATUS_RSMAP='(O)';  end
        if ~(exist(pRSMap_Z,'file')==2); STATUS_RSZMAP='(X)';else STATUS_RSZMAP='(O)';  end
        set(handles.Tx_rsMap,'String',['RS Maps ' STATUS_RSMAP ', RS(Z) Maps ' STATUS_RSZMAP]);
    end
    
    guidata(hObject, handles);
    BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');pause(0.01)
    [handles]=DispCase(hObject, eventdata, handles);
    DispIm(hObject, eventdata, handles);BtnSetting(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','on');
    IDX_NewSeed=0;

    set(handles.Tx_Message,'String',['>> '],'ForegroundColor',[0 0 0]); 
    waitbar(1,h,['Done']);
end
close(h)

% --- Executes on slider movement.
function Sd_SliceZ_Callback(hObject, eventdata, handles)
SliceZ=round( get(handles.Sd_SliceZ,'Value')); %disp(['SliceZ = ' num2str(SliceZ)])
set(handles.Ed_SliceZ,'string',num2str(SliceZ))

tstart = tic; 
DispIm(hObject, eventdata, handles)
telapsed = toc(tstart);
%disp(['||  lasts for: ' num2str(telapsed) ' sec, or ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec']);

% --- Executes during object creation, after setting all properties.
function Sd_SliceZ_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function Ed_SliceZ_Callback(hObject, eventdata, handles)
SliceZ=str2double( get(handles.Ed_SliceZ,'string'));
if ~isempty(SliceZ) SliceZ=round(SliceZ); end
set(handles.Ed_SliceZ,'string',num2str(SliceZ))
set(handles.Sd_SliceZ,'Value',SliceZ);
tstart = tic; 
DispIm(hObject, eventdata, handles)
telapsed = toc(tstart);
%disp(['||  lasts for: ' num2str(telapsed) ' sec, or ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec']);


function Ed_SliceZ_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Btn_rsMap_Callback(hObject, eventdata, handles)

[fRSMap,DirIn] = uigetfile({'*.nii'},'Select Rs-fMRI FC Map',handles.DirRS);pRSMap=[DirIn fRSMap];

F='MtxRSMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
F='DimRSMap' ; if isfield(handles, F); handles = rmfield(handles,F);end

if isequal(fRSMap,0) && isequal(DirIn,0) 
    set(handles.Tx_rsMap,'String','File is not selected!');
    handles.pRSMap='';
else
%     StuRSMap=load_untouch_nii(pRSMap);
%     handles.DimRSMap=size(StuRSMap.img);
    StuRSMap=nifti(pRSMap);
    handles.DimRSMap=size(StuRSMap.dat);

    if (numel(handles.DimRSMap)>3)
        handles.pRSMap='';
        set(handles.Tx_rsMap,'String',['[#Vol=' num2str(handles.DimRSMap(4)) '] ' 'RS Map Image should not be a 4D Dataset, please check!']);
    else
        handles.pRSMap=pRSMap;
        Dim= [sprintf('%3.3d',handles.DimRSMap(1)) 'x' sprintf('%3.3d',handles.DimRSMap(2)) 'x' sprintf('%3.3d',handles.DimRSMap(3))];
        if numel(fRSMap)>60
        set(handles.Tx_rsMap,'String',['[' Dim ']  ... ' fRSMap(end-59-1:end)]);
        else
          set(handles.Tx_rsMap,'String',['[' Dim ']  ... ' fRSMap]);
        end
        global ImSetOlayRS
        handles.MtxRSMap=double(StuRSMap.dat(:,:,:));
        ImSetOlayRS(1)=round(mean(handles.MtxRSMap(:))*100)/100;
        if (ImSetOlayRS(1)<0.5); ImSetOlayRS(1)=0.5;end
        ImSetOlayRS(2)=round((max(handles.MtxRSMap(:))-std(handles.MtxRSMap(:)))*100)/100;
        if (ImSetOlayRS(2)<0.5); ImSetOlayRS(1)=0.6;end
        % <Analysis Filename strucure>
        if ~isempty(findstr(fRSMap,'STAT_XYZ_'))
            idx_us=findstr(fRSMap,'_');
            if numel(idx_us)>5
            XX=str2num(fRSMap(idx_us(2)+1:idx_us(3)-1));
            YY=str2num(fRSMap(idx_us(3)+1:idx_us(4)-1));
            ZZ=str2num(fRSMap(idx_us(4)+1:idx_us(5)-1));
            VV=str2num(fRSMap(idx_us(5)+2:idx_us(6)-1));
            if isnumeric(XX) && isnumeric(YY) && isnumeric(ZZ) && isnumeric(VV)
                global SeedXYZV
                SeedXYZV=[XX YY ZZ VV];
                handles.rsSeed=[XX YY ZZ VV];
                set(handles.Ed_Cx,'string',sprintf('%3.3d',SeedXYZV(1)));
                set(handles.Ed_Cy,'string',sprintf('%3.3d',SeedXYZV(2)));
                set(handles.Ed_Cz,'string',sprintf('%3.3d',SeedXYZV(3)));
            end
            end
        end
     end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');pause(0.01)
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles);


function Ed_TR_Callback(hObject, eventdata, handles)
TR=str2double(get(handles.Ed_TR,'String'));
if ~isnan(TR)
    handles.TR=TR;
end
guidata(hObject, handles);


function Ed_TR_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Btn_rsMap_CreateFcn(hObject, eventdata, handles)

function RBtn_BBR_Callback(hObject, eventdata, handles)
function RBtn_CBR_Callback(hObject, eventdata, handles)
function RBtn_IBR_Callback(hObject, eventdata, handles)

function Ed_Rmm_Callback(hObject, eventdata, handles)

SeedR=str2double(get(handles.Ed_Rmm,'String'));
if ~isnan(SeedR)
    handles.SeedR=SeedR;
end

STR_SeedR=get(handles.Ed_Rmm, 'string');
if ~isnan(str2double(STR_SeedR))
        handles.SeedR=[str2double(STR_SeedR)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Set Seed Radius to ' STR_SeedR 'mm Sphere'])
else
    set(handles.Ed_Rmm,'string',num2str(handles.SeedR))
    set(handles.Tx_Message,'string',['Check !!!   "' STR_SeedR '"   is not a number !'])
end



guidata(hObject, handles);
function Ed_Rmm_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Ck_ReHo_Callback(hObject, eventdata, handles)

function BtnGrp_Reg_SelectionChangedFcn(hObject, eventdata, handles)
switch get(eventdata.NewValue,'Tag')
    case 'RBtn_CBR'
        handles.RegCoord='y';
    case 'RBtn_BBR'
        handles.RegCoord='n';
    case 'RBtn_IBR'
        handles.RegCoord='n';
end
guidata(hObject, handles);


% --- Executes on selection change in PMenu_Regmm.
function PMenu_Regmm_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_Regmm,'string');
selectedIndex = get(handles.PMenu_Regmm,'Value');
switch get(handles.PMenu_Regmm,'Value')
    case 1
        handles.RegRSmm=2;
    case 2
        handles.RegRSmm=3;
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function PMenu_Regmm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PMenu_Regmm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ed_FWHM_Callback(hObject, eventdata, handles)
FWHM=get(handles.Ed_FWHM, 'string');
if ~isnan(str2double(FWHM))
        handles.FWHM=[str2double(FWHM)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Set Smooth with ' FWHM 'mm FWHM'])
else
    set(handles.Ed_FWHM,'string',num2str(handles.FWHM))
    set(handles.Tx_Message,'string',['Check !!!   "' FWHM '"   is not a number !'])
end


% --- Executes during object creation, after setting all properties.
function Ed_FWHM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ed_FWHM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Btn_SPreview.
function Btn_SPreview_Callback(hObject, eventdata, handles)
global IDX_sPreview SeedXYZV gbl_p_Prep IDX_flipUD gbl_p_Seed gbl_SeedInfo

IDX_sPreview=1;
[DirF,FN,ext] = fileparts(handles.pRSData);FN=[FN ext];
FN=strrep(FN,'.nii.gz','');FN=strrep(FN,'.nii','');FN=strrep(FN,'.img','');

if ~isempty(SeedXYZV) && (exist(handles.pT1,'file')==2) && isfield(handles,'StuT1') && (exist(gbl_p_Prep,'file')==2)
    %     h = figure('Name','BEING PATIENT, PLEASE !!!','NumberTitle','off','units','pixels','position',[500 500 400 50],'windowstyle','modal');set(h,'color','w');
    %     uicontrol('style','text','string','Window wiil be closed when the processing is done','units','pixels','position',[10 10 400 30],'fontsize',12,'fontname','Century Gothic','backgroundcolor',[1 1 1]);
    
%     [DirPrep,f_Prep,ext] = fileparts(gbl_p_Prep);f_Prep=[f_Prep ext];
%     Idx=findstr(f_Prep,'.nii.gz'); if ~isempty(Idx); f_Prep=f_Prep(1:Idx-1); end
%     
%     StuT1=handles.StuT1;
%     R=handles.SeedR;
%     c_Mtx=SeedXYZV(1:3);
%     dx=abs(StuT1.mat(1,1));dy=abs(StuT1.mat(2,2));dz=abs(StuT1.mat(3,3));
%     nx=handles.DimT1(1);ny=handles.DimT1(2);nz=handles.DimT1(3);
%     %dx=abs(StuT1.hdr.dime.pixdim(2));dy=abs(StuT1.hdr.dime.pixdim(3));dz=abs(StuT1.hdr.dime.pixdim(4));
%     %nx=StuT1.hdr.dime.dim(2);ny=StuT1.hdr.dime.dim(3);nz=StuT1.hdr.dime.dim(4);
%     
%     gx=0:dx:(nx-1)*dx;
%     gy=0:dy:(ny-1)*dy;
%     gz=0:dz:(nz-1)*dz;
%     
%     [xx,yy,zz]=meshgrid(gx,gy,gz);
%     MtxSeed=zeros(size(xx));
%     MtxSeed(c_Mtx(1),c_Mtx(2),c_Mtx(3))=1;
%     MtxSeed=(permute(MtxSeed, [2 1 3])); % Transform back to Nii Read-in
%     [J,I,K] = ind2sub(size(xx),find(MtxSeed==1));
%     
%     PNT_IJK=[sprintf('%3.3d',I) '_' sprintf('%3.3d',J) '_' sprintf('%3.3d',K) '_V' sprintf('%3.2f',SeedXYZV(4))];
%     PNT_XYZ=[sprintf('%3.3d',c_Mtx(1)) '_' sprintf('%3.3d',c_Mtx(2)) '_' sprintf('%3.3d',c_Mtx(3)) '_V' sprintf('%3.2f',SeedXYZV(4))];
%     PNT_Rmm=['_R' num2str(R) 'mm'];
%     Center=[gx(c_Mtx(1)) gy(c_Mtx(2)) gz(c_Mtx(3))];
%     
%     fOut=handles.fT1;
%     Idx=findstr(fOut,'.nii.gz'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
%     Idx=findstr(fOut,'.img'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
%     Idx=findstr(fOut,'.nii'); if ~isempty(Idx); fOut=fOut(1:Idx-1); end
%     %pSeed= [handles.DirRS filesep fOut '_XYZ_' PNT_XYZ '.nii.gz'];
%     pSeed= [DirPrep filesep 'Seed_XYZ_' PNT_XYZ PNT_Rmm  '%' fOut '.nii'];
%     
%     if (exist(pSeed,'file')==2)
%         set(handles.Tx_Message,'String',['Data Exist :' fOut '_XYZ_' PNT_XYZ '.nii.gz'],'ForegroundColor',[0 0 0]);
%     else
%         set(handles.Tx_Message,'String',['Please Wait ! Generating Seed :' fOut '_XYZ_' PNT_XYZ PNT_Rmm '.nii.gz'],'ForegroundColor',[1 0 0]);
%         % Cartesian coordinates (x-x0)^2 + (y-y0)^2 + (z-z0)^2 = r^2
%         % A1=(xx-Center(1)).^2;A2=(yy-Center(2)).^2; A3=(zz-Center(3)).^2; A4=A1+A2+A3; A5=double(A4<=R^2);A6=fliplr(permute(A5, [2 1 3]));
%         R_Square=(xx-Center(1)).^2 + (yy-Center(2)).^2 + (zz-Center(3)).^2;
%         VOI=double(R_Square<=R^2);
%         if (IDX_flipUD==1)
%             VOI=fliplr(permute(VOI, [2 1 3]));
%         else
%             VOI=(permute(VOI, [2 1 3]));
%         end
%         % Save to Nii
%         %         Output=StuT1;
%         %         Output.img(:,:,:)=0;
%         %         Output.img(:,:,:)=VOI(:,:,:);
%         %         save_untouch_nii(Output,pSeed);
%         
%         spmV=spm_vol(handles.pT1);
%         ima=spm_read_vols(spmV);
%         ima=VOI(:,:,:);
%         spmV.fname=pSeed;
%         spm_write_vol(spmV,ima);
%         StuImU=nifti(spmV.fname);
%         
%         set(handles.Tx_Message,'String',[''],'ForegroundColor',[0 0 0]);
%     end
%

    MakeSeed(hObject, eventdata, handles)
    if (exist(gbl_p_Seed,'file')==2)
%         Stu_Seed=load_untouch_nii(pSeed);
%         handles.MtxSeed=logical(Stu_Seed.img(:,:,:));
        Stu_Seed=nifti(gbl_p_Seed);
        handles.MtxSeed=logical(Stu_Seed.dat(:,:,:));
        
        [DirSeed,f_Seed,ext] = fileparts(gbl_p_Seed);f_Seed=[f_Seed ext];
        set(handles.Tx_SeedMask,'String',f_Seed,'ForegroundColor',0.5*[1 1 1]);
        guidata(hObject, handles);
    end
    DispIm(hObject, eventdata, handles)
end


% --- Executes on selection change in PMenu_RSMethod.
function PMenu_RSMethod_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_RSMethod,'string');
selectedIndex = get(handles.PMenu_RSMethod,'Value');
switch get(handles.PMenu_RSMethod,'Value')
    case 1
        handles.RSMethod='Pearson';
    case 2
        handles.RSMethod='glm';
end
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function PMenu_RSMethod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PMenu_RSMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function [handles]=Btn_Anats_Callback(hObject, eventdata, handles)
global IDX_flipUD
[fAnat,DirIn] = uigetfile({'*.nii;*.img'},'Select Other Anatomical Image (Ex. FLAIR Image)',handles.DirRS);pAnat=[DirIn fAnat];
if isequal(fAnat,0) && isequal(DirIn,0)
    set(handles.Tx_Anats,'String','Anatomical data not selected!');
    handles.pAnat='';
else
    handles.pAnat=pAnat;
    fAnat2T1=strrep(fAnat,'.nii.gz',''); fAnat2T1=strrep(fAnat2T1,'.nii',''); fAnat2T1=strrep(fAnat2T1,'.img','');
    StuAnat=nifti(pAnat);
    if (numel(size(StuAnat.dat))>3)
        handles.pAnat='';
        handles.pAnat2T1='';
        set(handles.Tx_Anats,'String',['[#Vol=' num2str(size(StuAnat.img,4)) '] ' 'Anatomical data should not be a 4D dataset, please check!']);
    else
        handles.pAnat=pAnat;
        handles.fAnat=fAnat;
        DimAnat=size(StuAnat.dat);
        Dim= [sprintf('%3.3d',DimAnat(1)) 'x' sprintf('%3.3d',DimAnat(2)) 'x' sprintf('%3.3d',DimAnat(3))];
        set(handles.Tx_Anats,'String',['[' Dim '] ' fAnat]);
        if (sum(handles.DimT1==DimAnat)==3)
        	pAnat2T1=pAnat;
        else
            pAnat2T1=[DirIn fAnat2T1 '%T1_lpa.nii'];
        end
        handles.pAnat2T1=pAnat2T1;
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
set(handles.Tx_Message,'String',['>> '],'ForegroundColor',[0 0 0]); 

function PMenu_Anats_Callback(hObject, eventdata, handles)
global ImSetUlay_Buffer
global ImSetUlay 
SliceZ=round( get(handles.Sd_SliceZ,'Value')); %disp(['SliceZ = ' num2str(SliceZ)])
switch get(handles.PMenu_Anats,'Value')
    case 1
%         Stutmp=load_untouch_nii(handles.pT1);
        Stutmp=nifti(handles.pT1);
        handles.MtxT1=double(Stutmp.dat);
        ImSetUlay= ImSetUlay_Buffer(1,:);
    case 2
        Stutmp=nifti(handles.pAnat2T1);
        handles.MtxT1=double(Stutmp.dat);
        if (size(ImSetUlay_Buffer,1)==1)
            ImTMP=squeeze(handles.MtxT1(:,:,SliceZ));
            ImSetUlay_Buffer(2,:)=[min(ImTMP(:)) round(2*max(ImTMP(:))/3)];
        end
        ImSetUlay= ImSetUlay_Buffer(2,:);
end

set(handles.Ed_aWmin,'string',num2str(ImSetUlay(1)))
set(handles.Ed_aWMax,'string',num2str(ImSetUlay(2)))
% handles.cAUTO=1;
guidata(hObject, handles);% BtnSetting(hObject, eventdata, handles);
BtnOff(hObject, eventdata, handles);set(handles.Btn_rsData,'Enable','off');
[handles]=DispCase(hObject, eventdata, handles);
pause(0.01)
DispIm(hObject, eventdata, handles)

function PMenu_Anats_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Btn_Exit.
function Btn_Exit_Callback(hObject, eventdata, handles)
close


% --- Executes on button press in Ck_Despike.
function Ck_Despike_Callback(hObject, eventdata, handles)
% hObject    handle to Ck_Despike (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Ck_Despike


% --- Executes on button press in Btn_PrepData.
function Btn_PrepData_Callback(hObject, eventdata, handles)




function Tx_PrepData_Callback(hObject, eventdata, handles)



% --- Executes during object creation, after setting all properties.
function Tx_PrepData_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function [handles]=SetEd_Cxyz(hObject, eventdata, handles)
Cx=get(handles.Ed_Cx, 'string');
Cy=get(handles.Ed_Cy, 'string');
Cz=get(handles.Ed_Cz, 'string');
if ~isnan(str2double(Cx)) && ~isnan(str2double(Cx)) && ~isnan(str2double(Cz))
    Cx=str2double(get(handles.Ed_Cx, 'string'));
    Cy=str2double(get(handles.Ed_Cy, 'string'));
    Cz=str2double(get(handles.Ed_Cz, 'string'));
    if (Cx>0) && (Cy>0) && (Cz>0)
       PNT=['||   Set seed to' sprintf('%3.3d',Cx) ', ' sprintf('%3.3d',Cy) ', ' sprintf('%3.3d',Cz) ];% disp(PNT)
       COORD=round([Cx Cy]);
       SliceZ=round(Cz);
       % <Jump to set z>
       set(handles.Ed_SliceZ,'string',num2str(SliceZ))
       set(handles.Sd_SliceZ,'Value',SliceZ);
       tstart = tic;
       DispIm(hObject, eventdata, handles)
       telapsed = toc(tstart);
       

       global SeedXYZV gbl_p_Prep IDX_sPreview IDX_flipUD
       if (exist(handles.pTMap,'file')==2) && ~(exist(handles.pRSMap,'file')==2)
           if (IDX_flipUD==1)
               ZMap=round(100*flipud(handles.MtxTMap(:,:,SliceZ)'))/100;
           else
               ZMap=round(100*(handles.MtxTMap(:,:,SliceZ)'))/100;
           end
           SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
           PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
       elseif ~(exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
           if (IDX_flipUD==1)
               ZMap=round(100*flipud(handles.MtxRSMap(:,:,SliceZ)'))/100;
           else
               ZMap=round(100*(handles.MtxRSMap(:,:,SliceZ)'))/100;
           end
           SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
           PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
       elseif (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
           if (IDX_flipUD==1)
               ZMap=round(100*flipud(handles.MtxTMap(:,:,SliceZ)'))/100;
               RSMap=round(100*flipud(handles.MtxRSMap(:,:,SliceZ)'))/100;
           else
               ZMap=round(100*(handles.MtxTMap(:,:,SliceZ)'))/100;
               RSMap=round(100*(handles.MtxRSMap(:,:,SliceZ)'))/100;
           end
           SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1)) RSMap(COORD(2),COORD(1))];
           PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4)) ', ' sprintf('%3.2f',SeedXYZV(5))];
       else
           if (IDX_flipUD==1)
               ZMap=flipud( handles.MtxT1(:,:,SliceZ)');
           else
               ZMap=( handles.MtxT1(:,:,SliceZ)');
           end
           SeedXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
           PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
       end
    IDX_sPreview=0;   
    end
end
DispIm(hObject, eventdata, handles);

function Ed_Cx_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_Cx_Callback(hObject, eventdata, handles)
SetEd_Cxyz(hObject, eventdata, handles);
function Ed_Cy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_Cy_Callback(hObject, eventdata, handles)
SetEd_Cxyz(hObject, eventdata, handles);
function Ed_Cz_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_Cz_Callback(hObject, eventdata, handles)
SetEd_Cxyz(hObject, eventdata, handles);


function Ed_BP1_Callback(hObject, eventdata, handles)
BP1=get(handles.Ed_BP1, 'string');
BP2=get(handles.Ed_BP2, 'string');

if ~isnan(str2double(BP1)) && ~isnan(str2double(BP2))
    if (str2double(BP1)< str2double(BP2))
        Bandpass_Range=[str2double(BP1) str2double(BP2)];
        handles.Bandpass_Range=Bandpass_Range;
        guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Set Bandpass filter of ' sprintf('%.2f',handles.Bandpass_Range(1)) '-' sprintf('%.2f',handles.Bandpass_Range(2)) ' Hz'],'ForegroundColor',[0 0 1]);
    else
        set(handles.Tx_Message,'string',['Check !!! The lower bound of filter must be smaller than upper bound'],'ForegroundColor',[1 0 0]);
    end
else
    set(handles.Tx_Message,'string',['Check !!! The range of bandpass filter IS NOT a number !'],'ForegroundColor',[1 0 0]);
end
BtnSetting(hObject, eventdata, handles);
function Ed_BP1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ed_BP2_Callback(hObject, eventdata, handles)
BP1=get(handles.Ed_BP1, 'string');
BP2=get(handles.Ed_BP2, 'string');

if ~isnan(str2double(BP1)) && ~isnan(str2double(BP2))
    if (str2double(BP1)< str2double(BP2))
        Bandpass_Range=[str2double(BP1) str2double(BP2)];
        handles.Bandpass_Range=Bandpass_Range;
        guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Set Bandpass filter of ' sprintf('%.2f',handles.Bandpass_Range(1)) '-' sprintf('%.2f',handles.Bandpass_Range(2)) ' Hz'],'ForegroundColor',[0 0 1]);
    else
        set(handles.Tx_Message,'string',['Check !!! The upper bound of filter must be larger than lower bound'],'ForegroundColor',[1 0 0]);
    end
else
    set(handles.Tx_Message,'string',['Check !!! The range of bandpass filter IS NOT a number !'],'ForegroundColor',[1 0 0]);
end
BtnSetting(hObject, eventdata, handles);
function Ed_BP2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Btn_SeedMsk_Callback(hObject, eventdata, handles)
global gbl_p_Seed gbl_SeedInfo
% [f_Seed,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select Seed Mask matching the Resolution of High-Res T1 Image',handles.DirRS);

[f_Seed,DirIn] = uigetfile({'*.nii;*.img'},'Select Seed Mask matching the Resolution of High-Res T1 Image',handles.DirRS);pSeed=[DirIn f_Seed];

if isequal(f_Seed,0) && isequal(DirIn,0) 
    set(handles.Tx_SeedMask,'String','File is not selected!');
    gbl_p_Seed='';
elseif ~isempty(findstr(f_Seed,'.nii.gz'))
    set(handles.Tx_SeedMask,'String','".nii.gz" is not supported, please select ".nii" file');
    gbl_p_Seed='';
else
   if (exist(pSeed,'file')==2)
        gbl_p_Seed=pSeed;
        gbl_SeedInfo=['SeedMsk_' ];
        Stu_Seed=nifti(pSeed);
        handles.MtxSeed=logical(Stu_Seed.dat(:,:,:));
        set(handles.Tx_SeedMask,'String',f_Seed,'ForegroundColor',[0 0 1]);
        
        Mtxtmp=reshape(handles.MtxSeed,[size(handles.MtxSeed,1)*size(handles.MtxSeed,2) size(handles.MtxSeed,3)]);Mtxtmp=Mtxtmp';
        sliceSum=sum(Mtxtmp,2);
        [M,IdxM]=max(sliceSum);
        SliceZ=IdxM;
        set(handles.Ed_SliceZ,'string',num2str(SliceZ));
        set(handles.Sd_SliceZ, 'Value', SliceZ); % Somewhere between max and min.

        guidata(hObject, handles);
   end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);DispIm(hObject, eventdata, handles)




function Tx_SeedMask_Callback(hObject, eventdata, handles)



function Tx_SeedMask_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pnl_Seed_SelectionChangeFcn(hObject, eventdata, handles)
global gbl_p_Seed
global SeedXYZV
gbl_p_Seed='';

if isfield(handles,'MtxSeed'); rmfield(handles,'MtxSeed'); end
if isfield(handles,'MtxRSMap'); rmfield(handles,'MtxRSMap'); end
handles.pRSMap='';
guidata(hObject, handles);
DispCase(hObject, eventdata, handles);

set(handles.Tx_SeedMask,'String','','ForegroundColor',[0 0 0]);
set(handles.Tx_rsMap,'String','','ForegroundColor',[0 0 0]);
BtnSetting(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles);

switch get(eventdata.NewValue,'Tag')
    case 'RBtn_SeedXYZ'
        SetEd_Cxyz(hObject, eventdata, handles);
        set(handles.Tx_Message,'string',['Please set a seed by left-clicking the mouse on the imaging panel'],'ForegroundColor',[0 0 1]);
    case 'RBtn_SeedMask'
        SeedXYZV=[];
        set(handles.Ed_Cx, 'string','-');
        set(handles.Ed_Cy, 'string','-');
        set(handles.Ed_Cz, 'string','-');
        set(handles.Tx_Message,'string',['Please select a seed mask using the enabled "Seed Mask" button'],'ForegroundColor',[0 0 1]);
end
