function varargout = fmri2pacs(varargin)
% ||   
% ||  ===================================================================
% ||           ~~ Written by Ai-Ling Irene Hsu (2018.02.28)  ~~
% ||   Copyright (c) 2017 The University of Texas MD Anderson Cancer Center

% UI_VIWER MATLAB code for fmri2pacs.fig
%      UI_VIWER, by itself, creates a new UI_VIWER or raises the existing
%      singleton*.
%
%      H = UI_VIWER returns the handle to a new UI_VIWER or the handle to
%      the existing singleton*.
%
%      UI_VIWER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UI_VIWER.M with the given input arguments.
%
%      UI_VIWER('Property','Value',...) creates a new UI_VIWER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fmri2pacs_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fmri2pacs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
% Edit the above text to modify the response to help fmri2pacs
% Last Modified by GUIDE v2.5 17-Dec-2017 23:18:47
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @fmri2pacs_OpeningFcn, ...
    'gui_OutputFcn',  @fmri2pacs_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before fmri2pacs is made visible.
function fmri2pacs_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
BtnOff(hObject, eventdata, handles);
BtnINI(hObject, eventdata, handles);
% BtnSetting(hObject, eventdata, handles);


function [handles]=BtnINI(hObject, eventdata, handles)
global Idx_Flip Idx_Caxis_auto ImSetOlay IDX_flipUD
global SNAxG SNAxC SNSagC SNCorC
SNTEMP='---';SNAxG=SNTEMP;SNAxC=SNTEMP;SNSagC=SNTEMP;SNCorC=SNTEMP;
% clc;
% Idx_Flip: flip L/R; IDX_flipUD: flip Anterior/Posterior
IDX_flipUD=0;
Idx_Flip='n';set(handles.RBtnUlay,'Value',0);
Idx_Caxis_auto=1;
handles.ClickLR='L';
set(handles.FigUI,'Name','fMRI to PACS')

handles.pUlay='';handles.fUlay='';
handles.pOlay='';handles.fOlay='';
handles.pDCM='';handles.fDCM='';

handles.SN=''; % SeriesNumber
handles.DCMExt='.sdcopen'; set(handles.PMenu_Ext,'Value',1); % File Ext
handles.idxView=[];handles.Ls_fUlay='';

handles.Scale_BU=[];
handles.Colormap='autumn';
ImSetOlay=[0 100 1];
% handles.MtxImU=zeros(256,256);
handles.MtxImU=zeros(256,256);
guidata(hObject, handles);
set(handles.TxInfoV,'string','System Info >>> ');set(handles.TxInfoV,'ForegroundColor',[0 0 0]/255);

set(handles.CkBxCvtG,'Value',1);
if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
    PNT_Mod='REST ';
    set(handles.EdGrayAxDes,'string',[PNT_Mod 'Ax (surgical navigation)']);
    Ls_View3={'Ax','Sag','Cor'};
    for v=1:3
        set(getfield(handles,['EdRGB' Ls_View3{v} 'Des']),'string',[PNT_Mod Ls_View3{v} ' (not-for-diagnosis)']);
        set(getfield(handles,['CkBxCvtR' Ls_View3{v}]),'Value',1);
    end
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
    PNT_Mod='QI ';
    set(handles.EdGrayAxDes,'string',[PNT_Mod 'Ax (not-for-diagnosis)']);
    Ls_View3={'Ax','Sag','Cor'};
    for v=1:3
        set(getfield(handles,['CkBxCvtR' Ls_View3{v}]),'Value',0);
        set(getfield(handles,['EdRGB' Ls_View3{v} 'Des']),'string',[PNT_Mod Ls_View3{v} '(not-for-diagnosis)']);
        set(getfield(handles,['CkBxCvtR' Ls_View3{1}]),'Value',1);
    end
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
    PNT_Mod='';
        Ls_View3={'Ax','Sag','Cor'};
    for v=1:3
        set(getfield(handles,['EdRGB' Ls_View3{v} 'Des']),'string',['----------']);
        set(getfield(handles,['CkBxCvtR' Ls_View3{v}]),'Value',0);
    end
end

p_spm=which('spm.m');
if  ~(exist(p_spm, 'file')==2)
    set(handles.TxInfoV,'string','SPM is not detectd in PATH, Please add it !!! ','foregroundcolor',[1 0 0])
    handles.SPM=0;
else
     set(handles.TxInfoV,'string','SPM is detected in the path','foregroundcolor',[0 0 1])
     handles.SPM=1;
end
guidata(hObject, handles);

if (handles.SPM==1)
    BtnSetting(hObject, eventdata, handles);
else
    BtnOff(hObject, eventdata, handles);
        % <Image/Colorbar display : nan>
    imshow(zeros(256,256),'Parent',handles.AxIm);axis('image');%set(handles.AxIm,'XTickl',[],'YTickl',[]);
    SclBit=256;VecCB=[1:SclBit]';VecCB=VecCB*nan;
    imagesc(ones(SclBit,1),VecCB,VecCB,'Parent',handles.AxColorBar);colormap('gray')
    set(handles.AxColorBar, 'XTick', [], 'FontSize',1,'YAxisLocation', 'right') ;axis('xy') % 10 ticks
    set(handles.AxColorBar,'Visible','off')

end


% UIWAIT makes fmri2pacs wait for user response (see UIRESUME)
% uiwait(handles.FigUI);
% --- Outputs from this function are returned to the command line.
% function varargout = fmri2pacs_OutputFcn(hObject, eventdata, handles)
function varargout = fmri2pacs_OutputFcn(~, ~, handles)
varargout{1} = handles.output;
ffig='fmri2pacs.fig';
pfig=which(ffig);

if (exist(pfig,'file')==2)
    [DirM,~,ext]=fileparts(pfig);
else
    error(['Can not find "fig", please check Matlab path '])
end

if isdir(DirM)
    DirFn=[DirM filesep 'Fn'];
    DirDemo=[DirM filesep 'DEMO'];
    addpath(genpath(DirFn))
    addpath(DirM)
%     cd(DirDemo)
end


%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [Anatomical Selection ]
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function BtnAnat_Callback(hObject, eventdata, handles)
global ImSetUlay ImSetUlay_BU Idx_Caxis_auto Idx_OLay IDX_flipUD
% DirMapping
[handles]=BtnINI(hObject, eventdata, handles);
try
    if (get(handles.RBtnRS,'Value')==1)
       [Ls_fUlay, DirIn] = uigetfile({'*.nii;*.img'}, 'Hoding "shift" key for selecting multi anatomical image(s)', 'MultiSelect', 'on');
       % [Ls_fUlay, DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'}, 'Select anatomical data', 'MultiSelect', 'on');
       if iscell(Ls_fUlay)
           fUlay=Ls_fUlay{1};
           pUlay=[DirIn fUlay];
       else          
           fUlay=Ls_fUlay;clear Ls_fUlay
           Ls_fUlay{1}=fUlay;
           pUlay=[DirIn fUlay];
       end
    else  
%         [fUlay,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select anatomical data');pUlay=[DirIn fUlay];
     [fUlay,DirIn] = uigetfile({'*.nii;*.img'},'Select anatomical data');pUlay=[DirIn fUlay];
        Ls_fUlay='';
    end
    handles.Ls_fUlay=Ls_fUlay;
    if isequal(fUlay,0) && isequal(DirIn,0)
        handles.pUlay='';handles.pOlay='';handles.fOlay='';guidata(hObject, handles);
        BtnSetting(hObject, eventdata, handles)
        set(handles.TxInfoV,'string','Data not selected!','foregroundcolor',[1 0 0])
    else
        fUlay = strrep(fUlay, '.nii.gz', '');fUlay = strrep(fUlay, '.nii', '');fUlay = strrep(fUlay, '.img', '');
        handles.pUlay=pUlay; handles.fUlay=fUlay; handles.DirAnat=DirIn;
        handles.pOlay='';handles.fOlay='';
        
        if ~isempty(Ls_fUlay)
            clear ImgImU
            ImSetUlay_Buffer=zeros(numel(Ls_fUlay),2);
            for vol=1:numel(Ls_fUlay)
                
                % transform to nii format
                p_tmp=[DirIn Ls_fUlay{vol}];
                if ~isempty(findstr(p_tmp, '.img'))
                    V=spm_vol(p_tmp);
                    ima=spm_read_vols(V);
                    V.fname=strrep(p_tmp, '.img', '.nii');
                    spm_write_vol(V,ima);
                    StuImU=nifti(V.fname);
                else
                     StuImU=nifti(p_tmp);
                end
%                 StuImU=nifti([DirIn Ls_fUlay{vol}]);
                ImgImU(:,:,:,vol)=double(StuImU.dat);
%                 StuImU=load_untouch_nii([DirIn Ls_fUlay{vol}]);
%                 StuImU2=load_untouch_nii([DirIn Ls_fUlay{vol}]);
%                 ImgImU(:,:,:,vol)=double(StuImU.img);
                ImSetUlay_Buffer(vol,:)=[min(min(min(ImgImU(:,:,:,vol)))) max(max(max(ImgImU(:,:,:,vol))))];
            end
            handles.ImSetUlay_Buffer=ImSetUlay_Buffer;%ImSetUlay_Buffer(vol,:)=[min(MtxImU(:)) max(MtxImU(:))];
        else
            StuImU=nifti(pUlay);
%             StuImU=load_untouch_nii(pUlay);
%             handles.ImgImU=double(StuImU.img);
%             ImgImU(:,:,:,1)=double(StuImU.img);
            handles.ImgImU=double(StuImU.dat);
            ImgImU(:,:,:,1)=double(StuImU.dat);
        end
        handles.ImgImU=ImgImU;
%         handles.HDImU=StuImU.hdr.hist;guidata(hObject, handles);
        handles.HDImU=StuImU.mat;guidata(hObject, handles);
        % <Initial Setting : Volumn Selection>
        set(handles.SldrVAnat,'Value',1);
        set(handles.EdVAnat,'string','1');
        % <Initial Setting : Dir Z>
        if numel(size(handles.ImgImU))>=3
            numSteps=size(handles.ImgImU,3);
            SliceZ=round(2*numSteps/3);% SliceZ = cell2mat(varargin(1));
            set(handles.EdZ,'string',num2str(SliceZ));
            set(handles.SldrZ, 'min', 1); set(handles.SldrZ, 'max', numSteps);
            set(handles.SldrZ, 'Value', SliceZ); % Somewhere between max and min.
            set(handles.SldrZ, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
        else
            set(handles.EdZ,'string','1');
            set(handles.SldrZ, 'min', 1); set(handles.SldrZ, 'max', 1);set(handles.SldrZ, 'Value', 1);
            set(handles.EdZ,'Enable','off');set(handles.SldrZ, 'Enable', 'off');
        end
        
        % <Initial Setting : Imaging Window/Level>
        if numel(size(handles.ImgImU))>=4
            MtxImU=squeeze(handles.ImgImU(:,:,:,str2double(get(handles.EdVAnat,'string'))));
        else
            MtxImU=handles.ImgImU;
        end
        ImSetUlay=[min(MtxImU(:)) max(MtxImU(:))];ImSetUlay_BU=ImSetUlay;
        Idx_Caxis_auto=1;Idx_OLay=0;
        handles.MtxImU=MtxImU;
        
        % <Check q form>
        if isfield(handles,'HDImU')
            handles.qform=handles.HDImU;
        %if isfield(handles.HDImU,'srow_x') && isfield(handles.HDImU,'srow_y') && isfield(handles.HDImU,'srow_z')
            % Change to RAI System, where the initial offset(4) is R(+) A(+) I(-)
           if (handles.HDImU(2,4)>0); IDX_flipUD=0;else IDX_flipUD=1; end
           set(handles.TxInfoV,'ForegroundColor',[0 0 0]/255);
        else
            if (StuImU.filetype==0);IDX_flipUD=1; end % ANALYZE is the RPI system
            set(handles.TxInfoV,'string','Given Nifti data does not have initial orientation','ForegroundColor',[255 0 0]/255)
        end
        BtnSetting(hObject, eventdata, handles)
        DispIm(hObject, eventdata, handles)
        set(handles.TxInfoV,'string','Loading image successful!','foregroundcolor',[0 0 0])

        guidata(hObject, handles);
    end
catch
    set(handles.TxInfoV,'string','Unable to load the anatomical data !')
    imshow(zeros(256,256),'Parent',handles.AxIm);axis('image');%set(handles.AxIm,'XTickl',[],'YTickl',[]);
end

%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [Edit the Volumn of Anat + Slider the Volumn of Anat ]
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function SldrVAnat_Callback(hObject, eventdata, handles)
global Idx_Caxis_auto Idx_OLay ImSetUlay ImSetUlay_BU
VAnat=get(handles.SldrVAnat,'Value');
set(handles.EdVAnat,'string',num2str(VAnat));
% StuImU=handles.StuImU;
MtxImU=handles.ImgImU(:,:,:,VAnat);
handles.MtxImU=MtxImU;
if ~isempty(handles.Ls_fUlay)
    fUlay=handles.Ls_fUlay{VAnat};
    pUlay=[handles.DirAnat fUlay];
    StuImU=nifti(pUlay);
%     StuImU=load_untouch_nii(pUlay);
    handles.pUlay=pUlay;
     handles.HDImU=StuImU.mat;
%     handles.HDImU=StuImU.hdr.hist;
    fUlay = strrep(fUlay, '.nii.gz', '');fUlay = strrep(fUlay, '.nii', '');fUlay = strrep(fUlay, '.img', '');
    handles.fUlay=fUlay;
    guidata(hObject, handles);
end
ImSetUlay=handles.ImSetUlay_Buffer(VAnat,:);
BtnSetting(hObject, eventdata, handles)
Idx_Caxis_auto=1;Idx_OLay=0;
DispIm(hObject, eventdata, handles)
function SldrVAnat_CreateFcn(hObject, ~, ~)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function EdVAnat_Callback(hObject, eventdata, handles)
VAnat=str2double( get(handles.EdVAnat,'string'));VAnat(isnan(VAnat))=1;
if ~isempty(VAnat) VAnat=round(VAnat); end
set(handles.EdVAnat,'string',num2str(VAnat))
set(handles.SldrVAnat,'Value',VAnat);
SldrVAnat_Callback(hObject, eventdata, handles)
function EdVAnat_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [Mapping Selection ]
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function BtnfRst_Callback(hObject, eventdata, handles)

global ImSetUlay ImSetUlay_BU ImSetOlay ImSetOlay_BU IDX_flipUD
try
    % Condiction w/ or w/o Anatomical Image
    if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
        %         [fOlay,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select mapping result',handles.DirAnat);pOlay=[DirIn fOlay];
        [fOlay,DirIn] = uigetfile({'*.nii'},'Select mapping result',handles.DirAnat);pOlay=[DirIn fOlay];
    elseif  (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
        %         [fOlay,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select mapping result');pOlay=[DirIn fOlay];
        [fOlay,DirIn] = uigetfile({'*.nii'},'Select mapping result');pOlay=[DirIn fOlay];
    end
    
    if isequal(fOlay,0) && isequal(DirIn,0)
        handles.pOlay='';handles.fOlay='';guidata(hObject, handles);
        % <<qiMapping>>
        if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
            handles.pUlay='';handles.fUlay='';guidata(hObject, handles);
        end
        BtnSetting(hObject, eventdata, handles)
        DispIm(hObject, eventdata, handles)
        set(handles.TxInfoV,'string','Mapping file not selected!')
    else
        fOlay = strrep(fOlay, '.nii.gz', '');fOlay = strrep(fOlay, '.nii', '');fOlay = strrep(fOlay, '.img', '');
        %         StuImO=load_untouch_nii(pOlay);MtxImO=double(StuImO.img(:,:,:));
        if ~isempty(findstr(pOlay, '.img'))
            V=spm_vol(pOlay);
            ima=spm_read_vols(V);
            V.fname=strrep(pOlay, '.img', '.nii');
            spm_write_vol(V,ima);
            StuImO=nifti(V.fname);
        else
            StuImO=nifti(pOlay);
        end

        %StuImO=nifti(pOlay);
        MtxImO=double(StuImO.dat(:,:,:));
        % <<Extract Serier Number>>
        idxstr=strfind(fOlay,'_');
        if ~isempty(idxstr) && ~isempty(strfind(fOlay,'SN'))
            idxINI=strfind(fOlay,'SN')+2;
            idxEND=((idxstr-idxINI)>0);idxEND=find(idxEND==1);idxEND=idxstr(idxEND(1))-1;
            SN=str2double(fOlay(idxINI:idxEND));
        else
            SN=nan;
        end
        if ~isnan(SN) ;handles.SN=SN; else handles.SN=''; end; guidata(hObject, handles);
        set(handles.TxInfoV,'string','Loading rs-dataset ....')
        h = waitbar(0.3,['Loading...']);
        % <<qiMapping>>
        if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
            handles.pUlay=pOlay;
            handles.fUlay='-----';
            handles.MtxImU=0*MtxImO; % Set as black image
            handles.ImgImU=0*MtxImO;
            %handles.HDImU=StuImO.hdr.hist;
            handles.HDImU=StuImO.mat;
            if isfield(handles,'HDImU')
                handles.qform=handles.HDImU;
            %if isfield(handles.HDImU,'srow_x') && isfield(handles.HDImU,'srow_y') && isfield(handles.HDImU,'srow_z')
                % Change to RAI System, where the initial offset(4) is R(+) A(+) I(-)
                %if (handles.HDImU.srow_y(4)>0); IDX_flipUD=0;else IDX_flipUD=1; end
                if (handles.HDImU(2,4)>0); IDX_flipUD=0;else IDX_flipUD=1; end
            else
                if (StuImO.filetype==0);IDX_flipUD=1; end % ANALYZE is the RPI system
            end
            guidata(hObject, handles);
            Idx_Caxis_auto=999;
            handles.DirAnat='';
            % <Initial Setting : Dir Z>
            numSteps=size(handles.MtxImU,3);
            SliceZ=round(numSteps/2);% SliceZ = cell2mat(varargin(1));
            set(handles.EdZ,'string',num2str(SliceZ));
            set(handles.SldrZ, 'min', 1); set(handles.SldrZ, 'max', numSteps);
            set(handles.SldrZ, 'Value', SliceZ); % Somewhere between max and min.
            set(handles.SldrZ, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
            % <Initial Setting : Imaging Window/Level>
            MtxImU=handles.MtxImU;
            ImSetUlay=[min(MtxImU(:)) max(MtxImU(:))];ImSetUlay_BU=ImSetUlay;
            %Idx_OLay=1;
            ImSetOlay=[round(min(MtxImO(:))*100)/100 round(max(MtxImO(:))*100)/100 1];
            % <Initial Setting : Scale -5:5>
            set(handles.TxScale,'ForegroundColor',0*ones(1,3));
            set(handles.EdScale,'Enable','on');
            set(handles.SldrScale,'Enable','on');
            Scale=0;numSteps=11;
            set(handles.EdScale,'string',num2str(Scale));
            set(handles.SldrScale, 'min',-5); set(handles.SldrScale, 'max', 5);
            set(handles.SldrScale, 'Value', Scale); % Somewhere between max and min.
            set(handles.SldrScale, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
            Scale=get(handles.SldrScale,'Value');handles.Scale_BU=Scale;
%             MtxImO=(10^Scale)*double(StuImO.img(:,:,:));
            MtxImO=(10^Scale)*double(StuImO.dat(:,:,:));
        % <<rsMapping>>
        else
            ImSetOlay=[0.5 round(max(MtxImO(:))*100)/100 1.0];
            handles.Scale_BU=[];
        end
        
        MtxImU=handles.MtxImU;
        if(sum(size(MtxImU))~=sum(size(MtxImO)))
            [MtxImO]=Fn_ReSlice(MtxImO,size(MtxImU));
        end
%         handles.StuImO=double(StuImO.img(:,:,:));
        handles.StuImO=double(StuImO.dat(:,:,:));
        handles.MtxImO=MtxImO;
        handles.MtxImO_BU=MtxImO; % for QI purpose
        handles.IdxImO='y';
        handles.pOlay=pOlay;
        handles.fOlay=fOlay;
        handles.DirMapping=DirIn;
        
        ImSetOlay_BU=ImSetOlay;
        ImSetUlay_BU=ImSetUlay;
        set(handles.RBtnOlay,'Enable','on');
        set(handles.RBtnUlay,'Value',0);set(handles.RBtnOlay,'Value',1);
        % <Check q form>
        if isfield(handles,'HDImU')
            handles.qform=handles.HDImU;
        %if isfield(handles.HDImU,'srow_x') && isfield(handles.HDImU,'srow_x') && isfield(handles.HDImU,'srow_x')
            set(handles.TxInfoV,'ForegroundColor',[0 0 0]/255);
        else
            set(handles.TxInfoV,'ForegroundColor',[255 0 0]/255);
            set(handles.TxInfoV,'string','Given Nifti file does not have initial orientation')
        end
        
        guidata(hObject, handles);
        BtnSetting(hObject, eventdata, handles);
        waitbar(0.8,h,['Displaying...']);
        DispIm(hObject, eventdata, handles)
        set(handles.TxZvalV,'string','Ready!')
        
        close(h);
    end
catch
    set(handles.TxInfoV,'string','Unable to load the Mapping image !')
    set(handles.TxOlayV,'string','')
end

function BtnOff(hObject, eventdata, handles)
Status_OffOn='off';FColor=0.5*ones(1,3);
set(handles.BtnAnat,'Enable','off');
set(handles.BtnfRst,'Enable','off');
% set(handles.BtnConcatenate,'Enable','off');
% <Anatomical volumn setting>
set(handles.EdVAnat,'Enable','off')
set(handles.SldrVAnat,'Enable','off')
set(handles.BtnSort,'Enable','off')
set(handles.TxVolume,'ForegroundColor',FColor);
% <RadioBtn:: Ulay/OLay>
set(handles.RBtnUlay,'Enable','off');set(handles.RBtnOlay,'Enable','off');
% <Button/Pmenu Enable :: off>
set(handles.BtnDICOM,'Enable','off');
set(handles.PMenu_Ext,'Enable','off');
set(handles.Ed_Ext,'Enable','off');
set(handles.BtnCvt,'Enable','off');
set(handles.PMenu,'Enable','off');
% <min/max>
set(handles.EdMin,'Enable','off');
set(handles.Txmin,'ForegroundColor',FColor);
set(handles.EdMax,'Enable','off');
set(handles.Txmax,'ForegroundColor',FColor);
% <Flip>
set(handles.CkBxFlip,'Enable','off')
% <Opacity>
set(handles.SldrInt,'Enable','off');
set(handles.TxImInt,'ForegroundColor',FColor);
set(handles.EdOpacity,'Enable','off')
% <Series Number>
set(handles.TxRGBAx,'ForegroundColor',FColor);
set(handles.TxGrayAx,'ForegroundColor',FColor);
set(handles.EdGrayAx,'Enable','off');
set(handles.EdRGBAx,'Enable','off');
set(handles.EdRGBSag,'Enable','off');
set(handles.EdRGBCor,'Enable','off');
% <Series Des>
set(handles.EdGrayAxDes,'Enable','off');
set(handles.EdRGBAxDes,'Enable','off');
set(handles.EdRGBSagDes,'Enable','off');
set(handles.EdRGBCorDes,'Enable','off');
% <Checkbox Convert>
set(handles.CkBxCvtG,'Enable','off');
set(handles.CkBxCvtRAx,'Enable','off');
set(handles.CkBxCvtRSag,'Enable','off');
set(handles.CkBxCvtRCor,'Enable','off');
% <Dir Z>
set(handles.EdZ,'Enable','off');
set(handles.SldrZ,'Enable','off');
set(handles.TxSliceZ,'ForegroundColor',FColor);
% <Initial Setting : Scale>
set(handles.EdScale,'Enable','off');
set(handles.SldrScale,'Enable','off');
set(handles.TxScale,'ForegroundColor',FColor);
% <Initial Setting : Mode Selection>
set(handles.RBtnRS,'Enable','off');
set(handles.RBtnQI,'Enable','off');
set(handles.RBtnBasic,'Enable','off');
% <Unit>
set(handles.TxUnit,'ForegroundColor',FColor);
set(handles.PUnit,'Enable','off');
set(handles.EdUnit,'Enable','off');
%||=======================================================================|
%|| [All Button Setting]
%||=======================================================================|
function BtnSetting(hObject, ~, handles)
global ImSetOlay ImSetUlay
global SNAxG SNAxC SNSagC SNCorC

set(handles.EdGrayAx,'String',num2str(SNAxG))
set(handles.EdRGBAx,'String',num2str(SNAxC))
set(handles.EdRGBSag,'String',num2str(SNSagC))
set(handles.EdRGBCor,'String',num2str(SNCorC))

pUlay=handles.pUlay;
pOlay=handles.pOlay;fOlay=handles.fOlay;
pDCM=handles.pDCM;

set(handles.RBtnRS,'Enable','on');
set(handles.RBtnQI,'Enable','on');
set(handles.RBtnBasic,'Enable','on');

if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
    set(handles.BtnAnat,'Enable','on');
    set(handles.BtnfRst,'Enable','off');
    set(handles.Txmin,'String','Threshold');
    % <Initial Setting : Scale>
    set(handles.EdScale,'Enable','off');
    set(handles.SldrScale,'Enable','off');
    set(handles.TxScale,'ForegroundColor',0.5*ones(1,3));
    set(handles.PUnit,'Enable','off');
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
    set(handles.BtnAnat,'Enable','off');
    set(handles.BtnfRst,'Enable','on');
    set(handles.Txmin,'String','Window (L)');
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
    set(handles.BtnAnat,'Enable','on');
    set(handles.BtnfRst,'Enable','off');
    set(handles.Txmin,'String','Window (L)');
    % <Initial Setting : Scale>
    set(handles.EdScale,'Enable','off');
    set(handles.SldrScale,'Enable','off');
    set(handles.TxScale,'ForegroundColor',0.5*ones(1,3));
    set(handles.PUnit,'Enable','off');
end

%||-----------------------------------------------------------------------|
%||	[ Button Setting :: No ANY Image]
%||-----------------------------------------------------------------------|
if ~(exist(pUlay,'file')==2)
    % <Redundant field Removal>
    if isfield(handles, 'MtxImU');handles=rmfield(handles,'MtxImU');end
    if isfield(handles, 'MtxImO');handles=rmfield(handles,'MtxImO');end
    % <<QI Mapping>>
    if  (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
        set(handles.BtnfRst,'Enable','on');
    % <<RS Mapping>>
    elseif (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
        set(handles.BtnAnat,'Enable','on');
    end
    % <Anatomical volumn setting>
    set(handles.EdVAnat,'Enable','off')
    set(handles.SldrVAnat,'Enable','off')
    set(handles.TxVolume,'ForegroundColor',0.5*ones(1,3));
    % <RadioBtn:: Ulay/OLay>
    set(handles.RBtnUlay,'Value',0);set(handles.RBtnOlay,'Value',0);
    set(handles.RBtnUlay,'Enable','off');set(handles.RBtnOlay,'Enable','off');
    % <Button/Pmenu Enable :: off>
    %     set(handles.BtnfRst,'Enable','off');
    set(handles.BtnDICOM,'Enable','off');
    set(handles.BtnCvt,'Enable','off');
    set(handles.BtnCvt,'ForegroundColor',[0 0 0]/255);
    set(handles.PMenu,'Enable','off');
    % <min/max>
    set(handles.EdMin,'Enable','off');set(handles.EdMin,'string','0');
    set(handles.Txmin,'ForegroundColor',0.5*ones(1,3));
    set(handles.EdMax,'Enable','off');set(handles.EdMax,'string','8000');
    set(handles.Txmax,'ForegroundColor',0.5*ones(1,3));
    % <Flip>
    set(handles.CkBxFlip,'Enable','off')
    % <Opacity>
    set(handles.SldrInt,'Enable','off');
    set(handles.TxImInt,'ForegroundColor',0.5*ones(1,3));
    set(handles.EdOpacity,'Enable','off')
    % <Series Number>
    set(handles.EdGrayAx,'Enable','off');set(handles.EdGrayAx,'string','---');set(handles.TxGrayAx,'ForegroundColor',0.5*ones(1,3))
    set(handles.EdRGBAx,'Enable','off');set(handles.EdRGBAx,'string','---'); set(handles.TxRGBAx,'ForegroundColor',0.5*ones(1,3));
    set(handles.EdRGBSag,'Enable','off');set(handles.EdRGBSag,'string','---'); set(handles.TxRGBSag,'ForegroundColor',0.5*ones(1,3));
    set(handles.EdRGBCor,'Enable','off');set(handles.EdRGBCor,'string','---'); set(handles.TxRGBCor,'ForegroundColor',0.5*ones(1,3));
    % <Dir Z>
    set(handles.EdZ,'Enable','off');
    set(handles.SldrZ,'Enable','off');
    set(handles.TxSliceZ,'ForegroundColor',0.5*ones(1,3));
    % <Sring display :: ''>
    set(handles.TxUlayV,'string','')
    set(handles.TxOlayV,'string','')
    set(handles.TxDCMV,'string','')
    set(handles.TxZvalV,'string','------')
    % <Image/Colorbar display : nan>
    imshow(zeros(256,256),'Parent',handles.AxIm);axis('image');%set(handles.AxIm,'XTickl',[],'YTickl',[]);
    SclBit=256;VecCB=[1:SclBit]';VecCB=VecCB*nan;
    imagesc(ones(SclBit,1),VecCB,VecCB,'Parent',handles.AxColorBar);colormap('gray')
    set(handles.AxColorBar, 'XTick', [], 'FontSize',1,'YAxisLocation', 'right') ;axis('xy') % 10 ticks
    set(handles.AxColorBar,'Visible','off')
    
    % <Initial Setting : Scale>
    set(handles.EdScale,'Enable','off');
    set(handles.SldrScale,'Enable','off');
    set(handles.TxScale,'ForegroundColor',0.5*ones(1,3));
    % <Unit>
    set(handles.TxUnit,'ForegroundColor',0.5*ones(1,3));
    set(handles.PUnit,'Enable','off');set(handles.PUnit,'Value',1) % User defined
    set(handles.EdUnit,'string','') % User defined
%||-----------------------------------------------------------------------|
%||	[ Button Setting :: Antotomical Image ONLY ]
%||-----------------------------------------------------------------------|
elseif (exist(pUlay,'file')==2) && ~(exist(pOlay,'file')==2)
    % <<RS Mapping>>
    if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
        set(handles.BtnfRst,'Enable','on');
    end
    % <Redundant field Removal>
    if isfield(handles, 'MtxImO');handles=rmfield(handles,'MtxImO');end
    handles.fOlay='';guidata(hObject, handles);
    % <Select assigned volume>
    SzImg=size(squeeze(handles.ImgImU));
    if (numel(SzImg)<4)
        set(handles.SldrVAnat,'Enable','off')
        set(handles.EdVAnat,'Enable','off')
        set(handles.BtnSort,'Enable','off')
        set(handles.TxVolume,'ForegroundColor',0.5*ones(1,3));
    else
        set(handles.SldrVAnat, 'min', 1);set(handles.SldrVAnat, 'max', SzImg(4));
        set(handles.SldrVAnat, 'SliderStep', [1/(SzImg(4)-1) , 1/(SzImg(4)-1) ]);
        set(handles.SldrVAnat,'Enable','on')
        set(handles.EdVAnat,'Enable','on')
        set(handles.BtnSort,'Enable','on')
        set(handles.TxVolume,'ForegroundColor',0*ones(1,3));
    end
    %~~~~~~~~~~~~~~~~~~~~~~~~~
    % Imaging Setting
    %~~~~~~~~~~~~~~~~~~~~~~~~~
    % < Slider :: z >
    set(handles.EdZ,'Enable','on');
    set(handles.SldrZ,'Enable','on');
    set(handles.TxSliceZ,'ForegroundColor',0*ones(1,3));
    % < RadioBtn :: Ulay >
    set(handles.RBtnUlay,'Enable','on');set(handles.RBtnOlay,'Enable','off');
    set(handles.RBtnUlay,'Value',1);set(handles.RBtnOlay,'Value',0);
    % < Min >
    set(handles.EdMin,'string',num2str(ImSetUlay(1)));
    set(handles.EdMin,'Enable','on');
    set(handles.Txmin,'ForegroundColor',0*ones(1,3));
    % < Max >
    set(handles.EdMax,'string',num2str(ImSetUlay(2)));
    set(handles.EdMax,'Enable','on');
    set(handles.Txmax,'ForegroundColor',0*ones(1,3));
    % < Opacity >
    set(handles.EdOpacity,'Enable','off');
    set(handles.SldrInt,'Enable','off');
    set(handles.TxImInt,'ForegroundColor',0.5*ones(1,3));
    
    % < Setting for Next step preparation >
    % <<Basic>>
    if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
        set(handles.BtnfRst,'Enable','off');
        set(handles.TxZvalV,'string','------')
        set(handles.BtnDICOM,'Enable','on');
        % <<qiMapping or rsMapping>>
    else
        set(handles.BtnfRst,'Enable','on');
        set(handles.TxZvalV,'string','------')
    end
    %||-----------------------------------------------------------------------|
    %||	[ Button Setting :: Antotomical Image && Mapping Images ]
    %||-----------------------------------------------------------------------|
elseif (exist(pUlay,'file')==2) || (exist(pOlay,'file')==2)
    % <<QI Mapping>>
    if  (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
        % < RadioBtn :: Olay for qiMapping>
        set(handles.RBtnUlay,'Enable','off');set(handles.RBtnOlay,'Enable','on');
        set(handles.RBtnUlay,'Value',0);set(handles.RBtnOlay,'Value',1);
    % <<fMRI Mapping>>
    elseif (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
        set(handles.BtnfRst,'Enable','on');
        % < Opacity >
        set(handles.EdOpacity,'Enable','on')
        set(handles.EdOpacity,'string',num2str(ImSetOlay(3)))
        set(handles.SldrInt,'Enable','on');
        set(handles.TxImInt,'ForegroundColor',0*ones(1,3));
        set(handles.SldrInt, 'min', 0.15);
        set(handles.SldrInt, 'max', 1);
        set(handles.SldrInt,'Value',ImSetOlay(3))
        set(handles.SldrInt, 'SliderStep', [0.1 ,0.1]);
        % <Select assigned volume>
        SzImg=size(squeeze(handles.ImgImU));
        if (numel(SzImg)<4)
            set(handles.SldrVAnat,'Enable','off')
            set(handles.EdVAnat,'Enable','off')
            set(handles.TxVolume,'ForegroundColor',0.5*ones(1,3));
        else
            set(handles.SldrVAnat, 'min', 1);set(handles.SldrVAnat, 'max', SzImg(4));
            set(handles.SldrVAnat, 'SliderStep', [1/(SzImg(4)-1) , 1/(SzImg(4)-1) ]);
            set(handles.SldrVAnat,'Enable','on')
            set(handles.EdVAnat,'Enable','on')
            set(handles.TxVolume,'ForegroundColor',0*ones(1,3));
        end   
    end
    % < Min >
    set(handles.EdMin,'Enable','on');
    set(handles.Txmin,'ForegroundColor',0*ones(1,3));
    % < Max >
    set(handles.EdMax,'Enable','on');
    set(handles.Txmax,'ForegroundColor',0*ones(1,3));
    % < Opacity >
    set(handles.EdOpacity,'Enable','off');
    set(handles.SldrInt,'Enable','off');
    set(handles.TxImInt,'ForegroundColor',0.5*ones(1,3));
    % < Slider :: z >
    set(handles.EdZ,'Enable','on');
    set(handles.SldrZ,'Enable','on');
    set(handles.TxSliceZ,'ForegroundColor',0*ones(1,3));
    % < Min/Max >
    if (get(handles.RBtnUlay,'Value')==1)
        set(handles.EdMin,'string',num2str(ImSetUlay(1)));
        set(handles.EdMax,'string',num2str(ImSetUlay(2)));
    elseif (get(handles.RBtnOlay,'Value')==1)
        set(handles.EdMin,'string',num2str(ImSetOlay(1)));
        set(handles.EdMax,'string',num2str(ImSetOlay(2)));
    end
    % < Flip >
    set(handles.CkBxFlip,'Enable','on');
    % < Further Setting >
    set(handles.BtnDICOM,'Enable','on');
    set(handles.PMenu,'Enable','on');
    set(handles.PMenu,'String',{'Autumn','Jet','Blue-Hot'});
end

set(handles.TxUlayV,'string',handles.fUlay)
set(handles.TxOlayV,'string',handles.fOlay)
set(handles.TxDCMV,'string',handles.fDCM)

%||-----------------------------------------------------------------------|  
%||	[ Button Setting :: DICOM Setting ]
%||-----------------------------------------------------------------------|  

Ls_View3={'Ax','Sag','Cor'};
for v=1:3
    set(getfield(handles,['TxRGB' Ls_View3{v}]),'ForegroundColor',0.5*ones(1,3));
    set(getfield(handles,['EdRGB' Ls_View3{v}]),'Enable','off');
    set(getfield(handles,['EdRGB' Ls_View3{v} 'Des']),'Enable','off');
    % <Checkbox Convert>
    set(getfield(handles,['CkBxCvtR' Ls_View3{v}]),'Enable','off');
end
%<Set buttons off first>
set(handles.BtnCvt,'Enable','off');
set(handles.BtnCvt,'ForegroundColor',[0 0 0]/255);
set(handles.TxGrayAx,'ForegroundColor',0.5*ones(1,3));
set(handles.EdGrayAx,'Enable','off');
set(handles.EdGrayAxDes,'Enable','off');
set(handles.CkBxCvtG,'Enable','off');

% <<RBtnBasic>>
if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
    if (exist(pDCM,'file')==2) && (exist(pUlay,'file')==2)
        set(handles.BtnCvt,'Enable','on');
        set(handles.BtnCvt,'ForegroundColor',[255 0 0]/255);
        set(handles.PMenu_Ext,'Enable','on');
        if (get(handles.PMenu_Ext,'Value')==4)
            set(handles.Ed_Ext,'Enable','on');
        else
            set(handles.Ed_Ext,'Enable','off');
        end
        % <<Grayscale>>
        set(handles.TxGrayAx,'ForegroundColor',0*ones(1,3));
        set(handles.EdGrayAx,'Enable','on');
        set(handles.EdGrayAxDes,'Enable','on');
        set(handles.EdGrayAxDes,'String',[Ls_View3{handles.idxView} ' (not-for-diagnosis)']);
        set(handles.CkBxCvtG,'Enable','on');
    end
% <<qiMapping or rsMapping >>
else
    %<Set on when all info exist>
    if (exist(pDCM,'file')==2) && (exist(pOlay,'file')==2) && (exist(pUlay,'file')==2)
        set(handles.BtnCvt,'Enable','on');
        set(handles.BtnCvt,'ForegroundColor',[255 0 0]/255);
        % <<Grayscale>>
        set(handles.TxGrayAx,'ForegroundColor',0*ones(1,3));
        set(handles.EdGrayAx,'Enable','on');
        set(handles.EdGrayAxDes,'Enable','on');
        set(handles.CkBxCvtG,'Enable','on');
        % <<qiMapping>>
        if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
            set(handles.EdGrayAxDes,'String',['QI ' Ls_View3{handles.idxView} ' (not-for-diagnosis)']);
            set(handles.EdGrayAxDes,'Enable','on');
            set(getfield(handles,['TxRGB' Ls_View3{handles.idxView}]),'ForegroundColor',0*ones(1,3));
            set(getfield(handles,['EdRGB' Ls_View3{handles.idxView}]),'Enable','on');
            set(getfield(handles,['EdRGB' Ls_View3{handles.idxView} 'Des']),'Enable','on');
            set(getfield(handles,['CkBxCvtR' Ls_View3{handles.idxView}]),'Enable','on');
            set(handles.PUnit,'Enable','on');
            set(handles.EdUnit,'Enable','on');
            set(handles.EdUnit,'BackgroundColor',1*ones(1,3));
            set(handles.TxUnit,'ForegroundColor',1*ones(1,3));
        % <<rsMapping>>
        elseif (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
            set(handles.EdGrayAxDes,'String',['REST ' Ls_View3{handles.idxView} ' (surgical navigation)']);
            set(handles.EdGrayAxDes,'Enable','on');
            for v=1:3
                set(getfield(handles,['TxRGB' Ls_View3{v}]),'ForegroundColor',0*ones(1,3));
                set(getfield(handles,['EdRGB' Ls_View3{v}]),'Enable','on');
                set(getfield(handles,['EdRGB' Ls_View3{v} 'Des']),'Enable','on');
                set(getfield(handles,['CkBxCvtR' Ls_View3{v}]),'Enable','on');
            end
        end
        set(handles.BtnCvt,'Enable','on');
        set(handles.BtnCvt,'ForegroundColor',[255 0 0]/255); 
        set(handles.PMenu_Ext,'Enable','on');
        if (get(handles.PMenu_Ext,'Value')==4)
            set(handles.Ed_Ext,'Enable','on');
        else
             set(handles.Ed_Ext,'Enable','off');
        end
    end
end
%||=======================================================================|
%|| [Display :: Window/Level]
%||=======================================================================|
function WinLvl(~, ~, handles)
hFig=handles.FigUI;
G=get(hFig,'userdata');
G.oldWBMFcn = get(hFig,'WindowButtonMotionFcn');
set(hFig,'userdata',G);
set(hFig,'WindowButtonDownFcn',{@WBDFcn,handles})
set(hFig,'WindowButtonMotionFcn',{@AxImMap_MouseMoveFcn,handles})
set(hFig,'WindowButtonUpFcn',{@WBUFcn,handles}) 

function WBDFcn(~, ~, handles)
global ImSetUlay
global Idx_Caxis_auto
if (Idx_Caxis_auto<3) 
hFig=handles.FigUI;
if ~strcmp(get(hFig,'SelectionType'),'normal')
    set(handles.RBtnUlay,'Value',1);set(handles.RBtnOlay,'Value',0);
    set(handles.EdMin,'string',num2str(ImSetUlay(1)));
    set(handles.EdMax,'string',num2str(ImSetUlay(2)));
    set(handles.SldrInt,'Enable','off');
    set(handles.TxImInt,'ForegroundColor',0.5*ones(1,3));
    set(handles.EdOpacity,'Enable','off')
    set(handles.CkBxFlip,'Enable','off')
    set(hFig,'WindowButtonMotionFcn',{@AdjWL,handles}) 
    G=get(hFig,'userdata');
    G.initpnt=get(gca,'currentpoint');
    G.initClim = [ImSetUlay(1) ImSetUlay(2)];
    set (hFig,'userdata',G);
end
end
function WBUFcn(~, ~, handles)
% hFig=handles.FigUI;
% if ~strcmp(get(gcf,'SelectionType'),'normal')
% G=get(hFig,'userdata');
% set(hFig,'WindowButtonMotionFcn',G.oldWBMFcn);
% end
try
    switch get(hFig,'SelectionType')
        case 'normal' %right-click,ctrl+left button,
        case 'alt' %right-click,ctrl+left button,
            G=get(hFig,'userdata');
    end
    handles.ClickLR='L';
    guidata(hObject, handles);
    set(hFig,'WindowButtonMotionFcn',{@AxImMap_MouseMoveFcn,handles}) 
    
end;


function AdjWL(hObject, eventdata, handles)
global ImSetUlay
hFig=handles.FigUI;
G=get(hFig,'userdata');
G.cp=get(gca,'currentpoint');
G.x=G.cp(1,1);G.y=G.cp(1,2);
G.xinit = G.initpnt(1,1);
G.yinit = G.initpnt(1,2);
G.dx = G.x-G.xinit;G.dy = G.y-G.yinit;
G.clim = G.initClim+G.initClim(2).*[G.dx G.dy]./128;
try
    switch get(hFig,'SelectionType')
       case 'normal'
            handles.ClickLR='L';
%         case 'extend' % Mid-button, shft+left button,
%             set(handles.AxIm,'Clim',G.clim);
%             ImSetUlay(1:2)=caxis(handles.AxIm);
%             DispIm(hObject, eventdata, handles)
        case 'alt' %right-click,ctrl+left button,
            set(handles.AxIm,'Clim',G.clim);
            ImSetUlay(1:2)=caxis(handles.AxIm);
    end;
    
    guidata(hObject, handles); 
%     set(handles.Ed_aWmin,'string',num2str(ImSetUlay(1)));
%     set(handles.Ed_aWMax,'string',num2str(ImSetUlay(2)));
    DispIm(hObject, eventdata, handles);
end;

%||=======================================================================|
%|| [Display :: DispIm ]
%||=======================================================================|
function DispIm(hObject, eventdata, handles)
global MtxImUM ImSetUlay ImSetOlay D3_RGB Idx_Caxis_auto Idx_Flip Idx_CMap_BU
global ImSetUlay_BU ImSetOlay_BU Idx_Flip_BU IDX_flipUD
pUlay=handles.pUlay;
pOlay=handles.pOlay;

if  numel(size(handles.ImgImU))>3
    MtxImU=squeeze(handles.ImgImU(:,:,:,get(handles.SldrVAnat,'Value')));
else
    MtxImU=handles.ImgImU;
end

SliceZ=str2double( get(handles.EdZ,'string'));
MtxImUM=MtxImU; % UM: UnderlayModulated
if (sum(ImSetUlay==ImSetUlay_BU)<2)
    MtxImUM(MtxImUM<ImSetUlay(1))=ImSetUlay(1);
    MtxImUM(MtxImUM>ImSetUlay(2))=ImSetUlay(2);
end
%||-----------------------------------------------------------------------|
%||	[ Display :: Antotomical Image Only ]
%||-----------------------------------------------------------------------|
if (exist(pUlay,'file')==2) && ~(exist(pOlay,'file')==2) %
    if (Idx_Caxis_auto==1)
        if (IDX_flipUD==1)
            hIm=imshow(flipud(squeeze(MtxImUM(:,:,SliceZ))'),'Parent',handles.AxIm);caxis(handles.AxIm,'auto'); ImSetUlay(1:2)=caxis(handles.AxIm);
        else
            hIm=imshow((squeeze(MtxImUM(:,:,SliceZ))'),'Parent',handles.AxIm);caxis(handles.AxIm,'auto'); ImSetUlay(1:2)=caxis(handles.AxIm);
        end
        WinLvl(hObject, eventdata, handles)
        Idx_Caxis_auto=2;
    elseif (Idx_Caxis_auto==2)
        if (IDX_flipUD==1)
            hIm=imshow( flipud(squeeze(MtxImUM(:,:,SliceZ))'),ImSetUlay(1:2),'Parent',handles.AxIm);
        else
            hIm=imshow( (squeeze(MtxImUM(:,:,SliceZ))'),ImSetUlay(1:2),'Parent',handles.AxIm);
        end
    end
    SclBit=256;VecCB=linspace(ImSetUlay(1),ImSetUlay(2),SclBit)';
    imagesc(ones(SclBit,1),VecCB,VecCB,'Parent',handles.AxColorBar); colormap('gray')
    set(handles.AxColorBar, 'XTick', [], 'FontSize',8, 'YColor', 0.58*[1 1 1],'YAxisLocation', 'right','fontweight','b') ;axis(handles.AxColorBar,'xy') % 10 ticks
    set(handles.AxColorBar,'Visible','on')
    %set(handles.AxColorBar,'YTickLabel',num2str(get(handles.AxColorBar,'YTick')','%d'));  
    if get(handles.RBtnUlay,'Value')==1
        set(handles.EdMin,'string',num2str(ImSetUlay(1)));
        set(handles.EdMax,'string',num2str(ImSetUlay(2)));
    end
    % <RBtnBasic>
    if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
        OLay2Gray(hObject, eventdata, handles)
    end
%||-----------------------------------------------------------------------|
%||	[ Display :: Antotomical Image && Mapping Images ]
%||-----------------------------------------------------------------------|
elseif (exist(pUlay,'file')==2) && (exist(pOlay,'file')==2)
    Idx_Caxis_auto=999;
    MtxImO=handles.MtxImO;
    IdxImO=handles.IdxImO;
    IDX_Overlay_Calcuation=(sum(ImSetOlay==ImSetOlay_BU)+sum(ImSetUlay==ImSetUlay_BU));
    if sum(size(MtxImUM))>=sum(size(MtxImO))
        % set(handles.TxInfoV,'string','Size(Underlay) ~= Size(Ovelylay)....Doing Interpolation')
        %<RGB data will be re-generate when setting criteria being changed>
        if (IDX_Overlay_Calcuation<5) || ~strcmp(Idx_Flip_BU,Idx_Flip) || strcmp(IdxImO,'y') || ~strcmp(Idx_CMap_BU,handles.Colormap)
             if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
                 MtxImOQI=MtxImO;
                 MtxImOQI(MtxImO<ImSetOlay(1))=ImSetOlay(1);
                 MtxImOQI(MtxImO>ImSetOlay(2))=ImSetOlay(2);
                  [D3_RGB]=Fn_OLay2RGB(MtxImUM,MtxImOQI,ImSetOlay,'n',Idx_Flip,handles.Colormap);
             else
                  [D3_RGB]=Fn_OLay2RGB(MtxImUM,MtxImO,ImSetOlay,'n',Idx_Flip,handles.Colormap);
             end
            OLay2Gray(hObject, eventdata, handles)
            ImSetOlay_BU=ImSetOlay;
            ImSetUlay_BU=ImSetUlay;
            handles.Scale_BU=get(handles.SldrScale,'Value');
            Idx_Flip_BU=Idx_Flip;
            Idx_CMap_BU=handles.Colormap;
            handles.IdxImO='n';guidata(hObject, handles);
        end
        %<Showing Image>
         if (IDX_flipUD==1)
            hIm=imshow(flipud(permute(squeeze(D3_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxIm);
         else
            hIm=imshow((permute(squeeze(D3_RGB(:,:,SliceZ,:)), [2 1 3])),'Parent',handles.AxIm);
         end
         WinLvl(hObject, eventdata, handles)
          
        %<Showing colorbar>
        SclBit=256;VecCB=linspace(ImSetOlay(1),ImSetOlay(2),512)';%VecCB=[1:10]';
        imagesc(ones(512,1),VecCB,VecCB,'Parent',handles.AxColorBar);
        set(handles.AxColorBar, 'XTick', [], 'FontSize',8, 'YColor', 0.58*[1 1 1],'YAxisLocation', 'right') ;axis(handles.AxColorBar,'xy') % 10 ticks

        if strcmp(handles.Colormap,'autumn')
            colormap('autumn')
        elseif strcmp(handles.Colormap,'jet')
            colormap('jet')
        elseif strcmp(handles.Colormap,'bluehot')
            BlueHot = [0 1 1;0 0 1;0 0 0; 1 0 0;1 1 0;];
            coord = linspace(1, size(BlueHot, 1), SclBit);
            colormap(interp1(BlueHot, coord, 'linear'))
        end
        % set(handles.AxColorBar,'Visible','on')
 
        set(handles.TxInfoV,'string','Overlapping completed !')
    else
        set(handles.TxInfoV,'string','Size(Underlay) < Size(Ovelylay)....Please Check!')
        set(handles.TxInfoV,'ForegroundColor',[1 0 0]);
    end
end

if (exist(pUlay,'file')==2)
    set(hIm,'ButtonDownFcn',{@AxIm_ButtonDownFcn,handles}) % Set the motion detector.
end
%||=======================================================================|
%|| [Displaying OLay value ]
%||=======================================================================|
function AxImMap_MouseMoveFcn(hObject, eventdata, handles)
global SeedXYZV IDX_flipUD Idx_Flip
if (exist( handles.pUlay,'file')==2)
    if strcmp(handles.ClickLR,'L')
        oldunits = get(handles.AxIm, 'Units');
        %set(handles.AxIm, 'Units', 'pixels');
        C = round(get (handles.AxIm, 'CurrentPoint'));C = round(C(1,1:2));
        SliceZ=round(get(handles.SldrZ, 'Value'));
        
        if (IDX_flipUD==1)
            MapTEMP=flipud( handles.ImgImU(:,:,SliceZ)');
        else
            MapTEMP=( handles.ImgImU(:,:,SliceZ)');
        end
        
        
         if (C(1)>0) && (C(1)<size(MapTEMP,2)) && (C(2)>0) && (C(2)<size(MapTEMP,1))
%          if (C(1)>0) && (C(1)<size(handles.ImgImU,2)) && (C(2)>0) && (C(2)<size(handles.ImgImU,1))
             IDX_SHOWXYZ='O';
             COORD=C;
         else
             IDX_SHOWXYZ='X';
         end
      
         if strcmp(IDX_SHOWXYZ,'O')
             if (exist(handles.pOlay,'file')==2)
                 if (IDX_flipUD==1)
                     ZMap=round(100*flipud(handles.MtxImO(:,:,SliceZ)'))/100;
                 else
                     ZMap=round(100*(handles.MtxImO(:,:,SliceZ)'))/100;
                 end
                 if strcmp(Idx_Flip,'y')
                     ZMap=fliplr(ZMap);
                 end
                 
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
             else
                 if (IDX_flipUD==1)
                     ZMap=flipud( handles.ImgImU(:,:,SliceZ)');
                 else
                     ZMap=( handles.ImgImU(:,:,SliceZ)');
                 end
                 if strcmp(Idx_Flip,'y')
                     ZMap=fliplr(ZMap);
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
             end
             set(handles.TxZvalV,'string',num2str(round(CurrentXYZV(4)*10000)/10000))
             
             if (exist(handles.pOlay,'file')==2)
                 set(handles.TxInfoV,'string',['>> Current @ [x,y,z,value(par)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
             else
                 set(handles.TxInfoV,'string',['>> Current @ [x,y,z,value(anat)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
             end
             
%              if ~isempty(SeedXYZV)
%                  PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
%                  
%                  if (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
%                      set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value(t)] = [' PNT_SeedXYZV '];  '...
%                          'Current @ [x,y,z,value(t),value(rs)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
%                  else
%                      set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value] = [' PNT_SeedXYZV '];  '...
%                          'Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
%                  end     
%              else
%                  if (exist(handles.pTMap,'file')==2) && (exist(handles.pRSMap,'file')==2)
%                      set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value(t),value(rs)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
%                  else
%                      set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
%                  end
%              end    
         end
    end
end

function AxIm_ButtonDownFcn(~, ~, handles)
global Idx_Flip IDX_flipUD
pOlay=handles.pOlay;
if (exist(pOlay,'file')==2)
    SliceZ=str2double(get(handles.EdZ,'string'));
    MtxImU=handles.ImgImU;
    MtxImO=handles.MtxImO;
    coordinates = get(handles.AxIm,'CurrentPoint');
    coordinates = round(coordinates(1,1:2)); %disp(num2str([coordinates SliceZ]))
    
    if (IDX_flipUD==1)
        ZMap=flipud(MtxImO(:,:,SliceZ)');
    else
        ZMap=(MtxImO(:,:,SliceZ)');
    end
 
    if strcmp(Idx_Flip,'y')
        ZMap=fliplr(ZMap);
    end

    zval=ZMap(coordinates(2),coordinates(1));
    % message = sprintf('x: %.1f , y: %.1f , zval: %.3f',coordinates (1) ,coordinates (2),zval);disp(message)
    set(handles.TxZvalV,'string',num2str(round(zval*10000)/10000))
end
%||=======================================================================|
%|| [DICOM Selection]
%||=======================================================================|
function BtnDICOM_Callback(hObject, eventdata, handles)
global IDX_flipUD
global SNAxG SNAxC SNSagC SNCorC
try
    if (get(handles.RBtnBasic,'Value')==0)
        [fDCM,DirIn] = uigetfile({'*.dcm;*'},'Select ONE DICOM file',handles.DirMapping);pDCM=[DirIn fDCM];
    else
        [fDCM,DirIn] = uigetfile({'*.dcm;*'},'Select ONE DICOM file',handles.DirAnat);pDCM=[DirIn fDCM];
    end
    
    if isequal(fDCM,0) && isequal(DirIn,0)
        handles.pDCM='';handles.fDCM='';guidata(hObject, handles);
        BtnSetting(hObject, eventdata, handles)
        set(handles.TxInfoV,'ForegroundColor',[255 0 0]/255);
        set(handles.TxInfoV,'string','DICOM file not selected!')
    else
        % <Selected DICOM file>
        fDCM = strrep(fDCM, '.dcm', '');fDCM = strrep(fDCM, '.IMA', '');
        if length(fDCM)>50
            fDCM=['~' fDCM(end-50+2:end)];
        end
        handles.pDCM=pDCM;handles.fDCM=fDCM;guidata(hObject, handles);
        % <Look for all DICOM files in the same path>
        files=dir([DirIn]);
        files([files.isdir]) = [];  %remove non-directories
        Cell_FNs={files.name}';
        Cell_Dirs=cell(size(Cell_FNs));Cell_Dirs(:)={[DirIn filesep]};
        Cell_pFiles=cellstr([char(Cell_Dirs{:}) char(Cell_FNs{:})]);
        IIdx_dcm=cellfun(@isdicom,Cell_pFiles);
        Cell_pDCMs=Cell_pFiles(IIdx_dcm);
        
        %<check DICOM View>
        HDRIn= dicominfo(pDCM);
        ViewID(:,1)=[1;0;0;0;1;0]; % FOR AXIAL VIEW (z axis)
        ViewID(:,2)=[0;1;0;0;0;-1];% FOR Sagital VIEW (x axis)
        ViewID(:,3)=[1;0;0;0;0;-1]; % FOR Coronal VIEW (y axis)
        clear CMP;CMP=zeros(3,1);
        Sign=(HDRIn.ImageOrientationPatient>0)+(HDRIn.ImageOrientationPatient<0)*-1;
        ImgOrient=Sign.*(abs(HDRIn.ImageOrientationPatient)>0.5);%
        for v=1:3 ; CMP(v)=(sum(ImgOrient==ViewID(:,v))==6); end
        idxView=find(CMP==1);
        handles.idxView=idxView;
        handles.ImgOrient=HDRIn.ImageOrientationPatient;
        
        %<check whether the number of DICOM files is same as record of DICOM header>
        if (idxView==1); cksum= size(handles.ImgImU,3);
        elseif (idxView==2); cksum= size(handles.ImgImU,1);
        elseif (idxView==3); cksum= size(handles.ImgImU,2);
        end
        
        %<Get Q form from DICOM files>
        if (sum(IIdx_dcm)>=cksum)
            HDRT1= dicominfo(Cell_pDCMs{1});HDRTN= dicominfo(Cell_pDCMs{cksum});
            
            % % ---- Short cut for speeding up. ---------------------------
            % % However, it might not get the correct 1st and last files due to the difference of file sorting across OS.   
            % CT1=HDRT1.ImagePositionPatient;CTN=HDRTN.ImagePositionPatient;

            % % ---- Corret the error in reading 1st and last DCM files ---
            h=waitbar(0,['Reading DICOM files...' ' (' num2str(cksum) ' in ' num2str(sum(IIdx_dcm)) ')']);
            for n=1:cksum
                HDRttt= dicominfo(Cell_pDCMs{n});
                Coord_ttt(n,:)=[HDRttt.InstanceNumber HDRttt.ImagePositionPatient' n];
                waitbar(n / cksum)
            end
            close(h);
            Coord_CRT=sortrows(Coord_ttt,1);
            CT1=Coord_CRT(find(Coord_CRT(:,1)==1),2:4)';
            CTN=Coord_CRT(find(Coord_CRT(:,1)==cksum),2:4)';
            
            % Write the read DICOM coordinate for checking
            %parts = strsplit(DirIn, filesep);
            %ParFd = parts{end-1};
            idx_split=findstr(DirIn,filesep); 

            if (DirIn(end)==filesep)
               ParFd=DirIn(idx_split(end-1)+1:end-1);
            else
               ParFd=DirIn(idx_split(end)+1:end);
            end
            
            DayTime=[num2str(datestr(now,'mmdd')) num2str(datestr(now,'HHMM'))];
            dlmwrite([DirIn '(DCM_Coord)_D' DayTime '_' ParFd '.txt'],Coord_CRT,'delimiter','\t','precision','%.2f');
            
            %CT1=Coord_CRT(1,2:4)';CTN=Coord_CRT(n,2:4)';
%             
            [Affine_XYZ,Mtx_ImageOrient]=Fn_DCM2Affine(HDRIn,CT1,CTN,cksum);
            DCM_offset=CT1;

            handles.qform_DCM=[Affine_XYZ DCM_offset];
            handles.Mtx_ImageOrient=Mtx_ImageOrient;
            
            
            PassX=abs(abs(handles.qform_DCM(1,1))-abs(handles.qform_DCM(1,1)))<abs(handles.qform_DCM(1,1));
            PassY=abs(abs(handles.qform_DCM(2,2))-abs(handles.qform_DCM(2,2)))<abs(handles.qform_DCM(2,2));
            PassZ=abs(abs(handles.qform_DCM(3,3))-abs(handles.qform_DCM(3,3)))<abs(handles.qform_DCM(3,3));
            
            if (PassX+PassY+PassZ)<3
                if isfield(handles, 'qform_DCM');handles=rmfield(handles,'qform_DCM');end
            end
            
        else
            if isfield(handles, 'qform_DCM');handles=rmfield(handles,'qform_DCM');end
        end
        
%         handles.DCM_offset=DCM_offset;
        %<assign Series Number>
        if ~isempty(num2str(HDRIn.SeriesNumber))
            SNAxG=str2num([num2str(HDRIn.SeriesNumber) '01']);
            SNAxC=str2num([num2str(HDRIn.SeriesNumber) '02']);
            SNSagC=str2num([num2str(HDRIn.SeriesNumber) '03']);
            SNCorC=str2num([num2str(HDRIn.SeriesNumber) '04']);
        end
%         if ~isfield(handles,'qform')
%         end
        guidata(hObject, handles);BtnSetting(hObject, eventdata, handles)
        % <RBtnBasic>
        if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
            if (exist(handles.pDCM,'file')==2) && (exist(handles.pUlay,'file')==2)
                set(handles.TxInfoV,'string','Setting for DICOM conversion is READY !!!','ForegroundColor',[0 0 0])
            else
                set(handles.TxInfoV,'string','Missing at least one file, please check','ForegroundColor',[0 0 0]/255)
            end
        % <rsMapping> or <qiMapping>    
        else
            if (exist(handles.pDCM,'file')==2) && (exist(handles.pOlay,'file')==2) && (exist(handles.pUlay,'file')==2)
                set(handles.TxInfoV,'ForegroundColor',[0 0 0]);
                set(handles.TxInfoV,'string','Setting for DICOM conversion is READY !!!')
            else
                set(handles.TxInfoV,'ForegroundColor',[0 0 0]/255);
                set(handles.TxInfoV,'string','Missing at least one file, please check')
            end
            
            
            
            if (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
                 Ls_View3={'Ax','Sag','Cor'};
                for v=1:3
                    set(getfield(handles,['CkBxCvtR' Ls_View3{v}]),'Value',0);
                end
                set(getfield(handles,['CkBxCvtR' Ls_View3{idxView}]),'Value',1);
            end
            
            
        end
    end
    set(handles.TxDCMV,'string',handles.fDCM)
    BtnSetting(hObject, eventdata, handles)
catch
    set(handles.TxInfoV,'string','Unable to load DICOM !')
    set(handles.TxOlayV,'string','')
end
%||=======================================================================|
%|| [Slider Opacity ]
%||=======================================================================|
function SldrInt_CreateFcn(hObject, ~, ~)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function SldrInt_Callback(hObject, eventdata, handles)
% global ImSetUlay ImSetOlay Idx_Caxis_auto
global ImSetOlay 

if get(handles.RBtnOlay,'Value')==1
    ImSetOlay(3)=round(10*get(handles.SldrInt, 'Value'))/10;
    set(handles.SldrInt, 'Value',ImSetOlay(3))
    set(handles.EdOpacity, 'string',num2str(ImSetOlay(3)))
end
set(handles.TxInfoV,'string',['Set up Opacity to ' num2str(ImSetOlay(3))])
DispIm(hObject, eventdata, handles)

function EdOpacity_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdOpacity_Callback(hObject, eventdata, handles)
global ImSetOlay
if get(handles.RBtnOlay,'Value')==1
    if isempty(str2num(get(handles.EdOpacity, 'string')))
        set(handles.EdOpacity, 'string','0.8')
    end
    ImSetOlay(3)=round(10*str2num(get(handles.EdOpacity, 'string')))/10;
    set(handles.SldrInt,'Value',ImSetOlay(3));
end
set(handles.TxInfoV,'string',['Set up Opacity to ' num2str(ImSetOlay(3))])
DispIm(hObject, eventdata, handles)


%||=======================================================================|
%|| [Edit Z + Slider Z ]
%||=======================================================================|
function EdZ_Callback(hObject, eventdata, handles)
SliceZ=str2double( get(handles.EdZ,'string'));
if ~isempty(SliceZ) SliceZ=round(SliceZ); end
set(handles.EdZ,'string',num2str(SliceZ))
set(handles.SldrZ,'Value',SliceZ);
DispIm(hObject, eventdata, handles)
function EdZ_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SldrZ_Callback(hObject, eventdata, handles)
SliceZ=round( get(handles.SldrZ,'Value')); %disp(['SliceZ = ' num2str(SliceZ)])
set(handles.EdZ,'string',num2str(SliceZ))
DispIm(hObject, eventdata, handles)
function SldrZ_CreateFcn(hObject, ~, ~)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
%||=======================================================================|
%|| [Radio Button Selection]
%||=======================================================================|
function PnlImSetting_SelectionChangeFcn(~, eventdata, handles)
global ImSetUlay ImSetOlay
switch get(eventdata.NewValue,'Tag')
    case 'RBtnUlay'
        set(handles.EdMin,'string',num2str(ImSetUlay(1)));
        set(handles.EdMax,'string',num2str(ImSetUlay(2)));
        set(handles.SldrInt,'Enable','off');
        set(handles.TxImInt,'ForegroundColor',0.5*ones(1,3));
        set(handles.EdOpacity,'Enable','off')
        set(handles.CkBxFlip,'Enable','off')
    case 'RBtnOlay'
        set(handles.EdMin,'string',num2str(ImSetOlay(1)));
        set(handles.EdMax,'string',num2str(ImSetOlay(2)));
        set(handles.SldrInt, 'Value',ImSetOlay(3))
        set(handles.SldrInt,'Enable','on');
        set(handles.EdOpacity,'Enable','on')
        set(handles.TxImInt,'ForegroundColor',0*ones(1,3));
        set(handles.CkBxFlip,'Enable','on')
end
function RBtnUlay_Callback(~, ~, ~)
function RBtnOlay_Callback(~, ~, ~)

%||=======================================================================|
%|| [Range: Min/Max/Check Flip]
%||=======================================================================|

function EdMin_Callback(hObject, eventdata, handles)
global ImSetUlay ImSetOlay
StrMin=get(handles.EdMin, 'string');
StrMax=get(handles.EdMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        if get(handles.RBtnUlay,'Value')==1
            ImSetUlay(1)=str2double(get(handles.EdMin, 'string'));      
            if ~isempty(handles.Ls_fUlay)
                ImSetUlay_Buffer=handles.ImSetUlay_Buffer;
                ImSetUlay_Buffer(get(handles.SldrVAnat,'Value'),:)=ImSetUlay;
                handles.ImSetUlay_Buffer=ImSetUlay_Buffer;
            end   
        else
            ImSetOlay(1)=str2double(get(handles.EdMin, 'string'));
        end
        h = waitbar(0.3,['Change min to ' StrMin]);
        set(handles.TxInfoV,'string',['Change min to ' StrMin])
        guidata(hObject, handles);
        BtnSetting(hObject, eventdata, handles)
        DispIm(hObject, eventdata, handles)
        waitbar(1,h);close(h);
    else
        set(handles.TxInfoV,'string',['Check !!! "min" have to smaller than ' StrMax])
    end
else
    set(handles.TxInfoV,'string',['Check !!! :' StrMin '"   is not a number !'])
end
function EdMin_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdMax_Callback(hObject, eventdata, handles)
global ImSetUlay ImSetOlay

StrMin=get(handles.EdMin, 'string');
StrMax=get(handles.EdMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.TxInfoV,'string','Processing ...')
        if get(handles.RBtnUlay,'Value')==1
            ImSetUlay(2)=str2double(get(handles.EdMax, 'string'));
            if ~isempty(handles.Ls_fUlay)
                ImSetUlay_Buffer=handles.ImSetUlay_Buffer;
                ImSetUlay_Buffer(get(handles.SldrVAnat,'Value'),:)=ImSetUlay;
                handles.ImSetUlay_Buffer=ImSetUlay_Buffer;guidata(hObject, handles);
            end
        else
            ImSetOlay(2)=str2double(get(handles.EdMax, 'string'));
        end
        h = waitbar(0.3,['Change Max to ' StrMax]);
        set(handles.TxInfoV,'string',['Change Max to ' StrMax])
        DispIm(hObject, eventdata, handles)
        waitbar(1,h);
        close(h);
    else
        set(handles.TxInfoV,'string',['Check !!!  "Max" have to lager than ' StrMin])
    end
else
    set(handles.TxInfoV,'string',['Check !!!   "' StrMax '"   is not a number !'])
end
% BtnSetting(hObject, eventdata, handles)
function EdMax_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function CkBxFlip_Callback(hObject, eventdata, handles)
global Idx_Flip
set(handles.TxInfoV,'string','Procseeing...')
if (get(hObject,'Value') == get(hObject,'Max'))
	Idx_Flip='y';%display('Selected');
else
	Idx_Flip='n';%display('Not selected');
end
set(handles.TxInfoV,'string',['Set Flip L/R = [' Idx_Flip ']'])
DispIm(hObject, eventdata, handles)

%||=======================================================================|
%|| [DICOM Converting]
%||=======================================================================|
function BtnCvt_Callback(hObject, eventdata, handles)
global D3_RGB D3GrayMtx ImSetOlay ImSetUlay Idx_Flip
ImageComments='Processed';
fOlay=handles.fOlay;
pDCM=handles.pDCM;
DCMExt=handles.DCMExt;
BtnOff(hObject, eventdata, handles);%set(handles.BtnAnat,'Enable','off');

Ls_View3={'Ax','Sag','Cor'};
Ls_N3={size(D3GrayMtx,3),size(D3GrayMtx,1),size(D3GrayMtx,2)};
clear Ls_View Ls_N
% <<rsMapping>>
if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
    Modality='fMRI';
    Ls_View=Ls_View3;
    Ls_N=Ls_N3;
% <<qiMapping>>
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
    Modality='QI';
    Ls_View=Ls_View3(handles.idxView);
    Ls_N=Ls_N3(handles.idxView);
% <<Basic>>
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
    Modality='Basic';
    Ls_View=Ls_View3(handles.idxView);
    Ls_N=Ls_N3(handles.idxView);
end
if isfield(handles,'qform') 
    set(handles.TxInfoV,'ForegroundColor',[255 0 0]/255);
    %||-----------------------------------------------------------------------|
    %||                          [Gray ]
    %||-----------------------------------------------------------------------|
    TYPE='GRAY';
    %View=Ls_View{1};N=Ls_N{1};
    %View=Ls_View{handles.idxView};N=Ls_N{handles.idxView};
    % View='Ax';N=size(D3GrayMtx,3);
    
    % <<rsMapping>>
    if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
        View=Ls_View{handles.idxView};N=Ls_N{handles.idxView};
    % <<qiMapping>>
    else
        View=Ls_View{1};N=Ls_N{1};
    end
    
    
    SeriesNumberGray=str2double(get(handles.EdGrayAx, 'string'));
    if (get(handles.CkBxCvtG,'Value')==1)
        h = waitbar(0,['DICOM Outputing ' TYPE ' (SN' sprintf('%5.5d',SeriesNumberGray) ')']);
        DayTime=[num2str(datestr(now,'mmdd')) num2str(datestr(now,'HHMM'))];
        SeriesInstanceUID_GRAY= ['1.3.6.1.4.1.9.9.9.' num2str(datestr(now,'yyyymmdd')) num2str(datestr(now,'HHMMSS')) '.000.' get(handles.EdGrayAx, 'string')];
        
        % <<<Assign a new folder Name>>> ----------------------------------
        SPECICAL=[TYPE DayTime];%SPECICAL='Gray';
        % <<qiMapping>>
        if (get(handles.RBtnQI,'Value')==1)
            Fd_DCM=[handles.DirMapping filesep 'DCM_' SPECICAL '_' Modality  sprintf('%5.5d',SeriesNumberGray) '_' handles.fOlay];
            Fd_PreDCM=[handles.DirMapping];
            % <<rsMapping and Basic>>
        elseif (get(handles.RBtnRS,'Value')==1)
            Pnt_TH=[num2str(ImSetOlay(1)) '-' num2str(ImSetOlay(2))];
            Fd_DCM=[handles.DirMapping filesep 'DCM_' SPECICAL '_' Modality sprintf('%5.5d',SeriesNumberGray) '_' handles.fOlay '_TH' Pnt_TH];
            Fd_PreDCM=[handles.DirMapping];
            % <<Basic>>
        elseif (get(handles.RBtnBasic,'Value')==1)
            Fd_DCM=[handles.DirAnat filesep 'DCM_'  SPECICAL '_' Modality sprintf('%5.5d',SeriesNumberGray) '_' handles.fUlay];
            Fd_PreDCM=[handles.DirAnat];
        end
        Fd_DCM=strrep(Fd_DCM,[filesep filesep],filesep);
        Fd_PreDCM=strrep(Fd_PreDCM,[filesep filesep],filesep);
        
        % <<<Generate DICOM(s)>>> -----------------------------------------
        clear Coord_tmpCvt
        for n=1:N
            if (n==1)
                if ~(exist(Fd_DCM,'dir')==7);mkdir(Fd_DCM);end
            end
            set(handles.TxInfoV,'string',['DICOM Outputing ' TYPE  ' (SN' sprintf('%5.5d',SeriesNumberGray) ')' sprintf('%3.3d',n) ' / ' sprintf('%3.3d',N)],'foregroundcolor',[1 0 0])
            % n=62;
            % <Header preparation>
            clear HDRIn DHeader
            HDRIn= dicominfo(pDCM);
            %         qform=[handles.HDImU.srow_x ; handles.HDImU.srow_y; handles.HDImU.srow_z];
            qform=handles.qform;
            
            if isfield(handles,'qform_DCM')
                [DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3GrayMtx,qform,handles.qform_DCM,n,[]); % figure(2);imshow(IM);caxis auto
            else
                [DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3GrayMtx,qform,qform,n,[]); % figure(2);imshow(IM);caxis auto
            end
            %         CCC_TEST(n,:)=DHeader.ImagePositionPatient;
            %         DHeader.ImagePositionPatient=[handles.DCM_offset(1:2) DHeader.ImagePositionPatient(3)]; %% >>> HAVE to CHECK
            % %         DHeader.SliceLocation=DHeader.ImagePositionPatient(3);
            %         DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(handles.idxView,:);
           
            if strcmp(View,'Ax')
                DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(1,:);
            elseif  strcmp(View,'Sag')
                DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(2,:);
            elseif  strcmp(View,'Cor')
                DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(3,:);
            end
            DHeader.SeriesInstanceUID=SeriesInstanceUID_GRAY;
            DHeader.SeriesNumber=SeriesNumberGray;
            DHeader.SeriesDescription=get(handles.EdGrayAxDes, 'string');
            % Modified window
            DHeader.SmallestImagePixelValue=min(IM(:));
            DHeader.LargestImagePixelValue=max(IM(:));
            if (get(handles.RBtnQI,'Value')==1)
                DHeader.WindowWidth=round(ImSetOlay(2)-ImSetOlay(1));
            else
                DHeader.WindowWidth=round(ImSetUlay(2)-ImSetUlay(1));
            end
            DHeader.WindowCenter=round(DHeader.WindowWidth/2);
            % ~~~~~~~~~~~(Important)~~~~~~~~~~~~
            DHeader.ImageComments=ImageComments;
            %DHeader.ImageComments=['TH:(' num2str(ImSetOlay(1)) ')~(' num2str(ImSetOlay(2)) ')']; %(0020,4000)
            if (get(handles.RBtnQI,'Value')==1)
                DHeader.SeriesDescription=[get(handles.EdGrayAxDes, 'string') 'x10^' get(handles.EdScale,'string') ' (' get(handles.EdUnit, 'string') ')'];
            else
                DHeader.SeriesDescription=[get(handles.EdGrayAxDes, 'string')];
            end
            DHeader.SeriesDescription=strrep(DHeader.SeriesDescription,'()','');
            
            DHeader.RescaleIntercept=0;
            DHeader.RescaleSlope=1;
            % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            % <Output>
            pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',DHeader.InstanceNumber) DCMExt];
            %pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',n) DCMExt];
            %pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',n) '.dcm'];
            %pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',n) '.sdcopen'];
            
            dicomwrite(IM,pOT, DHeader, 'CreateMode', 'copy');
            

            Coord_tmpCvt(n,:)=[DHeader.InstanceNumber DHeader.ImagePositionPatient n];
            clear IM
            waitbar(n / N)
        end
        close(h);

        %dlmwrite([Fd_DCM filesep '(DCM_Coord)_D' DayTime '_Gray.txt'],Coord_tmpCvt,'delimiter','\t','precision','%.2f');
        dlmwrite([Fd_PreDCM filesep '(DCM_Coord)_D' DayTime '_Gray.txt'],sortrows(Coord_tmpCvt,1),'delimiter','\t','precision','%.2f');
    end
    %||-----------------------------------------------------------------------|
    %||                          [RGB ]
    %||-----------------------------------------------------------------------|
    if (get(handles.RBtnRS,'Value')==1) || (get(handles.RBtnQI,'Value')==1)
        TYPE='RGB';clear Coord_tmpCvt
        for v=1:numel(Ls_N)
            DayTime=[num2str(datestr(now,'mmdd')) num2str(datestr(now,'HHMM'))];
            %     View='Ax';N=size(D3_RGB,3);
            View=Ls_View{v};
            N=Ls_N{v};
            SeriesNumberRGB=[str2double(get(getfield(handles,['EdRGB' View]),'string'))];
            SeriesInstanceUID_GRB= ['1.3.6.1.4.1.9.9.9.' num2str(datestr(now,'yyyymmdd')) num2str(datestr(now,'HHMMSS')) '.'  sprintf('%3.3d',v) '.' num2str(SeriesNumberRGB)];
            SeriesDescription_GRB=get(getfield(handles,['EdRGB' View 'Des']),'string');
            
            % <Create a new folder>
            SPECICAL=[TYPE View DayTime];
            % <<qiMapping>>
            if (get(handles.RBtnQI,'Value')==1)
                Fd_DCM=[handles.DirMapping filesep 'DCM_' SPECICAL '_' Modality sprintf('%5.5d',SeriesNumberRGB) '_' handles.fOlay];
                Fd_PreDCM=[handles.DirMapping];
                % <<rsMapping>>
            elseif (get(handles.RBtnRS,'Value')==1)
                %Fd_DCM=[handles.DirMapping filesep 'DCM_' Modality SPECICAL '_' handles.fUlay '_' handles.fOlay];
                Fd_DCM=[handles.DirMapping filesep 'DCM_' SPECICAL '_' Modality sprintf('%5.5d',SeriesNumberRGB) '_'  handles.fOlay];
                Fd_PreDCM=[handles.DirMapping];
                % <<Basic>>
            elseif (get(handles.RBtnBasic,'Value')==1)
                Fd_DCM=[handles.DirAnat filesep 'DCM_' SPECICAL '_' Modality sprintf('%5.5d',SeriesNumberRGB) '_'  handles.fUlay];
                Fd_PreDCM=[handles.DirAnat];
            end
            Fd_DCM=strrep(Fd_DCM,[filesep filesep],filesep);
            Fd_PreDCM=strrep(Fd_PreDCM,[filesep filesep],filesep);
            
            if (get(getfield(handles,['CkBxCvtR' View]),'Value')==1)
                
                ssCount=0;
                h=waitbar(0,['DICOM Outputing on' TYPE View ' (SN' sprintf('%5.5d',SeriesNumberRGB) ')']);
                
                %if size(handles.ImgImU)>4
                if numel(size(handles.ImgImU))>=3
                    GivenVolume=size(handles.ImgImU,4);
                else
                    GivenVolume=1;
                end
                AmountN=N*GivenVolume;
                for u=1:GivenVolume
                    % <Header Info>
                    clear HDRIn DHeader
                    HDRIn= dicominfo(pDCM);
                    %qform=[handles.HDImU.srow_x ; handles.HDImU.srow_y; handles.HDImU.srow_z];
                    qform=handles.qform;
                    % <Header replacement>
                    %DHeader.ImagesInAcquisition=size(D3_RGB,3);
                    DHeader.ImagesInAcquisition=N*GivenVolume;
                    MtxImUM=handles.ImgImU(:,:,:,u); % UM: UnderlayModulated
                    if isfield(handles,'ImSetUlay_Buffer')
                        ImSetUlay_Buffer=handles.ImSetUlay_Buffer;
                    else
                        ImSetUlay_Buffer=ImSetUlay;
                    end
                    MtxImUM(MtxImUM< ImSetUlay_Buffer(u,1))=ImSetUlay_Buffer(u,1);
                    MtxImUM(MtxImUM> ImSetUlay_Buffer(u,2))=ImSetUlay_Buffer(u,2);
                    
                    [D3_RGB_TMP]=Fn_OLay2RGB(MtxImUM,handles.MtxImO,ImSetOlay,'n',Idx_Flip,handles.Colormap);
                    for n=1:N
                        if (n==1)
                            if ~(exist(Fd_DCM,'dir')==7);mkdir(Fd_DCM);end
                        end
                        ssCount=ssCount+1;
                        
                        set(handles.TxInfoV,'string',['DICOM Outputing on' TYPE ' ' View ' (SN' sprintf('%5.5d',SeriesNumberRGB) ')' sprintf('%3.3d',ssCount) ' / ' sprintf('%3.3d',N*size(handles.ImgImU,4))])
                        % <<rsMapping>>
                        if (get(handles.RBtnRS,'Value')==1) &&(get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
                            %[DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3_RGB,qform,n,[]); % figure(2);imshow(IM);caxis auto
                            if isfield(handles,'qform_DCM')
                                [DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3_RGB_TMP,qform,handles.qform_DCM,n,[]); % figure(2);imshow(IM);caxis auto
                            else
                                [DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3_RGB_TMP,qform,qform,n,[]); % figure(2);imshow(IM);caxis auto
                            end
                            % <<qiMapping>>
                        elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
                            if isfield(handles,'qform_DCM')
                                [DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3_RGB,qform,handles.qform_DCM,n,ImSetOlay(1:2),handles.Colormap); % figure(2);imshow(IM);caxis auto
                            else
                                [DHeader,IM]=Fn_HDR2OLayAdn(HDRIn,TYPE,View,D3_RGB,qform,qform,n,ImSetOlay(1:2),handles.Colormap); % figure(2);imshow(IM);caxis auto
                            end
                            
                        end
                        testCnt=(u-1)*N+DHeader.InstanceNumber;
                        % figure(10);imshow(IM)
                        DHeader.SeriesInstanceUID=SeriesInstanceUID_GRB; % (0020,000E)
                        DHeader.SeriesNumber=SeriesNumberRGB; % (0020,0011)
                        %DHeader.InstanceNumber=ssCount;
                        DHeader.InstanceNumber=testCnt;
                        if strcmp(View,'Ax')
                            DHeader.ImageOrientationPatient=[1;0;0;0;1;0];
                            DHeader.SliceLocation=DHeader.ImagePositionPatient(3);
%                             DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(1,:);
                        elseif  strcmp(View,'Sag')
                            DHeader.ImageOrientationPatient=[0;1;0;0;0;-1];
                            DHeader.SliceLocation=DHeader.ImagePositionPatient(1);
%                             DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(2,:);
                        elseif  strcmp(View,'Cor')
                            DHeader.ImageOrientationPatient=[1;0;0;0;0;-1];
                            DHeader.SliceLocation=DHeader.ImagePositionPatient(2);
%                             DHeader.ImageOrientationPatient=handles.Mtx_ImageOrient(3,:);
                        end
                        
                        DHeader.TimeOfSecondaryCapture=num2str(datestr(now,'HHMMSS'));
                        if (GivenVolume>1)
                            LsRm= {'AcquisitionMatrix'};
                            %LsRm= {'SliceLocation','AcquisitionMatrix'};
                            for r=1:numel(LsRm)
                                if isfield(DHeader, LsRm{r})
                                    DHeader = rmfield(DHeader,LsRm{r});
                                end
                            end
                        end
                        % ~~~~~~~~~~~(Important)~~~~~~~~~~~
                        % DHeader.SeriesDescription= SeriesDescription_GRB; % (0008,103E)
                        DHeader.ImageComments=ImageComments;
                        % DHeader.ImageComments=['TH:(' num2str(ImSetOlay(1)) ')~(' num2str(ImSetOlay(2)) ')'];
                        if (get(handles.RBtnQI,'Value')==1)
                            % DHeader.SeriesDescription=[SeriesDescription_GRB ' ( Scaled by 10^(' get(handles.EdScale,'string') ' without thresholding)'];
                            DHeader.SeriesDescription=[SeriesDescription_GRB 'x10^' get(handles.EdScale,'string') ' (' get(handles.EdUnit, 'string') ')'];
                        else
                            DHeader.SeriesDescription=[SeriesDescription_GRB];
                        end
                        DHeader.SeriesDescription=strrep(DHeader.SeriesDescription,'()','');
                        if isfield(DHeader, 'SliceLocation')
                            DHeader = rmfield(DHeader,'SliceLocation');
                        end
                        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        % <Output>
                        %pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',ssCount) '.sdcopen'];
                        %pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',ssCount) '.dcm'];
                        %pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',ssCount) DCMExt];
                        pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',testCnt) DCMExt];
                       
                        
                        
                        dicomwrite(IM,pOT, DHeader, 'CreateMode', 'copy');
                        Coord_tmpCvt(ssCount,:)=[DHeader.InstanceNumber DHeader.ImagePositionPatient ssCount];
                        clear IM
                        waitbar(ssCount/AmountN)
                        %waitbar(n /N)
                    end
                end
                close(h)
                dlmwrite([Fd_PreDCM filesep '(DCM_Coord)_D' DayTime '_RGB' View '.txt'],sortrows(Coord_tmpCvt,1),'delimiter','\t','precision','%.2f');
                set(handles.TxInfoV,'string',['(' View ' View) DICOM Outputing successfully '],'ForegroundColor',[0 0 255]/255)
                
            end
        end
    end
    BtnSetting(hObject, eventdata, handles);
else
    set(handles.TxInfoV,'ForegroundColor',[255 0 0]/255);
    set(handles.TxInfoV,'string',['Checking orientation matrix is in the Nifti file'])
    BtnSetting(hObject, eventdata, handles);
    hm=msgbox('Nifti file does not contain initial orientation.', 'Error','error');
    kids0 = findobj( hm, 'Type', 'UIControl' );kids1 = findobj( hm, 'Type', 'Text' );
    set( [kids1],'FontName','Unicode');
    %set( [kids0, kids1],'FontName','Unicode', 'FontSize', 10 );
end
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [DICOM Series Number Assigement] (RGB + Gray)
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function EdGrayAx_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdGrayAx_Callback(~, ~, handles)
%  global SNAxG SNAxC SNSagC SNCorC
global SNAxG
if ~isempty(str2num(get(handles.EdGrayAx, 'string')))
    SNAxG=str2num(get(handles.EdGrayAx, 'string'));
    set(handles.TxInfoV,'string',['Set Gray(Ax) SN to ' num2str(SNAxG)],'ForegroundColor',[0 0 255]/255)
else
    set(handles.EdGrayAx,'string',num2str(SNAxG));
end

function EdRGBAx_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdRGBAx_Callback(~, ~, handles)
global SNAxC
if ~isempty(str2num(get(handles.EdRGBAx, 'string')))
    SNAxC=str2num(get(handles.EdRGBAx, 'string'));
    set(handles.TxInfoV,'string',['Set Color(Ax) SN to ' num2str(SNAxC)],'ForegroundColor',[0 0 255]/255)
else
    set(handles.EdRGBAx,'string',num2str(SNAxC));
end
% pDCM=handles.pDCM;
% DHeader=dicominfo(pDCM);
% DCM_NS=str2num(get(handles.EdRGBAx, 'string'));
% if isempty(DCM_NS)
%     DCM_NS=[num2str(DHeader.SeriesNumber) '02'];
%     set(handles.EdRGBAx,'string',DCM_NS)
% end

function EdRGBSag_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdRGBSag_Callback(~, ~, handles)
global SNSagC
if ~isempty(str2num(get(handles.EdRGBSag,'string')))
    SNSagC=str2num(get(handles.EdRGBSag,'string'));
    set(handles.TxInfoV,'string',['Set Color(Sag) SN to ' num2str(SNSagC)],'ForegroundColor',[0 0 255]/255)
else
    set(handles.EdRGBSag,'string',num2str(SNSagC));
end

function EdRGBCor_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdRGBCor_Callback(~, ~, handles)
global SNCorC
if ~isempty(str2num(get(handles.EdRGBCor, 'string')))
    SNCorC=str2num(get(handles.EdRGBCor, 'string'));
    set(handles.TxInfoV,'string',['Set Color(Cor) SN to ' num2str(SNCorC)],'ForegroundColor',[0 0 255]/255)
else
    set(handles.EdRGBCor,'string',num2str(SNCorC));
end


%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [Producing rs-Mapping Overlay with INT16 Gray Scale ]
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OLay2Gray(~, ~, handles)
global ImSetOlay Idx_Flip D3GrayMtx

% MtxImU=handles.ImgImU;
% MtxImO=handles.MtxImO;

% <<rsMapping>>
if (get(handles.RBtnRS,'Value')==1) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==0)
%     D3GrayMtx=handles.ImgImU;
    D3GrayMtx=handles.MtxImU;
    D3GrayMtx(handles.MtxImO>=ImSetOlay(1))=2^15;
% <<qiMapping>>
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==1) && (get(handles.RBtnBasic,'Value')==0)
    D3GrayMtx=handles.MtxImO;
%     D3GrayMtx(handles.MtxImO<ImSetOlay(1))=0;
% <<Basic>>
elseif (get(handles.RBtnRS,'Value')==0) && (get(handles.RBtnQI,'Value')==0) && (get(handles.RBtnBasic,'Value')==1)
    D3GrayMtx=handles.MtxImU;
end

if strcmp(Idx_Flip,'y')
    D3GrayMtx=flipud(D3GrayMtx); % data wiil be changeed to format with Int16 in Fn_HDR2OLAyAdn directly
%     D3GrayQI=flipud(D3GrayQI);
end

% 
% 
% if strcmp(Idx_Flip,'y')
% %     D3_Gray=int16(fliplr(flipud(permute(D3GrayMtx, [2 1 3]))));
%     D3GrayMtx=flipud(D3GrayMtx);
% % else
% %     D3_Gray=int16(flipud(permute(D3GrayMtx, [2 1 3])));
% end



function BtnExit_Callback(~, ~, ~)
close
function BtnAnat_CreateFcn(~, ~, ~)
function BtnfRst_CreateFcn(~, ~, ~)
function BtnCvt_CreateFcn(~, ~, ~)
function PnlImSetting_CreateFcn(~, ~, ~)
function RBtnUlay_CreateFcn(~, ~, ~)

function PMenu_Callback(hObject, eventdata, handles)
    switch get(handles.PMenu,'Value')
        case 1
            handles.Colormap='autumn';
        case 2
            handles.Colormap='jet';   
        case 3
            handles.Colormap='bluehot';           
    end
guidata(hObject, handles);
DispIm(hObject, eventdata, handles)
% set(handles.TxInfoV,'string',['Colormap is ' handles.Colormap])
function PMenu_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PnlModality_SelectionChangeFcn(hObject, eventdata, handles)
% global Idx_Caxis_auto
handles.pUlay='';handles.fUlay='';
handles.pOlay='';handles.fOlay='';
handles.pDCM='';handles.fDCM='';
handles.SN=''; % SeriesNumber
handles.idxView=[];handles.Scale_BU=[];
set(handles.PMenu,'Value',1);handles.Colormap='autumn';
handles.MtxImU=zeros(256,256);
set(handles.TxInfoV,'string','System Info >>> ');set(handles.TxInfoV,'ForegroundColor',[0 0 0]/255);
LsRm= {'ImgImU','HDImU'};
for r=1:numel(LsRm)
    if isfield(handles, LsRm{r}); handles = rmfield(handles,LsRm{r});end
end
guidata(hObject, handles);%BtnSetting(hObject, eventdata, handles)
switch get(eventdata.NewValue,'Tag')
    case 'RBtnRS'
        set(handles.TxInfoV,'string','Please select anatomical data');
    case 'RBtnQI'
        % <Initial Setting : Scale -5:5>
        Scale=0;numSteps=11;
        set(handles.EdScale,'string',num2str(Scale));
        set(handles.SldrScale, 'min',-5); set(handles.SldrScale, 'max', 5);
        set(handles.SldrScale, 'Value', Scale); % Somewhere between max and min.
        set(handles.SldrScale, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
        set(handles.TxInfoV,'string','Please select mapping data');
    case 'RBtnBasic'
        set(handles.TxInfoV,'string','Please select anatomical data');
end
BtnINI(hObject, eventdata, handles);

function SldrScale_Callback(hObject, eventdata, handles)
global ImSetOlay
Scale=get(handles.SldrScale,'Value'); %disp(['Scale = ' num2str(Scale)]);
set(handles.EdScale,'string',num2str(Scale))

ScaleDiff=Scale-handles.Scale_BU;

% handles.MtxImO=(10^Scale)*double(handles.StuImO(:,:,:));
handles.MtxImO=(10^Scale)*double(handles.MtxImO_BU(:,:,:));
guidata(hObject, handles);
ImSetOlay=[(10^ScaleDiff)*ImSetOlay(1) (10^ScaleDiff)*ImSetOlay(2) 1];
BtnSetting(hObject, eventdata, handles)
DispIm(hObject, eventdata, handles)

% % handles.MtxImU=MtxImU;
% % guidata(hObject, handles);
% ImSetUlay=[min(MtxImU(:)) max(MtxImU(:)) 0.5];
% ImSetUlay_BU=ImSetUlay;
% BtnSetting(hObject, eventdata, handles)
% Idx_Caxis_auto=1;Idx_OLay=0;
% DispIm(hObject, eventdata, handles)

function SldrScale_CreateFcn(hObject, ~, ~)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function PMenuDes_Callback(~, ~, ~)
function PMenuDes_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdGrayAxDes_Callback(~, ~, ~)
function EdGrayAxDes_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EdRGBAxDes_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdRGBAxDes_Callback(~, ~, ~)

function EdRGBSagDes_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdRGBSagDes_Callback(~, ~, ~)

function EdRGBCorDes_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdRGBCorDes_Callback(~, ~, ~)

function EdUnit_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdUnit_Callback(~, ~, ~)

function PUnit_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function PUnit_Callback(~, ~, handles)
    switch get(handles.PUnit,'Value')
        case 1
            set(handles.EdUnit,'string','') % User defined
        case 2
            set(handles.EdUnit,'string','mL/min/100 g') % mL/min/100 g
        case 3
            set(handles.EdUnit,'string','mL/g') % mL/g
        case 4
            set(handles.EdUnit,'string','ratio') % ratio
        case 5
            set(handles.EdUnit,'string','1/min') % 1/min
        case 6
            set(handles.EdUnit,'string','fraction (%)  ') % fraction (%)            
    end

% function BtnConcatenate_Callback(hObject, eventdata, handles)
% % <select folders of DICOM files>
% if isfield(handles,'DirMapping')
%     if ~isempty(handles.DirMapping)
%         DirCurrent=handles.DirMapping;
%     end
% else
%     DirCurrent=pwd;
% end
% 
% Ls_DirCmb=uigetdir2(DirCurrent, 'Please select at least 2 folders for combining data with the same SN');
% 
% if ~isempty(Ls_DirCmb) && (numel(Ls_DirCmb)>1)
%     idxCCT=1;
% else
%     idxCCT=0;set(handles.TxInfoV,'string','Please select at least 2 folders of DICOM files ');
% end
%     
% if (idxCCT==1)
%     %<Check the orientation of selected DCM folders>
%     clear LsDCM
%     CMPRst=0;
%     for Fd=1:numel(Ls_DirCmb)
%         clear pDCM
%         LsDCM{Fd}=dir([Ls_DirCmb{Fd} filesep 'IM_' '*.sdcopen']);
%         pDCM=[Ls_DirCmb{Fd} filesep LsDCM{Fd}(1).name];
%         [LsView{Fd,1}  LsViewIdx{Fd,1}]=Fn_CheckDcmView(pDCM);
%         CMPRst=CMPRst+isequal(LsView{1,1},LsView{Fd,1});
%         LsSN{Fd,1}= getfield(dicominfo(pDCM),'SeriesNumber');
%     end
%     %<orientation is consistant over the selected folders >
%     if (CMPRst==numel(Ls_DirCmb))
%         % <create a list of all select DICOMs>
%         clear pDCMs
%         for Fd=1:numel(Ls_DirCmb)
%             LsDCM{Fd}=dir([Ls_DirCmb{Fd} filesep 'IM_' '*.sdcopen']);
%             NumDCMs(Fd)=numel(LsDCM{Fd});
%             for f=1:numel(LsDCM{Fd})
%                 if Fd>1
%                     loc=sum(NumDCMs([1:Fd-1]))+f;
%                 else
%                     loc=sum(NumDCMs([1:Fd-1]))+f;
%                 end
%                 pDCMs{loc,1}=[Ls_DirCmb{Fd} filesep LsDCM{Fd}(f).name];
%             end
%         end
%         N=numel(pDCMs);
%         % <create a list of all select DICOMs>
%         DayTime=[num2str(datestr(now,'yymmdd')) '_' num2str(datestr(now,'HHMMSS'))];
%         View=LsView{1};N=numel(pDCMs);v=LsViewIdx{1};
%         % View=Ls_View{v};N=Ls_N{v};
%         %SeriesNumber=6015;
%         SeriesNumber=getfield(dicominfo(pDCMs{1}),'SeriesNumber');
%         SeriesInstanceUID= ['1.3.6.1.4.1.9.9.9.' num2str(datestr(now,'yyyymmdd')) num2str(datestr(now,'HHMMSS')) '.'  sprintf('%3.3d',v) '.' num2str(SeriesNumber)];
%         SeriesDescription=getfield(dicominfo(pDCMs{1}),'SeriesDescription');
%         h = waitbar(0,['Concatenate (' View ')' ' with SN=[' num2str(SeriesNumber) ']']);
%         for n=1:N
%             %     set(handles.TxInfoV,'string',['Converting (' TYPE '@' View ' view) ' sprintf('%3.3d',n) ' / ' sprintf('%3.3d',N)])
%             % <Create a new folder>
% %             sprintf('%5.5d',SeriesNumber)
%             SPECICAL=[ 'SN' num2str(SeriesNumber) '_' View  '_' DayTime ];
%             Fd_DCM=[DirCurrent filesep 'DCM_Concatenate_' SPECICAL];Fd_DCM(findstr(Fd_DCM,[filesep filesep]))='';
%             if ~(exist(Fd_DCM,'dir')==7);mkdir(Fd_DCM);end
%             % <Header Info>
%             clear HDRIn DHeader
%             HDRIn= dicominfo(pDCMs{n});
%             HDRIn.SeriesInstanceUID=SeriesInstanceUID; % (0020,000E)
%             HDRIn.SeriesNumber=SeriesNumber; % (0020,0011)
%             HDRIn.SeriesDescription=SeriesDescription; % (0008,103E)
%             HDRIn.InstanceNumber=n;
%             HDRIn.ImagesInAcquisition=N;
%             HDRIn.TimeOfSecondaryCapture=num2str(datestr(now,'HHMMSS'));
%             LsRm= {'SliceLocation','AcquisitionMatrix'};
%             for r=1:numel(LsRm)
%                 if isfield(HDRIn, LsRm{r})
%                     HDRIn = rmfield(HDRIn,LsRm{r});
%                 end
%             end
%             % <Data Info>
%             IM=dicomread(pDCMs{n});
%             % <Output>
%             pOT=[Fd_DCM filesep 'IM_' sprintf('%4.4d',n) '.sdcopen'];
%             dicomwrite(IM,pOT, HDRIn, 'CreateMode', 'copy');
%             clear IM
%             waitbar(n /N)
%         end
%         close(h)
%     else
%         set(handles.TxInfoV,'string','Checking orientation matrix is consistent over the selected folders ');
%     end
% end

function EdScale_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function EdScale_Callback(hObject, eventdata, handles)
Scale=str2double( get(handles.EdScale,'string'));Scale(isnan(Scale))=0;
if ~isnan(Scale)
    Scale=round(Scale);
    if (Scale>5) || (Scale<-5)
        Scale=0;
        set(handles.TxInfoV,'string','Checking range of the scale is [-5~5]');
    end
    set(handles.EdScale,'string',num2str(Scale))
    set(handles.SldrScale,'Value',Scale);
    set(handles.TxInfoV,'string',['Set scale to power of 10^(' num2str(Scale) ')']);
    SldrScale_Callback(hObject, eventdata, handles)
end

function BtnSort_Callback(hObject, eventdata, handles)
global Idx_Caxis_auto Idx_OLay ImSetUlay ImSetUlay_BU
DirIn=handles.DirAnat;
Ls_fUlay=handles.Ls_fUlay;
ImSetUlay_Buffer=handles.ImSetUlay_Buffer;
ImgImU=handles.ImgImU;
if ~isempty(Ls_fUlay)
    for n=1:numel(Ls_fUlay)
        idxN=abs(n-numel(Ls_fUlay))+1;
        Ls_fUlay_New{n}=Ls_fUlay{idxN};
        ImSetUlay_Buffer_New(n,:)=ImSetUlay_Buffer(idxN,:);
        ImgImU_New(:,:,:,n)=ImgImU(:,:,:,idxN);
        
        handles.Ls_fUlay=Ls_fUlay_New;
        handles.ImSetUlay_Buffer=ImSetUlay_Buffer_New;
        handles.ImgImU=ImgImU_New;
    end
    % <Initial Setting : Imaging Window/Level>
    VAnat=get(handles.SldrVAnat,'Value');
    MtxImU=handles.ImgImU(:,:,:,VAnat);
    handles.MtxImU=MtxImU;
   
    fUlay=handles.Ls_fUlay{VAnat};
    pUlay=[handles.DirAnat fUlay];
%     StuImU=load_untouch_nii(pUlay);
    StuImU=nifti(pUlay);
    handles.pUlay=pUlay;
%     handles.HDImU=StuImU.hdr.hist;
    handles.HDImU=StuImU.mat;
    fUlay = strrep(fUlay, '.nii.gz', '');fUlay = strrep(fUlay, '.nii', '');fUlay = strrep(fUlay, '.img', '');
    handles.fUlay=fUlay;
    guidata(hObject, handles);
    
    ImSetUlay=handles.ImSetUlay_Buffer(VAnat,:);
    BtnSetting(hObject, eventdata, handles)
    Idx_Caxis_auto=1;Idx_OLay=0;
    DispIm(hObject, eventdata, handles)
    %         if numel(size(handles.ImgImU))>=4
    %             MtxImU=squeeze(handles.ImgImU(:,:,:,VAnat));
    %         else
    %             MtxImU=handles.ImgImU;
    %         end
    %         handles.MtxImU=MtxImU;
    
    %         ImSetUlay=[min(MtxImU(:)) max(MtxImU(:))];ImSetUlay_BU=ImSetUlay;
    %         ImSetUlay=ImSetUlay_Buffer_New(VAnat,:);
    %         %Idx_Caxis_auto=1;Idx_OLay=0;
    %
    %         guidata(hObject, handles);
    %         BtnSetting(hObject, eventdata, handles)
    %         DispIm(hObject, eventdata, handles)
    

end

% handles.Ls_fUlay=Ls_fUlay_New;
% if ~isempty(Ls_fUlay_New)
%    
%     for vol=1:numel(Ls_fUlay_New)
%         StuImU=load_untouch_nii([DirIn Ls_fUlay_New{vol}]);
%         ImgImU(:,:,:,vol)=double(StuImU.img);
% 
%     end
%     handles.ImSetUlay_Buffer=ImSetUlay_Buffer;%ImSetUlay_Buffer(vol,:)=[min(MtxImU(:)) max(MtxImU(:))];  
%     handles.ImgImU=ImgImU;
%     % <Initial Setting : Imaging Window/Level>
%         if numel(size(handles.ImgImU))>=4
%             MtxImU=squeeze(handles.ImgImU(:,:,:,str2double(get(handles.EdVAnat,'string'))));
%         else
%             MtxImU=handles.ImgImU;
%         end
%         ImSetUlay=[min(MtxImU(:)) max(MtxImU(:))];ImSetUlay_BU=ImSetUlay;
%         Idx_Caxis_auto=1;Idx_OLay=0;
%         handles.MtxImU=MtxImU;
%         guidata(hObject, handles);
%         BtnSetting(hObject, eventdata, handles)
%         DispIm(hObject, eventdata, handles)
    
    
% end


% --- Executes on button press in CkBxCvtG.
function CkBxCvtG_Callback(hObject, eventdata, handles)
function CkBxCvtRAx_Callback(hObject, eventdata, handles)
function CkBxCvtRSag_Callback(hObject, eventdata, handles)
function CkBxCvtRCor_Callback(hObject, eventdata, handles)


% --- Executes on selection change in PMenu_Ext.
function PMenu_Ext_Callback(hObject, eventdata, handles)
switch get(handles.PMenu_Ext,'Value')
    case 1
        handles.DCMExt='.sdcopen'; 
    case 2
        handles.DCMExt='.dcm'; 
    case 3
        handles.DCMExt='.ima';  
    case 4
        handles.DCMExt='Other';
end
guidata(hObject, handles);
BtnSetting(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function PMenu_Ext_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ed_Ext_Callback(hObject, eventdata, handles)
% DCMExt=handles.DCMExt;
DCMExt=get(handles.Ed_Ext, 'string');
% DCMExt='Other'
if isempty(findstr(DCMExt,'.'))
    DCMExt=['.' DCMExt];
end
handles.DCMExt=DCMExt;
guidata(hObject, handles);
BtnSetting(hObject, eventdata, handles)
function Ed_Ext_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
