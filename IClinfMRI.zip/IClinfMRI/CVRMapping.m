function varargout = CVRMapping(varargin)
% ||                  ~~ Written by Ai-Ling Irene Hsu  ~~
% ||   Copyright (c) 2017 The University of Texas MD Anderson Cancer Center
% ||   
% CVRMAPPING MATLAB code for CVRMapping.fig
%      CVRMAPPING, by itself, creates a new CVRMAPPING or raises the existing
%      singleton*.
%
%      H = CVRMAPPING returns the handle to a new CVRMAPPING or the handle to
%      the existing singleton*.
%
%      CVRMAPPING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CVRMAPPING.M with the given input arguments.
%
%      CVRMAPPING('Property','Value',...) creates a new CVRMAPPING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CVRMapping_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CVRMapping_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CVRMapping

% Last Modified by GUIDE v2.5 24-Aug-2017 10:39:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CVRMapping_OpeningFcn, ...
                   'gui_OutputFcn',  @CVRMapping_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CVRMapping is made visible.
function CVRMapping_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
BtnINI(hObject, eventdata, handles);

function [handles]=BtnINI(hObject, eventdata, handles)
set(handles.Fig_CVRMapping,'Name','Cerebrovascular reactivity analysis for indicating fMRI confidence');
global Idx_Execute CMap_BU Idx_SvDiag IDX_fusion
global IDX_flipUD SeedXYZV ImSetUlay ImSetUlay_Buffer ImSetOlay ImSetOlayCVR ImSetOlayCVR_BU ImSetUlay_BU ImSetOlay_BU
SeedXYZV=[];
ImSetUlay=[200 6000];ImSetUlay_Buffer=ImSetUlay;
ImSetOlay=[3 8 0.9];
ImSetOlayCVR=[0.6 1.5 1];
ImSetUlay_BU=ImSetUlay;
ImSetOlay_BU=ImSetOlay;
ImSetOlayCVR_BU=ImSetOlayCVR;
IDX_flipUD=0;
Idx_Execute=0;
Idx_SvDiag=0;
IDX_fusion=0;
handles.ClickLR='L';
% <Default Setting : Dir Source>
tmp_PWD=pwd;
LsWorking={tmp_PWD,'C:\Users\AHSU\RScript_Toolbox\Matalb\UI_IClinfMRI_VB'};
% LsWorking={'/mnt/data/B2/MDACC_Patients','C:\Users\AHSU\RScript_Toolbox\Matalb\UI_rsMapping\DataTest',tmp_PWD};
for s=1:numel(LsWorking)
    if (exist(LsWorking{s},'dir')==7)
        handles.DirW=LsWorking{s};
    else
        handles.DirW=pwd;
    end
end
% guidata(hObject, handles);

% <Default for Img Input>
handles.pTData='';
handles.pT1='';
handles.pAnat='';
handles.pHRepi='';
handles.pfMap='';
handles.pcvrMap='';
handles.pAnat2T1='';
handles.pwd=tmp_PWD;
set(handles.Tx_tData,'String',handles.pTData);
set(handles.Tx_T1,'String',handles.pT1);
set(handles.Tx_Anat,'String',handles.pAnat);
set(handles.Tx_HRepi,'String',handles.pHRepi);
set(handles.Tx_fRst,'String',handles.pfMap);
set(handles.Tx_cvrMap,'String',handles.pcvrMap);

F='MtxfMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
F='MtxcvrMap' ; if isfield(handles, F); handles = rmfield(handles,F);end

handles.IRF='RRF';set(handles.PMenu_IRF,'Value',1);
% handles.IRF='HRF';set(handles.PMenu_IRF,'Value',2);

handles.CMap='autumn';
CMap_BU=handles.CMap;
handles.cAUTO=1;

handles.RegRSmm=2;set(handles.PMenu_Regmm,'Value',1);
handles.FWHM=4;set(handles.Ed_FWHM,'String',num2str(handles.FWHM));
% <Default Task PreProcess >
handles.TR=2;handles.tPattern='alt+z';
% <Default CVR Diagram >
handles.Onset=[30 90 150];
handles.Duration=[15 15 15];
handles.delayVec=[-8:8];
% handles.delayVec=[10:15];

set(handles.Ed_tOnset,'String',['[' num2str(handles.Onset) ']'])
set(handles.Ed_tDuration,'String',['[' num2str(handles.Duration) ']'])
set(handles.Ed_tDelay,'String',['[' num2str(handles.delayVec(1)) ':' num2str(handles.delayVec(end)) ']'])
% set(handles.Ed_tDelay,'String',['[' num2str(handles.delayVec) ']'])

set(handles.Sd_fOpt, 'min', 0.1); set(handles.Sd_fOpt, 'max', 1);
set(handles.Sd_fOpt, 'Value', ImSetOlay(3)); % Somewhere between max and min.
set(handles.Sd_fOpt, 'SliderStep', [0.1 , 0.1]);

set(handles.Sd_cOpt, 'min', 0.1); set(handles.Sd_fOpt, 'max', 1);
set(handles.Sd_cOpt, 'Value', ImSetOlayCVR(3)); % Somewhere between max and min.
set(handles.Sd_cOpt, 'SliderStep', [0.1 , 0.1]);

% Reg Setting
set(handles.RBtn_CBR,'Value',1)
set(handles.RBtn_BBR,'Value',0)
set(handles.RBtn_IBR,'Value',0)

% <Default Task PreProcess >
handles.tPrep_T=0;  handles.tPrep_M=1;  handles.tPrep_F=0;  handles.tPrep_D=0;  handles.tPrep_B=1;
set(handles.Ck_DftTPrep,'Value',1);
set(handles.Ck_tSliceT,'Value',handles.tPrep_T);
set(handles.Ck_tMCRT,'Value',handles.tPrep_M);
set(handles.Ck_tFMCRT,'Value',handles.tPrep_F);
set(handles.Ck_Despike,'Value',1);
set(handles.Ck_tDDdnt,'Value',handles.tPrep_D);
set(handles.Ck_tBlur,'Value',handles.tPrep_B);

% <Default Setting : Task Selection on CVR>
handles.TR=3;handles.TaskReps=70;
guidata(hObject, handles);
BtnOff(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
PlotTDiagram(hObject, eventdata, handles)
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)

function WinLvl(~, ~, handles)
hFig=handles.Fig_CVRMapping;
G=get(hFig,'userdata');
set(hFig,'userdata',G);
set(hFig,'WindowButtonMotionFcn',{@AxMap_MouseMoveFcn,handles});
% set(hFig,'WindowButtonDownFcn',{@AxtMap_ButtonDownFcn,handles})
% set(hFig,'WindowButtonUpFcn',{@WBUFcn,handles}) 

function AxMap_MouseMoveFcn(hObject, eventdata, handles)
global SeedXYZV IDX_flipUD 
if (exist(handles.pT1,'file')==2)
    if strcmp(handles.ClickLR,'L')
        C = round(get (handles.AxfMap, 'CurrentPoint'));C = round(C(1,1:2));
        Crs = round(get (handles.AxcvrMap, 'CurrentPoint'));Crs = round(Crs(1,1:2));       
        SliceZ=round(get(handles.Sd_SliceZ, 'Value'));
        

        if (IDX_flipUD==1)
            MapTEMP=flipud( handles.MtxT1(:,:,SliceZ)');
        else
            MapTEMP=( handles.MtxT1(:,:,SliceZ)');
        end
        
%         
%          if (C(1)>0) && (C(1)<size(handles.MtxT1,2)) && (C(2)>0) && (C(2)<size(handles.MtxT1,1))
%              IDX_SHOWXYZ='O';
%              COORD=C;
%          elseif (Crs(1)>0) && (Crs(1)<size(handles.MtxT1,2)) && (Crs(2)>0) && (Crs(2)<size(handles.MtxT1,1))
%              IDX_SHOWXYZ='O';
%              COORD=Crs;
%          else
%              IDX_SHOWXYZ='X';
%          end
         
         
         if (C(1)>0) && (C(1)<size(MapTEMP,2)) && (C(2)>0) && (C(2)<size(MapTEMP,1))
             IDX_SHOWXYZ='O';
             COORD=C;
         elseif (Crs(1)>0) && (Crs(1)<size(MapTEMP,2)) && (Crs(2)>0) && (Crs(2)<size(MapTEMP,1))
             IDX_SHOWXYZ='O';
             COORD=Crs;
         else
             IDX_SHOWXYZ='X';
         end

         if strcmp(IDX_SHOWXYZ,'O')
             if (exist(handles.pfMap,'file')==2) && ~(exist(handles.pcvrMap,'file')==2)
                 if (IDX_flipUD==1)
                     ZMap=round(100*flipud(handles.MtxfMap(:,:,SliceZ)'))/100;
                 else
                     ZMap=round(100*(handles.MtxfMap(:,:,SliceZ)'))/100;
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
            elseif ~(exist(handles.pfMap,'file')==2) && (exist(handles.pcvrMap,'file')==2)
                 if (IDX_flipUD==1)
                     ZMap=round(100*flipud(handles.MtxcvrMap(:,:,SliceZ)'))/100;
                 else
                     ZMap=round(100*(handles.MtxcvrMap(:,:,SliceZ)'))/100;
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
         
             elseif (exist(handles.pfMap,'file')==2) && (exist(handles.pcvrMap,'file')==2)
                 if (IDX_flipUD==1)
                     ZMap=round(100*flipud(handles.MtxfMap(:,:,SliceZ)'))/100;
                     RSMap=round(100*flipud(handles.MtxcvrMap(:,:,SliceZ)'))/100;
                 else
                     ZMap=round(100*(handles.MtxfMap(:,:,SliceZ)'))/100;
                     RSMap=round(100*(handles.MtxcvrMap(:,:,SliceZ)'))/100;
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1)) RSMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4)) ', ' sprintf('%3.2f',CurrentXYZV(5))];
             else
                 if (IDX_flipUD==1)
                     ZMap=flipud( handles.MtxT1(:,:,SliceZ)');
                 else
                     ZMap=( handles.MtxT1(:,:,SliceZ)');
                 end
                 CurrentXYZV=[COORD SliceZ ZMap(COORD(2),COORD(1))];
                 PNT_CurrentXYZV=[sprintf('%3.3d',CurrentXYZV(1)) ', ' sprintf('%3.3d',CurrentXYZV(2)) ', ' sprintf('%3.3d',CurrentXYZV(3)) ', ' sprintf('%3.2f',CurrentXYZV(4))];
             end
             
             if ~isempty(SeedXYZV)
                 PNT_SeedXYZV=[sprintf('%3.3d',SeedXYZV(1)) ', ' sprintf('%3.3d',SeedXYZV(2)) ', ' sprintf('%3.3d',SeedXYZV(3)) ', ' sprintf('%3.2f',SeedXYZV(4))];
                 
                 if (exist(handles.pfMap,'file')==2) && (exist(handles.pcvrMap,'file')==2)
                     set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value(t)] = [' PNT_SeedXYZV '];  '...
                         'Current @ [x,y,z,value(fmap), value(CVR)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 elseif (exist(handles.pfMap,'file')==2) && ~(exist(handles.pcvrMap,'file')==2)
                     set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value(t)] = [' PNT_SeedXYZV '];  '...
                         'Current @ [x,y,z,value(fmap)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 elseif ~(exist(handles.pfMap,'file')==2) && (exist(handles.pcvrMap,'file')==2)
                     set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value(t)] = [' PNT_SeedXYZV '];  '...
                         'Current @ [x,y,z, value(CVR)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 else
                     set(handles.Tx_Message,'string',['>> Seed @ [x,y,z,value] = [' PNT_SeedXYZV '];  '...
                         'Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 end     
             else
                 if (exist(handles.pfMap,'file')==2) && (exist(handles.pcvrMap,'file')==2)
                     set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value(fmap), value(CVR)] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 else
                     set(handles.Tx_Message,'string',['>> Current @ [x,y,z,value] = [' PNT_CurrentXYZV  ']'],'ForegroundColor',[0 0 0]);
                 end
             end    
         end
    end
end


function Cal_MtxT1M(hObject, eventdata, handles)
global ImSetUlay ImSetUlay_BU MtxT1M IDX_flipUD
MtxT1M=handles.MtxT1; % M: Modulated
if (sum(ImSetUlay==ImSetUlay_BU)<2)
    MtxT1M(MtxT1M<ImSetUlay(1))=ImSetUlay(1);
    MtxT1M(MtxT1M>ImSetUlay(2))=ImSetUlay(2);
end
if (IDX_flipUD==1)
    MtxT1M=flipud(permute(MtxT1M(:,:,:), [2 1 3]));
else
    MtxT1M=(permute(MtxT1M(:,:,:), [2 1 3]));
end

function Cal_MtxRGB(hObject, eventdata, handles)
global ImSetUlay ImSetUlay_BU ImSetOlay ImSetOlay_BU ImSetOlayCVR ImSetOlayCVR_BU CMap_BU 
global fMap_RGB cvrMap_RGB MtxT1M IDX_flipUD IDX_fusion

MtxT1M=handles.MtxT1; % M: Modulated
if (sum(ImSetUlay==ImSetUlay_BU)<2) || (sum(ImSetOlay==ImSetOlay_BU)<3) || (sum(ImSetOlayCVR==ImSetOlayCVR_BU)<3) || ~strcmp(CMap_BU,handles.CMap) 
    MtxT1M(MtxT1M<ImSetUlay(1))=ImSetUlay(1);
    MtxT1M(MtxT1M>ImSetUlay(2))=ImSetUlay(2);
end
% <Re-Calcuate RGB : f Map>
if (sum(ImSetUlay==ImSetUlay_BU)<2) || (sum(ImSetOlay==ImSetOlay_BU)<3) || ~strcmp(CMap_BU,handles.CMap) || (IDX_fusion==1)
    %if (IDX_OLayT<5) || ~strcmp(CMap_BU,handles.CMap)
    if (IDX_fusion==1) && (isfield(handles,'MtxfMap')==1) && (isfield(handles,'MtxcvrMap')==1)
        [fMap_RGB]=Fn_fMRIConf(MtxT1M,handles.MtxfMap,handles.MtxcvrMap,ImSetOlay,ImSetOlayCVR,'n','n',handles.CMap);
    else
         if ~(isfield(handles,'MtxfMap')==1)
            MtxfMap=MtxT1M;MtxfMap(:)=0;
         else
            MtxfMap=handles.MtxfMap;
         end
         [fMap_RGB]=Fn_OLay2RGB(MtxT1M,MtxfMap,ImSetOlay,'n','n',handles.CMap);
    end
    ImSetOlay_BU=ImSetOlay;CMap_BU=handles.CMap;
    if (IDX_flipUD==1)
        fMap_RGB=flipud(permute(fMap_RGB, [2 1 3 4]));
    else
        fMap_RGB=(permute(fMap_RGB, [2 1 3 4]));
    end
end
if (sum(ImSetUlay==ImSetUlay_BU)<2) || (sum(ImSetOlayCVR==ImSetOlayCVR_BU)<3) || ~strcmp(CMap_BU,handles.CMap)
%     || (IDX_NewSeed==1)
    if ~(exist(handles.pcvrMap,'file')==2)
        MtxcvrMap=MtxT1M;MtxcvrMap(:)=0;
    else
        MtxcvrMap=handles.MtxcvrMap;
    end
    [cvrMap_RGB]=Fn_OLay2RGB(MtxT1M,MtxcvrMap,ImSetOlayCVR,'n','n',handles.CMap);
    ImSetOlayCVR_BU=ImSetOlayCVR;CMap_BU=handles.CMap;
    if (IDX_flipUD==1)
        cvrMap_RGB=flipud(permute(cvrMap_RGB, [2 1 3 4]));
    else
        cvrMap_RGB=(permute(cvrMap_RGB, [2 1 3 4]));
    end
end

function [handles]=DispCase(hObject, eventdata, handles)
if ~(exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxfMap')==1) && ~(isfield(handles,'MtxcvrMap')==1)
    handles.DispCase=0;
elseif (exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxfMap')==1) && ~(isfield(handles,'MtxcvrMap')==1)
    handles.DispCase=1;
    Cal_MtxT1M(hObject, eventdata, handles);
elseif (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxfMap')==1) && ~(isfield(handles,'MtxcvrMap')==1)
    handles.DispCase=2;
%     global ImSetOlayCVR ImSetUlay
%     ImSetOlayCVR=[ImSetUlay 1];BtnSetting(hObject, eventdata, handles)
    Cal_MtxRGB(hObject, eventdata, handles);
elseif (exist(handles.pT1,'file')==2) && ~(isfield(handles,'MtxfMap')==1) && (isfield(handles,'MtxcvrMap')==1)
    handles.DispCase=2;
%     global ImSetOlay ImSetUlay
%     ImSetOlay=[ImSetUlay 1];BtnSetting(hObject, eventdata, handles);
    Cal_MtxRGB(hObject, eventdata, handles);
elseif (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxfMap')==1) && (isfield(handles,'MtxcvrMap')==1)
    handles.DispCase=2;
    Cal_MtxRGB(hObject, eventdata, handles);
end
guidata(hObject, handles);


function DispIm(hObject, eventdata, handles)
global SeedXYZV ImSetUlay ImSetOlayCVR  
global fMap_RGB cvrMap_RGB 
global IDX_flipUD IDX_fusion
global MtxT1M
SliceZ=str2double(get(handles.Ed_SliceZ,'string'));
switch handles.DispCase
    case 0
        imshow(  zeros(256,256),[0 5000],'Parent',handles.AxfMap);
        imshow(  zeros(256,256),[0 5000],'Parent',handles.AxcvrMap);
    case 1
        imshow( squeeze(MtxT1M(:,:,SliceZ)),ImSetUlay,'Parent',handles.AxfMap);
        imshow( squeeze(MtxT1M(:,:,SliceZ)),ImSetUlay,'Parent',handles.AxcvrMap);
        WinLvl(hObject, eventdata, handles)
    case 2
        imshow(squeeze(fMap_RGB(:,:,SliceZ,:)),'Parent',handles.AxfMap);
        imshow(squeeze(cvrMap_RGB(:,:,SliceZ,:)),'Parent',handles.AxcvrMap);
        WinLvl(hObject, eventdata, handles)
        
        if (IDX_fusion==1) && (isfield(handles,'MtxfMap')==1) && (isfield(handles,'MtxcvrMap')==1)
            D3CVR_Thr=(handles.MtxcvrMap>ImSetOlayCVR(1));
            hold(handles.AxfMap,'on');
            if (IDX_flipUD==1)
                ImCVRMsk=flipud(squeeze(D3CVR_Thr(:,:,SliceZ))');
            else
                ImCVRMsk=(squeeze(D3CVR_Thr(:,:,SliceZ))');
            end
            [B,L]=bwboundaries(ImCVRMsk);
            for k=1:length(B)
                boundary=B{k};
                plot(boundary(:,2),boundary(:,1),'color',[0 32 96]/256,'LineWidth',1,'Parent',handles.AxfMap);
            end
        end
        
        
        
%         if ~isempty(SeedXYZV)
%             if (isfield(handles,'MtxSeed')==1) && (IDX_sPreview==1)
%                 hold(handles.AxtMap,'on');hold(handles.AxcvrMap,'on');
%                 if (IDX_flipUD==1)
%                     ImSeed=flipud(squeeze(handles.MtxSeed(:,:,SliceZ))');
%                 else
%                     ImSeed=(squeeze(handles.MtxSeed(:,:,SliceZ))');
%                 end
%                 [BB,LL]=bwboundaries(ImSeed,'noholes');
%                 for kk=1:length(BB)
%                     boundary2=BB{kk};
%                     plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',2,'Parent',handles.AxfMap);
%                     plot(boundary2(:,2),boundary2(:,1),'color',[0 0.7 1],'LineWidth',2,'Parent',handles.AxcvrMap);
%                 end
%                 if (SeedXYZV(3)==round(SliceZ))
%                     C=SeedXYZV;
%                     hold(handles.AxfMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxfMap);
%                 end
%             else
%                 if (SeedXYZV(3)==round(SliceZ))
%                     C=SeedXYZV;
%                     hold(handles.AxfMap,'on'); plot(C(1),C(2),'.','color',[0 0.7 1],'markersize', 20,'Parent',handles.AxfMap);
%                     hold(handles.AxcvrMap,'on'); plot(C(1),C(2),'.','color',[0 .7 1],'markersize', 20,'Parent',handles.AxcvrMap);
%                     %hold(handles.AxrsMap,'on'); plot(C(1),C(2),'.','color',[0 1 1],'markersize', 20,'Parent',handles.AxrsMap);
%                 end
%             end
%         end
        guidata(hObject, handles);
end    
BtnSetting(hObject, eventdata, handles)

%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%  [ Plot task fMRI Diagram ]
%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function PlotTDiagram(hObject, eventdata, handles)
global Idx_Execute Ls_Diagrams Idx_SvDiag
% <RRF Model>
if strcmp(handles.IRF,'RRF')
    t=0:1:60;IRF=0.6.*(t).^(2.1).*exp(-t/1.6)-0.0023.*t.^(3.54).*exp(-t/4.25);
else
    t=0:1:32;IRF = spm_hrf(1);
end
% RT = 0.5; hrf = spm_hrf(0.5); plot(0:RT:32, hrf);

% t=1:1:60;
% RRF=0.6.*(t-1).^(2.1).*exp(-(t-1)/1.6)-0.0023.*(t-1).^(3.54).*exp(-t/4.25);

% <Boxcar conv with RRF>
T=handles.TR;
Scans=handles.TaskReps;
% ts=[0:0.1:Scans*T]';

ts=[0:1:Scans*T]';
Onset=handles.Onset;
D=handles.Duration;
% delayVec=[0 10:20];
delayVec=handles.delayVec;
cla(handles.AxtProfile,'reset')

clear Ls_Diagrams;
xTicktmp=sort([Onset Onset+D]);
if (max(ts)>=max(xTicktmp))
    xTicktmp=[0 xTicktmp max(ts)];
    for d=1:numel(delayVec)
        % d=2;
        delay=delayVec(d);
        S=Onset+delay;
        TDiagram=zeros(numel(ts),1);
        
        for ss=1:numel(S)
            idx= (ts>=S(ss)) & (ts<=S(ss)+D(ss));
            TDiagram(idx)=ones(sum(idx),1);
        end
        
        pad_point=200;
        if strcmp(handles.IRF,'RRF')
            TDiagram_Ivt=999*ones(numel(ts),1);
            TDiagram_Ivt(TDiagram==0)=1;
            TDiagram_Ivt(TDiagram==1)=0;
            TDiagram_Ivt=[ones(pad_point,1);TDiagram_Ivt];
            TDiagram=TDiagram_Ivt;
        else
            TDiagram=[zeros(pad_point,1);TDiagram];
        end
        % DiagRRF=conv(TDiagram,RRF,'same');
        DiagRRF=conv(TDiagram,IRF);
        % DiagRRF= DiagRRF / max(abs([max(DiagRRF) min(DiagRRF)]));
        
        baseline=mean(DiagRRF(150:180));
%         if strcmp(handles.IRF,'RRF')
            TDiagram(1:pad_point)=[];
            DiagRRF(1:pad_point)=[];
%         end
        
        if (baseline>0)
            DiagRRF=DiagRRF-baseline;
        elseif (baseline<0)
            DiagRRF=DiagRRF+abs(baseline);
        end
            
        DiagRRF=DiagRRF(1:numel(TDiagram));
        
        t_ds=[0:T:(Scans-1)*T];
        %t_ds=[T:T:Scans*T];
        clear idx_tds
        for i=1:Scans
            idx_tds(i)=find(ts==t_ds(i));
        end
        DiagRRF_ds=DiagRRF(idx_tds);
        
        if (exist(handles.pTData,'file')==2)
            if (delay==0)
                Clr_TDiagRRF=[0 0 1];
                Clr_LineWidth=2;
            else
                %Clr_TDiagRRF=0.5*[1 1 1];
                Clr_TDiagRRF=[153 204 255]/255;
                Clr_LineWidth=1;
            end
        else
            Clr_TDiagRRF=0.7*[1 1 1];
            Clr_LineWidth=1;
        end
        
        plot(ts,1.5+TDiagram,'LineWidth',Clr_LineWidth,'Color',Clr_TDiagRRF,'Parent',handles.AxtProfile);
        %hold(handles.AxtProfile,'on');plot(ts,DiagRRF,'LineWidth',Clr_LineWidth,'Color',Clr_TDiagRRF,'Parent',handles.AxtProfile);
        %hold(handles.AxtProfile,'on');plot(t_ds,DiagRRF_ds,'LineWidth',Clr_LineWidth,'Color',Clr_TDiagRRF,'Parent',handles.AxtProfile);
        hold(handles.AxtProfile,'on');plot(t_ds,DiagRRF_ds/max(abs([max(DiagRRF_ds) min(DiagRRF_ds)])),'LineWidth',Clr_LineWidth,'Color',Clr_TDiagRRF,'Parent',handles.AxtProfile);
       
        if (Idx_SvDiag==1)
            if (d==1)
                fig=figure('Name','Diagram','units','pixels','position',[ 200   100   650   550],'visible','on','color',[1 1 1]);
            end
            findobj('Name','Diagram');plot(ts,1+TDiagram,'LineWidth',Clr_LineWidth,'Color',Clr_TDiagRRF);
            hold on;plot(t_ds,DiagRRF_ds/max(abs([max(DiagRRF_ds) min(DiagRRF_ds)])),'LineWidth',Clr_LineWidth,'Color',Clr_TDiagRRF);
        end
        
        if (delay<0)
            pnt_delay=sprintf('%03d',delay);pnt_delay=strrep(pnt_delay,'-','N');
        elseif (delay==0)
            pnt_delay=sprintf('%03d',delay);
        elseif (delay>0)
            pnt_delay=['P' sprintf('%02d',delay)];
        end
        Ls_Diagrams(:,d)=DiagRRF_ds;
        Ls_TDiagrams(:,d)=TDiagram(idx_tds);
        %     disp(['D' sprintf('%02d',d) '_' pnt_delay])
        %     dlmwrite(['1218807_RRF_' 'D' sprintf('%02d',d) '_' pnt_delay '.txt'],DiagRRF_ds,'delimiter','\t','precision','%.6f')
    end
    
    set(handles.AxtProfile,'xlim',[min(ts) max(ts)],'ylim',[-1.5 3])
    XYColor=0.2*ones(1,3);PlotColor=0.5*[1 1 1];
    set(handles.AxtProfile,'xtick',xTicktmp,'ytick',[-1.5:0.5:3],'XColor', XYColor);
    xlabel(handles.AxtProfile,'Time (s)')
    set(handles.AxtProfile,'XGrid','on','YGrid','off')
    set(handles.AxtProfile,'yticklabel',{'','','',handles.IRF,'','','OFF','','ON',''})
    
    if (Idx_SvDiag==1)
        hAxes = findobj(fig,'type','axes');
        set(hAxes,'xlim',[min(ts) max(ts)],'ylim',[-1.5 3])
        XYColor=0.2*ones(1,3);PlotColor=0.5*[1 1 1];
        set(hAxes,'xtick',xTicktmp,'ytick',[-1.5:0.5:3],'XColor', XYColor);
        xlabel(hAxes,'Time (s)')
        set(hAxes,'XGrid','on','YGrid','off')
        set(hAxes,'yticklabel',{'','','',handles.IRF,'','OFF','','ON','',''})
    end
    
    handles.Ls_TDiagrams=Ls_TDiagrams;
    handles.Ls_Diagrams=Ls_Diagrams; handles.t_ds=t_ds; guidata(hObject, handles);
    Idx_Execute=1;

else
    plot(ts,ones(numel(ts),1),'LineWidth',2,'Color',[1 0 0],'Parent',handles.AxtProfile);
    set(handles.Tx_Message,'string', ['>> The Data length and paradigm DOES NOT MATCH !' ],'foregroundcolor',[1 0 0])
    Idx_Execute=0;
end


function varargout = CVRMapping_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;
% ffig='IClinfMRI.fig';
% pfig=which(ffig);
% 
% if (exist(pfig,'file')==2)
%     [DirM,~,ext]=fileparts(pfig);
% else
%     error(['Can not find ".fig", please check Matlab path '])
% end
% 
% if isdir(DirM)
%     DirFn=[DirM filesep 'Fn'];
%     handles.DirFn=DirFn; guidata(hObject, handles);
% %     DirDemo=[DirM filesep 'DEMO'];
%     %addpath(genpath(DirFn))
%     addpath(DirFn)
%     addpath(DirM)
% %     cd(DirM)
% end
clc;
ffig='IClinfMRI.fig';
pfig=which(ffig);

if (exist(pfig,'file')==2)
    [DirM,~,ext]=fileparts(pfig);
else
    error(['Can Not find ".fig", please check Matlab path ']);
end

if isdir(DirM)
    DirFn=[DirM filesep 'Fn'];handles.DirFn=DirFn; guidata(hObject, handles);
    DirDemo=[DirM filesep 'DEMO'];
    addpath(genpath(DirFn))
    addpath(DirM)
end

if isdir(handles.DirFn) && (isunix)
    formatBasic ='cd %s \n bash %sFn_getenv.sh -t "y"';
    ts_setting = sprintf(formatBasic,[handles.DirFn],[handles.DirFn filesep]);
    [s,ts_rst]=system(ts_setting);
    if (numel(findstr(ts_rst,'[O]'))>=1)
        handles.Terminal=1;
        MsgAFNI=strrep(['; Library Setting:  ' ts_rst '!!! '], sprintf('\n'),' ');
    else
        handles.Terminal=0;
        MsgAFNI=strrep(['; Missing part of links, ' ts_rst '!!! '], sprintf('\n'),' ');
    end
else
    handles.Terminal=0;
    if ~(isunix)
        MsgAFNI=[',but this program must runs on Linux system'];
    elseif ~isdir(handles.DirFn)
        MsgAFNI=['; Missing the "Fn" folder, Please check !!! '];
    end
end

p_spm=which('spm.m');
if  ~(exist(p_spm, 'file')==2)
    MsgSPM='SPM is not detectd in PATH, Please add it! ';
    handles.SPM=0;
else
     MsgSPM='SPM is detected in the path';
     handles.SPM=1;
end
guidata(hObject, handles);

if (handles.SPM==1) && (handles.Terminal==1)
    set(handles.Tx_Message,'String',[MsgSPM ' ' MsgAFNI],'ForegroundColor',[0 0 1]);
else
    set(handles.Tx_Message,'String',[MsgSPM ' ' MsgAFNI],'ForegroundColor',[1 0 0]);
end

if (handles.SPM==1)
    BtnSetting(hObject, eventdata, handles);
    set(handles.Btn_tData,'Enable','on');
else
    BtnOff(hObject, eventdata, handles);
    set(handles.Btn_tData,'Enable','off');
end

function BtnOff(hObject, eventdata, handles)
Status_OffOn='off';FColor=0.5*ones(1,3);

set(handles.Tx_SliceZ,'ForegroundColor',FColor);
set(handles.Ed_SliceZ,'Enable',Status_OffOn)
set(handles.Sd_SliceZ,'Enable',Status_OffOn)

set(handles.Btn_tData,'Enable',Status_OffOn)
set(handles.Btn_T1,'Enable',Status_OffOn)
set(handles.Btn_HResEPI,'Enable',Status_OffOn)
set(handles.Btn_fRst,'Enable',Status_OffOn)
set(handles.Btn_cvrMap,'Enable',Status_OffOn)
set(handles.Btn_Anat,'Enable',Status_OffOn)
set(handles.Btn_Fusion,'Enable',Status_OffOn);


set(handles.Tx_TR,'ForegroundColor',FColor);
set(handles.Ed_TR,'Enable',Status_OffOn);
set(handles.Ck_DftTPrep,'Enable',Status_OffOn);
set(handles.Btn_ExecuteTask,'Enable',Status_OffOn)

%||-----------------------------------------------------------------------|
%||	[ Task Paradiam Setting ]
%||-----------------------------------------------------------------------|
set(handles.Tx_Onset,'ForegroundColor',FColor);
set(handles.Tx_Duration,'ForegroundColor',FColor);
set(handles.Tx_Delay,'ForegroundColor',FColor);

set(handles.Ed_tOnset,'Enable',Status_OffOn)
set(handles.Ed_tDuration,'Enable',Status_OffOn)
set(handles.Ed_tDelay,'Enable',Status_OffOn)

set(handles.Tx_tData,'ForegroundColor',FColor);
set(handles.Pnl_taskSetting,'ForegroundColor',FColor);
set(handles.Pnl_taskPrep,'ForegroundColor',FColor);

set(handles.PMenu_IRF,'Enable',Status_OffOn);

%||-----------------------------------------------------------------------|
%||	[ Task Processing Setting ]
%||-----------------------------------------------------------------------|

set(handles.Ck_tSliceT,'Enable',Status_OffOn);
set(handles.Tx_SliceTime1,'ForegroundColor',0.5*ones(1,3));
set(handles.Tx_SliceTime2,'ForegroundColor',0.5*ones(1,3));
set(handles.PMenu_SliceTime,'Enable',Status_OffOn);

set(handles.Ck_tMCRT,'Enable',Status_OffOn);
set(handles.Ck_tFMCRT,'Enable',Status_OffOn);
set(handles.Ck_tDDdnt,'Enable',Status_OffOn);
set(handles.Ck_Despike,'Enable',Status_OffOn);
set(handles.Ck_tBlur,'Enable',Status_OffOn);
set(handles.Ck_Coreg,'Enable',Status_OffOn);
set(handles.PMenu_Regmm,'Enable',Status_OffOn);
set(handles.BtnGrp_Reg,'ForegroundColor',FColor);
set(handles.RBtn_BBR,'Enable',Status_OffOn)
set(handles.RBtn_CBR,'Enable',Status_OffOn);
set(handles.RBtn_IBR,'Enable',Status_OffOn);
set(handles.Ed_FWHM,'Enable',Status_OffOn);
set(handles.Tx_FWHM,'ForegroundColor',FColor);


%||-----------------------------------------------------------------------|
%||	[ Window/level Control Setting ]
%||-----------------------------------------------------------------------|
% < Anatomy Setting>
set(handles.Pnl_aSetting,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'ForegroundColor',FColor);
set(handles.Tx_aWMax,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'Enable',Status_OffOn);
set(handles.Tx_aWMax,'Enable',Status_OffOn);
set(handles.Ed_aWmin,'Enable',Status_OffOn);
set(handles.Ed_aWMax,'Enable',Status_OffOn);
% < Task Result Setting>
set(handles.Pnl_fRst,'ForegroundColor',FColor);
set(handles.Tx_fTH,'ForegroundColor',FColor);
set(handles.Tx_fWMax,'ForegroundColor',FColor);
set(handles.Tx_fOpt,'ForegroundColor',FColor);
set(handles.Ed_fTH,'Enable',Status_OffOn);
set(handles.Ed_fWMax,'Enable',Status_OffOn);
set(handles.Ed_fOpt,'Enable',Status_OffOn);
set(handles.Sd_fOpt,'Enable',Status_OffOn);
set(handles.Tx_AxfMap,'Visible',Status_OffOn);

% < Resting Result Setting>
set(handles.Pnl_cvrRst,'ForegroundColor',FColor);
set(handles.Tx_cTH,'ForegroundColor',FColor);
set(handles.Tx_cWMax,'ForegroundColor',FColor);
set(handles.Tx_cOpt,'ForegroundColor',FColor);
set(handles.Ed_cTH,'Enable',Status_OffOn);
set(handles.Ed_cWMax,'Enable',Status_OffOn);
set(handles.Ed_cOpt,'Enable',Status_OffOn);
set(handles.Sd_cOpt,'Enable',Status_OffOn);
set(handles.Tx_AxcvrMap,'Visible',Status_OffOn);

set(handles.PMenu_CMap,'Enable',Status_OffOn);
%||=======================================================================|
%|| [Button Setting]
%||=======================================================================|
function BtnSetting(hObject, eventdata, handles)
global Idx_Execute ImSetUlay ImSetOlay ImSetOlayCVR ImSetUlay_Buffer

switch get(handles.PMenu_Anats,'Value')
    case 1
         ImSetUlay_Buffer(1,:)=ImSetUlay;
    case 2
         ImSetUlay_Buffer(2,:)=ImSetUlay;
end

set(handles.Btn_tData,'Enable','on');

set(handles.Ed_aWmin, 'string',num2str(ImSetUlay(1)));
set(handles.Ed_aWMax, 'string',num2str(ImSetUlay(2)));

set(handles.Ed_fTH, 'string',num2str(ImSetOlay(1)));
set(handles.Ed_fWMax, 'string',num2str(ImSetOlay(2)));
set(handles.Ed_fOpt, 'string',num2str(ImSetOlay(3)));
set(handles.Sd_fOpt,'Value',ImSetOlay(3));

set(handles.Ed_cTH, 'string',num2str(ImSetOlayCVR(1)));
set(handles.Ed_cWMax, 'string',num2str(ImSetOlayCVR(2)));
set(handles.Ed_cOpt, 'string',num2str(ImSetOlayCVR(3)));
set(handles.Sd_cOpt,'Value',ImSetOlayCVR(3));
    


%||-----------------------------------------------------------------------|
%||	[ Default : X / O ]
%||-----------------------------------------------------------------------|
% <Task PreProcess : on / off >

if (exist(handles.pTData,'file')==2)
    set(handles.Tx_TR,'ForegroundColor',0*ones(1,3));
    set(handles.Ed_TR,'Enable','on');
else
    set(handles.Tx_TR,'ForegroundColor',0.5*ones(1,3));
    set(handles.Ed_TR,'Enable','off');
end 
%     &&(exist(handles.pT1,'file')==2)
if (exist(handles.pTData,'file')==2)
    Status_OffOn='on';FColor=0*ones(1,3);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end
set(handles.Ck_DftTPrep,'Enable',Status_OffOn);
set(handles.Btn_T1,'Enable',Status_OffOn);

%||-----------------------------------------------------------------------|
%||	[ Task Setting ]
%||-----------------------------------------------------------------------|
% set(handles.Tx_tName,'ForegroundColor',FColor);

set(handles.Tx_Onset,'ForegroundColor',FColor);
set(handles.Tx_Duration,'ForegroundColor',FColor);
set(handles.Tx_Delay,'ForegroundColor',FColor);

set(handles.Ed_tOnset,'Enable',Status_OffOn)
set(handles.Ed_tDuration,'Enable',Status_OffOn)
set(handles.Ed_tDelay,'Enable',Status_OffOn)
set(handles.PMenu_IRF,'Enable',Status_OffOn);


set(handles.Tx_tData,'ForegroundColor',FColor);
set(handles.Pnl_taskSetting,'ForegroundColor',FColor);
set(handles.Pnl_taskPrep,'ForegroundColor',FColor);

% if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2) 
if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2) && (Idx_Execute==1)
    Status_OffOn='on';FColor=0*ones(1,3);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end

set(handles.Btn_ExecuteTask,'Enable',Status_OffOn)
set(handles.Btn_HResEPI,'Enable',Status_OffOn)
set(handles.Btn_Anat,'Enable',Status_OffOn)
set(handles.Btn_fRst,'Enable',Status_OffOn)
set(handles.Btn_cvrMap,'Enable',Status_OffOn)

set(handles.Tx_SliceZ,'ForegroundColor',FColor);
set(handles.Ed_SliceZ,'Enable',Status_OffOn)
set(handles.Sd_SliceZ,'Enable',Status_OffOn)


%||-----------------------------------------------------------------------|
%||	[ Preprocessing ]
%||-----------------------------------------------------------------------|
% <The function belong to slice timing >
if (get(handles.Ck_DftTPrep,'Value')==0)
    Status_OffOn='on';FColor=0*ones(1,3);
else
    Status_OffOn='off';FColor=0.5*ones(1,3);
end

set(handles.Ck_tSliceT,'Enable',Status_OffOn);
% <The function belong to slice timing >
if  (get(handles.Ck_tSliceT,'Value')==1) && (get(handles.Ck_DftTPrep,'Value')==0)
    set(handles.Tx_SliceTime1,'ForegroundColor',0*ones(1,3));
    set(handles.Tx_SliceTime2,'ForegroundColor',0*ones(1,3));
    set(handles.PMenu_SliceTime,'Enable','on');
else
    set(handles.Tx_SliceTime1,'ForegroundColor',0.5*ones(1,3));
    set(handles.Tx_SliceTime2,'ForegroundColor',0.5*ones(1,3));
    set(handles.PMenu_SliceTime,'Enable','off');
end
% < Preprocessing:: Motion Correction >------------------------------------
set(handles.Ck_tMCRT,'Enable',Status_OffOn);
    if  (get(handles.Ck_tMCRT,'Value')==1) && (get(handles.Ck_DftTPrep,'Value')==0)
        set(handles.Ck_tMCRT,'ForegroundColor',0*ones(1,3));
    else
        set(handles.Ck_tMCRT,'ForegroundColor',0.5*ones(1,3));
    end
% set(handles.Ck_tMCRT,'Enable','off');
% set(handles.Ck_tMCRT,'Value',1);

set(handles.Ck_tFMCRT,'Enable','off');
set(handles.Ck_tFMCRT,'Value',0);
set(handles.Ck_Despike,'Enable','off');
set(handles.Ck_Despike,'Value',1);
set(handles.Ck_tDDdnt,'Enable',Status_OffOn);
set(handles.Ck_tBlur,'Enable',Status_OffOn);

set(handles.Ck_Coreg,'Enable','off');
set(handles.Ck_Coreg,'Value',1);
set(handles.PMenu_Regmm,'Enable',Status_OffOn);
set(handles.BtnGrp_Reg,'ForegroundColor',FColor);
% <RS Data && T1 && High Resolution EPI>
if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2) && (exist(handles.pHRepi,'file')==2)
    set(handles.RBtn_BBR,'Value',1)
    set(handles.RBtn_BBR,'Enable',Status_OffOn)
else
    set(handles.RBtn_BBR,'Enable','off')
end
set(handles.RBtn_CBR,'Enable',Status_OffOn);
set(handles.RBtn_IBR,'Enable',Status_OffOn);

set(handles.Ed_FWHM,'Enable',Status_OffOn);
set(handles.Tx_FWHM,'ForegroundColor',FColor);

%||-----------------------------------------------------------------------|
%||	[ Data Input ]
%||-----------------------------------------------------------------------|
% < Anatomy Setting>
if (exist(handles.pT1,'file')==2);Status_OffOn='on';FColor=0*ones(1,3);else Status_OffOn='off';FColor=0.5*ones(1,3);end
set(handles.Pnl_aSetting,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'ForegroundColor',FColor);
set(handles.Tx_aWMax,'ForegroundColor',FColor);
set(handles.Tx_aWmin,'Enable',Status_OffOn);
set(handles.Tx_aWMax,'Enable',Status_OffOn);
set(handles.Ed_aWmin,'Enable',Status_OffOn);
set(handles.Ed_aWMax,'Enable',Status_OffOn);

if (exist(handles.pAnat2T1, 'file')==2)
    set(handles.PMenu_Anats,'String',strvcat('T1','Other Anat'))
    set(handles.PMenu_Anats,'Enable','on');
    if (get(handles.PMenu_Anats,'Value')==1)
        PNT_Under='T1';
    else
        PNT_Under='Other Anat';
    end
else
    set(handles.PMenu_Anats,'Value',1);  PNT_Under='T1';
    set(handles.PMenu_Anats,'Enable','off');
end
set(handles.Tx_AxfMap,'Visible',Status_OffOn);
set(handles.Tx_AxcvrMap,'Visible',Status_OffOn);
set(handles.Tx_AxfMap,'String',PNT_Under);
set(handles.Tx_AxcvrMap,'String',PNT_Under);

% < Task Result Setting>
if (exist(handles.pfMap,'file')==2);Status_OffOn='on';FColor=0*ones(1,3);set(handles.Tx_AxfMap,'String',[PNT_Under ' + fMRI Map']);else Status_OffOn='off';FColor=0.5*ones(1,3);end
set(handles.Pnl_fRst,'ForegroundColor',FColor);
set(handles.Tx_fTH,'ForegroundColor',FColor);
set(handles.Tx_fWMax,'ForegroundColor',FColor);
set(handles.Tx_fOpt,'ForegroundColor',FColor);
set(handles.Ed_fTH,'Enable',Status_OffOn);
set(handles.Ed_fWMax,'Enable',Status_OffOn);
set(handles.Ed_fOpt,'Enable',Status_OffOn);
set(handles.Sd_fOpt,'Enable',Status_OffOn);
% set(handles.Tx_AxfMap,'Visible',Status_OffOn);
set(handles.PMenu_CMap,'Enable',Status_OffOn);
% < Resting Result Setting>
if (exist(handles.pcvrMap,'file')==2);Status_OffOn='on';FColor=0*ones(1,3);set(handles.Tx_AxcvrMap,'String',[PNT_Under '+ CVR Map ']);else Status_OffOn='off';FColor=0.5*ones(1,3);end
set(handles.Pnl_cvrRst,'ForegroundColor',FColor);
set(handles.Tx_cTH,'ForegroundColor',FColor);
set(handles.Tx_cWMax,'ForegroundColor',FColor);
set(handles.Tx_cOpt,'ForegroundColor',FColor);
set(handles.Ed_cTH,'Enable',Status_OffOn);
set(handles.Ed_cWMax,'Enable',Status_OffOn);
set(handles.Ed_cOpt,'Enable',Status_OffOn);
set(handles.Sd_cOpt,'Enable',Status_OffOn);
set(handles.PMenu_CMap,'Enable',Status_OffOn);
% set(handles.Tx_AxcvrMap,'Visible',Status_OffOn);

if (exist(handles.pfMap,'file')==2)&&(exist(handles.pcvrMap,'file')==2);Status_OffOn='on';else Status_OffOn='off';end
set(handles.Btn_Fusion,'Enable',Status_OffOn);

if (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxfMap')==1) && (isfield(handles,'MtxcvrMap')==1)
    set(handles.Tx_AxfMap,'String',[PNT_Under ' + fMRI Map + CVR Map' ])
end

%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function Btn_tData_Callback(hObject, eventdata, handles)
[handles]=BtnINI(hObject, eventdata, handles);
[fTData,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select fMRI data for CVR mapping',handles.DirW);pTData=[DirIn fTData];
if isequal(fTData,0) && isequal(DirIn,0) 
    set(handles.Tx_tData,'String','File is not selected!');
    % handles.pTData='';
    StrTime=['0 ~ ???'  ' seconds'];
    set(handles.Tx_Paradigm,'string',['Task Setting (#Vol= ??? ) >>> (' StrTime ')']);
%     set(handles.Pnl_taskSetting,'Title',['Task Setting (#Vol= ??? ) >>> (' StrTime ')']);
    set(handles.Tx_Message,'string',['>> Please select a 4D dataset.' ],'foregroundcolor',[1 0 0])
else
%     set(handles.Tx_tData,'String',fTData);
    handles.pTData=pTData;
    handles.DirT=DirIn;
%     StuTData=load_untouch_nii(pTData);
%  handles.DimT=size(StuTData.img);
    StuTData=nifti(pTData);
    handles.DimT=size(StuTData.dat);
   
    if (numel(handles.DimT)>3)
        if (handles.DimT(4)>0)
            handles.TR=StuTData.timing.tspace;
%     if (numel(size(StuTData.img))>3)
%         if (StuTData.hdr.dime.pixdim(5)>0)
%             handles.TR=StuTData.hdr.dime.pixdim(5);
            set(handles.Ed_TR,'String',num2str(handles.TR))
%             if (handles.TR>=3)
%                 %set(handles.PMenu_tName,'Value',4);
%                 set(handles.PMenu_tOnset,'Value',1);handles.Onset=handles.LsTDiagram(4).Onset;
%                 set(handles.PMenu_tDuration,'Value',1);handles.Duration=handles.LsTDiagram(4).Duration;
%             end
        end
%         handles.TaskReps=size(StuTData.img,4);
        handles.TaskReps=handles.DimT(4);
        Dim= [sprintf('%3.3d',handles.DimT(1)) 'x' sprintf('%3.3d',handles.DimT(2)) 'x' sprintf('%3.3d',handles.DimT(3)) 'x' sprintf('%3.3d',handles.DimT(4))];
        set(handles.Tx_tData,'String',['[' Dim '] ' fTData]);
%         TEND=(handles.TaskReps-1)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
        TEND=(handles.TaskReps)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
%         set(handles.Pnl_taskSetting,'Title',['Task Setting (#Vol=' num2str(handles.TaskReps) ') >>> (' StrTime ')']);
        set(handles.Tx_Paradigm,'string',['Task paradigm (#Vol=' num2str(handles.TaskReps) ') >>> (' StrTime ')'],'fontweight','bold');
        set(handles.Tx_Message,'string', ['>> ' ],'foregroundcolor',[0 0 0])
    else
        handles.pTData='';
        if isfield(handles,'DimT');handles = rmfield(handles,'DimT');end
        set(handles.Tx_Message,'string',['>> The selected data should be a 4D dataset, please check!' ],'foregroundcolor',[1 0 0])
    end

end
guidata(hObject, handles);
BtnSetting(hObject, eventdata, handles)
PlotTDiagram(hObject, eventdata, handles)

function PMenu_SliceTime_Callback(hObject, eventdata, handles)
function PMenu_SliceTime_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Ed_TR_Callback(hObject, eventdata, handles)

if ~isempty(str2num(get(handles.Ed_TR,'String')))
    handles.TR=get(handles.Ed_TR,'String');
    set(handles.Tx_Message,'string', ['>> Set TR to ' get(handles.Ed_TR,'String') 'sec' ],'foregroundcolor',[0 0 1])
    % TEND=(handles.TaskReps-1)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
    TEND=(handles.TaskReps)*handles.TR; StrTime=['0 ~ ' num2str(TEND) ' seconds'];
    set(handles.Pnl_taskSetting,'Title',['Task Setting (#Vol=' num2str(handles.TaskReps) ') >>> (' StrTime ')']);
    % handles.TaskReps
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_TR,'String') 'is not a number' ],'foregroundcolor',[1 0 0])
end
function Ed_TR_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_tOnset_Callback(hObject, eventdata, handles)
if ~isempty(str2num(get(handles.Ed_tOnset,'String')))
    handles.Onset=str2num(get(handles.Ed_tOnset,'String'));
    if ~(numel(handles.Onset)==numel(handles.Duration))
        handles.Duration=15*ones(size(handles.Onset));
        set(handles.Ed_tDuration,'String',['[' num2str(handles.Duration) ']'])
    end
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
    BtnSetting(hObject, eventdata, handles)
    
    set(handles.Tx_Message,'string', ['>> Set ONSET to ' get(handles.Ed_tOnset,'String') ' sec(s)' ],'foregroundcolor',[0 0 1])
    
    if isempty(str2num(get(handles.Ed_tDuration,'String')))
        set(handles.Ed_tDuration,'String','5');handles.Duration=5;
        set(handles.Tx_Message,'string', ['>> Set ONSET to ' get(handles.Ed_tOnset,'String') ' sec(s), but random assign DURATION to 15 sec(s), please check !' ],'foregroundcolor',[0 0 1])
    end

else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_tOnset,'String') 'is not a numerical array' ],'foregroundcolor',[1 0 0])
end

function Ed_tOnset_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_tDuration_Callback(hObject, eventdata, handles)
if ~isempty(str2num(get(handles.Ed_tDuration,'String')))
    handles.Duration=str2num(get(handles.Ed_tDuration,'String'));
    
    set(handles.Tx_Message,'string', ['>> Set DURATION to ' get(handles.Ed_tDuration,'String') 'sec' ],'foregroundcolor',[0 0 1])
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
    BtnSetting(hObject, eventdata, handles)
else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_tDuration,'String') 'is not a number' ],'foregroundcolor',[1 0 0])
    set(handles.Ed_tDuration,'String',num2str(handles.Duration))
end
function Ed_tDuration_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function PMenu_tName_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% function PMenu_tOnset_Callback(hObject, eventdata, handles)
% allItems = get(handles.PMenu_tOnset,'string');
% selectedIndex = get(handles.PMenu_tOnset,'Value');
% % selectedItem = allItems{selectedIndex};
% switch get(handles.PMenu_tOnset,'Value')
%     case 1
%         handles.Onset=str2num(allItems{1});
%     case 2
%         handles.Onset=str2num(allItems{2});
%     case 3
%         handles.Onset=5;
% end
% set(handles.Ed_tOnset,'String',num2str(handles.Onset));
% guidata(hObject, handles);
% PlotTDiagram(hObject, eventdata, handles)
% BtnSetting(hObject, eventdata, handles)
% 

% function PMenu_tOnset_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% function PMenu_tDuration_Callback(hObject, eventdata, handles)
% allItems = get(handles.PMenu_tDuration,'string');
% selectedIndex = get(handles.PMenu_tDuration,'Value');
% switch get(handles.PMenu_tDuration,'Value')
%     case 1
%         handles.Duration=str2num(allItems{1});
%     case 2
%         handles.Duration=str2num(allItems{2});
%     case 3
%         handles.Duration=5;
%         
% end
% set(handles.Ed_tDuration,'String',num2str(handles.Duration));
% guidata(hObject, handles);
% PlotTDiagram(hObject, eventdata, handles)
% BtnSetting(hObject, eventdata, handles)
% 
% function PMenu_tDuration_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% function Ed_tName_Callback(hObject, eventdata, handles)
% function Ed_tName_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
function Ck_DftTPrep_Callback(hObject, eventdata, handles)
if (get(handles.Ck_DftTPrep,'Value')==1)
    set(handles.Ck_tSliceT,'Value',handles.tPrep_T);
    set(handles.Ck_tMCRT,'Value',handles.tPrep_M);
    set(handles.Ck_tFMCRT,'Value',handles.tPrep_F);
    set(handles.Ck_Despike,'Value',1);
    set(handles.Ck_tDDdnt,'Value',handles.tPrep_D);
    set(handles.Ck_tBlur,'Value',handles.tPrep_B);
    
    handles.RegRSmm=2;set(handles.PMenu_Regmm,'Value',1);
    handles.FWHM=4;set(handles.Ed_FWHM,'String',num2str(handles.FWHM));
    set(handles.RBtn_CBR,'Value',1)
    set(handles.RBtn_BBR,'Value',0)
    set(handles.RBtn_IBR,'Value',0)
    set(handles.Tx_Message,'string',['>>> Using default setting' ],'foregroundcolor',[0 0 1])

end
guidata(hObject, handles);
BtnSetting(hObject, eventdata, handles)
function Ck_tSliceT_Callback(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)

function Ck_tMCRT_Callback(hObject, eventdata, handles)
function Ck_tFMCRT_Callback(hObject, eventdata, handles)
function Ck_tDDdnt_Callback(hObject, eventdata, handles)
function Ck_tBlur_Callback(hObject, eventdata, handles)

% --- Executes on button press in Btn_ExecuteTask.
function Btn_ExecuteTask_Callback(hObject, eventdata, handles)
global Idx_Execute Idx_SvDiag

% handles.Ls_Diagrams=Ls_Diagrams; handles.t_ds=t_ds; guidata(hObject, handles);

[DirF,FN,ext] = fileparts(handles.pTData);FN=[FN ext];
FN=strrep(FN,'.nii.gz','');FN=strrep(FN,'.nii','');

Idx=findstr(FN,'_');ID=FN(1:Idx(1)-1);Cnd=FN(Idx(1)+1:end);
handles.Condition=Cnd;

% <Create Dir for Log file>
Dir_Log=[DirF filesep '0_LOG_files'];
if ~(exist(Dir_Log, 'dir')==7);mkdir(Dir_Log);end

cd(Dir_Log);
if (exist('diary','file')==2);delete ('diary');end
if (exist('CVR_STATUS.txt','file')==2);delete ('CVR_STATUS.txt');end
diary CVR_STATUS.txt

p_Diary=[Dir_Log filesep '=M4=(LOG)=cvrMap=' FN '===D' datestr(now,'yymmdd_THHMMSS')  '_Detail.txt'];


% <Specify the Preprocessing step as the input for script>
PrepIDX=[ 'T' num2str(get(handles.Ck_tSliceT,'Value')) ';'...
    'M' num2str(get(handles.Ck_tMCRT,'Value')) ';'...
    'F' num2str(get(handles.Ck_tFMCRT,'Value')) ';'...
    'D' num2str(get(handles.Ck_tDDdnt,'Value')) ';'...
    'N0;'...
    'S' num2str(get(handles.Ck_tBlur,'Value')) ];

% <check whether the data has been processed already>
PNT_PREP='_';
if (get(handles.Ck_tSliceT,'Value')==1); PNT_PREP=[PNT_PREP 'T'];end
if (get(handles.Ck_tMCRT,'Value')==1); PNT_PREP=[PNT_PREP 'M'];end
if (get(handles.Ck_tMCRT,'Value')==0); PNT_PREP=[PNT_PREP 'A'];end
if (get(handles.Ck_tFMCRT,'Value')==1); PNT_PREP=[PNT_PREP 'F'];end
if (get(handles.Ck_tDDdnt,'Value')==1); PNT_PREP=[PNT_PREP 'D1'];end
if (get(handles.Ck_tDDdnt,'Value')==0); PNT_PREP=[PNT_PREP 'DK'];end
%PNT_PREP=[PNT_PREP 'N6'];
if (get(handles.Ck_tBlur,'Value')==1); PNT_PREP=[PNT_PREP 'S' num2str(handles.FWHM) 'mm'];end
f_Prep=[FN PNT_PREP '.nii.gz'];

% <Create Dir for processing>
if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2)
    Dir_Cnd=[DirF filesep Cnd];
    Dir_Cndtmp=[DirF filesep Cnd filesep 'Fd_Temp'];
    if ~(exist(Dir_Cnd, 'dir')==7);mkdir(Dir_Cnd);end
    if ~(exist(Dir_Cndtmp, 'dir')==7);mkdir(Dir_Cndtmp);end
end
% -------------------------------------------------------------------------
% ----------------------------------------------------<Start preprocessing>
h = waitbar(0,['Start preprocessing...']);
set(handles.Tx_Message,'string', ['>> Starting preprocessing ! Creating folders and checking files' ],'foregroundcolor',[0 0 1])
BtnOff(hObject, eventdata, handles);
% -------------------------------------------------------<Anat Coreg to T1>
if (exist(handles.pAnat,'file')==2) && (exist(handles.pT1,'file')==2)
    if ~(exist(handles.pAnat2T1, 'file')==2)
        waitbar(0.01,h,['[1/3] Aligning Anat to T1 usually takes 2 mins.']);
        set(handles.Tx_Message,'string', ['>> Aligning Anat to T1 usually takes 2 mins. Once completed, the next step will automatically initiate' ],'foregroundcolor',[0 0 1])
        %                  <0>              <1>     <2>     <3>
        formatCoReg ='bash %sFn_CoReg.sh -a "%s" -f "%s" -S "%s"';
        cmdStrCoReg = sprintf(formatCoReg,[handles.DirFn filesep],handles.pT1,handles.pAnat,handles.DirFn);
        %                                     <0>      ,  <1>  pT1 , <2> pFLAIR  ,<3> SDIR
        disp('|| ');disp('|| EXECUTE Bash CoReg');disp(['>>    ' cmdStrCoReg]);disp('|| ');
        pause(0.1)
        tstart = tic; system(cmdStrCoReg);telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for Coreg: ' num2str(telapsed) ' sec(s), or ' num2str(floor(telapsed/60)) ' min(s) ' num2str(telapsed-60*floor(telapsed/60)) ' sec(s)']); disp('|| ');
    else
        set(handles.Tx_Message,'string', ['>> Coreg btw Anat and T1 already exist !!' ],'foregroundcolor',[0 0 1])
        waitbar(0.07,h,['[1/3] Anat has aligned to T1 already.']);
    end
end
% -----------------------------------------------------------<Segmentation>
waitbar(0.07,h,['[2/3] Checking Segmentation files']);
p_spm=which('spm.m');
if (exist(p_spm, 'file')==2)
    
    % <Create Dir>
    Dir_Seg=[DirF filesep '2_T1Segment'];
    if ~(exist(Dir_Seg, 'dir')==7);mkdir(Dir_Seg);end;
    cd(Dir_Seg);
    
    
    fT1=handles.fT1;fT1=strrep(fT1,'.nii.gz','');fT1=strrep(fT1,'.nii','');fT1=strrep(fT1,'.img','');
    CkSeg=(exist([Dir_Seg filesep 'c1' fT1 '.nii'], 'file')==2)&&...
        (exist([Dir_Seg filesep 'c2' fT1 '.nii'], 'file')==2)&&...
        (exist([Dir_Seg filesep 'c3' fT1 '.nii'], 'file')==2)&&...
        (exist([Dir_Seg filesep 'c4' fT1 '.nii'], 'file')==2)&&...
        (exist([Dir_Seg filesep 'c5' fT1 '.nii'], 'file')==2)&&...
        (exist([Dir_Seg filesep 'c6' fT1 '.nii'], 'file')==2);
    
     pT1Nii=[Dir_Seg filesep fT1 '.nii'];
     if ~(exist(pT1Nii, 'file')==2)
         copyfile(handles.pT1,pT1Nii);

     end
    
    if (CkSeg==1)
        waitbar(0.15,h,['[2/3] Segmentated files already exist !!']);
        set(handles.Tx_Message,'string', ['>> Segmentated files already exist ! Move to the next processes step...' ],'foregroundcolor',[0 0 1])
        disp('|| ');disp('|| Segmentated file exist already !!');disp('|| ');
    else
        waitbar(0.11,h,['[2/3] Segmentation usually takes 5 mins.']);
        set(handles.Tx_Message,'string', ['>> Segmentation usually takes 5 mins. Once completed, the next step will automatically initiate' ],'foregroundcolor',[0 0 1])
        pause(0.01);
        disp('|| ');disp('|| Conducting Segmentation via SPM');disp('|| ');
        
        tstart = tic;
        addpath([handles.DirFn]);cd(Dir_Seg);Fn_batch_SPM12_Segment([fT1 '.nii']);
        telapsed = toc(tstart);
        cd(handles.pwd);
        disp('|| ');disp(['|| Segmentation lasts for: ' num2str(telapsed) ' sec, or ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec']);disp('|| ');
    end
else
    set(handles.Tx_Message,'String',['SPM is not detectd in PATH, Please add it !!! '],'ForegroundColor',[1 0 0]);
end
close(h)
% ---------------------------------------------------------<CVR Processing>
if (exist(handles.pTData,'file')==2) && (exist(handles.pT1,'file')==2) && (Idx_Execute==1)
    
    Onset=handles.Onset; pnt_Onset='';
    Duration=handles.Duration;
    delayVec=handles.delayVec;
    ddmin=num2str(min(delayVec));ddMax=num2str(max(delayVec));
    for s=1:numel(Onset)
        if (s==1); pnt_Onset=num2str(Onset(s));pnt_Dur=num2str(Duration(s));else pnt_Onset=[pnt_Onset '-' num2str(Onset(s))]; pnt_Dur=[pnt_Dur  '-' num2str(Duration(s))]; end
    end
    % <Delay Vector>
    DiffV=[9 delayVec(2:end)-delayVec(1:end-1)];
    for v=1:numel(delayVec)
        if (v==1)
            pnt_Delay=[num2str(delayVec(v))];
        elseif DiffV(v)>1
            pnt_Delay=[pnt_Delay '-' num2str(delayVec(v))];
        end
        
        if (DiffV(v)==1) && (v<numel(delayVec))
            if (DiffV(v+1)>1);pnt_Delay=[pnt_Delay '--' num2str(delayVec(v))];end
        elseif (DiffV(v)==1) && (v==numel(delayVec))
            pnt_Delay=[pnt_Delay '--' num2str(delayVec(v))];
        end
        
    end
    
    if (get(handles.RBtn_CBR,'Value')==1)
        RegM='CBR';
    elseif (get(handles.RBtn_IBR,'Value')==1)
        RegM='IBR';
    elseif  (get(handles.RBtn_BBR,'Value')==1)
        RegM='BBR';
    end
        
    fOptPSG=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '_Dur' pnt_Dur '_' num2str(numel(delayVec)) 'Delay' pnt_Delay '_Optimal_PSG%' RegM '_T1.nii'];
    %fOptTmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '-Dur' pnt_Dur '-' num2str(numel(delayVec)) 'Delay' ddmin '-' ddMax '_Optimal_Delays%T1.nii'];
    p_OptPSG=[Dir_Cnd filesep fOptPSG];

    
    fOptTmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '_Dur' pnt_Dur '_' num2str(numel(delayVec)) 'Delay' pnt_Delay '_Optimal_Tmap%' RegM '_T1.nii'];
    %fOptTmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '-Dur' pnt_Dur '-' num2str(numel(delayVec)) 'Delay' ddmin '-' ddMax '_Optimal_Delays%T1.nii'];
    p_OptTmap=[Dir_Cnd filesep fOptTmap];
    
    fOptDelaymap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '_Dur' pnt_Dur '_' num2str(numel(delayVec)) 'Delay' pnt_Delay '_Optimal_Delay%' RegM '_T1.nii'];
    %fOptTmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '-Dur' pnt_Dur '-' num2str(numel(delayVec)) 'Delay' ddmin '-' ddMax '_Optimal_Delays%T1.nii'];
    p_OptDelaymap=[Dir_Cnd filesep fOptDelaymap];
    
    fOptDelayTimemap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '_Dur' pnt_Dur '_' num2str(numel(delayVec)) 'Delay' pnt_Delay '_Optimal_DelayTime%' RegM '_T1.nii'];
    %fOptTmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '-Dur' pnt_Dur '-' num2str(numel(delayVec)) 'Delay' ddmin '-' ddMax '_Optimal_Delays%T1.nii'];
    p_OptDelayTimemap=[Dir_Cnd filesep fOptDelayTimemap];

    fOptPSGmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '_Dur' pnt_Dur '_' num2str(numel(delayVec)) 'Delay' pnt_Delay '_Optimal_PSG%' RegM '_T1.nii'];
    %fOptTmap=['GLM_' handles.IRF '_' FN PNT_PREP '_Onset' pnt_Onset '-Dur' pnt_Dur '-' num2str(numel(delayVec)) 'Delay' ddmin '-' ddMax '_Optimal_Delays%T1.nii'];
    p_OptPSGmap=[Dir_Cnd filesep fOptPSGmap];


    set(handles.Tx_Message,'string', ['>> The cvr-dataset processing ....' ],'foregroundcolor',[0 0 1]);
    
    % handles.Ls_TDiagrams=Ls_TDiagrams;handles.Ls_Diagrams=Ls_Diagrams; handles.t_ds=t_ds;
    % handles.Ls_Diagrams=Ls_Diagrams; handles.t_ds=t_ds; guidata(hObject, handles);
    if isfield(handles,'Ls_Diagrams') && ~(exist(p_OptTmap, 'file')==2)
        % saveas(handles.AxtProfile,[Dir_Cnd filesep 'Paradigm.tiff']);
        Idx_SvDiag=1;PlotTDiagram(hObject, eventdata, handles);
        Fig=findobj('Name','Diagram');saveas(Fig(1),[Dir_Cnd filesep 'Paradigm_' handles.IRF '_Onset' pnt_Onset '_Dur' pnt_Dur '_' num2str(numel(delayVec)) 'Delay' pnt_Delay '.tiff']);close(Fig);
      
        Idx_SvDiag=0;
        Ls_Diagrams=handles.Ls_Diagrams;
        tstart = tic;
        h = waitbar(0,['[3/3] Conduct CVR mappping with ' num2str(delayVec(1)) '~' num2str(delayVec(end)) '(s) delay ' ]);
        waitbar(1 / [size(Ls_Diagrams,2)+3]);
        for d=1:size(Ls_Diagrams,2)
            delay=delayVec(d);
            if (delay<0)
                pnt_delay=sprintf('%03d',delay);pnt_delay=strrep(pnt_delay,'-','N');
            elseif (delay==0)
                pnt_delay=sprintf('%03d',delay);
            elseif (delay>0)
                pnt_delay=['P' sprintf('%02d',delay)];
            end
            p_Status=[Dir_Log filesep '=M4=(LOG)=cvrMap=' FN '_RRFDelay' sprintf('%02d',d) '_' pnt_delay  '_Summary.txt'];
                       
            %p_Diagram=[Dir_Cndtmp filesep handles.IRF '_' FN '_Onset' pnt_Onset '_Dur' pnt_Dur '_Delay' sprintf('%02d',d) '_' pnt_delay '.txt'];
            p_Diagram=[Dir_Cndtmp filesep handles.IRF '_' FN '_Onset' pnt_Onset '_Dur' pnt_Dur '_Delay' '_' pnt_delay '.xmat.1D'];
            %p_Diagram=[Dir_Cndtmp filesep FN '_' 'RRFDelay' sprintf('%02d',d) '_' pnt_delay '.txt'];

            if ~(exist(p_Diagram,'file')==2);dlmwrite(p_Diagram, Ls_Diagrams(:,d),'delimiter','\t','precision','%.6f');end
            
            %               <0>         <1>                       <2>     <3>     <4>     <5>    <6>      <7>     <8>     <9>
            formatBasic ='cd %s \n bash %sFn_MDAS3_cvrPrep.sh -t "%s" -T "%s" -a "%s" -z "%s" -P "%s" -d "%s" -O "%s" -S "%s"';
            cmdStrBasic = sprintf(formatBasic,[Dir_Cnd],[handles.DirFn filesep],handles.pTData,num2str(handles.TR),handles.pT1,handles.tPattern,PrepIDX,[p_Diagram],[DirF],[handles.DirFn]);
            %                                   <0>    ,           <1>         ,<2> task Data ,       <3> TR      ,  <4>  pT1 ,  <5> tPattern  ,<6>PREP,<7>Diagram ,<8>DirOT,   <9>SDIR
            if  (get(handles.RBtn_CBR,'Value')==1)
                cmdStrReg=sprintf('%s -c "y"',cmdStrBasic);
            elseif (get(handles.RBtn_IBR,'Value')==1)
                cmdStrReg=sprintf('%s -c "n"',cmdStrBasic);
            elseif (get(handles.RBtn_BBR,'Value')==1)
                cmdStrReg=sprintf('%s -j "%s" -c "n"',cmdStrBasic,handles.pHRepi);
            end
            
            cmdStr=sprintf('%s | tee "%s"',cmdStrReg,p_Status);
            pause(0.01)
            disp('|| ');disp('|| EXECUTE Bash file');disp(['>>    ' cmdStr]);disp('|| ');
            p_GLMtmp=[Dir_Cnd filesep 'Fd_Temp' filesep 'GLM_' handles.IRF '_' FN PNT_PREP  '_' pnt_delay '.nii.gz'];
            
            %tstart = tic; system(cmdStr);telapsed = toc(tstart);
            if ~(exist(p_GLMtmp,'file')==2);
                system(cmdStr);
            else
                disp('||~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                disp(['>> Data Exist: ' p_GLMtmp]);
                disp('||~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
            end
            
            fname=dir([Dir_Cndtmp filesep handles.IRF '_' pnt_delay '%' RegM '_T1.nii']);
            p_Tmap=[Dir_Cndtmp filesep fname.name];
            
            fnamePSG=dir([Dir_Cndtmp filesep handles.IRF '_PSG_' pnt_delay '%' RegM '_T1.nii']);
            p_PSGmap=[Dir_Cndtmp filesep fnamePSG.name];
            if (exist(p_Tmap)==2)
                if (d==1)
                    TcatLs=p_Tmap;
                else
                    TcatLs=[TcatLs ' ' p_Tmap];
                end
            end
            
            if (exist(p_PSGmap)==2)
                if (d==1)
                    PSGcatLs=p_PSGmap;
                else
                    PSGcatLs=[PSGcatLs ' ' p_PSGmap];
                end
            end
            percentage=(d+1)/(size(Ls_Diagrams,2)+3);
            waitbar(percentage,h,['[3/3] CVR mappping with ' num2str(delayVec(d)) '(s) delay has been processed.' ]); pause(0.1);
        end
        % ----------------------------------------------------<Concatenate>
        disp('||~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
        disp(['>> Concatenate CVR maps with different delays ' ]);
        disp('||~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
        p_CatTmap=[Dir_Cndtmp filesep 'GLM_' handles.IRF '_All_' sprintf('%02d',size(Ls_Diagrams,2)) '_Onset' pnt_Onset '_Dur' pnt_Dur '_' FN PNT_PREP '%T1.nii'];
        cmdStrBasic=sprintf('rm -f %s\n3dTcat -relabel -prefix "%s" %s',[p_CatTmap],[p_CatTmap],[TcatLs]);
        system(cmdStrBasic);
        
        p_CatPSGmap=[Dir_Cndtmp filesep 'GLM_' handles.IRF '_All_PSG_' sprintf('%02d',size(Ls_Diagrams,2)) '_Onset' pnt_Onset '_Dur' pnt_Dur '_' FN PNT_PREP '%T1.nii'];
        cmdStrBasic=sprintf('rm -f %s\n3dTcat -relabel -prefix "%s" %s',[p_CatPSGmap],[p_CatPSGmap],[PSGcatLs]);
        system(cmdStrBasic);
        
        waitbar((d+2) / [size(Ls_Diagrams,2)+3],h,['Concatenate CVR maps with different delays']);
        % ---------------------------------------------<Select the Optimal>
        disp('||~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
        disp(['>> Select the optimal CVR map ' ]);
        disp('||~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
        if (exist(p_CatPSGmap)==2)
            cmdStrBasic=sprintf('rm -f %s\n3dTstat -max -prefix "%s" %s',[p_OptPSGmap],[p_OptPSGmap],[p_CatPSGmap]);
            system(cmdStrBasic);
        end
        
        if (exist(p_CatTmap)==2)
            %cmdStrBasic=sprintf('rm -f %s\n3dTstat -signed_absmax -prefix "%s" %s',[p_OptTmap],[p_OptTmap],[p_CatTmap]);
            cmdStrBasic=sprintf('rm -f %s\n3dTstat -max -prefix "%s" %s',[p_OptTmap],[p_OptTmap],[p_CatTmap]);
            system(cmdStrBasic);
          
            %cmdStrBasic=sprintf('rm -f %s\n3dTstat -argabsmax1 -prefix "%s" %s',[p_OptDelaymap],[p_OptDelaymap],[p_CatTmap]);
            cmdStrBasic=sprintf('rm -f %s\n3dTstat -max -prefix "%s" %s',[p_OptTmap],[p_OptTmap],[p_CatTmap]);
            system(cmdStrBasic);
            
            if (exist(p_OptDelaymap, 'file')==2)
                StuDelayMap=nifti(p_OptDelaymap);
                MtxDelayMap=(double(StuDelayMap.dat));
                MtxDelayTimeMap=-100*ones(size(MtxDelayMap));
                for d=1:size(Ls_Diagrams,2)
                     delay=delayVec(d);
                     MtxDelayTimeMap(MtxDelayMap(:)==d)=delay;
                end
                
                spmV=spm_vol(p_OptDelaymap);
                ima=spm_read_vols(spmV);
                ima=MtxDelayTimeMap(:,:,:);
                spmV.fname=p_OptDelayTimemap;
                spm_write_vol(spmV,ima);
                
                delete(p_OptDelaymap);
            end
        end
        
        cmdStrBasic=sprintf('rm -f %s %s',[Dir_Cnd filesep '3dDeconvolve.err'],[Dir_Cnd filesep '3dREMLfit.err'],[Dir_Cnd filesep 'Decon.REML_cmd']);
        system(cmdStrBasic);
        
        waitbar((d+3) / [size(Ls_Diagrams,2)+3],h,['Optimize CVR map']);
        close(h);
        
        telapsed = toc(tstart);
        disp('|| ');disp(['|| Computation time for task-dataset processing: ' num2str(telapsed) ' sec, or ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec']); disp('|| ');
        diary off
        
        cd(Dir_Log);
        if (exist('CVR_STATUS.txt')==2);
            movefile('CVR_STATUS.txt', p_Diary);
            Ls_Summary = dir([Dir_Log filesep '=M4=(LOG)=cvrMap=' FN '_RRFDelay*Summary.txt']);
            for f=1:numel(Ls_Summary)
                delete([Dir_Log filesep Ls_Summary(f).name ]);
            end
        end
        pause(0.01)
        set(handles.Tx_Message,'string', ['>> Done ! ' 'Computation time for task-dataset processing: ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec' ],'foregroundcolor',[0 0 1])
    end
    
    if (exist(p_OptTmap, 'file')==2)
        
        handles.pcvrMap=p_OptTmap;
        StucvrMap=nifti(p_OptTmap);
        handles.DimcvrMap=size(StucvrMap.dat);
        Mtxtemp=(double(StucvrMap.dat));
        Dim= [sprintf('%3.3d',handles.DimcvrMap(1)) 'x' sprintf('%3.3d',handles.DimcvrMap(2)) 'x' sprintf('%3.3d',handles.DimcvrMap(3))];

        handles.MtxcvrMap=Mtxtemp;
        set(handles.Tx_cvrMap,'String',['[' Dim '] ' fOptTmap],'foregroundcolor',[0 0 0]);
        
        global ImSetOlayCVR
        ImSetOlayCVR(1)=round(mean(handles.MtxcvrMap(:))*100)/100;
        if ImSetOlayCVR(1)<2
            ImSetOlayCVR(1)=2;
        end
        ImSetOlayCVR(2)=round((max(handles.MtxcvrMap(:))-std(handles.MtxcvrMap(:)))*100)/100;
        
%         guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
%         BtnOff(hObject, eventdata, handles);pause(0.01)
%         DispIm(hObject, eventdata, handles)
        
        h = waitbar(0.5,['Loading CVR Map']);%pause(0.01)
        guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading CVR Map']);close(h)

        
        
        
    end
    set(handles.Btn_tData,'Enable','on')
    set(handles.Btn_T1,'Enable','on')
    set(handles.Btn_HResEPI,'Enable','on')
    BtnSetting(hObject, eventdata, handles)

end

% function pushbutton6_Callback(hObject, eventdata, handles)
function Btn_T1_Callback(hObject, eventdata, handles)
[fT1,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select T1 anatomical data',handles.DirT);pT1=[DirIn fT1];
global ImSetUlay
if isequal(fT1,0) && isequal(DirIn,0) 
    set(handles.Tx_T1,'String','T1 anatomical data not selected!');
    handles.pT1='';
else
    handles.pT1=pT1;
%     StuT1=load_untouch_nii(pT1);
%     handles.DimT1=size(StuT1.img);
    StuT1=nifti(pT1);
    handles.DimT1=size(StuT1.dat);

    if (numel( handles.DimT1)>3)
        handles.pT1='';
        set(handles.Tx_T1,'String',['[#Vol=' num2str(handles.DimT1(4)) '] ' 'T1 data should not be a 4D Dataset, please check!']);
    else
        handles.pT1=pT1;
        handles.StuT1=StuT1;
        handles.fT1=fT1;
        Dim= [sprintf('%3.3d',handles.DimT1(1)) 'x' sprintf('%3.3d',handles.DimT1(2)) 'x' sprintf('%3.3d',handles.DimT1(3))];
  
        handles.qform=StuT1.mat;
        if (handles.qform(2,2)<0); IDX_flipUD=0;else IDX_flipUD=1; end

        set(handles.Tx_T1,'String',['[' Dim '] ' fT1]);
        handles.MtxT1=double(StuT1.dat);
        % <Initial Setting : Dir Z>
        numSteps=handles.DimT1(3);
        SliceZ=round(2*numSteps/3);% SliceZ = cell2mat(varargin(1));
        set(handles.Ed_SliceZ,'string',num2str(SliceZ));
        set(handles.Sd_SliceZ, 'min', 1); set(handles.Sd_SliceZ, 'max', numSteps);
        set(handles.Sd_SliceZ, 'Value', SliceZ); % Somewhere between max and min.
        set(handles.Sd_SliceZ, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
        % <Initial Setting : Adjust ImSetUlay>
        ImSetUlay=[min(min(handles.MtxT1(:,:,SliceZ))) round(0.8*max(max(handles.MtxT1(:,:,SliceZ))))];

    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
set(handles.Tx_Message,'String',['Loading & Displaying Images >>> '],'ForegroundColor',[1 0 0]); pause(0.1);

PlotTDiagram(hObject, eventdata, handles)
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles);BtnSetting(hObject, eventdata, handles);
set(handles.Tx_Message,'String',['>> '],'ForegroundColor',[0 0 0]); 

function Btn_HResEPI_Callback(hObject, eventdata, handles)

[fHRepi,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select high-resolution EPI for boundary-based registration',handles.DirT);pHRepi=[DirIn fHRepi];
if isequal(fHRepi,0) && isequal(DirIn,0) 
    set(handles.Tx_HRepi,'String','File not selected!');
    handles.pHRepi='';
else
    
    StuHRepi=nifti(pHRepi);
    handles.DimHRepi=size(StuHRepi.dat);

    DimT=handles.DimT(1)*handles.DimT(2)*handles.DimT(3);
%     Dim3DRS=handles.DimRS(1)*handles.DimRS(2)*handles.DimRS(3);
    Dim3DHRepi=handles.DimHRepi(1)*handles.DimHRepi(2)*handles.DimHRepi(3);
    Dim= [sprintf('%3.3d',handles.DimHRepi(1)) 'x' sprintf('%3.3d',handles.DimHRepi(2)) 'x' sprintf('%3.3d',handles.DimHRepi(3))];

    if (Dim3DHRepi<DimT)
        handles.pHRepi='';
        set(handles.Tx_HRepi,'String',[ 'The Dimenstion of high-resoultion EPI MUST LARGER THAN that of task-dataset']);
    else
        handles.pHRepi=pHRepi;
        set(handles.Tx_HRepi,'String',['[' Dim '] ' fHRepi]);   
    end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles)


% --- Executes on button press in Ck_Coreg.
function Ck_Coreg_Callback(hObject, eventdata, handles)
% hObject    handle to Ck_Coreg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Ck_Coreg



function Ed_FWHM_Callback(hObject, eventdata, handles)
FWHM=get(handles.Ed_FWHM, 'string');
if ~isnan(str2double(FWHM))
        handles.FWHM=[str2double(FWHM)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Set Smooth with ' FWHM 'mm FWHM'],'foregroundcolor',[0 0 0])
else
    set(handles.Ed_FWHM,'string',num2str(handles.FWHM))
    set(handles.Tx_Message,'string',['Check !!!   "' FWHM '"   is not a number !'],'foregroundcolor',[1 0 0])
end

function Ed_FWHM_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PMenu_Regmm_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_Regmm,'string');
selectedIndex = get(handles.PMenu_Regmm,'Value');
switch get(handles.PMenu_Regmm,'Value')
    case 1
        handles.RegRSmm=2;
    case 2
        handles.RegRSmm=3;
end
guidata(hObject, handles);
function PMenu_Regmm_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Btn_fRst_Callback(hObject, eventdata, handles)
[ffMap,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select task result as the prior knowledge',handles.DirT);pfMap=[DirIn ffMap];
if isequal(ffMap,0) && isequal(DirIn,0) 
    set(handles.Tx_fRst,'String','Data not selected!');
    handles.pfMap='';
    F='DimfMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
    F='MtxfMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
    handles.cAUTO=2;
else
    
    StufMap=nifti(pfMap);
    handles.DimfMap=size(StufMap.dat);
    
    Dim3DfMap=handles.DimfMap(1)*handles.DimfMap(2)*handles.DimfMap(3);
    Dim3DT1=handles.DimT1(1)*handles.DimT1(2)*handles.DimT1(3);
    Dim= [sprintf('%3.3d',handles.DimfMap(1)) 'x' sprintf('%3.3d',handles.DimfMap(2)) 'x' sprintf('%3.3d',handles.DimfMap(3))];

    if (Dim3DfMap==Dim3DT1)
        handles.pfMap=pfMap;
        Mtxtemp=(double(StufMap.dat));
        if (numel(size(Mtxtemp))==3)
            handles.MtxfMap=Mtxtemp;
            set(handles.Tx_fRst,'String',['[' Dim '] ' ffMap],'foregroundcolor',[0 0 0]);
          
            global ImSetOlay
            ImSetOlay(1)=round(mean(handles.MtxfMap(:))*100)/100;
            if ImSetOlay(1)<0.5
                ImSetOlay(1)=0.5;
            end
            ImSetOlay(2)=round((max(handles.MtxfMap(:))-std(handles.MtxfMap(:)))*100)/100;
        else
            handles.pfMap='';
            strDIM=strrep( num2str(size(Mtxtemp)),' ','x');
            strDIM=strrep(strDIM,'xxxx','x');strDIM=strrep(strDIM,'xxx','x');strDIM=strrep(strDIM,'xx','x');
            set(handles.Tx_tMap,'String',[ 'Dimenstion is [' strDIM '], choose the 3D image instead' ],'foregroundcolor',[1 0 0]);
        end
    else
        handles.pTMap='';
        set(handles.Tx_fRst,'String',[ 'The Dimenstion of functional result MUST at T1 Space'],'foregroundcolor',[1 0 0]);
    end
end
% [handles]=DispCase(hObject, eventdata, handles);
% guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
% % BtnOff(hObject, eventdata, handles);pause(0.1)
% DispIm(hObject, eventdata, handles)

h = waitbar(0.5,['Loading fMRI Map']);%pause(0.01)
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading fMRI Map']);close(h)




function Sd_SliceZ_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function Sd_SliceZ_Callback(hObject, eventdata, handles)
SliceZ=round( get(handles.Sd_SliceZ,'Value')); %disp(['SliceZ = ' num2str(SliceZ)])
set(handles.Ed_SliceZ,'string',num2str(SliceZ))

tstart = tic; 
DispIm(hObject, eventdata, handles)
telapsed = toc(tstart);


function Ed_SliceZ_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_SliceZ_Callback(hObject, eventdata, handles)
SliceZ=str2double( get(handles.Ed_SliceZ,'string'));
if ~isempty(SliceZ) SliceZ=round(SliceZ); end
set(handles.Ed_SliceZ,'string',num2str(SliceZ))
set(handles.Sd_SliceZ,'Value',SliceZ);
% tstart = tic; 
DispIm(hObject, eventdata, handles)
% telapsed = toc(tstart);
% disp(['||  lasts for: ' num2str(telapsed) ' sec, or ' num2str(floor(telapsed/60)) ' min ' num2str(telapsed-60*floor(telapsed/60)) ' sec']);

function Ed_fOpt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_fOpt_Callback(hObject, eventdata, handles)
global ImSetOlay
if isnan(str2double(get(handles.Ed_fOpt, 'string')))
    % set(handles.Ed_fOpt, 'string','0.8')
    set(handles.Tx_Message,'string',['"' get(handles.Ed_fOpt, 'string') '"is not a number '])
else
    ImSetOlay(3)=round(10*str2double(get(handles.Ed_fOpt, 'string')))/10;
    set(handles.Sd_fOpt,'Value',ImSetOlay(3));
    set(handles.Tx_Message,'string',['Set up Opacity to ' num2str(ImSetOlay(3))])
end

% BtnOff(hObject, eventdata, handles);pause(0.1)
% DispIm(hObject, eventdata, handles)
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)



function Ed_fWMax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_fWMax_Callback(hObject, eventdata, handles)
global ImSetOlay
StrMin=get(handles.Ed_fTH, 'string');
StrMax=get(handles.Ed_fWMax, 'string');

if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlay(2)=str2double(StrMax);
        set(handles.Tx_Message,'string',['Change Window(Max) to ' StrMax])
%         BtnOff(hObject, eventdata, handles);pause(0.1)
%         DispIm(hObject, eventdata, handles)
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
    else
        set(handles.Tx_Message,'string',['Check !!!  "Window(Max)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end

function Sd_fOpt_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function Sd_fOpt_Callback(hObject, eventdata, handles)
global ImSetOlay 
ImSetOlay(3)=round(10*get(handles.Sd_fOpt, 'Value'))/10;
set(handles.Sd_fOpt, 'Value',ImSetOlay(3))
set(handles.Ed_fOpt, 'string',num2str(ImSetOlay(3)))
set(handles.Tx_Message,'string',['Set up Opacity to ' num2str(ImSetOlay(3))])
% BtnOff(hObject, eventdata, handles);pause(0.1)
% DispIm(hObject, eventdata, handles)
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Ed_aWmin_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_aWmin_Callback(hObject, eventdata, handles)
global ImSetUlay
StrMin=get(handles.Ed_aWmin, 'string');
StrMax=get(handles.Ed_aWMax, 'string');

if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        ImSetUlay=[str2double(StrMin) str2double(StrMax)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Change anatomical window(Max) to ' StrMax])
%         DispIm(hObject, eventdata, handles)
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
    else
        set(handles.Tx_Message,'string',['Check !!!  "Max" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end

function Ed_aWMax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_aWMax_Callback(hObject, eventdata, handles)
global ImSetUlay
StrMin=get(handles.Ed_aWmin, 'string');
StrMax=get(handles.Ed_aWMax, 'string');

if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        ImSetUlay=[str2double(StrMin) str2double(StrMax)];guidata(hObject, handles);
        set(handles.Tx_Message,'string',['Change anatomical window(Max) to ' StrMax])
        
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)

%         DispIm(hObject, eventdata, handles)
    else
        set(handles.Tx_Message,'string',['Check !!!  "Max" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end


function Ed_cOpt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_cOpt_Callback(hObject, eventdata, handles)
global ImSetOlayCVR
if isnan(str2double(get(handles.Ed_cOpt, 'string')))
%     set(handles.Ed_cOpt, 'string','0.8')
set(handles.Tx_Message,'string',['"' get(handles.Ed_cOpt, 'string') '"is not a number '])
else
    ImSetOlayCVR(3)=round(10*str2double(get(handles.Ed_cOpt, 'string')))/10;
    set(handles.Sd_cOpt,'Value',ImSetOlayCVR(3));
end
set(handles.Tx_Message,'string',['Set up Opacity of CVR map to ' num2str(ImSetOlayCVR(3))])
% BtnOff(hObject, eventdata, handles);pause(0.1)
% DispIm(hObject, eventdata, handles)
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)


function Sd_cOpt_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function Sd_cOpt_Callback(hObject, eventdata, handles)
global ImSetOlayCVR
ImSetOlayCVR(3)=round(10*get(handles.Sd_cOpt, 'Value'))/10;
set(handles.Sd_cOpt, 'Value',ImSetOlayCVR(3))
set(handles.Ed_cOpt, 'string',num2str(ImSetOlayCVR(3)))
set(handles.Tx_Message,'string',['Set up Opacity of CVR Map to ' num2str(ImSetOlayCVR(3))])
% BtnOff(hObject, eventdata, handles);pause(0.1)
% DispIm(hObject, eventdata, handles)
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Ed_cWMax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_cWMax_Callback(hObject, eventdata, handles)
global ImSetOlayCVR
StrMin=get(handles.Ed_cTH, 'string');
StrMax=get(handles.Ed_cWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlayCVR(2)=str2double(StrMax);
        set(handles.Tx_Message,'string',['Change Window(Max) of CVR map to ' StrMax])
%         BtnOff(hObject, eventdata, handles);pause(0.1)
%         DispIm(hObject, eventdata, handles)
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
    else
        set(handles.Tx_Message,'string',['Check !!!  "Window(Max)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMax '"   is not a number !'])
end



function Ed_cTH_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_cTH_Callback(hObject, eventdata, handles)
global ImSetOlayCVR
StrMin=get(handles.Ed_cTH, 'string');
StrMax=get(handles.Ed_cWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlayCVR(1)=str2double(StrMin);
        set(handles.Tx_Message,'string',['Change Threshold of CVR map to ' StrMin])
%         BtnOff(hObject, eventdata, handles);pause(0.1)
%         DispIm(hObject, eventdata, handles)
        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)
    else
        set(handles.Tx_Message,'string',['Check !!!  "window(min)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMin '"   is not a number !'])
end

function PMenu_CMap_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function PMenu_CMap_Callback(hObject, eventdata, handles)
switch get(handles.PMenu_CMap,'Value')
    case 1
        handles.CMap='autumn';
    case 2
        handles.CMap='jet';
    case 3
        handles.CMap='bluehot';
end
guidata(hObject, handles);
% BtnOff(hObject, eventdata, handles);pause(0.1)
% DispIm(hObject, eventdata, handles)
h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading the Imaging Setting']);close(h)

function Ed_tDelay_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_tDelay_Callback(hObject, eventdata, handles)
if ~isempty(str2num(get(handles.Ed_tDelay,'String')))
    handles.delayVec=str2num(get(handles.Ed_tDelay,'String'));
    guidata(hObject, handles);
    PlotTDiagram(hObject, eventdata, handles)
    BtnSetting(hObject, eventdata, handles)
    
    set(handles.Tx_Message,'string', ['>> Set Delay to ' get(handles.Ed_tDelay,'String') ' sec(s)' ],'foregroundcolor',[0 0 1])
    
    if isempty(str2num(get(handles.Ed_tDelay,'String')))
        set(handles.Ed_tDelay,'String','[0]');handles.Ed_tDelay=0;
        set(handles.Tx_Message,'string', ['>> Set Delay to ' get(handles.Ed_tDelay,'String') ' sec(s) !' ],'foregroundcolor',[0 0 1])
    end

else
    set(handles.Tx_Message,'string', ['>>  ' get(handles.Ed_tDelay,'String') 'is not a numerical array' ],'foregroundcolor',[1 0 0])
end

function Ed_fTH_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function Ed_fTH_Callback(hObject, eventdata, handles)
global ImSetOlay
StrMin=get(handles.Ed_fTH, 'string');
StrMax=get(handles.Ed_fWMax, 'string');
if ~isnan(str2double(StrMin)) && ~isnan(str2double(StrMax))
    if (str2double(StrMin)<= str2double(StrMax))
        set(handles.Tx_Message,'string','Processing ...')
        ImSetOlay(1)=str2double(StrMin);
        set(handles.Tx_Message,'string',['Change Threshold to ' StrMin])
%         BtnOff(hObject, eventdata, handles);pause(0.1)
%         DispIm(hObject, eventdata, handles)

        h = waitbar(0.5,['Loading the Imaging Setting']);%pause(0.01)
        BtnOff(hObject, eventdata, handles);
        [handles]=DispCase(hObject, eventdata, handles);
        DispIm(hObject, eventdata, handles)
        waitbar(1,h,['Loading the Imaging Setting']);close(h)

    else
        set(handles.Tx_Message,'string',['Check !!!  "window(min)" have to lager than ' StrMin])
    end
else
    set(handles.Tx_Message,'string',['Check !!!   "' StrMin '"   is not a number !'])
end

function Tx_cvrMap_Callback(hObject, eventdata, handles)
function Tx_cvrMap_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[240 240 240]/255);
end

function Btn_cvrMap_Callback(hObject, eventdata, handles)
[fcvrMap,DirIn] = uigetfile({'*.nii;*.nii.gz;*.img'},'Select task result as the prior knowledge',handles.DirT);pcvrMap=[DirIn fcvrMap];
if isequal(fcvrMap,0) && isequal(DirIn,0) 
    set(handles.Tx_cvrMap,'String','Data not selected!');
    handles.pcvrMap='';
    F='DimcvrMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
    F='MtxcvrMap' ; if isfield(handles, F); handles = rmfield(handles,F);end
    handles.cAUTO=2;
else
    
    StucvrMap=nifti(pcvrMap);
    handles.DimcvrMap=size(StucvrMap.dat);
    
    Dim3DcvrMap=handles.DimcvrMap(1)*handles.DimcvrMap(2)*handles.DimcvrMap(3);
    Dim3DT1=handles.DimT1(1)*handles.DimT1(2)*handles.DimT1(3);
    Dim= [sprintf('%3.3d',handles.DimcvrMap(1)) 'x' sprintf('%3.3d',handles.DimcvrMap(2)) 'x' sprintf('%3.3d',handles.DimcvrMap(3))];

    if (Dim3DcvrMap==Dim3DT1)
        handles.pcvrMap=pcvrMap;
        Mtxtemp=(double(StucvrMap.dat));
        if (numel(size(Mtxtemp))==3)
            handles.MtxcvrMap=Mtxtemp;
            set(handles.Tx_cvrMap,'String',['[' Dim '] ' fcvrMap],'foregroundcolor',[0 0 0]);
          
            global ImSetOlayCVR
            ImSetOlayCVR(1)=round(mean(handles.MtxcvrMap(:))*100)/100;
            if ImSetOlayCVR(1)<0.5
                ImSetOlayCVR(1)=0.5;
            end
            ImSetOlayCVR(2)=round((max(handles.MtxcvrMap(:))-std(handles.MtxcvrMap(:)))*100)/100;
            % fcvrMap='GLM_HRF_BM021_CVR_MS4mm_Onset22-76-120-166_Dur10-8-10-14_7Delay0-10--15_Optimal_Delays%T1.nii'
            if ~isempty(findstr(fcvrMap,'GLM_')) && ~isempty(findstr(fcvrMap,'Onset'))
                idx_us=findstr(fcvrMap,'_');
                
                if numel(idx_us)>4
                     %<IRF>
                     IRF=fcvrMap(idx_us(1)+1:idx_us(2)-1);
                     handles.IRF=IRF;
                     if strcmp(IRF,'HRF'); set(handles.PMenu_IRF,'Value',2);else set(handles.PMenu_IRF,'Value',1);end
                     %<Onset>
                     idx_ini=findstr(fcvrMap,'Onset')+numel('Onset');
                     strtmp=fcvrMap(idx_ini:end);idx_end=findstr(strtmp,'_')-1;
                     strtmp=strtmp(1:idx_end(1));
                     Onset=str2num(strrep(strtmp,'-',' '));
                     handles.Onset=Onset;
                     set(handles.Ed_tOnset,'String',['[' num2str(Onset) ']'])
                     %<Dur>
                     idx_ini=findstr(fcvrMap,'Dur')+numel('Dur');
                     strtmp=fcvrMap(idx_ini:end);idx_end=findstr(strtmp,'_')-1;
                     strtmp=strtmp(1:idx_end(1));
                     Dur=str2num(strrep(strtmp,'-',' '));
                     handles.Duration=Dur;
                     set(handles.Ed_tDuration,'String',['[' num2str(Dur) ']'])
                     
                     %<Delay>
                     idx_ini=findstr(fcvrMap,'Delay')+numel('Delay');idx_ini=idx_ini(1);
                     strtmp=fcvrMap(idx_ini:end);idx_end=findstr(strtmp,'_')-1;
                     strtmp=strtmp(1:idx_end(1));
                     delaySTR=strrep(strtmp,'--',':'); delaySTR=strrep(delaySTR,'-',' ')
                     delaySTR=['[' delaySTR ']'];
                     delayVec=str2num(delaySTR);
                     set(handles.Ed_tDelay,'String',delaySTR)
                     handles.delayVec=delayVec;

                end
                guidata(hObject, handles);
                PlotTDiagram(hObject, eventdata, handles)
                BtnSetting(hObject, eventdata, handles)
                
                set(handles.Tx_Message,'string', ['>> Set ONSET to ' handles.Onset ' sec(s)' ],'foregroundcolor',[0 0 1])
                
                if isempty(str2num(get(handles.Ed_tDuration,'String')))
                    set(handles.Ed_tDuration,'String','5');handles.Duration=5;
                    set(handles.Tx_Message,'string', ['>> Set ONSET to ' get(handles.Ed_tOnset,'String') ' sec(s), but random assign DURATION to 15 sec(s), please check !' ],'foregroundcolor',[0 0 1])
                end
                
            end
            
        
        
        else
            handles.pcvrMap='';
            strDIM=strrep( num2str(size(Mtxtemp)),' ','x');
            strDIM=strrep(strDIM,'xxxx','x');strDIM=strrep(strDIM,'xxx','x');strDIM=strrep(strDIM,'xx','x');
            set(handles.Tx_cvrMap,'String',[ 'Dimenstion is [' strDIM '], choose the 3D image instead' ],'foregroundcolor',[1 0 0]);
        end
    else
        handles.pcvrMap='';
        set(handles.Tx_cvrMap,'String',[ 'The Dimenstion of functional result MUST at T1 Space'],'foregroundcolor',[1 0 0]);
    end
end

% guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
% BtnOff(hObject, eventdata, handles);pause(0.01)
% [handles]=DispCase(hObject, eventdata, handles);
% DispIm(hObject, eventdata, handles)

h = waitbar(0.5,['Loading CVR Map']);%pause(0.01)
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Loading CVR Map']);close(h)



function PMenu_Anats_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function PMenu_Anats_Callback(hObject, eventdata, handles)
global ImSetUlay_Buffer
global ImSetUlay 
SliceZ=round( get(handles.Sd_SliceZ,'Value')); %disp(['SliceZ = ' num2str(SliceZ)])
switch get(handles.PMenu_Anats,'Value')
    case 1
        Stutmp=nifti(handles.pT1);
        handles.MtxT1=double(Stutmp.dat);
        ImSetUlay= ImSetUlay_Buffer(1,:);
    case 2
        Stutmp=nifti(handles.pAnat2T1);
        handles.MtxT1=double(Stutmp.dat);
        if (size(ImSetUlay_Buffer,1)==1)
            ImTMP=squeeze(handles.MtxT1(:,:,SliceZ));
            ImSetUlay_Buffer(2,:)=[min(ImTMP(:)) round(2*max(ImTMP(:))/3)];
        end
        ImSetUlay= ImSetUlay_Buffer(2,:);
end
set(handles.Ed_aWmin,'string',num2str(ImSetUlay(1)))
set(handles.Ed_aWMax,'string',num2str(ImSetUlay(2)))
guidata(hObject, handles);% BtnSetting(hObject, eventdata, handles);
BtnOff(hObject, eventdata, handles);pause(0.01); 
[handles]=DispCase(hObject, eventdata, handles);
BtnSetting(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)

function Btn_Anat_Callback(hObject, eventdata, handles)
global IDX_flipUD
[fAnat,DirIn] = uigetfile({'*.nii;*.img'},'Select other anatomical data',handles.DirT);pAnat=[DirIn fAnat];
if isequal(fAnat,0) && isequal(DirIn,0)
    set(handles.Tx_Anat,'String','Anatomical data not selected!');
    handles.pAnat='';
else
    handles.pAnat=pAnat;
    fAnat2T1=strrep(fAnat,'.nii.gz',''); fAnat2T1=strrep(fAnat2T1,'.nii',''); fAnat2T1=strrep(fAnat2T1,'.img','');
    StuAnat=nifti(pAnat);
    if (numel(size(StuAnat.dat))>3)
        handles.pAnat='';
        handles.pAnat2T1='';
        set(handles.Tx_Anat,'String',['[#Vol=' num2str(size(StuAnat.img,4)) '] ' 'Anatomical data should not be a 4D dataset, please check!']);
    else
        handles.pAnat=pAnat;
        handles.fAnat=fAnat;
        DimAnat=size(StuAnat.dat);
        Dim= [sprintf('%3.3d',DimAnat(1)) 'x' sprintf('%3.3d',DimAnat(2)) 'x' sprintf('%3.3d',DimAnat(3))];
        
        set(handles.Tx_Anat,'String',['[' Dim '] ' fAnat]);
        if (sum(handles.DimT1==DimAnat)==3)
         pAnat2T1=pAnat;
        else
          pAnat2T1=[DirIn fAnat2T1 '%T1_lpa.nii'];
        end
        handles.pAnat2T1=pAnat2T1;
        
     end
end
guidata(hObject, handles);BtnSetting(hObject, eventdata, handles);
set(handles.Tx_Message,'String',['>> '],'ForegroundColor',[0 0 0]); 


% --- Executes on selection change in PMenu_IRF.
function PMenu_IRF_Callback(hObject, eventdata, handles)
allItems = get(handles.PMenu_IRF,'string');
selectedIndex = get(handles.PMenu_IRF,'Value');
switch get(handles.PMenu_IRF,'Value')
    case 1
        handles.IRF='RRF';
        handles.delayVec=[-8:8];
        set(handles.Ed_tDelay,'String',['[-8:8]'])
    case 2
        handles.IRF='HRF';
        handles.delayVec=[10:15];
        set(handles.Ed_tDelay,'String',['[10:15]'])
end
guidata(hObject, handles);

PlotTDiagram(hObject, eventdata, handles)
BtnSetting(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.
function PMenu_IRF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PMenu_IRF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in Btn_Fusion.
function Btn_Fusion_Callback(hObject, eventdata, handles)
global IDX_fusion ImSetOlayCVR
if (exist(handles.pT1,'file')==2) && (isfield(handles,'MtxfMap')==1) && (isfield(handles,'MtxcvrMap')==1)
IDX_fusion=1;
h = waitbar(0.5,['Fusing CVR map to fMRI map']);%pause(0.01)
ImSetOlayCVR(3)=0.3;
BtnSetting(hObject, eventdata, handles);
BtnOff(hObject, eventdata, handles);
[handles]=DispCase(hObject, eventdata, handles);
DispIm(hObject, eventdata, handles)
waitbar(1,h,['Fusing CVR map to fMRI map']);close(h)
end


% --- Executes on button press in Ck_Despike.
function Ck_Despike_Callback(hObject, eventdata, handles)
% hObject    handle to Ck_Despike (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Ck_Despike
